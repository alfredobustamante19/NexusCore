"""API request and response models."""

from datetime import datetime
from typing import Annotated
from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict, Field, PlainSerializer, field_validator

from app.clock import to_utc_iso
from app.config import headers_limit, payload_limit
from app.cron import normalize_cron
from app.jsonutil import canonicalize_headers, canonicalize_payload

UtcDateTime = Annotated[
    datetime,
    PlainSerializer(to_utc_iso, return_type=str, when_used="json"),
]


class TaskWrite(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    name: str = Field(min_length=1, max_length=200)
    cron_expression: str = Field(min_length=1, max_length=100)
    target_url: str = Field(min_length=1, max_length=2000)
    http_method: str = "POST"
    payload_json: str | None = None
    headers_json: str | None = None
    is_active: bool = True

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        cleaned = " ".join(value.split())
        if not cleaned:
            raise ValueError("Name is required")
        return cleaned

    @field_validator("cron_expression")
    @classmethod
    def clean_cron(cls, value: str) -> str:
        return normalize_cron(value)

    @field_validator("target_url")
    @classmethod
    def clean_url(cls, value: str) -> str:
        return validate_target_url(value)

    @field_validator("http_method")
    @classmethod
    def clean_method(cls, value: str) -> str:
        method = value.strip().upper()
        if method not in {"GET", "POST"}:
            raise ValueError("http_method must be GET or POST")
        return method

    @field_validator("payload_json")
    @classmethod
    def clean_payload(cls, value: str | None) -> str | None:
        return canonicalize_payload(value, limit=payload_limit())

    @field_validator("headers_json")
    @classmethod
    def clean_headers(cls, value: str | None) -> str | None:
        return canonicalize_headers(value, limit=headers_limit())


class TaskUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    name: str | None = Field(default=None, min_length=1, max_length=200)
    cron_expression: str | None = Field(default=None, min_length=1, max_length=100)
    target_url: str | None = Field(default=None, min_length=1, max_length=2000)
    http_method: str | None = None
    payload_json: str | None = None
    headers_json: str | None = None
    is_active: bool | None = None

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = " ".join(value.split())
        if not cleaned:
            raise ValueError("Name is required")
        return cleaned

    @field_validator("cron_expression")
    @classmethod
    def clean_cron(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return normalize_cron(value)

    @field_validator("target_url")
    @classmethod
    def clean_url(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return validate_target_url(value)

    @field_validator("http_method")
    @classmethod
    def clean_method(cls, value: str | None) -> str | None:
        if value is None:
            return None
        method = value.strip().upper()
        if method not in {"GET", "POST"}:
            raise ValueError("http_method must be GET or POST")
        return method

    @field_validator("payload_json")
    @classmethod
    def clean_payload(cls, value: str | None) -> str | None:
        return canonicalize_payload(value, limit=payload_limit())

    @field_validator("headers_json")
    @classmethod
    def clean_headers(cls, value: str | None) -> str | None:
        return canonicalize_headers(value, limit=headers_limit())


class TaskRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    cron_expression: str
    target_url: str
    http_method: str
    payload_json: str | None
    headers_json: str | None
    is_active: bool
    last_run_at: UtcDateTime | None
    next_run_at: UtcDateTime | None
    created_at: UtcDateTime
    last_success: bool | None = None
    last_status_code: int | None = None


class LogRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    task_id: str
    task_name: str | None = None
    status_code: int
    response_body: str
    duration_ms: int
    executed_at: UtcDateTime
    success: bool


class LogPage(BaseModel):
    items: list[LogRead]
    total: int
    page: int
    page_size: int


class CronPreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    cron_expression: str

    @field_validator("cron_expression")
    @classmethod
    def clean_cron(cls, value: str) -> str:
        return normalize_cron(value)


class CronPreviewRead(BaseModel):
    cron_expression: str
    next_run_at: UtcDateTime
    timezone: str


class StatsRead(BaseModel):
    tasks_total: int
    tasks_active: int
    tasks_paused: int
    runs_total: int
    runs_success: int
    runs_failed: int
    scheduler_running: bool
    scheduler_last_tick_at: UtcDateTime | None
    scheduler_last_error: str | None
    timezone: str
    server_time: UtcDateTime
    version: str


class HealthRead(BaseModel):
    status: str
    version: str


def validate_target_url(value: str) -> str:
    candidate = value.strip()
    parsed = urlparse(candidate)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("target_url must be an absolute http or https URL")
    if any(char in candidate for char in "\r\n\t "):
        raise ValueError("target_url cannot contain whitespace")
    return candidate
