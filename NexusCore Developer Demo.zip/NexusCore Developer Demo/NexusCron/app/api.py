"""HTTP API for tasks, manual runs, logs, and dashboard stats."""

import logging
from datetime import datetime

from fastapi import APIRouter, HTTPException, Query, Response
from sqlalchemy import delete
from sqlmodel import func, select

from app import __version__
from app.clock import as_utc, utcnow
from app.config import timezone_name
from app.cron import compute_next_run
from app.database import session_scope
from app.models import ScheduledTask, TaskExecutionLog
from app.scheduler import (
    TaskAlreadyRunningError,
    TaskNotFoundError,
    scheduler_snapshot,
    trigger_task,
)
from app.schemas import (
    CronPreview,
    CronPreviewRead,
    HealthRead,
    LogPage,
    LogRead,
    StatsRead,
    TaskRead,
    TaskUpdate,
    TaskWrite,
)

logger = logging.getLogger("pulse.api")
router = APIRouter(prefix="/api")


@router.get("/health", response_model=HealthRead, tags=["system"])
def health() -> HealthRead:
    return HealthRead(status="ok", version=__version__)


@router.get("/stats", response_model=StatsRead, tags=["system"])
def stats() -> StatsRead:
    with session_scope() as session:
        tasks_total = _count(session, ScheduledTask)
        tasks_active = _count(session, ScheduledTask, ScheduledTask.is_active.is_(True))
        runs_total = _count(session, TaskExecutionLog)
        runs_success = _count(session, TaskExecutionLog, TaskExecutionLog.success.is_(True))
    snapshot = scheduler_snapshot()
    last_tick = snapshot["last_tick_at"]
    return StatsRead(
        tasks_total=tasks_total,
        tasks_active=tasks_active,
        tasks_paused=tasks_total - tasks_active,
        runs_total=runs_total,
        runs_success=runs_success,
        runs_failed=runs_total - runs_success,
        scheduler_running=bool(snapshot["running"]),
        scheduler_last_tick_at=last_tick if isinstance(last_tick, datetime) else None,
        scheduler_last_error=snapshot["last_error"] if isinstance(snapshot["last_error"], str) else None,
        timezone=timezone_name(),
        server_time=utcnow(),
        version=__version__,
    )


@router.post("/cron/preview", response_model=CronPreviewRead, tags=["tasks"])
def preview_cron(body: CronPreview) -> CronPreviewRead:
    return CronPreviewRead(
        cron_expression=body.cron_expression,
        next_run_at=compute_next_run(body.cron_expression),
        timezone=timezone_name(),
    )


@router.get("/tasks", response_model=list[TaskRead], tags=["tasks"])
def list_tasks(
    q: str | None = Query(default=None, max_length=200),
    active: bool | None = None,
) -> list[TaskRead]:
    with session_scope() as session:
        statement = select(ScheduledTask)
        if active is not None:
            statement = statement.where(ScheduledTask.is_active.is_(active))
        if q and q.strip():
            pattern = _like(q.strip())
            statement = statement.where(
                ScheduledTask.name.like(pattern, escape="\\")
                | ScheduledTask.target_url.like(pattern, escape="\\")
                | ScheduledTask.cron_expression.like(pattern, escape="\\")
            )
        statement = statement.order_by(ScheduledTask.is_active.desc(), ScheduledTask.next_run_at)
        tasks = list(session.exec(statement.limit(500)).all())
        latest = _latest_results(session, [task.id for task in tasks])
        return [_serialize_task(task, latest.get(task.id)) for task in tasks]


@router.post("/tasks", response_model=TaskRead, status_code=201, tags=["tasks"])
def create_task(body: TaskWrite, response: Response) -> TaskRead:
    with session_scope() as session:
        task = ScheduledTask(
            name=body.name,
            cron_expression=body.cron_expression,
            target_url=body.target_url,
            http_method=body.http_method,
            payload_json=body.payload_json,
            headers_json=body.headers_json,
            is_active=body.is_active,
            next_run_at=compute_next_run(body.cron_expression),
            created_at=utcnow(),
        )
        session.add(task)
        session.flush()
        response.headers["Location"] = f"/api/tasks/{task.id}"
        logger.info("created task id=%s name=%s", task.id, task.name)
        return _serialize_task(task, None)


@router.get("/tasks/{task_id}", response_model=TaskRead, tags=["tasks"])
def get_task(task_id: str) -> TaskRead:
    with session_scope() as session:
        task = _require_task(session, task_id)
        latest = _latest_results(session, [task.id])
        return _serialize_task(task, latest.get(task.id))


@router.put("/tasks/{task_id}", response_model=TaskRead, tags=["tasks"])
def replace_task(task_id: str, body: TaskWrite) -> TaskRead:
    with session_scope() as session:
        task = _require_task(session, task_id)
        previous_active = task.is_active
        previous_cron = task.cron_expression
        task.name = body.name
        task.cron_expression = body.cron_expression
        task.target_url = body.target_url
        task.http_method = body.http_method
        task.payload_json = body.payload_json
        task.headers_json = body.headers_json
        task.is_active = body.is_active
        _refresh_next_run(
            task,
            previous_active=previous_active,
            cron_changed=body.cron_expression != previous_cron,
        )
        session.flush()
        return _serialize_task(task, _latest_results(session, [task.id]).get(task.id))


@router.patch("/tasks/{task_id}", response_model=TaskRead, tags=["tasks"])
def update_task(task_id: str, body: TaskUpdate) -> TaskRead:
    changes = body.model_dump(exclude_unset=True)
    if not changes:
        raise HTTPException(status_code=422, detail="No fields to update")
    with session_scope() as session:
        task = _require_task(session, task_id)
        previous_active = task.is_active
        previous_cron = task.cron_expression
        for key, value in changes.items():
            setattr(task, key, value)
        _refresh_next_run(
            task,
            previous_active=previous_active,
            cron_changed="cron_expression" in changes and task.cron_expression != previous_cron,
        )
        session.flush()
        return _serialize_task(task, _latest_results(session, [task.id]).get(task.id))


@router.delete("/tasks/{task_id}", status_code=204, tags=["tasks"])
def delete_task(task_id: str) -> Response:
    with session_scope() as session:
        task = _require_task(session, task_id)
        session.execute(delete(TaskExecutionLog).where(TaskExecutionLog.task_id == task.id))
        session.delete(task)
        logger.info("deleted task id=%s name=%s", task.id, task.name)
    return Response(status_code=204)


@router.post("/tasks/{task_id}/trigger", response_model=LogRead, tags=["tasks"])
async def trigger(task_id: str) -> LogRead:
    try:
        return await trigger_task(task_id)
    except TaskNotFoundError:
        raise HTTPException(status_code=404, detail="Task not found") from None
    except TaskAlreadyRunningError:
        raise HTTPException(status_code=409, detail="Task is already running") from None


@router.get("/tasks/{task_id}/logs", response_model=LogPage, tags=["logs"])
def task_logs(
    task_id: str,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
) -> LogPage:
    with session_scope() as session:
        task = _require_task(session, task_id)
        return _log_page(session, page=page, page_size=page_size, task_id=task.id, task_name=task.name)


@router.get("/logs", response_model=LogPage, tags=["logs"])
def recent_logs(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    task_id: str | None = None,
) -> LogPage:
    with session_scope() as session:
        task_name = None
        if task_id is not None:
            task = _require_task(session, task_id)
            task_name = task.name
        return _log_page(session, page=page, page_size=page_size, task_id=task_id, task_name=task_name)


def _require_task(session, task_id: str) -> ScheduledTask:
    task = session.get(ScheduledTask, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


def _refresh_next_run(
    task: ScheduledTask,
    *,
    previous_active: bool,
    cron_changed: bool,
) -> None:
    resumed = task.is_active and not previous_active
    next_run = task.next_run_at
    overdue = next_run is None or as_utc(next_run) <= utcnow()
    if cron_changed or next_run is None or (resumed and overdue) or (not task.is_active and overdue):
        task.next_run_at = compute_next_run(task.cron_expression)


def _serialize_task(task: ScheduledTask, latest: tuple[bool, int] | None) -> TaskRead:
    last_success = None
    last_status = None
    if latest is not None:
        last_success, last_status = latest
    return TaskRead(
        id=task.id,
        name=task.name,
        cron_expression=task.cron_expression,
        target_url=task.target_url,
        http_method=task.http_method,
        payload_json=task.payload_json,
        headers_json=task.headers_json,
        is_active=task.is_active,
        last_run_at=task.last_run_at,
        next_run_at=task.next_run_at,
        created_at=task.created_at,
        last_success=last_success,
        last_status_code=last_status,
    )


def _latest_results(session, task_ids: list[str]) -> dict[str, tuple[bool, int]]:
    if not task_ids:
        return {}
    ranked = (
        select(
            TaskExecutionLog.task_id,
            TaskExecutionLog.success,
            TaskExecutionLog.status_code,
            func.row_number()
            .over(
                partition_by=TaskExecutionLog.task_id,
                order_by=(TaskExecutionLog.executed_at.desc(), TaskExecutionLog.id.desc()),
            )
            .label("rn"),
        )
        .where(TaskExecutionLog.task_id.in_(task_ids))
        .subquery()
    )
    rows = session.execute(
        select(ranked.c.task_id, ranked.c.success, ranked.c.status_code).where(ranked.c.rn == 1)
    ).all()
    return {task_id: (bool(success), int(status_code)) for task_id, success, status_code in rows}


def _log_page(
    session,
    *,
    page: int,
    page_size: int,
    task_id: str | None,
    task_name: str | None,
) -> LogPage:
    filters = []
    if task_id is not None:
        filters.append(TaskExecutionLog.task_id == task_id)
    count_stmt = select(func.count()).select_from(TaskExecutionLog)
    list_stmt = select(TaskExecutionLog, ScheduledTask.name).join(
        ScheduledTask,
        ScheduledTask.id == TaskExecutionLog.task_id,
        isouter=True,
    )
    for clause in filters:
        count_stmt = count_stmt.where(clause)
        list_stmt = list_stmt.where(clause)
    total = int(session.exec(count_stmt).one())
    rows = session.exec(
        list_stmt.order_by(TaskExecutionLog.executed_at.desc(), TaskExecutionLog.id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()
    items = [
        LogRead(
            id=log.id,
            task_id=log.task_id,
            task_name=name if name is not None else task_name,
            status_code=log.status_code,
            response_body=log.response_body,
            duration_ms=log.duration_ms,
            executed_at=log.executed_at,
            success=log.success,
        )
        for log, name in rows
    ]
    return LogPage(items=items, total=total, page=page, page_size=page_size)


def _count(session, model, where=None) -> int:
    statement = select(func.count()).select_from(model)
    if where is not None:
        statement = statement.where(where)
    return int(session.exec(statement).one())


def _like(term: str) -> str:
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"
