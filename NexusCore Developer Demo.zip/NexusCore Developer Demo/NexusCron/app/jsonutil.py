"""JSON field normalization for stored headers and payloads."""

import json

_BLOCKED_HEADERS = {
    "host",
    "content-length",
    "content-type",
    "transfer-encoding",
    "connection",
}


def canonicalize_payload(value: str | None, *, limit: int) -> str | None:
    if value is None:
        return None
    text = value.strip()
    if not text:
        return None
    if len(text) > limit:
        raise ValueError(f"payload_json exceeds {limit} characters")
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError("payload_json must be valid JSON") from exc
    if parsed is None:
        return None
    return json.dumps(parsed, separators=(",", ":"), ensure_ascii=False)


def canonicalize_headers(value: str | None, *, limit: int) -> str | None:
    if value is None:
        return None
    text = value.strip()
    if not text:
        return None
    if len(text) > limit:
        raise ValueError(f"headers_json exceeds {limit} characters")
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError("headers_json must be valid JSON") from exc
    if parsed is None:
        return None
    if not isinstance(parsed, dict):
        raise ValueError("headers_json must be a JSON object")
    clean: dict[str, str] = {}
    for key, item in parsed.items():
        if not isinstance(key, str) or not key.strip():
            raise ValueError("Header names must be non-empty strings")
        name = key.strip()
        if name.lower() in _BLOCKED_HEADERS:
            raise ValueError(f"Header is not allowed: {name}")
        if isinstance(item, bool) or not isinstance(item, (str, int, float)):
            raise ValueError(f"Header '{name}' must be a string or number")
        rendered = item if isinstance(item, str) else str(item)
        if "\r" in name or "\n" in name or "\r" in rendered or "\n" in rendered:
            raise ValueError("Header values cannot contain newlines")
        try:
            name.encode("latin-1")
            rendered.encode("latin-1")
        except UnicodeEncodeError as exc:
            raise ValueError(f"Header '{name}' must be Latin-1 text") from exc
        clean[name] = rendered
    if not clean:
        return None
    return json.dumps(clean, separators=(",", ":"), ensure_ascii=False)
