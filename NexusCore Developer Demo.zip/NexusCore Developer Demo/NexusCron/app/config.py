"""Runtime settings read from the environment on each call."""

import os
from pathlib import Path

from app import __version__

APP_VERSION = __version__
USER_AGENT = f"PulseScheduler/{APP_VERSION}"
PROJECT_ROOT = Path(__file__).resolve().parents[1]


def load_dotenv() -> None:
    """Load KEY=value pairs from a .env file without overriding real environment."""
    candidates = [Path.cwd() / ".env", PROJECT_ROOT / ".env"]
    seen: set[Path] = set()
    for path in candidates:
        resolved = path.resolve()
        if resolved in seen or not path.is_file():
            continue
        seen.add(resolved)
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export ") :].strip()
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
                value = value[1:-1]
            if key:
                os.environ.setdefault(key, value)


def _raw(name: str, default: str) -> str:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    return value.strip()


def database_path() -> Path:
    return Path(_raw("DATABASE_PATH", "data/scheduler.db")).expanduser()


def scheduler_enabled() -> bool:
    return _raw("SCHEDULER_ENABLED", "1").lower() not in {"0", "false", "no", "off"}


def timezone_name() -> str:
    return _raw("SCHEDULER_TIMEZONE", "UTC")


def poll_seconds() -> float:
    return _bounded_float("SCHEDULER_POLL_SECONDS", 1.0, minimum=0.2, maximum=60.0)


def http_timeout_seconds() -> float:
    return _bounded_float("HTTP_TIMEOUT_SECONDS", 30.0, minimum=1.0, maximum=300.0)


def http_max_concurrency() -> int:
    return _bounded_int("HTTP_MAX_CONCURRENCY", 10, minimum=1, maximum=100)


def response_body_limit() -> int:
    return _bounded_int("RESPONSE_BODY_LIMIT", 8192, minimum=256, maximum=1_000_000)


def max_json_chars(name: str, default: int) -> int:
    return _bounded_int(name, default, minimum=1, maximum=2_000_000)


def payload_limit() -> int:
    return max_json_chars("PAYLOAD_JSON_LIMIT", 262_144)


def headers_limit() -> int:
    return max_json_chars("HEADERS_JSON_LIMIT", 8_192)


def shutdown_timeout_seconds() -> float:
    return http_timeout_seconds() + 5.0


def _bounded_float(name: str, default: float, *, minimum: float, maximum: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be a number") from exc
    if not minimum <= value <= maximum:
        raise RuntimeError(f"{name} must be between {minimum} and {maximum}")
    return value


def _bounded_int(name: str, default: int, *, minimum: int, maximum: int) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc
    if not minimum <= value <= maximum:
        raise RuntimeError(f"{name} must be between {minimum} and {maximum}")
    return value
