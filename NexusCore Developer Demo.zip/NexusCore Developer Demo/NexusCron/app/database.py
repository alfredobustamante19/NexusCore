"""SQLite engine, WAL mode, and short-lived sessions."""

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import Engine, event
from sqlalchemy.engine import Connection
from sqlmodel import Session, SQLModel, create_engine

from app.config import database_path

_engine: Engine | None = None


def sqlite_url(path: Path) -> str:
    resolved = path.expanduser().resolve()
    return "sqlite:///" + resolved.as_posix()


@event.listens_for(Engine, "connect")
def _sqlite_pragmas(dbapi_connection: Connection, _connection_record: object) -> None:
    module = dbapi_connection.__class__.__module__.split(".", 1)[0]
    if module != "sqlite3":
        return
    cursor = dbapi_connection.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.fetchall()
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.execute("PRAGMA synchronous=NORMAL")
    finally:
        cursor.close()


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        path = database_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        _engine = create_engine(
            sqlite_url(path),
            connect_args={"check_same_thread": False, "timeout": 30},
            pool_pre_ping=True,
        )
    return _engine


def reset_engine() -> None:
    global _engine
    if _engine is not None:
        _engine.dispose()
        _engine = None


def init_db() -> None:
    SQLModel.metadata.create_all(get_engine())


@contextmanager
def session_scope() -> Iterator[Session]:
    session = Session(get_engine())
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
