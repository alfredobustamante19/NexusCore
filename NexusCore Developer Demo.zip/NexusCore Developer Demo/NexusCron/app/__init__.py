"""Pulse, a self-hosted cron and background task scheduler."""

__version__ = "1.0.0"
