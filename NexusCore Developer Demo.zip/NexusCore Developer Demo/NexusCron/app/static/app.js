const PRESETS = {
  "* * * * *": "Every minute",
  "*/5 * * * *": "Every 5 minutes",
  "*/15 * * * *": "Every 15 minutes",
  "0 * * * *": "Hourly",
  "0 0 * * *": "Daily at 00:00",
  "0 9 * * 1-5": "Weekdays at 09:00",
};

const state = {
  tasks: [],
  logs: [],
  stats: null,
  tasksSig: "",
  logsSig: "",
  query: "",
  filter: "all",
  logsPage: 1,
  logsPageSize: 20,
  logsTotal: 0,
  expandedLogId: null,
  pending: new Set(),
  editingId: null,
  method: "POST",
  refreshing: false,
};

let toastTimer = 0;
let previewTimer = 0;
let previewToken = 0;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function errorMessage(data) {
  if (!data) return "Request failed";
  if (typeof data.detail === "string") return data.detail;
  if (Array.isArray(data.detail)) {
    return data.detail
      .map((item) => String(item.msg || item.message || "Invalid value").replace(/^Value error,\s*/i, ""))
      .join(" ");
  }
  return "Request failed";
}

async function api(path, options = {}) {
  const headers = { Accept: "application/json", ...(options.headers || {}) };
  if (options.body) headers["Content-Type"] = "application/json";
  let response;
  try {
    response = await fetch(path, { ...options, headers });
  } catch {
    throw new Error("Unable to reach the scheduler");
  }
  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { detail: text.slice(0, 300) };
    }
  }
  if (!response.ok) {
    const error = new Error(errorMessage(data));
    error.status = response.status;
    throw error;
  }
  return data;
}

function timezone() {
  return document.documentElement.dataset.timezone || "UTC";
}

function formatAbsolute(iso) {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  try {
    return new Intl.DateTimeFormat(undefined, {
      timeZone: timezone(),
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }).format(date);
  } catch {
    return date.toISOString();
  }
}

function formatRelative(epochMs) {
  const seconds = Math.round((epochMs - Date.now()) / 1000);
  const abs = Math.abs(seconds);
  if (abs < 5) return seconds >= 0 ? "now" : "just now";
  let value = abs;
  let unit = "s";
  if (abs >= 86400) {
    value = Math.round(abs / 86400);
    unit = "d";
  } else if (abs >= 3600) {
    value = Math.round(abs / 3600);
    unit = "h";
  } else if (abs >= 60) {
    value = Math.round(abs / 60);
    unit = "m";
  }
  return seconds >= 0 ? `in ${value}${unit}` : `${value}${unit} ago`;
}

function formatDuration(ms) {
  if (ms == null) return "—";
  if (ms < 1000) return `${ms} ms`;
  return `${(ms / 1000).toFixed(1)} s`;
}

function formatClock() {
  try {
    return new Intl.DateTimeFormat(undefined, {
      timeZone: timezone(),
      weekday: "short",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
      timeZoneName: "short",
    }).format(new Date());
  } catch {
    return new Date().toISOString();
  }
}

function formatPercent(success, total) {
  if (!total) return "—";
  const value = (100 * success) / total;
  if (value === 0 || value === 100) return `${value.toFixed(0)}%`;
  return `${value.toFixed(1)}%`;
}

function timeStack(iso) {
  const wrap = el("div");
  if (!iso) {
    wrap.textContent = "—";
    wrap.className = "text-zinc-500";
    return wrap;
  }
  const date = new Date(iso);
  const relative = el("div", "text-zinc-100");
  relative.dataset.epoch = String(date.getTime());
  relative.textContent = formatRelative(date.getTime());
  wrap.append(relative, el("div", "mt-0.5 text-xs text-zinc-500", formatAbsolute(iso)));
  return wrap;
}

function pretty(raw) {
  if (!raw) return "";
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}

function showBanner(message) {
  const banner = document.getElementById("banner");
  banner.textContent = message;
  banner.classList.remove("hidden");
}

function hideBanner() {
  document.getElementById("banner").classList.add("hidden");
}

function toast(message, tone) {
  const node = document.getElementById("toast");
  node.textContent = message;
  node.dataset.tone = tone || "ok";
  node.classList.remove("hidden");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => node.classList.add("hidden"), 3200);
}

function renderStats() {
  const stats = state.stats;
  if (!stats) return;
  document.getElementById("stat-active").textContent = String(stats.tasks_active);
  document.getElementById("stat-paused").textContent = String(stats.tasks_paused);
  document.getElementById("stat-runs").textContent = String(stats.runs_total);
  document.getElementById("stat-success").textContent = formatPercent(stats.runs_success, stats.runs_total);
  document.getElementById("stat-success-detail").textContent = stats.runs_total
    ? `${stats.runs_failed} failed`
    : "No runs yet";
  const status = document.getElementById("scheduler-state");
  if (!stats.scheduler_running) {
    status.textContent = "Scheduler stopped";
    status.dataset.tone = "warn";
    status.title = "";
  } else if (stats.scheduler_last_error) {
    status.textContent = "Scheduler degraded";
    status.dataset.tone = "bad";
    status.title = stats.scheduler_last_error;
  } else {
    status.textContent = "Scheduler running";
    status.dataset.tone = "ok";
    status.title = "";
  }
}

function visibleTasks() {
  const query = state.query.trim().toLowerCase();
  return state.tasks.filter((task) => {
    if (state.filter === "active" && !task.is_active) return false;
    if (state.filter === "paused" && task.is_active) return false;
    if (!query) return true;
    return [task.name, task.target_url, task.cron_expression, task.http_method]
      .join(" ")
      .toLowerCase()
      .includes(query);
  });
}

function renderFilters() {
  const counts = { all: state.tasks.length, active: 0, paused: 0 };
  state.tasks.forEach((task) => {
    if (task.is_active) counts.active += 1;
    else counts.paused += 1;
  });
  document.getElementById("filter-all").textContent = `All ${counts.all}`;
  document.getElementById("filter-active").textContent = `Active ${counts.active}`;
  document.getElementById("filter-paused").textContent = `Paused ${counts.paused}`;
  document.querySelectorAll("[data-filter]").forEach((button) => {
    button.setAttribute("aria-pressed", String(button.dataset.filter === state.filter));
  });
}

function actionButton(label, action, id, danger) {
  const button = el("button", "row-btn", label);
  button.type = "button";
  button.dataset.action = action;
  button.dataset.id = id;
  if (danger) button.dataset.danger = "true";
  if (action === "run" && state.pending.has(id)) {
    button.disabled = true;
    button.textContent = "Running";
  }
  return button;
}

function renderTasks() {
  renderFilters();
  const tasks = visibleTasks();
  const empty = document.getElementById("tasks-empty");
  const table = document.getElementById("tasks-table-wrap");
  const body = document.getElementById("tasks-body");
  if (tasks.length === 0) {
    empty.classList.remove("hidden");
    table.classList.add("hidden");
    const noneAtAll = state.tasks.length === 0;
    document.getElementById("tasks-empty-title").textContent = noneAtAll ? "No tasks yet" : "No matching tasks";
    document.getElementById("tasks-empty-copy").textContent = noneAtAll
      ? "Create a task to call an HTTP endpoint on a cron schedule."
      : "Try a different search or filter.";
    document.getElementById("empty-create").classList.toggle("hidden", !noneAtAll);
    body.replaceChildren();
    return;
  }
  empty.classList.add("hidden");
  table.classList.remove("hidden");
  const rows = tasks.map((task) => {
    const row = document.createElement("tr");
    row.className = "border-t border-white/5 align-top";
    const name = el("td", "px-4 py-3");
    const title = el("div", "font-medium text-zinc-100", task.name);
    const result = el("div", "mt-1 text-xs");
    if (task.last_status_code == null) {
      result.textContent = "No runs";
      result.dataset.tone = "muted";
    } else if (task.last_success) {
      result.textContent = `Last ${task.last_status_code}`;
      result.dataset.tone = "ok";
    } else {
      result.textContent = task.last_status_code === 0 ? "Last error" : `Last ${task.last_status_code}`;
      result.dataset.tone = "bad";
    }
    name.append(title, result);

    const schedule = el("td", "px-4 py-3");
    schedule.append(
      el("div", "font-mono text-xs text-cyan-200", task.cron_expression),
      el("div", "mt-1 text-xs text-zinc-500", PRESETS[task.cron_expression] || "Custom"),
    );

    const target = el("td", "max-w-[16rem] px-4 py-3");
    const url = el("div", "truncate font-mono text-xs text-zinc-300", task.target_url);
    url.title = task.target_url;
    target.append(el("div", "text-xs uppercase tracking-wide text-zinc-500", task.http_method), url);

    const next = el("td", "px-4 py-3");
    next.append(timeStack(task.next_run_at));
    const last = el("td", "px-4 py-3");
    last.append(timeStack(task.last_run_at));

    const status = el("td", "px-4 py-3");
    const badge = el("span", "badge", task.is_active ? "Active" : "Paused");
    badge.dataset.tone = task.is_active ? "ok" : "muted";
    status.append(badge);

    const actions = el("td", "px-4 py-3");
    const group = el("div", "flex flex-wrap justify-end gap-1");
    group.append(
      actionButton("Run", "run", task.id, false),
      actionButton(task.is_active ? "Pause" : "Resume", "toggle", task.id, false),
      actionButton("Edit", "edit", task.id, false),
      actionButton("Delete", "delete", task.id, true),
    );
    actions.append(group);
    row.append(name, schedule, target, next, last, status, actions);
    return row;
  });
  body.replaceChildren(...rows);
}

function snippet(body) {
  const line = (body || "Empty response").split("\n")[0];
  return line.length > 80 ? `${line.slice(0, 80)}...` : line;
}

function renderLogs() {
  const empty = document.getElementById("logs-empty");
  const table = document.getElementById("logs-table-wrap");
  const body = document.getElementById("logs-body");
  if (state.logs.length === 0) {
    empty.classList.remove("hidden");
    table.classList.add("hidden");
    body.replaceChildren();
    renderLogPager();
    return;
  }
  empty.classList.add("hidden");
  table.classList.remove("hidden");
  const rows = [];
  state.logs.forEach((log) => {
    const row = document.createElement("tr");
    row.className = "cursor-pointer border-t border-white/5 align-top hover:bg-white/[0.03]";
    row.dataset.logId = log.id;
    const when = el("td", "px-4 py-3");
    when.append(timeStack(log.executed_at));
    const task = el("td", "px-4 py-3");
    task.append(el("div", "font-medium text-zinc-100", log.task_name || "Deleted task"));
    const result = el("td", "px-4 py-3");
    const badge = el("span", "badge", log.status_code === 0 ? "ERR" : String(log.status_code));
    badge.dataset.tone = log.success ? "ok" : "bad";
    result.append(badge);
    rows.push(row);
    row.append(
      when,
      task,
      result,
      el("td", "px-4 py-3 tabular-nums text-zinc-300", formatDuration(log.duration_ms)),
      el("td", "max-w-xs truncate px-4 py-3 font-mono text-xs text-zinc-400", snippet(log.response_body)),
    );
    if (state.expandedLogId === log.id) {
      const detail = document.createElement("tr");
      const cell = el("td", "bg-black/40 px-4 py-3");
      cell.colSpan = 5;
      const pre = el(
        "pre",
        "max-h-64 overflow-auto whitespace-pre-wrap break-words font-mono text-xs text-zinc-300",
        log.response_body || "Empty response",
      );
      cell.append(pre);
      detail.append(cell);
      rows.push(detail);
    }
  });
  body.replaceChildren(...rows);
  renderLogPager();
}

function renderLogPager() {
  const total = state.logsTotal;
  const size = state.logsPageSize;
  const page = state.logsPage;
  const pages = Math.max(1, Math.ceil(total / size) || 1);
  const start = total === 0 ? 0 : (page - 1) * size + 1;
  const end = Math.min(page * size, total);
  document.getElementById("logs-label").textContent = total === 0 ? "No executions" : `${start}–${end} of ${total}`;
  document.getElementById("logs-prev").disabled = page <= 1;
  document.getElementById("logs-next").disabled = page >= pages;
}

async function refresh() {
  if (state.refreshing) return;
  state.refreshing = true;
  try {
    const [tasks, logs, stats] = await Promise.all([
      api("/api/tasks"),
      api(`/api/logs?page=${state.logsPage}&page_size=${state.logsPageSize}`),
      api("/api/stats"),
    ]);
    hideBanner();
    state.stats = stats;
    if (stats.timezone) document.documentElement.dataset.timezone = stats.timezone;
    renderStats();
    const tasksSig = JSON.stringify(tasks);
    if (tasksSig !== state.tasksSig) {
      state.tasks = tasks;
      state.tasksSig = tasksSig;
      renderTasks();
    }
    const logsSig = JSON.stringify(logs);
    if (logsSig !== state.logsSig) {
      state.logs = logs.items;
      state.logsTotal = logs.total;
      state.logsSig = logsSig;
      if (state.logs.length === 0 && state.logsPage > 1 && state.logsTotal > 0) {
        state.logsPage -= 1;
        state.logsSig = "";
        state.refreshing = false;
        await refresh();
        return;
      }
      renderLogs();
    } else {
      renderLogPager();
    }
  } catch (error) {
    showBanner(error.message || "Unable to reach the scheduler");
  } finally {
    state.refreshing = false;
  }
}

function tick() {
  const clock = document.getElementById("clock");
  if (clock) clock.textContent = formatClock();
  document.querySelectorAll("[data-epoch]").forEach((node) => {
    const epoch = Number(node.dataset.epoch);
    if (!Number.isNaN(epoch)) node.textContent = formatRelative(epoch);
  });
}

function clearFormError() {
  const node = document.getElementById("form-error");
  node.textContent = "";
  node.classList.add("hidden");
  document.getElementById("cron-error").textContent = "";
}

function showFormError(message) {
  const node = document.getElementById("form-error");
  node.textContent = message;
  node.classList.remove("hidden");
}

function setMethod(method) {
  state.method = method;
  document.getElementById("method-get").setAttribute("aria-pressed", String(method === "GET"));
  document.getElementById("method-post").setAttribute("aria-pressed", String(method === "POST"));
  document.getElementById("payload-note").classList.toggle("hidden", method !== "GET");
}

function schedulePreview() {
  window.clearTimeout(previewTimer);
  previewTimer = window.setTimeout(updatePreview, 250);
}

async function updatePreview() {
  const token = ++previewToken;
  const expression = document.getElementById("field-cron").value.trim();
  const next = document.getElementById("cron-next");
  const error = document.getElementById("cron-error");
  if (!expression) {
    next.textContent = "";
    error.textContent = "";
    return;
  }
  try {
    const data = await api("/api/cron/preview", {
      method: "POST",
      body: JSON.stringify({ cron_expression: expression }),
    });
    if (token !== previewToken) return;
    error.textContent = "";
    const when = new Date(data.next_run_at);
    next.textContent = `Next run ${formatAbsolute(data.next_run_at)} (${formatRelative(when.getTime())})`;
  } catch (err) {
    if (token !== previewToken) return;
    next.textContent = "";
    error.textContent = err.message;
  }
}

function openCreate() {
  state.editingId = null;
  document.getElementById("dialog-title").textContent = "New task";
  document.getElementById("save-task").textContent = "Create task";
  document.getElementById("task-form").reset();
  document.getElementById("field-cron").value = "*/5 * * * *";
  document.getElementById("field-enabled").checked = true;
  setMethod("POST");
  clearFormError();
  updatePreview();
  const dialog = document.getElementById("task-dialog");
  if (!dialog.open) dialog.showModal();
  document.getElementById("field-name").focus();
}

function openEdit(id) {
  const task = state.tasks.find((item) => item.id === id);
  if (!task) return;
  state.editingId = id;
  document.getElementById("dialog-title").textContent = "Edit task";
  document.getElementById("save-task").textContent = "Save changes";
  document.getElementById("field-name").value = task.name;
  document.getElementById("field-cron").value = task.cron_expression;
  document.getElementById("field-url").value = task.target_url;
  document.getElementById("field-headers").value = pretty(task.headers_json);
  document.getElementById("field-payload").value = pretty(task.payload_json);
  document.getElementById("field-enabled").checked = task.is_active;
  setMethod(task.http_method === "GET" ? "GET" : "POST");
  clearFormError();
  updatePreview();
  const dialog = document.getElementById("task-dialog");
  if (!dialog.open) dialog.showModal();
  document.getElementById("field-name").focus();
}

function emptyToNull(value) {
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function validateOptionalJson(value, label, objectOnly) {
  if (!value) return;
  let parsed;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new Error(`${label} must be valid JSON`);
  }
  if (parsed == null) return;
  if (objectOnly && (typeof parsed !== "object" || Array.isArray(parsed))) {
    throw new Error(`${label} must be a JSON object`);
  }
}

async function saveTask(event) {
  event.preventDefault();
  clearFormError();
  const save = document.getElementById("save-task");
  save.disabled = true;
  const editingId = state.editingId;
  try {
    const payload = {
      name: document.getElementById("field-name").value.trim(),
      cron_expression: document.getElementById("field-cron").value.trim(),
      target_url: document.getElementById("field-url").value.trim(),
      http_method: state.method,
      headers_json: emptyToNull(document.getElementById("field-headers").value),
      payload_json: emptyToNull(document.getElementById("field-payload").value),
      is_active: document.getElementById("field-enabled").checked,
    };
    if (!payload.name || !payload.cron_expression || !payload.target_url) {
      throw new Error("Name, cron expression, and target URL are required");
    }
    validateOptionalJson(payload.headers_json, "Headers", true);
    validateOptionalJson(payload.payload_json, "Payload", false);
    const path = editingId ? `/api/tasks/${editingId}` : "/api/tasks";
    const method = editingId ? "PUT" : "POST";
    await api(path, { method, body: JSON.stringify(payload) });
    document.getElementById("task-dialog").close();
    toast(editingId ? "Task saved" : "Task created", "ok");
    state.tasksSig = "";
    await refresh();
  } catch (error) {
    showFormError(error.message);
  } finally {
    save.disabled = false;
  }
}

async function runTask(id) {
  const task = state.tasks.find((item) => item.id === id);
  state.pending.add(id);
  renderTasks();
  try {
    const log = await api(`/api/tasks/${id}/trigger`, { method: "POST" });
    const label = log.status_code === 0 ? "ERR" : String(log.status_code);
    toast(`${task ? task.name : "Task"} · ${label} · ${formatDuration(log.duration_ms)}`, log.success ? "ok" : "bad");
    state.logsPage = 1;
    state.logsSig = "";
  } catch (error) {
    toast(error.message, "bad");
  } finally {
    state.pending.delete(id);
    state.tasksSig = "";
    await refresh();
  }
}

async function toggleTask(id) {
  const task = state.tasks.find((item) => item.id === id);
  if (!task) return;
  try {
    await api(`/api/tasks/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ is_active: !task.is_active }),
    });
    toast(task.is_active ? "Task paused" : "Task resumed", "ok");
    state.tasksSig = "";
    await refresh();
  } catch (error) {
    toast(error.message, "bad");
  }
}

function confirmAction({ title, body, confirmLabel }) {
  const dialog = document.getElementById("confirm-dialog");
  document.getElementById("confirm-title").textContent = title;
  document.getElementById("confirm-body").textContent = body;
  document.getElementById("confirm-ok").textContent = confirmLabel;
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      dialog.removeEventListener("close", onClose);
      if (dialog.open) dialog.close();
      resolve(value);
    };
    const onClose = () => finish(false);
    document.getElementById("confirm-ok").onclick = () => finish(true);
    document.getElementById("confirm-cancel").onclick = () => finish(false);
    dialog.addEventListener("close", onClose);
    if (!dialog.open) dialog.showModal();
  });
}

async function deleteTask(id) {
  const task = state.tasks.find((item) => item.id === id);
  const confirmed = await confirmAction({
    title: "Delete task",
    body: `Delete “${task ? task.name : "this task"}” and its execution history?`,
    confirmLabel: "Delete",
  });
  if (!confirmed) return;
  try {
    await api(`/api/tasks/${id}`, { method: "DELETE" });
    toast("Task deleted", "ok");
    state.tasksSig = "";
    state.logsSig = "";
    await refresh();
  } catch (error) {
    toast(error.message, "bad");
  }
}

function onTaskClick(event) {
  const button = event.target.closest("button[data-action]");
  if (!button || button.disabled) return;
  const { action, id } = button.dataset;
  if (action === "run") runTask(id);
  else if (action === "toggle") toggleTask(id);
  else if (action === "edit") openEdit(id);
  else if (action === "delete") deleteTask(id);
}

function onLogClick(event) {
  const row = event.target.closest("tr[data-log-id]");
  if (!row) return;
  state.expandedLogId = state.expandedLogId === row.dataset.logId ? null : row.dataset.logId;
  renderLogs();
}

async function changeLogPage(delta) {
  state.logsPage = Math.max(1, state.logsPage + delta);
  state.logsSig = "";
  state.expandedLogId = null;
  await refresh();
}

function closeTaskDialog() {
  const dialog = document.getElementById("task-dialog");
  if (dialog.open) dialog.close();
}

function init() {
  document.getElementById("new-task").addEventListener("click", openCreate);
  document.getElementById("empty-create").addEventListener("click", openCreate);
  document.getElementById("refresh-button").addEventListener("click", () => {
    state.tasksSig = "";
    state.logsSig = "";
    refresh();
  });
  document.getElementById("task-form").addEventListener("submit", saveTask);
  document.getElementById("cancel-task").addEventListener("click", closeTaskDialog);
  document.getElementById("cancel-task-secondary").addEventListener("click", closeTaskDialog);
  document.getElementById("field-cron").addEventListener("input", schedulePreview);
  document.querySelectorAll("[data-preset]").forEach((button) => {
    button.addEventListener("click", () => {
      document.getElementById("field-cron").value = button.dataset.preset;
      updatePreview();
    });
  });
  document.getElementById("method-get").addEventListener("click", () => setMethod("GET"));
  document.getElementById("method-post").addEventListener("click", () => setMethod("POST"));
  document.getElementById("search").addEventListener("input", (event) => {
    state.query = event.target.value;
    renderTasks();
  });
  document.querySelectorAll("[data-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      state.filter = button.dataset.filter;
      renderTasks();
    });
  });
  document.getElementById("tasks-body").addEventListener("click", onTaskClick);
  document.getElementById("logs-body").addEventListener("click", onLogClick);
  document.getElementById("logs-prev").addEventListener("click", () => changeLogPage(-1));
  document.getElementById("logs-next").addEventListener("click", () => changeLogPage(1));
  document.getElementById("task-dialog").addEventListener("click", (event) => {
    if (event.target.id === "task-dialog") closeTaskDialog();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") refresh();
  });
  window.setInterval(tick, 1000);
  window.setInterval(refresh, 4000);
  tick();
  refresh();
}

init();
