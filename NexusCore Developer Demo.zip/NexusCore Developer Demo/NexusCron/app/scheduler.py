"""Background cron loop and outbound HTTP execution.

Each due occurrence is claimed by moving next_run_at forward before the request
is sent. A restart therefore runs a missed slot once, then waits for the next
future match, and a crash mid-request does not fire that same slot again.
"""

import asyncio
import json
import logging
import time
from dataclasses import dataclass
from datetime import datetime

import httpx
from sqlmodel import select

from app.clock import as_utc, utcnow
from app.config import (
    USER_AGENT,
    http_max_concurrency,
    http_timeout_seconds,
    poll_seconds,
    response_body_limit,
)
from app.cron import compute_next_run, repair_delay
from app.database import session_scope
from app.models import ScheduledTask, TaskExecutionLog, new_id
from app.schemas import LogRead

logger = logging.getLogger("pulse.scheduler")

_inflight: set[str] = set()
_lock: asyncio.Lock | None = None
_semaphore: asyncio.Semaphore | None = None
_client: httpx.AsyncClient | None = None
_status: dict[str, object] = {
    "running": False,
    "last_tick_at": None,
    "last_error": None,
}


class TaskNotFoundError(Exception):
    def __init__(self, task_id: str) -> None:
        self.task_id = task_id
        super().__init__(task_id)


class TaskAlreadyRunningError(Exception):
    def __init__(self, task_id: str) -> None:
        self.task_id = task_id
        super().__init__(task_id)


@dataclass(frozen=True)
class TaskSnapshot:
    id: str
    name: str
    target_url: str
    http_method: str
    payload_json: str | None
    headers_json: str | None

    @classmethod
    def from_task(cls, task: ScheduledTask) -> "TaskSnapshot":
        return cls(
            id=task.id,
            name=task.name,
            target_url=task.target_url,
            http_method=task.http_method,
            payload_json=task.payload_json,
            headers_json=task.headers_json,
        )


def reset_runtime_state() -> None:
    global _lock, _semaphore, _client
    _inflight.clear()
    _lock = None
    _semaphore = None
    _client = None
    _status["running"] = False
    _status["last_tick_at"] = None
    _status["last_error"] = None


def scheduler_snapshot() -> dict[str, object]:
    return {
        "running": bool(_status["running"]),
        "last_tick_at": _status["last_tick_at"],
        "last_error": _status["last_error"],
    }


def _get_lock() -> asyncio.Lock:
    global _lock
    if _lock is None:
        _lock = asyncio.Lock()
    return _lock


def _get_semaphore() -> asyncio.Semaphore:
    global _semaphore
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(http_max_concurrency())
    return _semaphore


def build_client() -> httpx.AsyncClient:
    timeout = http_timeout_seconds()
    return httpx.AsyncClient(
        timeout=httpx.Timeout(timeout, connect=min(10.0, timeout)),
        follow_redirects=True,
        max_redirects=5,
        limits=httpx.Limits(
            max_connections=max(20, http_max_concurrency()),
            max_keepalive_connections=10,
        ),
    )


def open_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = build_client()
    return _client


async def close_client() -> None:
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


def claim_due_snapshots(now: datetime, busy: frozenset[str]) -> list[TaskSnapshot]:
    """Advance next_run_at for every due active task and return claimed copies.

    `busy` is a snapshot of in-flight ids taken on the event loop. Those tasks
    are left alone so a running call is not claimed or rescheduled again.
    """
    snapshots: list[TaskSnapshot] = []
    limit = max(http_max_concurrency() * 2, 1)
    with session_scope() as session:
        repair = session.exec(
            select(ScheduledTask).where(
                ScheduledTask.next_run_at.is_(None)
                | (
                    ScheduledTask.is_active.is_(False)
                    & ScheduledTask.next_run_at.is_not(None)
                    & (ScheduledTask.next_run_at <= now)
                )
            )
        ).all()
        for task in repair:
            if task.id in busy:
                continue
            task.next_run_at = _safe_next_run(task, now)

        due = session.exec(
            select(ScheduledTask)
            .where(ScheduledTask.is_active.is_(True))
            .where(ScheduledTask.next_run_at.is_not(None))
            .where(ScheduledTask.next_run_at <= now)
            .order_by(ScheduledTask.next_run_at)
            .limit(limit)
        ).all()
        for task in due:
            if task.id in busy:
                continue
            snapshots.append(TaskSnapshot.from_task(task))
            task.next_run_at = _safe_next_run(task, now)
    return snapshots


def _safe_next_run(task: ScheduledTask, now: datetime) -> datetime:
    try:
        return compute_next_run(task.cron_expression, as_utc(now))
    except (ValueError, RuntimeError):
        logger.exception("invalid cron on task id=%s name=%s", task.id, task.name)
        return repair_delay(now)


async def dispatch_due_tasks() -> list[str]:
    now = utcnow()
    async with _get_lock():
        busy = frozenset(_inflight)
        snapshots = await asyncio.to_thread(claim_due_snapshots, now, busy)
        for snapshot in snapshots:
            _inflight.add(snapshot.id)
    if not snapshots:
        return []

    async def finish(snapshot: TaskSnapshot) -> None:
        try:
            async with _get_semaphore():
                await record_execution(snapshot, touch_last_run=True, trigger="schedule")
        except Exception:
            logger.exception("scheduled run failed task=%s", snapshot.id)
        finally:
            _inflight.discard(snapshot.id)

    await asyncio.gather(*(finish(snapshot) for snapshot in snapshots))
    return [snapshot.id for snapshot in snapshots]


async def trigger_task(task_id: str) -> LogRead:
    async with _get_lock():
        if task_id in _inflight:
            raise TaskAlreadyRunningError(task_id)
        snapshot = await asyncio.to_thread(_load_for_trigger, task_id)
        _inflight.add(snapshot.id)
    try:
        async with _get_semaphore():
            return await record_execution(snapshot, touch_last_run=True, trigger="manual")
    finally:
        _inflight.discard(snapshot.id)


def _load_for_trigger(task_id: str) -> TaskSnapshot:
    with session_scope() as session:
        task = session.get(ScheduledTask, task_id)
        if task is None:
            raise TaskNotFoundError(task_id)
        return TaskSnapshot.from_task(task)


async def record_execution(
    snapshot: TaskSnapshot,
    *,
    touch_last_run: bool,
    trigger: str,
) -> LogRead:
    execution_id = new_id()
    started = time.perf_counter()
    status_code = 0
    success = False
    body = ""
    logger.info(
        "run start trigger=%s task=%s id=%s %s %s",
        trigger,
        snapshot.name,
        snapshot.id,
        snapshot.http_method,
        snapshot.target_url,
    )
    try:
        status_code, body = await perform_request(
            snapshot,
            trigger=trigger,
            execution_id=execution_id,
        )
        success = 200 <= status_code < 300
    except httpx.TimeoutException:
        body = "Request timed out"
    except httpx.RequestError as exc:
        body = f"Request failed: {exc.__class__.__name__}: {exc}"
    except ValueError as exc:
        body = str(exc)
    except Exception as exc:
        logger.exception("task execution error id=%s", snapshot.id)
        body = f"Unexpected error: {exc.__class__.__name__}: {exc}"

    duration_ms = max(0, int(round((time.perf_counter() - started) * 1000)))
    executed_at = utcnow()
    limit = response_body_limit()
    if len(body) > limit:
        body = body[:limit] + "...[truncated]"

    def persist() -> LogRead:
        with session_scope() as session:
            log = TaskExecutionLog(
                id=execution_id,
                task_id=snapshot.id,
                status_code=status_code,
                response_body=body,
                duration_ms=duration_ms,
                executed_at=executed_at,
                success=success,
            )
            session.add(log)
            if touch_last_run:
                task = session.get(ScheduledTask, snapshot.id)
                if task is not None:
                    task.last_run_at = executed_at
            return LogRead(
                id=log.id,
                task_id=log.task_id,
                task_name=snapshot.name,
                status_code=log.status_code,
                response_body=log.response_body,
                duration_ms=log.duration_ms,
                executed_at=log.executed_at,
                success=log.success,
            )

    try:
        result = await asyncio.to_thread(persist)
    except Exception:
        logger.exception("failed to persist execution id=%s task=%s", execution_id, snapshot.id)
        raise
    logger.info(
        "run complete trigger=%s task=%s id=%s status=%s success=%s duration_ms=%s",
        trigger,
        snapshot.name,
        snapshot.id,
        status_code,
        success,
        duration_ms,
    )
    return result


async def perform_request(
    snapshot: TaskSnapshot,
    *,
    trigger: str,
    execution_id: str,
    client: httpx.AsyncClient | None = None,
) -> tuple[int, str]:
    headers = {
        "Accept": "*/*",
        "User-Agent": USER_AGENT,
    }
    if snapshot.headers_json:
        try:
            stored = json.loads(snapshot.headers_json)
        except json.JSONDecodeError as exc:
            raise ValueError("Stored headers_json is not valid JSON") from exc
        if isinstance(stored, dict):
            headers.update({str(key): str(value) for key, value in stored.items()})
    try:
        snapshot.name.encode("latin-1")
    except UnicodeEncodeError:
        pass
    else:
        headers["X-Pulse-Task-Name"] = snapshot.name
    headers["X-Pulse-Task-Id"] = snapshot.id
    headers["X-Pulse-Execution-Id"] = execution_id
    headers["X-Pulse-Trigger"] = trigger

    request_kwargs: dict[str, object] = {"headers": headers}
    if snapshot.http_method != "GET" and snapshot.payload_json:
        try:
            request_kwargs["json"] = json.loads(snapshot.payload_json)
        except json.JSONDecodeError as exc:
            raise ValueError("Stored payload_json is not valid JSON") from exc

    http = client or open_client()
    limit = response_body_limit()
    async with http.stream(snapshot.http_method, snapshot.target_url, **request_kwargs) as response:
        chunks: list[bytes] = []
        size = 0
        async for chunk in response.aiter_bytes():
            if not chunk:
                continue
            chunks.append(chunk)
            size += len(chunk)
            if size >= limit:
                break
        raw = b"".join(chunks)[:limit]
        text = raw.decode("utf-8", errors="replace")
        if size > limit:
            text += "...[truncated]"
        return response.status_code, text


async def scheduler_loop(stop: asyncio.Event) -> None:
    """Poll for due tasks until `stop` is set. Run one worker per database."""
    _status["running"] = True
    logger.info("scheduler started poll=%ss", poll_seconds())
    try:
        while not stop.is_set():
            try:
                started = await dispatch_due_tasks()
                _status["last_tick_at"] = utcnow()
                _status["last_error"] = None
                if started:
                    logger.info("dispatched %s task(s)", len(started))
            except Exception as exc:
                logger.exception("scheduler tick failed")
                _status["last_tick_at"] = utcnow()
                _status["last_error"] = str(exc)[:300]
            try:
                await asyncio.wait_for(stop.wait(), timeout=poll_seconds())
            except TimeoutError:
                continue
    finally:
        _status["running"] = False
        logger.info("scheduler stopped")
