"""SQLModel tables. All datetimes are timezone-aware UTC."""

from datetime import datetime
from typing import Optional
from uuid import uuid4

from sqlalchemy import Index
from sqlmodel import Field, SQLModel

from app.clock import utcnow


def new_id() -> str:
    return str(uuid4())


class ScheduledTask(SQLModel, table=True):
    __tablename__ = "scheduled_task"
    __table_args__ = (
        Index("ix_scheduled_task_due", "is_active", "next_run_at"),
    )

    id: str = Field(default_factory=new_id, primary_key=True)
    name: str = Field(index=True, max_length=200)
    cron_expression: str = Field(max_length=100)
    target_url: str = Field(max_length=2000)
    http_method: str = Field(max_length=8)
    payload_json: Optional[str] = Field(default=None)
    headers_json: Optional[str] = Field(default=None)
    is_active: bool = Field(default=True)
    last_run_at: Optional[datetime] = Field(default=None)
    next_run_at: Optional[datetime] = Field(default=None)
    created_at: datetime = Field(default_factory=utcnow, nullable=False)


class TaskExecutionLog(SQLModel, table=True):
    __tablename__ = "task_execution_log"
    __table_args__ = (
        Index("ix_task_execution_log_task_executed", "task_id", "executed_at"),
    )

    id: str = Field(default_factory=new_id, primary_key=True)
    task_id: str = Field(foreign_key="scheduled_task.id", index=True)
    status_code: int
    response_body: str = Field(default="")
    duration_ms: int
    executed_at: datetime = Field(default_factory=utcnow, index=True)
    success: bool = Field(default=False)
