"""UTC timestamps. SQLModel stores these as timezone-aware UTC values."""

from datetime import datetime, timezone


def utcnow() -> datetime:
    """Current UTC time, truncated to seconds."""
    return datetime.now(timezone.utc).replace(microsecond=0)


def as_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        aware = value.replace(tzinfo=timezone.utc)
    else:
        aware = value.astimezone(timezone.utc)
    return aware.replace(microsecond=0)


def to_utc_iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    aware = as_utc(value)
    return aware.isoformat().replace("+00:00", "Z")
