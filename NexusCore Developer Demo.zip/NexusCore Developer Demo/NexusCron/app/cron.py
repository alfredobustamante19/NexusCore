"""Five-field cron parsing. Expressions are evaluated in SCHEDULER_TIMEZONE."""

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from croniter import croniter
from croniter.croniter import CroniterBadCronError, CroniterBadDateError, CroniterNotAlphaError

from app.clock import as_utc, utcnow
from app.config import timezone_name

_CRON_ERRORS = (CroniterBadCronError, CroniterBadDateError, CroniterNotAlphaError, KeyError)


def get_timezone() -> ZoneInfo:
    name = timezone_name()
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as exc:
        raise RuntimeError(f"Unknown SCHEDULER_TIMEZONE '{name}'") from exc


def normalize_cron(expression: str) -> str:
    if not isinstance(expression, str):
        raise ValueError("Cron expression is required")
    compact = " ".join(expression.strip().split())
    if not compact:
        raise ValueError("Cron expression is required")
    fields = compact.split(" ")
    if len(fields) != 5:
        raise ValueError("Cron expression must have 5 fields: minute hour day month weekday")
    probe = datetime(2026, 1, 1, 0, 0, 0)
    try:
        croniter(compact, probe).get_next(datetime)
    except _CRON_ERRORS as exc:
        raise ValueError(f"Invalid cron expression: {compact}") from exc
    return compact


def compute_next_run(expression: str, after: datetime | None = None) -> datetime:
    """Next fire time strictly after `after`, returned as timezone-aware UTC.

    The cron fields are matched against the wall clock in SCHEDULER_TIMEZONE.
    """
    normalized = normalize_cron(expression)
    tz = get_timezone()
    anchor = utcnow() if after is None else as_utc(after)
    local_anchor = anchor.astimezone(tz).replace(tzinfo=None)
    iterator = croniter(normalized, local_anchor)
    # A year of minute slots is enough to walk past a DST fold and still fail closed.
    for _ in range(366 * 24 * 60):
        nxt_local = iterator.get_next(datetime)
        nxt_utc = as_utc(nxt_local.replace(tzinfo=tz))
        if nxt_utc > anchor:
            return nxt_utc
    raise ValueError(f"Could not compute a future run for: {normalized}")


def repair_delay(after: datetime | None = None) -> datetime:
    """Backoff used when a stored cron expression can no longer be evaluated."""
    anchor = utcnow() if after is None else as_utc(after)
    return anchor + timedelta(minutes=5)
