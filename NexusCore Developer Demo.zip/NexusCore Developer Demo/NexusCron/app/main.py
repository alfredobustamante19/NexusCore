"""FastAPI application, dashboard, and process lifespan."""

import asyncio
import logging
from contextlib import asynccontextmanager, suppress
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app import __version__
from app.api import router
from app.config import load_dotenv, scheduler_enabled, shutdown_timeout_seconds, timezone_name
from app.database import init_db
from app.scheduler import close_client, open_client, scheduler_loop

load_dotenv()

logger = logging.getLogger("pulse")
BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
_MAX_BODY_BYTES = 1_000_000


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    timezone = timezone_name()
    # Fail fast on an unknown zone before accepting traffic.
    from app.cron import get_timezone

    get_timezone()
    open_client()
    logger.info("database ready timezone=%s", timezone)
    stop = asyncio.Event()
    worker: asyncio.Task[None] | None = None
    if scheduler_enabled():
        worker = asyncio.create_task(scheduler_loop(stop), name="pulse-scheduler")
    try:
        yield
    finally:
        stop.set()
        if worker is not None:
            try:
                await asyncio.wait_for(worker, timeout=shutdown_timeout_seconds())
            except TimeoutError:
                worker.cancel()
                with suppress(asyncio.CancelledError):
                    await worker
        await close_client()


app = FastAPI(
    title="Pulse Scheduler",
    summary="Self-hosted cron and background task scheduler",
    version=__version__,
    lifespan=lifespan,
)
app.include_router(router)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


@app.middleware("http")
async def guard_requests(request: Request, call_next):
    length = request.headers.get("content-length")
    if length is not None and length.isdigit() and int(length) > _MAX_BODY_BYTES:
        return JSONResponse({"detail": "Request body is too large"}, status_code=413)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self'; script-src 'self'; "
        "img-src 'self'; connect-src 'self'; base-uri 'self'; form-action 'self'"
    )
    return response


@app.get("/", include_in_schema=False)
def dashboard(request: Request):
    return templates.TemplateResponse(
        request,
        "index.html",
        {"timezone": timezone_name(), "version": __version__},
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, workers=1)
