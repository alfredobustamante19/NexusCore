# Pulse

Self-hosted cron and background task scheduler. Pulse stores schedules in a SQLite file, wakes about once a second, and calls your HTTP endpoints when they are due. The dashboard, API, and database all run in one process. Nothing is sent to an external service.

## What it does

- Stores scheduled tasks and execution logs in a local SQLite file.
- Evaluates standard 5-field cron expressions (`minute hour day month weekday`) in a timezone you choose. The default is UTC.
- Calls each target with `GET` or `POST` through a shared async HTTP client, with a concurrency cap and a response-size cap.
- Claims a due run by moving `next_run_at` forward **before** the request is sent. After downtime, a missed slot runs once and then the schedule continues. A crash mid-request does not fire that same slot again.
- Exposes CRUD, an on-demand trigger, and paginated logs.
- Serves a dark dashboard for creating, pausing, editing, running, and inspecting tasks.

Run **one** process per database. SQLite plus the in-memory run lock are for a single scheduler, not a multi-worker cluster.

## Project layout

```
app/
  main.py            FastAPI app, lifespan, dashboard
  models.py          ScheduledTask and TaskExecutionLog
  database.py        SQLite engine and sessions
  scheduler.py       Cron loop and HTTP execution
  api.py             JSON API
  schemas.py         Request and response models
  cron.py            Cron parsing and next-run math
  templates/index.html
  static/app.js
  static/app.css
Dockerfile
docker-compose.yml
requirements.txt
```

## Local setup

Requires Python 3.12 or newer.

Windows (PowerShell):

```powershell
cd cron-scheduler
py -3 -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

macOS or Linux:

```bash
cd cron-scheduler
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open [http://127.0.0.1:8000](http://127.0.0.1:8000). Interactive API docs are at [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).

The database file is created at `data/scheduler.db` on first start. Copy `.env.example` to `.env` when you want different settings. Variables already exported in the shell take priority over `.env`.

## Docker

The image is Python only. The Tailwind stylesheet is already built into `app/static/app.css`.

```bash
docker compose up --build -d
```

The SQLite file lives in the `pulse-data` volume at `/data/scheduler.db`. The API listens on port 8000.

Equivalent `docker run`:

```bash
docker build -t pulse-scheduler .
docker run --rm -p 8000:8000 -v pulse-data:/data pulse-scheduler
```

Stop the compose stack with `docker compose down`. Add `-v` only when you also want to delete the database volume.

## Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `DATABASE_PATH` | `data/scheduler.db` | SQLite file path |
| `SCHEDULER_TIMEZONE` | `UTC` | Wall clock used to interpret cron fields |
| `SCHEDULER_POLL_SECONDS` | `1` | How often the loop looks for due tasks |
| `SCHEDULER_ENABLED` | `1` | Set to `0` to serve the API without firing schedules |
| `HTTP_TIMEOUT_SECONDS` | `30` | Outbound request timeout |
| `HTTP_MAX_CONCURRENCY` | `10` | Maximum simultaneous outbound calls |
| `RESPONSE_BODY_LIMIT` | `8192` | Characters of response body kept in the log |
| `LOG_LEVEL` | `INFO` | Process log level |

Cron fields are minute-resolution. The loop still wakes every second so a task due this minute starts promptly instead of waiting for the next coarse tick.

## API

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/health` | Process health |
| `GET` | `/api/stats` | Counts and scheduler status |
| `POST` | `/api/cron/preview` | Next run time for an expression |
| `GET` | `/api/tasks` | List tasks (`q`, `active`) |
| `POST` | `/api/tasks` | Create a task |
| `GET` | `/api/tasks/{id}` | Fetch one task |
| `PUT` | `/api/tasks/{id}` | Replace a task |
| `PATCH` | `/api/tasks/{id}` | Update fields, including `is_active` |
| `DELETE` | `/api/tasks/{id}` | Delete a task and its logs |
| `POST` | `/api/tasks/{id}/trigger` | Run now, without moving the cron schedule |
| `GET` | `/api/tasks/{id}/logs` | Paginated logs for one task |
| `GET` | `/api/logs` | Paginated logs across tasks |

Create a task:

```bash
curl -X POST http://127.0.0.1:8000/api/tasks \
  -H "Content-Type: application/json" \
  -d "{\"name\":\"Health\",\"cron_expression\":\"*/5 * * * *\",\"target_url\":\"http://127.0.0.1:8000/api/health\",\"http_method\":\"GET\"}"
```

Each outbound call includes `X-Pulse-Task-Id`, `X-Pulse-Execution-Id`, and `X-Pulse-Trigger` (`schedule` or `manual`). `GET` stores an optional payload but does not send it. `POST` sends `payload_json` as a JSON body. A 2xx status is recorded as success. Timeouts and connection errors are stored with status `0`.

`Host`, `Content-Length`, `Content-Type`, `Transfer-Encoding`, and `Connection` cannot be set in `headers_json`.

## Dashboard

The home page lists every task, the live execution history, and a dialog for create and edit. Presets cover common schedules. Search and the Active / Paused filters run in the browser. History is paged from the API and refreshes every few seconds.

Pausing a task keeps it in the database and stops scheduled runs. **Run** still executes it immediately. Resuming a task whose next time is already in the past schedules the next future match instead of firing the missed one. Use **Run** when you want that call now.

## Tests

```bash
pip install -r requirements-dev.txt
pytest
```

## Rebuild the stylesheet

The running app does not download Tailwind. After changing `app/templates/index.html` or `app/static/app.js`:

```bash
npm install
npm run build:css
```

That writes `app/static/app.css`, which Docker copies as-is.

## Backup and reset

Stop Pulse, then copy `data/scheduler.db` (and the `-wal` / `-shm` files if they exist). To wipe the schedule, stop the process and delete those files. The next start creates an empty database. There is no migration tool: if you change the tables, use a new database file.

## Security

Pulse has no built-in login. It will call any `http` or `https` URL you save, including addresses on your own network. Bind it to `127.0.0.1`, or put it behind a reverse proxy and an access control layer you already trust, before exposing the port.

Do not start Uvicorn with more than one worker. A second process will claim the same due tasks.
