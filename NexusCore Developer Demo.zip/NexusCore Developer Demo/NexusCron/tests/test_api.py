from datetime import datetime, timedelta

from app.clock import utcnow
from app.database import session_scope
from app.models import ScheduledTask


def _payload(**overrides):
    body = {
        "name": "Health ping",
        "cron_expression": "*/5 * * * *",
        "target_url": "http://127.0.0.1:9/health",
        "http_method": "GET",
        "headers_json": '{"X-Job": "pulse"}',
        "payload_json": '{"ping": true}',
        "is_active": True,
    }
    body.update(overrides)
    return body


def test_dashboard_and_health(client):
    page = client.get("/")
    assert page.status_code == 200
    assert "Pulse" in page.text
    assert "text/html" in page.headers["content-type"]
    assert "default-src 'self'" in page.headers["content-security-policy"]
    assert page.headers["x-frame-options"] == "DENY"

    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"

    script = client.get("/static/app.js")
    assert script.status_code == 200
    assert "function refresh" in script.text or "async function refresh" in script.text

    stylesheet = client.get("/static/app.css")
    assert stylesheet.status_code == 200
    assert len(stylesheet.content) > 1000


def test_create_list_get_and_preview(client):
    created = client.post("/api/tasks", json=_payload())
    assert created.status_code == 201
    body = created.json()
    assert body["name"] == "Health ping"
    assert body["cron_expression"] == "*/5 * * * *"
    assert body["headers_json"] == '{"X-Job":"pulse"}'
    assert body["payload_json"] == '{"ping":true}'
    assert body["next_run_at"].endswith("Z")
    assert body["created_at"].endswith("Z")
    assert created.headers["location"] == f"/api/tasks/{body['id']}"

    listing = client.get("/api/tasks")
    assert listing.status_code == 200
    assert len(listing.json()) == 1

    fetched = client.get(f"/api/tasks/{body['id']}")
    assert fetched.status_code == 200
    assert fetched.json()["id"] == body["id"]

    preview = client.post("/api/cron/preview", json={"cron_expression": "0 * * * *"})
    assert preview.status_code == 200
    assert preview.json()["next_run_at"].endswith("Z")
    assert preview.json()["timezone"] == "UTC"


def test_validation_errors(client):
    assert client.post("/api/tasks", json=_payload(cron_expression="* * * * * *")).status_code == 422
    assert client.post("/api/tasks", json=_payload(target_url="file:///etc/passwd")).status_code == 422
    assert client.post("/api/tasks", json=_payload(http_method="PUT")).status_code == 422
    assert client.post("/api/tasks", json=_payload(payload_json="{")).status_code == 422
    assert client.post("/api/tasks", json=_payload(headers_json='{"Host": "evil"}')).status_code == 422
    assert client.post("/api/tasks", json=_payload(headers_json='{"X-Job": "a\\nb"}')).status_code == 422
    assert client.post("/api/tasks", json=_payload(name="  ")).status_code == 422


def test_search_update_pause_and_delete(client):
    first = client.post("/api/tasks", json=_payload(name="Alpha job")).json()
    client.post("/api/tasks", json=_payload(name="Beta job", target_url="http://127.0.0.1:9/beta"))

    found = client.get("/api/tasks", params={"q": "Alpha"})
    assert [item["name"] for item in found.json()] == ["Alpha job"]
    assert client.get("/api/tasks", params={"q": "100%"}).json() == []

    replaced = client.put(
        f"/api/tasks/{first['id']}",
        json=_payload(name="Alpha renamed", cron_expression="0 * * * *"),
    )
    assert replaced.status_code == 200
    assert replaced.json()["name"] == "Alpha renamed"
    assert replaced.json()["cron_expression"] == "0 * * * *"

    paused = client.patch(f"/api/tasks/{first['id']}", json={"is_active": False})
    assert paused.status_code == 200
    assert paused.json()["is_active"] is False
    assert client.get("/api/tasks", params={"active": False}).json()[0]["id"] == first["id"]

    empty = client.patch(f"/api/tasks/{first['id']}", json={})
    assert empty.status_code == 422

    deleted = client.delete(f"/api/tasks/{first['id']}")
    assert deleted.status_code == 204
    assert client.get(f"/api/tasks/{first['id']}").status_code == 404
    assert client.post(f"/api/tasks/{first['id']}/trigger").status_code == 404


def test_trigger_and_log_pagination(client, monkeypatch):
    seen = {}

    async def fake(snapshot, *, trigger, execution_id, client=None):
        seen["trigger"] = trigger
        seen["payload"] = snapshot.payload_json
        seen["method"] = snapshot.http_method
        return 200, "pong"

    monkeypatch.setattr("app.scheduler.perform_request", fake)
    created = client.post("/api/tasks", json=_payload(http_method="POST")).json()

    for _ in range(3):
        triggered = client.post(f"/api/tasks/{created['id']}/trigger")
        assert triggered.status_code == 200
        assert triggered.json()["success"] is True
        assert triggered.json()["executed_at"].endswith("Z")

    assert seen["trigger"] == "manual"
    assert seen["method"] == "POST"
    assert seen["payload"] == '{"ping":true}'

    page = client.get(f"/api/tasks/{created['id']}/logs", params={"page": 1, "page_size": 2})
    assert page.status_code == 200
    body = page.json()
    assert body["total"] == 3
    assert len(body["items"]) == 2
    assert body["items"][0]["task_name"] == "Health ping"

    second = client.get("/api/logs", params={"page": 2, "page_size": 2, "task_id": created["id"]})
    assert second.status_code == 200
    assert len(second.json()["items"]) == 1

    stats = client.get("/api/stats").json()
    assert stats["tasks_total"] == 1
    assert stats["runs_total"] == 3
    assert stats["runs_success"] == 3
    assert stats["scheduler_running"] is False

    client.delete(f"/api/tasks/{created['id']}")
    assert client.get(f"/api/tasks/{created['id']}/logs").status_code == 404
    assert client.get("/api/logs").json()["total"] == 0


def test_resume_skips_a_missed_slot(client):
    created = client.post("/api/tasks", json=_payload(is_active=False)).json()
    with session_scope() as session:
        task = session.get(ScheduledTask, created["id"])
        task.is_active = False
        task.next_run_at = utcnow() - timedelta(minutes=30)

    resumed = client.patch(f"/api/tasks/{created['id']}", json={"is_active": True})
    assert resumed.status_code == 200
    body = resumed.json()
    assert body["is_active"] is True
    next_run = datetime.fromisoformat(body["next_run_at"].replace("Z", "+00:00"))
    assert next_run > utcnow()
    assert client.get(f"/api/tasks/{created['id']}/logs").json()["total"] == 0


def test_rejects_oversized_body(client):
    response = client.post(
        "/api/tasks",
        content=b"x" * 1_000_001,
        headers={"content-type": "application/json"},
    )
    assert response.status_code == 413
