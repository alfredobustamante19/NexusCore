import pytest


@pytest.fixture
def db(tmp_path, monkeypatch):
    monkeypatch.setenv("DATABASE_PATH", str(tmp_path / "scheduler.db"))
    monkeypatch.setenv("SCHEDULER_ENABLED", "0")
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "UTC")
    from app.database import init_db, reset_engine
    from app.scheduler import reset_runtime_state

    reset_runtime_state()
    reset_engine()
    init_db()
    yield
    reset_runtime_state()
    reset_engine()


@pytest.fixture
def client(db):
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app) as test_client:
        yield test_client
