from datetime import datetime, timezone

import pytest

from app.cron import compute_next_run, normalize_cron

UTC = timezone.utc


def test_normalize_collapses_whitespace():
    assert normalize_cron("  */5   * * * * ") == "*/5 * * * *"


@pytest.mark.parametrize(
    "expression",
    ["* * * *", "* * * * * *", "60 * * * *", "", "not a cron"],
)
def test_normalize_rejects_bad_expressions(expression):
    with pytest.raises(ValueError):
        normalize_cron(expression)


def test_next_run_is_strictly_after_an_exact_match(monkeypatch):
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "UTC")
    nxt = compute_next_run("* * * * *", datetime(2026, 6, 1, 12, 0, 0, tzinfo=UTC))
    assert nxt == datetime(2026, 6, 1, 12, 1, 0, tzinfo=UTC)


def test_hourly_from_mid_hour(monkeypatch):
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "UTC")
    nxt = compute_next_run("0 * * * *", datetime(2026, 6, 1, 12, 30, 0, tzinfo=UTC))
    assert nxt == datetime(2026, 6, 1, 13, 0, 0, tzinfo=UTC)


def test_weekday_morning_in_madrid_winter(monkeypatch):
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "Europe/Madrid")
    # 07:30 UTC is 08:30 CET. The next 09:00 local is 08:00 UTC.
    nxt = compute_next_run("0 9 * * 1-5", datetime(2026, 1, 15, 7, 30, 0, tzinfo=UTC))
    assert nxt == datetime(2026, 1, 15, 8, 0, 0, tzinfo=UTC)


def test_weekday_morning_in_madrid_summer(monkeypatch):
    monkeypatch.setenv("SCHEDULER_TIMEZONE", "Europe/Madrid")
    # 06:30 UTC is 08:30 CEST. The next 09:00 local is 07:00 UTC.
    nxt = compute_next_run("0 9 * * 1-5", datetime(2026, 7, 15, 6, 30, 0, tzinfo=UTC))
    assert nxt == datetime(2026, 7, 15, 7, 0, 0, tzinfo=UTC)
