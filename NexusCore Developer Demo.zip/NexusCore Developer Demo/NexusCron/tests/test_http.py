import httpx
import pytest

from app.models import new_id
from app.scheduler import TaskSnapshot, perform_request


def _snapshot(**overrides) -> TaskSnapshot:
    fields = {
        "id": new_id(),
        "name": "ping",
        "target_url": "http://example.test/hook",
        "http_method": "POST",
        "payload_json": '{"hello":"world"}',
        "headers_json": '{"X-Job":"pulse"}',
    }
    fields.update(overrides)
    return TaskSnapshot(**fields)


@pytest.mark.asyncio
async def test_post_sends_json_and_pulse_headers():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        captured["body"] = request.content
        captured["headers"] = request.headers
        return httpx.Response(201, text='{"ok":true}')

    snapshot = _snapshot()
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        status, body = await perform_request(
            snapshot,
            trigger="manual",
            execution_id="exec-1",
            client=client,
        )

    assert status == 201
    assert body == '{"ok":true}'
    assert captured["method"] == "POST"
    assert captured["body"] == b'{"hello":"world"}'
    headers = captured["headers"]
    assert headers["x-pulse-task-id"] == snapshot.id
    assert headers["x-pulse-execution-id"] == "exec-1"
    assert headers["x-pulse-trigger"] == "manual"
    assert headers["x-job"] == "pulse"
    assert headers["user-agent"].startswith("PulseScheduler/")


@pytest.mark.asyncio
async def test_get_does_not_send_a_body():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = request.content
        return httpx.Response(204)

    snapshot = _snapshot(http_method="GET")
    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        status, body = await perform_request(
            snapshot,
            trigger="schedule",
            execution_id="exec-2",
            client=client,
        )

    assert status == 204
    assert body == ""
    assert captured["body"] == b""


@pytest.mark.asyncio
async def test_response_body_is_truncated(monkeypatch):
    monkeypatch.setenv("RESPONSE_BODY_LIMIT", "256")

    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"x" * 1000)

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
        _status, body = await perform_request(
            _snapshot(http_method="GET", payload_json=None),
            trigger="schedule",
            execution_id="exec-3",
            client=client,
        )

    assert body.startswith("x" * 256)
    assert body.endswith("...[truncated]")
    assert len(body) < 1000
