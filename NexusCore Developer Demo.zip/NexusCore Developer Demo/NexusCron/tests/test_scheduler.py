import asyncio
from datetime import timedelta

import httpx
import pytest

from app.clock import utcnow
from app.database import session_scope
from app.models import ScheduledTask, TaskExecutionLog
from app.scheduler import TaskAlreadyRunningError, dispatch_due_tasks, trigger_task
from sqlmodel import select


def _add_task(**overrides) -> str:
    now = utcnow()
    fields = {
        "name": "hook",
        "cron_expression": "* * * * *",
        "target_url": "http://example.test/hook",
        "http_method": "POST",
        "payload_json": '{"ok":true}',
        "is_active": True,
        "next_run_at": now - timedelta(minutes=2),
        "created_at": now,
    }
    fields.update(overrides)
    with session_scope() as session:
        task = ScheduledTask(**fields)
        session.add(task)
        session.flush()
        task_id = task.id
    return task_id


def _task(task_id: str) -> ScheduledTask:
    with session_scope() as session:
        task = session.get(ScheduledTask, task_id)
        session.expunge(task)
        return task


def _logs() -> list[TaskExecutionLog]:
    with session_scope() as session:
        rows = list(session.exec(select(TaskExecutionLog)).all())
        for row in rows:
            session.expunge(row)
        return rows


@pytest.mark.asyncio
async def test_dispatch_runs_due_task_once(db, monkeypatch):
    async def fake(snapshot, *, trigger, execution_id, client=None):
        assert trigger == "schedule"
        assert execution_id
        return 202, "accepted"

    monkeypatch.setattr("app.scheduler.perform_request", fake)
    task_id = _add_task()
    before = utcnow()

    started = await dispatch_due_tasks()
    assert started == [task_id]
    assert await dispatch_due_tasks() == []

    task = _task(task_id)
    logs = _logs()
    assert task.last_run_at is not None
    assert task.next_run_at > before
    assert len(logs) == 1
    assert logs[0].success is True
    assert logs[0].status_code == 202
    assert logs[0].response_body == "accepted"


@pytest.mark.asyncio
async def test_paused_task_is_not_fired(db, monkeypatch):
    called = False

    async def fake(snapshot, *, trigger, execution_id, client=None):
        nonlocal called
        called = True
        return 200, "ok"

    monkeypatch.setattr("app.scheduler.perform_request", fake)
    task_id = _add_task(is_active=False)
    before = utcnow()
    assert await dispatch_due_tasks() == []
    assert called is False
    assert _task(task_id).next_run_at > before
    assert _logs() == []


@pytest.mark.asyncio
async def test_future_task_waits(db, monkeypatch):
    async def fake(snapshot, *, trigger, execution_id, client=None):
        raise AssertionError("future task was called")

    monkeypatch.setattr("app.scheduler.perform_request", fake)
    future = utcnow() + timedelta(hours=3)
    task_id = _add_task(next_run_at=future)
    assert await dispatch_due_tasks() == []
    assert _task(task_id).next_run_at == future


@pytest.mark.asyncio
async def test_manual_trigger_does_not_move_schedule(db, monkeypatch):
    async def fake(snapshot, *, trigger, execution_id, client=None):
        assert trigger == "manual"
        return 200, "ok"

    monkeypatch.setattr("app.scheduler.perform_request", fake)
    future = utcnow() + timedelta(hours=2)
    task_id = _add_task(next_run_at=future)
    log = await trigger_task(task_id)
    assert log.success is True
    task = _task(task_id)
    assert task.next_run_at == future
    assert task.last_run_at is not None


@pytest.mark.asyncio
async def test_timeout_is_logged_as_failure(db, monkeypatch):
    async def fake(snapshot, *, trigger, execution_id, client=None):
        raise httpx.TimeoutException("timed out")

    monkeypatch.setattr("app.scheduler.perform_request", fake)
    task_id = _add_task()
    await dispatch_due_tasks()
    logs = _logs()
    assert len(logs) == 1
    assert logs[0].task_id == task_id
    assert logs[0].success is False
    assert logs[0].status_code == 0
    assert "timed out" in logs[0].response_body.lower()


@pytest.mark.asyncio
async def test_overlapping_run_is_rejected(db, monkeypatch):
    started = asyncio.Event()
    release = asyncio.Event()

    async def slow(snapshot, *, trigger, execution_id, client=None):
        started.set()
        await release.wait()
        return 200, "ok"

    monkeypatch.setattr("app.scheduler.perform_request", slow)
    task_id = _add_task()
    runner = asyncio.create_task(dispatch_due_tasks())
    await asyncio.wait_for(started.wait(), timeout=2)
    with pytest.raises(TaskAlreadyRunningError):
        await trigger_task(task_id)
    release.set()
    await runner
    assert len(_logs()) == 1
