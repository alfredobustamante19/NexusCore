import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import type { FastifyInstance } from 'fastify';
import { createApp } from '../src/app.js';
import type { Config } from '../src/config.js';
import { openDatabase, type LogStore } from '../src/db.js';

export const TOKEN = 'test-token-nexuslog-0123456789abcdef';

export interface TestAppOptions {
  alerts?: unknown;
  now?: () => number;
  retentionDays?: number;
  rateLimitPerMinute?: number;
  telegramApiBase?: string;
  sseMaxClients?: number;
}

export interface TestContext {
  app: FastifyInstance;
  store: LogStore;
  dir: string;
  token: string;
  alertsPath: string;
  auth: { authorization: string };
  close: () => Promise<void>;
}

export async function createTestApp(options: TestAppOptions = {}): Promise<TestContext> {
  const dir = mkdtempSync(path.join(tmpdir(), 'nexuslog-'));
  const dbPath = path.join(dir, 'test.sqlite');
  const alertsPath = path.join(dir, 'alerts.json');
  writeFileSync(alertsPath, JSON.stringify(options.alerts ?? { rules: [] }), 'utf8');
  let store: LogStore | undefined;
  try {
    store = openDatabase(dbPath);
    const config: Config = {
      host: '127.0.0.1',
      port: 0,
      token: TOKEN,
      dbPath,
      retentionDays: options.retentionDays ?? 14,
      cleanupIntervalMinutes: 60,
      alertsPath,
      bodyLimitBytes: 262_144,
      rateLimitPerMinute: options.rateLimitPerMinute ?? 0,
      sseMaxClients: options.sseMaxClients ?? 100,
      cookieSecure: false,
      logLevel: 'silent',
    };
    const app = createApp({
      config,
      store,
      awaitAlerts: true,
      now: options.now,
      telegramApiBase: options.telegramApiBase,
      logger: false,
    });
    const opened = store;
    return {
      app,
      store,
      dir,
      token: TOKEN,
      alertsPath,
      auth: { authorization: `Bearer ${TOKEN}` },
      async close() {
        await app.close();
        opened.close();
        rmSync(dir, { recursive: true, force: true });
      },
    };
  } catch (err) {
    store?.close();
    rmSync(dir, { recursive: true, force: true });
    throw err;
  }
}

export function postLog(ctx: TestContext, body: Record<string, unknown>) {
  return ctx.app.inject({
    method: 'POST',
    url: '/api/v1/log',
    headers: ctx.auth,
    payload: body,
  });
}
