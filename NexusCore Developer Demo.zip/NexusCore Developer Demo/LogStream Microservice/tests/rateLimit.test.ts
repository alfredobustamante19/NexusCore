import { afterEach, describe, expect, it, vi } from 'vitest';
import { createRateLimiter } from '../src/rateLimit.js';

describe('createRateLimiter', () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it('allows every request when the limit is disabled', () => {
    const limiter = createRateLimiter(0);
    expect(limiter.allow('ip')).toBe(true);
    expect(limiter.allow('ip')).toBe(true);
    limiter.stop();
  });

  it('blocks the next call from the same key and allows another key', () => {
    vi.useFakeTimers();
    const limiter = createRateLimiter(2);
    expect(limiter.allow('ip')).toBe(true);
    expect(limiter.allow('ip')).toBe(true);
    expect(limiter.allow('ip')).toBe(false);
    expect(limiter.allow('other')).toBe(true);
    vi.advanceTimersByTime(60_001);
    expect(limiter.allow('ip')).toBe(true);
    limiter.stop();
  });
});
