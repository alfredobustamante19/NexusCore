import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { loadConfig } from '../src/config.js';
import { loadEnvFile } from '../src/env.js';

const token = 'a'.repeat(24);

describe('configuration', () => {
  it('requires a real token', () => {
    expect(() => loadConfig({})).toThrow(/NEXUS_TOKEN is required/);
    expect(() => loadConfig({ NEXUS_TOKEN: 'short' })).toThrow(/16/);
    expect(() => loadConfig({ NEXUS_TOKEN: 'replace-with-a-long-random-token' })).toThrow(/placeholder/);
  });

  it('parses runtime settings and rejects invalid values', () => {
    const config = loadConfig({
      NEXUS_TOKEN: token,
      PORT: '8799',
      HOST: '0.0.0.0',
      LOG_RETENTION_DAYS: '30',
      COOKIE_SECURE: 'true',
      RATE_LIMIT_PER_MINUTE: '0',
      DB_PATH: './data/custom.sqlite',
    });
    expect(config).toMatchObject({
      port: 8799,
      host: '0.0.0.0',
      retentionDays: 30,
      cookieSecure: true,
      rateLimitPerMinute: 0,
      dbPath: './data/custom.sqlite',
    });

    expect(() => loadConfig({ NEXUS_TOKEN: token, LOG_RETENTION_DAYS: '0' })).toThrow(/LOG_RETENTION_DAYS/);
    expect(() => loadConfig({ NEXUS_TOKEN: token, PORT: 'nope' })).toThrow(/PORT/);
    expect(() => loadConfig({ NEXUS_TOKEN: token, LOG_LEVEL: 'loud' })).toThrow(/LOG_LEVEL/);
  });

  it('loads a dotenv file without overriding existing variables', () => {
    const dir = mkdtempSync(path.join(tmpdir(), 'nexuslog-env-'));
    const file = path.join(dir, '.env');
    try {
      writeFileSync(
        file,
        ['# comment', 'export PORT="8788"', "NEXUS_TOKEN='abcdefghijklmnopqrstuvwxyz'", 'COOKIE_SECURE=yes', 'NOT VALID', 'HOST=127.0.0.1'].join('\n'),
        'utf8',
      );
      const env: NodeJS.ProcessEnv = { PORT: '1' };
      loadEnvFile(file, env);
      expect(env.PORT).toBe('1');
      expect(env.NEXUS_TOKEN).toBe('abcdefghijklmnopqrstuvwxyz');
      expect(env.HOST).toBe('127.0.0.1');
      expect(loadConfig(env).cookieSecure).toBe(true);
      expect(loadConfig(env).port).toBe(1);

      const untouched: NodeJS.ProcessEnv = { NEXUS_TOKEN: token };
      loadEnvFile(path.join(dir, 'missing.env'), untouched);
      expect(loadConfig(untouched).port).toBe(8787);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});
