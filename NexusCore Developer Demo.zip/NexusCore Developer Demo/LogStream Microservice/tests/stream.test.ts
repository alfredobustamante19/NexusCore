import http from 'node:http';
import { describe, expect, it } from 'vitest';
import { createStreamHub, formatLogEvent } from '../src/stream.js';
import type { PublicLog } from '../src/types.js';
import { createTestApp, postLog } from './helpers.js';

const sample: PublicLog = {
  id: 7,
  level: 'INFO',
  service: 'api',
  message: 'hello',
  payload: { ok: true },
  timestamp: '2026-10-07T00:00:00.000Z',
  receivedAt: '2026-10-07T00:00:00.000Z',
};

describe('stream hub', () => {
  it('broadcasts log events and enforces capacity', () => {
    const hub = createStreamHub(1);
    const chunks: string[] = [];
    const client = {
      write(chunk: string) {
        chunks.push(chunk);
        return true;
      },
    };
    expect(hub.add(client)).toBe(true);
    expect(hub.add({ write: () => true })).toBe(false);
    hub.broadcast(sample);
    expect(chunks).toEqual([formatLogEvent(sample)]);
    expect(chunks[0]).toContain('event: log');
    hub.remove(client);
    expect(hub.size()).toBe(0);
    hub.close();
  });

  it('drops clients whose sockets throw', () => {
    const hub = createStreamHub(5);
    hub.add({
      write() {
        throw new Error('closed');
      },
    });
    hub.broadcast(sample);
    expect(hub.size()).toBe(0);
    hub.close();
  });
});

function waitForLog(base: string, token: string, headers: Record<string, string>, produce?: () => Promise<void>) {
  return new Promise<PublicLog>((resolve, reject) => {
    let done = false;
    const finish = (err?: Error, log?: PublicLog) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      req.destroy();
      if (err) reject(err);
      else if (log) resolve(log);
      else reject(new Error('stream ended'));
    };
    const timer = setTimeout(() => finish(new Error('SSE timed out')), 5_000);
    let started = false;
    let buffer = '';
    const req = http.request(
      new URL('/api/v1/stream', base),
      { headers: { authorization: `Bearer ${token}`, ...headers } },
      (res) => {
        res.setEncoding('utf8');
        res.on('data', (chunk: string) => {
          buffer += chunk;
          const parts = buffer.split('\n\n');
          buffer = parts.pop() ?? '';
          for (const part of parts) {
            if (!started && part.includes('event: hello') && produce) {
              started = true;
              produce().catch((err: unknown) => {
                finish(err instanceof Error ? err : new Error(String(err)));
              });
            }
            if (!part.includes('event: log')) continue;
            const dataLine = part.split('\n').find((line) => line.startsWith('data: '));
            if (!dataLine) continue;
            finish(undefined, JSON.parse(dataLine.slice('data: '.length)) as PublicLog);
          }
        });
        res.on('error', (err) => finish(err));
      },
    );
    req.on('error', (err) => {
      if ((err as NodeJS.ErrnoException).code === 'ECONNRESET') return;
      finish(err);
    });
    req.end();
  });
}

describe('SSE endpoint', () => {
  it('pushes ingested logs and replays events after Last-Event-ID', async () => {
    const ctx = await createTestApp();
    try {
      const base = await ctx.app.listen({ port: 0, host: '127.0.0.1' });
      const live = waitForLog(base, ctx.token, {}, () =>
        postLog(ctx, { level: 'INFO', service: 'sse', message: 'streamed line', payload: { n: 1 } }).then(() => undefined),
      );
      await expect(live).resolves.toMatchObject({
        service: 'sse',
        message: 'streamed line',
        level: 'INFO',
        payload: { n: 1 },
      });

      const created = await postLog(ctx, { level: 'ERROR', service: 'sse', message: 'replay me' });
      const id = (created.json() as { id: number }).id;
      const replayed = await waitForLog(base, ctx.token, { 'last-event-id': String(id - 1) });
      expect(replayed.message).toBe('replay me');
    } finally {
      await ctx.close();
    }
  });

  it('returns 503 when the stream is at capacity', async () => {
    const ctx = await createTestApp({ sseMaxClients: 1 });
    try {
      const base = await ctx.app.listen({ port: 0, host: '127.0.0.1' });
      const held = waitForLog(base, ctx.token, {}, async () => {
        const blocked = await ctx.app.inject({
          method: 'GET',
          url: '/api/v1/stream',
          headers: ctx.auth,
        });
        expect(blocked.statusCode).toBe(503);
        expect(blocked.json()).toEqual({ error: 'Stream capacity reached' });
        await postLog(ctx, { level: 'INFO', service: 'sse', message: 'release' });
      });
      await expect(held).resolves.toMatchObject({ message: 'release' });
    } finally {
      await ctx.close();
    }
  });
});
