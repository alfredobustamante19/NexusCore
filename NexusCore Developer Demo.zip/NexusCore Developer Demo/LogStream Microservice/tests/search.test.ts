import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { startRetentionJob } from '../src/cleanup.js';
import { createTestApp, postLog, type TestContext } from './helpers.js';

describe('search and retention', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await createTestApp();
    const rows = [
      { level: 'ERROR', service: 'billing', message: 'payment failed for invoice 42', payload: { invoice: '42' } },
      { level: 'INFO', service: 'auth', message: 'user login succeeded' },
      { level: 'INFO', service: 'billing', message: 'payment queued' },
      { level: 'WARN', service: 'disk', message: 'volume almost full' },
    ];
    for (const row of rows) {
      const res = await postLog(ctx, row);
      expect(res.statusCode).toBe(201);
    }
  });

  afterAll(async () => {
    await ctx.close();
  });

  async function search(query: string) {
    const res = await ctx.app.inject({
      method: 'GET',
      url: `/api/v1/logs?${query}`,
      headers: ctx.auth,
    });
    expect(res.statusCode).toBe(200);
    return res.json() as {
      logs: Array<{ id: number; message: string; service: string; level: string; payload: unknown }>;
      nextBefore: number | null;
    };
  }

  it('filters by service and level', async () => {
    const billing = await search('service=billing');
    expect(billing.logs.map((log) => log.message).sort()).toEqual([
      'payment failed for invoice 42',
      'payment queued',
    ]);

    const errors = await search('service=billing&level=error');
    expect(errors.logs).toHaveLength(1);
    expect(errors.logs[0]?.message).toBe('payment failed for invoice 42');

    const warnings = await search('level=warning');
    expect(warnings.logs.map((log) => log.level)).toEqual(['WARN']);
  });

  it('runs full-text search across message, service, and payload', async () => {
    const payment = await search('q=PAYMENT');
    expect(payment.logs.map((log) => log.message).sort()).toEqual([
      'payment failed for invoice 42',
      'payment queued',
    ]);

    const invoice = await search('q=invoice');
    expect(invoice.logs).toHaveLength(1);
    expect(invoice.logs[0]?.payload).toEqual({ invoice: '42' });

    const combined = await search('q=login&service=auth');
    expect(combined.logs).toHaveLength(1);
    expect(combined.logs[0]?.service).toBe('auth');

    const none = await search('q=redis');
    expect(none.logs).toEqual([]);

    const injected = await search(`q=${encodeURIComponent('" OR 1=1')}`);
    expect(injected.logs).toEqual([]);
  });

  it('paginates with a before cursor', async () => {
    const page = await ctx.app.inject({
      method: 'GET',
      url: '/api/v1/logs?limit=2',
      headers: ctx.auth,
    });
    expect(page.statusCode).toBe(200);
    const first = page.json() as { logs: Array<{ id: number; message: string }>; nextBefore: number | null };
    expect(first.logs).toHaveLength(2);
    expect(first.nextBefore).toBe(first.logs[1]?.id ?? null);
    const older = await ctx.app.inject({
      method: 'GET',
      url: `/api/v1/logs?limit=2&before=${first.nextBefore}`,
      headers: ctx.auth,
    });
    const second = older.json() as { logs: Array<{ id: number }> };
    expect(second.logs.length).toBeGreaterThan(0);
    expect(Math.max(...second.logs.map((log) => log.id))).toBeLessThan(first.nextBefore ?? 0);
  });

  it('rejects invalid search queries', async () => {
    const limit = await ctx.app.inject({ method: 'GET', url: '/api/v1/logs?limit=0', headers: ctx.auth });
    expect(limit.statusCode).toBe(400);
    expect(limit.json()).toEqual({ error: 'limit must be between 1 and 500' });

    const huge = await ctx.app.inject({ method: 'GET', url: '/api/v1/logs?limit=9999', headers: ctx.auth });
    expect(huge.statusCode).toBe(400);

    const level = await ctx.app.inject({ method: 'GET', url: '/api/v1/logs?level=NOPE', headers: ctx.auth });
    expect(level.statusCode).toBe(400);

    const q = await ctx.app.inject({
      method: 'GET',
      url: `/api/v1/logs?q=${'a'.repeat(201)}`,
      headers: ctx.auth,
    });
    expect(q.statusCode).toBe(400);
    expect(q.json()).toEqual({ error: 'q is too long' });
  });

  it('lists known services', async () => {
    const res = await ctx.app.inject({ method: 'GET', url: '/api/v1/services', headers: ctx.auth });
    expect(res.statusCode).toBe(200);
    const body = res.json() as { services: Array<{ service: string; count: number }> };
    const names = body.services.map((item) => item.service).sort();
    expect(names).toEqual(['auth', 'billing', 'disk']);
    expect(body.services.find((item) => item.service === 'billing')?.count).toBe(2);
  });

  it('purges logs older than the retention window', async () => {
    const created = await postLog(ctx, {
      level: 'INFO',
      service: 'archive',
      message: 'ancient record',
      timestamp: '2020-01-01T00:00:00.000Z',
    });
    expect(created.statusCode).toBe(201);
    await postLog(ctx, { level: 'INFO', service: 'archive', message: 'fresh record' });

    expect(ctx.store.purgeOlderThan(14)).toBeGreaterThanOrEqual(1);
    const body = await search('q=record');
    expect(body.logs.map((log) => log.message)).toEqual(['fresh record']);
  });

  it('purges once when the retention job starts', async () => {
    await postLog(ctx, {
      level: 'INFO',
      service: 'archive',
      message: 'stale startup record',
      timestamp: '2021-05-01T00:00:00.000Z',
    });
    const stop = startRetentionJob(ctx.store, 14, 60, { info() {}, warn() {}, error() {} });
    try {
      const body = await search('q=stale');
      expect(body.logs).toEqual([]);
    } finally {
      stop();
    }
  });
});
