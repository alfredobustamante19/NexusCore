import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { utimesSync, writeFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { createTestApp, postLog, type TestContext } from './helpers.js';

interface Hit {
  url: string;
  body: Record<string, unknown>;
  headers: http.IncomingHttpHeaders;
}

let server: http.Server;
let baseUrl = '';
let hits: Hit[] = [];
let statusCode = 204;

function webhook(path = '/hook', headers?: Record<string, string>) {
  return { type: 'webhook', url: `${baseUrl}${path}`, headers };
}

beforeAll(async () => {
  server = http.createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => {
      chunks.push(chunk);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      const body = raw ? (JSON.parse(raw) as Record<string, unknown>) : {};
      hits.push({ url: req.url ?? '', body, headers: req.headers });
      res.writeHead(statusCode, { connection: 'close', 'content-type': 'application/json' });
      res.end('{}');
    });
  });
  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });
  const address = server.address() as AddressInfo;
  baseUrl = `http://127.0.0.1:${address.port}`;
});

afterAll(async () => {
  await new Promise<void>((resolve, reject) => {
    server.closeAllConnections();
    server.close((err) => (err ? reject(err) : resolve()));
  });
});

beforeEach(() => {
  hits = [];
  statusCode = 204;
});

async function postMany(ctx: TestContext, count: number, body: Record<string, unknown>) {
  for (let index = 0; index < count; index += 1) {
    const res = await postLog(ctx, { ...body, message: `${String(body.message)} ${index}` });
    expect(res.statusCode).toBe(201);
  }
}

describe('alert triggering', () => {
  it('fires webhook and discord targets only after the threshold is exceeded', async () => {
    const ctx = await createTestApp({
      telegramApiBase: baseUrl,
      alerts: {
        rules: [
          {
            id: 'error-spike',
            enabled: true,
            description: 'Error spike',
            match: { level: 'ERROR' },
            threshold: 5,
            windowSeconds: 60,
            cooldownSeconds: 300,
            notify: [webhook(), { type: 'discord', url: `${baseUrl}/discord` }],
          },
        ],
      },
    });
    try {
      await postMany(ctx, 5, { level: 'ERROR', service: 'billing', message: 'payment failed' });
      expect(hits).toHaveLength(0);
      await postMany(ctx, 1, { level: 'ERROR', service: 'billing', message: 'payment failed again' });
      expect(hits).toHaveLength(2);

      const hook = hits.find((hit) => hit.url === '/hook');
      expect(hook?.body).toMatchObject({
        source: 'NexusLog',
        version: 1,
        ruleId: 'error-spike',
        description: 'Error spike',
        count: 6,
        threshold: 5,
        windowSeconds: 60,
      });
      const samples = hook?.body.samples as Array<{ message: string }>;
      expect(samples.some((sample) => sample.message.includes('payment failed again'))).toBe(true);
      expect(samples[0]).not.toHaveProperty('payload');
      expect(String(hook?.body.firedAt)).toMatch(/^\d{4}-\d{2}-\d{2}T/);

      const discord = hits.find((hit) => hit.url === '/discord');
      expect(String(discord?.body.content)).toContain('Error spike');
      expect(discord?.body.allowed_mentions).toEqual({ parse: [] });
      expect(ctx.store.listFires()).toHaveLength(1);

      await postMany(ctx, 1, { level: 'ERROR', service: 'billing', message: 'still failing' });
      expect(hits).toHaveLength(2);
      expect(ctx.store.listFires()).toHaveLength(1);
    } finally {
      await ctx.close();
    }
  });

  it('ignores logs that do not match the rule', async () => {
    const ctx = await createTestApp({
      alerts: {
        rules: [
          {
            id: 'api-errors',
            enabled: true,
            description: 'API errors',
            match: { level: 'ERROR', service: 'api', messageIncludes: 'disk' },
            threshold: 5,
            windowSeconds: 60,
            cooldownSeconds: 60,
            notify: [webhook()],
          },
        ],
      },
    });
    try {
      await postMany(ctx, 8, { level: 'INFO', service: 'api', message: 'disk full' });
      await postMany(ctx, 8, { level: 'ERROR', service: 'billing', message: 'disk full' });
      await postMany(ctx, 5, { level: 'ERROR', service: 'api', message: 'other problem' });
      expect(hits).toHaveLength(0);
      await postMany(ctx, 6, { level: 'ERROR', service: 'api', message: 'disk full' });
      expect(hits).toHaveLength(1);
      expect(hits[0]?.body.count).toBe(6);
    } finally {
      await ctx.close();
    }
  });

  it('does not fire a disabled rule and skips invalid rules', async () => {
    const ctx = await createTestApp({
      alerts: {
        rules: [
          { id: '!!!', threshold: 0 },
          {
            id: 'disabled-spike',
            enabled: false,
            description: 'Disabled',
            match: { level: 'ERROR' },
            threshold: 0,
            windowSeconds: 60,
            cooldownSeconds: 30,
            notify: [webhook()],
          },
        ],
      },
    });
    try {
      await postMany(ctx, 3, { level: 'ERROR', service: 'api', message: 'boom' });
      expect(hits).toHaveLength(0);
      expect(ctx.store.listFires()).toEqual([]);
    } finally {
      await ctx.close();
    }
  });

  it('respects cooldown and retries after a failed delivery', async () => {
    let now = 1_700_000_000_000;
    const ctx = await createTestApp({
      now: () => now,
      alerts: {
        rules: [
          {
            id: 'error-spike',
            enabled: true,
            description: 'Error spike',
            match: { level: 'ERROR' },
            threshold: 5,
            windowSeconds: 600,
            cooldownSeconds: 30,
            notify: [webhook()],
          },
        ],
      },
    });
    try {
      await postMany(ctx, 6, { level: 'ERROR', service: 'api', message: 'boom' });
      expect(hits).toHaveLength(1);
      now += 10_000;
      await postMany(ctx, 1, { level: 'ERROR', service: 'api', message: 'boom' });
      expect(hits).toHaveLength(1);

      now += 30_000;
      await postMany(ctx, 1, { level: 'ERROR', service: 'api', message: 'boom' });
      expect(hits).toHaveLength(2);
      expect(ctx.store.listFires()).toHaveLength(2);

      statusCode = 500;
      now += 40_000;
      await postMany(ctx, 1, { level: 'ERROR', service: 'api', message: 'boom' });
      expect(ctx.store.listFires()).toHaveLength(2);
      expect(hits).toHaveLength(3);

      statusCode = 204;
      now += 20_000;
      await postMany(ctx, 1, { level: 'ERROR', service: 'api', message: 'boom' });
      expect(ctx.store.listFires()).toHaveLength(3);
    } finally {
      await ctx.close();
    }
  });

  it('posts Telegram messages and custom webhook headers', async () => {
    const ctx = await createTestApp({
      telegramApiBase: baseUrl,
      alerts: {
        rules: [
          {
            id: 'telegram-any',
            enabled: true,
            description: 'Telegram',
            match: { level: 'FATAL' },
            threshold: 0,
            windowSeconds: 60,
            cooldownSeconds: 60,
            notify: [
              { type: 'telegram', botToken: '123:ABC', chatId: '42' },
              webhook('/hook', { 'X-Token': 'secret' }),
            ],
          },
        ],
      },
    });
    try {
      const res = await postLog(ctx, { level: 'FATAL', service: 'edge', message: 'process down' });
      expect(res.statusCode).toBe(201);
      expect(hits).toHaveLength(2);
      const telegram = hits.find((hit) => hit.url === '/bot123:ABC/sendMessage');
      expect(telegram?.body.chat_id).toBe('42');
      expect(telegram?.body.parse_mode).toBe('HTML');
      expect(String(telegram?.body.text)).toContain('process down');
      const hook = hits.find((hit) => hit.url === '/hook');
      expect(hook?.headers['x-token']).toBe('secret');
      expect(String(hook?.headers['user-agent'])).toContain('NexusLog');
    } finally {
      await ctx.close();
    }
  });

  it('reloads alert rules when the file changes', async () => {
    const ctx = await createTestApp({ alerts: { rules: [] } });
    try {
      await postLog(ctx, { level: 'ERROR', service: 'api', message: 'before rules' });
      expect(hits).toHaveLength(0);
      writeFileSync(
        ctx.alertsPath,
        JSON.stringify({
          rules: [
            {
              id: 'late-rule',
              enabled: true,
              description: 'Late',
              match: { level: 'ERROR' },
              threshold: 0,
              windowSeconds: 60,
              cooldownSeconds: 60,
              notify: [webhook()],
            },
          ],
        }),
        'utf8',
      );
      const touched = new Date(Date.now() + 5_000);
      utimesSync(ctx.alertsPath, touched, touched);
      await postLog(ctx, { level: 'ERROR', service: 'api', message: 'after rules' });
      expect(hits).toHaveLength(1);
      expect(hits[0]?.body.ruleId).toBe('late-rule');
    } finally {
      await ctx.close();
    }
  });
});
