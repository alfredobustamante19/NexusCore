import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { LEVEL_LIST } from '../src/levels.js';
import { createTestApp, postLog, TOKEN, type TestContext } from './helpers.js';

describe('ingestion', () => {
  let ctx: TestContext;

  beforeAll(async () => {
    ctx = await createTestApp();
  });

  afterAll(async () => {
    await ctx.close();
  });

  it('rejects missing and invalid credentials', async () => {
    const missing = await ctx.app.inject({
      method: 'POST',
      url: '/api/v1/log',
      payload: { level: 'INFO', service: 'api', message: 'hello' },
    });
    expect(missing.statusCode).toBe(401);
    expect(missing.json()).toEqual({ error: 'Unauthorized' });

    const wrong = await ctx.app.inject({
      method: 'POST',
      url: '/api/v1/log',
      headers: { authorization: 'Bearer definitely-wrong-token' },
      payload: { level: 'INFO', service: 'api', message: 'hello' },
    });
    expect(wrong.statusCode).toBe(401);

    const logs = await ctx.app.inject({ method: 'GET', url: '/api/v1/logs' });
    expect(logs.statusCode).toBe(401);

    const stream = await ctx.app.inject({ method: 'GET', url: '/api/v1/stream' });
    expect(stream.statusCode).toBe(401);
  });

  it('accepts a lowercase bearer scheme', async () => {
    const res = await ctx.app.inject({
      method: 'POST',
      url: '/api/v1/log',
      headers: { authorization: `bearer ${TOKEN}` },
      payload: { level: 'INFO', service: 'api', message: 'lowercase scheme' },
    });
    expect(res.statusCode).toBe(201);
  });

  it('rejects malformed logs', async () => {
    const cases: Array<{ body: unknown; error: string }> = [
      { body: [], error: 'Body must be a JSON object' },
      { body: {}, error: `level must be one of ${LEVEL_LIST}` },
      { body: { level: 'NOPE', service: 'api', message: 'm' }, error: `level must be one of ${LEVEL_LIST}` },
      { body: { level: 'INFO', service: 'api' }, error: 'message is required' },
      { body: { level: 'INFO', service: 'api', message: '   ' }, error: 'message is required' },
      { body: { level: 'INFO', service: '   ', message: 'm' }, error: 'service is required' },
      { body: { level: 'INFO', service: 'bad\nname', message: 'm' }, error: 'service contains invalid characters' },
      { body: { level: 'INFO', service: 'a'.repeat(121), message: 'm' }, error: 'service is too long' },
      { body: { level: 'INFO', service: 'api', message: 'm'.repeat(16_001) }, error: 'message is too long' },
      { body: { level: 'INFO', service: 'api', message: 'm', timestamp: true }, error: 'timestamp must be an ISO-8601 string or unix time' },
      { body: { level: 'INFO', service: 'api', message: 'm', timestamp: 'not-a-date' }, error: 'timestamp is invalid' },
      { body: { level: 'INFO', service: 'api', message: 'm', timestamp: '1999-12-31T00:00:00.000Z' }, error: 'timestamp is out of range' },
      { body: { level: 'INFO', service: 'api', message: 'm', timestamp: '2999-01-01T00:00:00.000Z' }, error: 'timestamp is out of range' },
    ];

    for (const item of cases) {
      const res = await ctx.app.inject({
        method: 'POST',
        url: '/api/v1/log',
        headers: ctx.auth,
        payload: item.body,
      });
      expect(res.statusCode, JSON.stringify(item.body)).toBe(400);
      expect(res.json()).toEqual({ error: item.error });
    }
  });

  it('stores a log and returns its id', async () => {
    const res = await postLog(ctx, {
      level: 'error',
      service: ' billing ',
      message: ' payment failed ',
      payload: { invoice: '42', nested: [1, false] },
      timestamp: 1_700_000_000,
      ignored: 'nope',
    });
    expect(res.statusCode).toBe(201);
    const created = res.json() as { id: number; accepted: boolean };
    expect(created.accepted).toBe(true);
    expect(created.id).toBeGreaterThan(0);

    const found = await ctx.app.inject({
      method: 'GET',
      url: '/api/v1/logs?q=invoice',
      headers: ctx.auth,
    });
    expect(found.statusCode).toBe(200);
    const body = found.json() as { logs: Array<Record<string, unknown>> };
    const log = body.logs.find((entry) => entry.id === created.id);
    expect(log).toMatchObject({
      level: 'ERROR',
      service: 'billing',
      message: 'payment failed',
      payload: { invoice: '42', nested: [1, false] },
      timestamp: new Date(1_700_000_000 * 1000).toISOString(),
    });
    expect(log?.receivedAt).toMatch(/^\d{4}-\d{2}-\d{2}T/);
    expect(log).not.toHaveProperty('ignored');
  });

  it('accepts unix milliseconds and warning aliases', async () => {
    const stamp = 1_700_000_000_123;
    const res = await postLog(ctx, {
      level: 'warning',
      service: 'worker',
      message: 'disk warning',
      timestamp: String(stamp),
      payload: null,
    });
    expect(res.statusCode).toBe(201);
    const created = res.json() as { id: number };
    const found = await ctx.app.inject({
      method: 'GET',
      url: '/api/v1/logs?service=worker&level=WARN',
      headers: ctx.auth,
    });
    const body = found.json() as { logs: Array<{ id: number; timestamp: string; payload: unknown; level: string }> };
    const log = body.logs.find((entry) => entry.id === created.id);
    expect(log?.level).toBe('WARN');
    expect(log?.payload).toBeNull();
    expect(log?.timestamp).toBe(new Date(stamp).toISOString());
  });

  it('issues an httpOnly session cookie and accepts it on later requests', async () => {
    const login = await ctx.app.inject({
      method: 'POST',
      url: '/api/v1/session',
      payload: { token: TOKEN },
    });
    expect(login.statusCode).toBe(200);
    expect(login.json()).toEqual({ authenticated: true });
    const setCookie = login.headers['set-cookie'];
    const cookie = (Array.isArray(setCookie) ? setCookie[0] : setCookie) ?? '';
    expect(cookie).toContain('HttpOnly');
    expect(cookie).toContain('SameSite=Strict');
    const pair = cookie.split(';')[0] ?? '';

    const session = await ctx.app.inject({
      method: 'GET',
      url: '/api/v1/session',
      headers: { cookie: pair },
    });
    expect(session.statusCode).toBe(200);

    const logs = await ctx.app.inject({
      method: 'GET',
      url: '/api/v1/logs',
      headers: { cookie: pair },
    });
    expect(logs.statusCode).toBe(200);

    const logout = await ctx.app.inject({
      method: 'POST',
      url: '/api/v1/logout',
      headers: { cookie: pair },
    });
    expect(logout.statusCode).toBe(200);
    expect(String(logout.headers['set-cookie'])).toContain('Max-Age=0');
  });

  it('rejects a bad login without setting a cookie', async () => {
    const res = await ctx.app.inject({
      method: 'POST',
      url: '/api/v1/session',
      payload: { token: 'not-the-real-token-value' },
    });
    expect(res.statusCode).toBe(401);
    expect(res.headers['set-cookie']).toBeUndefined();
  });

  it('serves the dashboard shell without embedding the token', async () => {
    const page = await ctx.app.inject({ method: 'GET', url: '/' });
    expect(page.statusCode).toBe(200);
    expect(String(page.headers['content-type'])).toContain('text/html');
    expect(page.body).toContain('NexusLog');
    expect(page.body).toContain('https://cdn.tailwindcss.com');
    expect(page.body).toContain('id="search"');
    expect(page.body).toContain('textContent');
    expect(page.body).not.toContain('innerHTML');
    expect(page.body).not.toContain(TOKEN);
    expect(String(page.headers['content-security-policy'])).toContain('cdn.tailwindcss.com');
    expect(String(page.headers['x-frame-options'])).toBe('DENY');

    const health = await ctx.app.inject({ method: 'GET', url: '/healthz' });
    expect(health.statusCode).toBe(200);
    expect(health.json()).toEqual({ ok: true });
    expect(health.body).not.toContain(TOKEN);

    const missing = await ctx.app.inject({ method: 'GET', url: '/missing' });
    expect(missing.statusCode).toBe(404);
  });

  it('rate limits ingestion per client', async () => {
    const limited = await createTestApp({ rateLimitPerMinute: 2 });
    try {
      expect((await postLog(limited, { level: 'INFO', service: 'api', message: 'one' })).statusCode).toBe(201);
      expect((await postLog(limited, { level: 'INFO', service: 'api', message: 'two' })).statusCode).toBe(201);
      const blocked = await postLog(limited, { level: 'INFO', service: 'api', message: 'three' });
      expect(blocked.statusCode).toBe(429);
      expect(blocked.json()).toEqual({ error: 'Rate limit exceeded' });
      expect(blocked.headers['retry-after']).toBe('60');
    } finally {
      await limited.close();
    }
  });
});
