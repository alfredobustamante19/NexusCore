import type { LogStore } from './db.js';
import type { MiniLogger } from './types.js';

export function startRetentionJob(
  store: LogStore,
  retentionDays: number,
  intervalMinutes: number,
  log: MiniLogger = console,
): () => void {
  const run = (): void => {
    try {
      const removed = store.purgeOlderThan(retentionDays);
      if (removed > 0) log.info(`Purged ${removed} expired log${removed === 1 ? '' : 's'}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      log.error(`Retention purge failed: ${message}`);
    }
  };

  run();
  const timer = setInterval(run, intervalMinutes * 60_000);
  timer.unref?.();
  return () => clearInterval(timer);
}
