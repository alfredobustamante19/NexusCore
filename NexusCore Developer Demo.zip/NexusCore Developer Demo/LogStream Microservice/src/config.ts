const PLACEHOLDER_TOKENS = new Set([
  'replace-with-a-long-random-token',
  'change-me-please-now',
]);

const LOG_LEVELS = new Set(['trace', 'debug', 'info', 'warn', 'error', 'fatal', 'silent']);

export interface Config {
  host: string;
  port: number;
  token: string;
  dbPath: string;
  retentionDays: number;
  cleanupIntervalMinutes: number;
  alertsPath: string;
  bodyLimitBytes: number;
  rateLimitPerMinute: number;
  sseMaxClients: number;
  cookieSecure: boolean;
  logLevel: string;
}

function requiredInt(
  env: NodeJS.ProcessEnv,
  key: string,
  fallback: number,
  min: number,
  max: number,
): number {
  const raw = env[key];
  if (raw == null || raw.trim() === '') return fallback;
  if (!/^-?\d+$/.test(raw.trim())) {
    throw new Error(`${key} must be an integer between ${min} and ${max}`);
  }
  const value = Number(raw);
  if (!Number.isInteger(value) || value < min || value > max) {
    throw new Error(`${key} must be an integer between ${min} and ${max}`);
  }
  return value;
}

function flag(env: NodeJS.ProcessEnv, key: string): boolean {
  const value = (env[key] ?? '').trim().toLowerCase();
  return value === '1' || value === 'true' || value === 'yes';
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const token = (env.NEXUS_TOKEN ?? '').trim();
  if (!token) {
    throw new Error('NEXUS_TOKEN is required');
  }
  if (token.length < 16 || token.length > 512) {
    throw new Error('NEXUS_TOKEN must be between 16 and 512 characters');
  }
  if (PLACEHOLDER_TOKENS.has(token)) {
    throw new Error('NEXUS_TOKEN is still the example placeholder. Generate a unique token.');
  }

  const host = (env.HOST ?? '127.0.0.1').trim() || '127.0.0.1';
  const dbPath = (env.DB_PATH ?? './data/nexuslog.sqlite').trim();
  if (!dbPath) throw new Error('DB_PATH is required');
  const alertsPath = (env.ALERTS_PATH ?? './alerts.json').trim();
  if (!alertsPath) throw new Error('ALERTS_PATH is required');

  const logLevel = (env.LOG_LEVEL ?? 'info').trim().toLowerCase() || 'info';
  if (!LOG_LEVELS.has(logLevel)) {
    throw new Error('LOG_LEVEL must be trace, debug, info, warn, error, fatal, or silent');
  }

  return {
    host,
    port: requiredInt(env, 'PORT', 8787, 1, 65535),
    token,
    dbPath,
    retentionDays: requiredInt(env, 'LOG_RETENTION_DAYS', 14, 1, 3650),
    cleanupIntervalMinutes: requiredInt(env, 'CLEANUP_INTERVAL_MINUTES', 60, 1, 1440),
    alertsPath,
    bodyLimitBytes: requiredInt(env, 'BODY_LIMIT_BYTES', 262_144, 1024, 2_000_000),
    rateLimitPerMinute: requiredInt(env, 'RATE_LIMIT_PER_MINUTE', 300, 0, 100_000),
    sseMaxClients: requiredInt(env, 'SSE_MAX_CLIENTS', 100, 1, 10_000),
    cookieSecure: flag(env, 'COOKIE_SECURE'),
    logLevel,
  };
}
