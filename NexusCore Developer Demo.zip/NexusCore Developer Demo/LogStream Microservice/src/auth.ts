import { createHash, timingSafeEqual } from 'node:crypto';

export const SESSION_COOKIE = 'nexus_session';

export function tokensMatch(provided: string, expected: string): boolean {
  const left = createHash('sha256').update(provided).digest();
  const right = createHash('sha256').update(expected).digest();
  return timingSafeEqual(left, right);
}

export function readCookie(header: string | undefined, name: string): string | undefined {
  if (!header) return undefined;
  for (const part of header.split(';')) {
    const trimmed = part.trim();
    const eq = trimmed.indexOf('=');
    if (eq <= 0) continue;
    if (trimmed.slice(0, eq) !== name) continue;
    try {
      return decodeURIComponent(trimmed.slice(eq + 1));
    } catch {
      return undefined;
    }
  }
  return undefined;
}

export function extractToken(
  authorization: string | undefined,
  cookieHeader: string | undefined,
): string | undefined {
  if (authorization !== undefined) {
    const match = /^Bearer\s+(\S+)\s*$/i.exec(authorization.trim());
    return match?.[1];
  }
  const cookie = readCookie(cookieHeader, SESSION_COOKIE);
  return cookie || undefined;
}

export function isAuthorized(
  authorization: string | undefined,
  cookieHeader: string | undefined,
  expected: string,
): boolean {
  const provided = extractToken(authorization, cookieHeader);
  if (!provided) return false;
  return tokensMatch(provided, expected);
}

export function serializeSessionCookie(token: string, secure: boolean, maxAgeSeconds: number): string {
  const parts = [
    `${SESSION_COOKIE}=${encodeURIComponent(token)}`,
    'HttpOnly',
    'SameSite=Strict',
    'Path=/',
    `Max-Age=${maxAgeSeconds}`,
  ];
  if (secure) parts.push('Secure');
  return parts.join('; ');
}

export function clearSessionCookie(secure: boolean): string {
  return serializeSessionCookie('', secure, 0);
}
