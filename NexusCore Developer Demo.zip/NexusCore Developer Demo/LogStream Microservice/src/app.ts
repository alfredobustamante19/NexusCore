import Fastify, {
  type FastifyInstance,
  type FastifyReply,
  type FastifyRequest,
  type FastifyServerOptions,
} from 'fastify';
import { AlertEngine } from './alerts.js';
import { clearSessionCookie, isAuthorized, serializeSessionCookie } from './auth.js';
import type { Config } from './config.js';
import type { LogStore } from './db.js';
import { DASHBOARD_HTML } from './dashboard.js';
import { createRateLimiter } from './rateLimit.js';
import { createStreamHub, formatLogEvent, type StreamClient } from './stream.js';
import type { MiniLogger } from './types.js';
import { parseLogBody, parseSearchQuery } from './validate.js';

const SESSION_MAX_AGE = 7 * 24 * 60 * 60;

export interface CreateAppOptions {
  config: Config;
  store: LogStore;
  awaitAlerts?: boolean;
  now?: () => number;
  fetchImpl?: typeof fetch;
  telegramApiBase?: string;
  logger?: FastifyServerOptions['logger'];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function unauthorized(reply: FastifyReply): void {
  reply
    .code(401)
    .header('WWW-Authenticate', 'Bearer realm="NexusLog"')
    .send({ error: 'Unauthorized' });
}

export function createApp(options: CreateAppOptions): FastifyInstance {
  const { config, store } = options;
  const now = options.now ?? (() => Date.now());
  const hub = createStreamHub(config.sseMaxClients);
  const ingestLimit = createRateLimiter(config.rateLimitPerMinute);
  const sessionLimit = createRateLimiter(
    config.rateLimitPerMinute === 0 ? 0 : Math.min(30, config.rateLimitPerMinute),
  );

  const app = Fastify({
    logger: options.logger ?? false,
    bodyLimit: config.bodyLimitBytes,
    trustProxy: false,
  });

  const log: MiniLogger = {
    info(message) {
      app.log.info(message);
    },
    warn(message) {
      app.log.warn(message);
    },
    error(message) {
      app.log.error(message);
    },
  };

  const engine = new AlertEngine({
    store,
    alertsPath: config.alertsPath,
    now,
    fetchImpl: options.fetchImpl,
    telegramApiBase: options.telegramApiBase,
    log,
  });

  app.addHook('onRequest', async (_req, reply) => {
    reply.header('X-Content-Type-Options', 'nosniff');
    reply.header('X-Frame-Options', 'DENY');
    reply.header('Referrer-Policy', 'no-referrer');
    reply.header('X-DNS-Prefetch-Control', 'off');
    reply.header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    reply.header('Cross-Origin-Opener-Policy', 'same-origin');
    reply.header('Cross-Origin-Resource-Policy', 'same-origin');
  });

  app.addHook('onClose', async () => {
    hub.close();
    ingestLimit.stop();
    sessionLimit.stop();
  });

  app.setErrorHandler((err, req, reply) => {
    const error = err instanceof Error ? err : new Error('Internal server error');
    const statusCode = typeof err === 'object' && err && 'statusCode' in err ? Number(err.statusCode) : 500;
    const status = Number.isInteger(statusCode) && statusCode >= 400 && statusCode < 600 ? statusCode : 500;
    if (status >= 500) req.log.error(error);
    const message = status >= 500 ? 'Internal server error' : error.message;
    return reply.code(status).send({ error: message });
  });

  app.setNotFoundHandler((_req, reply) => reply.code(404).send({ error: 'Not found' }));

  const ensureAuth = (req: FastifyRequest, reply: FastifyReply): boolean => {
    if (!isAuthorized(req.headers.authorization, req.headers.cookie, config.token)) {
      unauthorized(reply);
      return false;
    }
    return true;
  };

  app.get('/healthz', async () => ({ ok: true }));

  app.get('/robots.txt', async (_req, reply) => {
    return reply.type('text/plain; charset=utf-8').send('User-agent: *\nDisallow: /\n');
  });

  app.get('/', async (_req, reply) => {
    return reply
      .type('text/html; charset=utf-8')
      .header('Cache-Control', 'no-store')
      .header(
        'Content-Security-Policy',
        [
          "default-src 'self'",
          "script-src 'self' https://cdn.tailwindcss.com 'unsafe-inline' 'unsafe-eval'",
          "style-src 'self' 'unsafe-inline'",
          "connect-src 'self' https://cdn.tailwindcss.com",
          "img-src 'self' data:",
          "font-src 'self'",
          "frame-ancestors 'none'",
          "base-uri 'self'",
          "form-action 'self'",
        ].join('; '),
      )
      .send(DASHBOARD_HTML);
  });

  app.get('/api/v1/session', async (req, reply) => {
    if (!ensureAuth(req, reply)) return;
    return reply.send({ authenticated: true });
  });

  app.post('/api/v1/session', async (req, reply) => {
    if (!sessionLimit.allow(req.ip || 'unknown')) {
      return reply.code(429).header('Retry-After', '60').send({ error: 'Rate limit exceeded' });
    }
    const body: unknown = req.body;
    const token = isRecord(body) && typeof body.token === 'string' ? body.token.trim() : '';
    if (!token || !isAuthorized(`Bearer ${token}`, undefined, config.token)) {
      unauthorized(reply);
      return;
    }
    return reply
      .header('Set-Cookie', serializeSessionCookie(token, config.cookieSecure, SESSION_MAX_AGE))
      .send({ authenticated: true });
  });

  app.post('/api/v1/logout', async (req, reply) => {
    if (!ensureAuth(req, reply)) return;
    return reply.header('Set-Cookie', clearSessionCookie(config.cookieSecure)).send({ authenticated: false });
  });

  app.post('/api/v1/log', async (req, reply) => {
    if (!ensureAuth(req, reply)) return;
    if (!ingestLimit.allow(req.ip || 'unknown')) {
      return reply.code(429).header('Retry-After', '60').send({ error: 'Rate limit exceeded' });
    }
    const parsed = parseLogBody(req.body, now());
    if (!parsed.ok) return reply.code(400).send({ error: parsed.error });
    const record = store.insertLog(parsed.value, now());
    hub.broadcast(record);
    const task = engine.onLog(record);
    if (options.awaitAlerts) {
      await task;
    } else {
      task.catch((err: unknown) => {
        const message = err instanceof Error ? err.message : String(err);
        req.log.error(`Alert evaluation failed: ${message}`);
      });
    }
    return reply.code(201).send({ id: record.id, accepted: true });
  });

  app.get('/api/v1/logs', async (req, reply) => {
    if (!ensureAuth(req, reply)) return;
    const parsed = parseSearchQuery(req.query);
    if (!parsed.ok) return reply.code(400).send({ error: parsed.error });
    let logs;
    try {
      logs = store.search(parsed.value);
    } catch {
      return reply.code(400).send({ error: 'q could not be parsed' });
    }
    const oldest = logs.at(-1);
    return reply.send({
      logs,
      nextBefore: logs.length === parsed.value.limit && oldest ? oldest.id : null,
    });
  });

  app.get('/api/v1/services', async (req, reply) => {
    if (!ensureAuth(req, reply)) return;
    return reply.send({ services: store.listServices() });
  });

  app.get('/api/v1/stream', (req, reply) => {
    if (!ensureAuth(req, reply)) return;
    if (hub.size() >= config.sseMaxClients) {
      reply.code(503).send({ error: 'Stream capacity reached' });
      return;
    }

    reply.hijack();
    const raw = reply.raw;
    raw.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'no-referrer',
    });

    const client: StreamClient = {
      write(chunk: string) {
        return raw.write(chunk);
      },
    };
    hub.add(client);
    raw.write('retry: 3000\n\n');
    raw.write('event: hello\ndata: {"ok":true}\n\n');

    const lastHeader = req.headers['last-event-id'];
    const lastRaw = Array.isArray(lastHeader) ? lastHeader[0] : lastHeader;
    const lastId = Number(lastRaw);
    if (typeof lastRaw === 'string' && lastRaw.trim() !== '' && Number.isSafeInteger(lastId) && lastId >= 0) {
      for (const log of store.logsAfter(lastId, 200)) raw.write(formatLogEvent(log));
    }

    const detach = (): void => {
      hub.remove(client);
    };
    req.raw.on('close', detach);
    req.raw.on('error', detach);
    return;
  });

  return app;
}
