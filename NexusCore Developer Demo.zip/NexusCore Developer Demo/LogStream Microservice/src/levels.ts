export const LEVELS = ['TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL'] as const;

export type Level = (typeof LEVELS)[number];

export const LEVEL_LIST = LEVELS.join(', ');

const ALIASES: Readonly<Record<string, Level>> = {
  WARNING: 'WARN',
  ERR: 'ERROR',
};

export function normalizeLevel(input: string): Level | null {
  const key = input.trim().toUpperCase();
  if ((LEVELS as readonly string[]).includes(key)) return key as Level;
  return ALIASES[key] ?? null;
}
