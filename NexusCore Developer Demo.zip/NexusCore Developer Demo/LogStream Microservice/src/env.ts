import { readFileSync } from 'node:fs';

function unquote(value: string): string {
  if (value.length >= 2) {
    const first = value[0];
    const last = value[value.length - 1];
    if ((first === '"' && last === '"') || (first === "'" && last === "'")) {
      return value.slice(1, -1);
    }
  }
  return value;
}

/**
 * Loads KEY=VALUE pairs into `target` without overriding keys that are already set.
 * Missing files are ignored. Full-line comments (#) and optional `export ` prefixes are supported.
 */
export function loadEnvFile(file: string, target: NodeJS.ProcessEnv = process.env): void {
  let text: string;
  try {
    text = readFileSync(file, 'utf8');
  } catch (err) {
    const code = (err as NodeJS.ErrnoException).code;
    if (code === 'ENOENT') return;
    throw err;
  }

  text = text.replace(/^\uFEFF/, '');
  for (const rawLine of text.split(/\r?\n/)) {
    let line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    if (line.startsWith('export ')) line = line.slice('export '.length).trim();
    const eq = line.indexOf('=');
    if (eq <= 0) continue;
    const key = line.slice(0, eq).trim();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
    if (target[key] !== undefined) continue;
    target[key] = unquote(line.slice(eq + 1).trim());
  }
}
