import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import Database from 'better-sqlite3';
import type { AlertFire, AlertMatch, AlertSample, AlertState, PublicLog, SearchParams, ServiceCount, ValidLog } from './types.js';

interface LogRow {
  id: number;
  level: string;
  service: string;
  message: string;
  payload: string | null;
  timestamp: number;
  received_at: number;
}

interface CountRow {
  c: number;
}

interface ServiceRow {
  service: string;
  count: number;
}

interface FireRow {
  id: number;
  rule_id: string;
  fired_at: number;
  count: number;
  summary: string;
}

interface StateRow {
  last_fired_at: number;
  last_count: number;
}

const SCHEMA = `
CREATE TABLE IF NOT EXISTS logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  level TEXT NOT NULL,
  service TEXT NOT NULL,
  message TEXT NOT NULL,
  payload TEXT,
  timestamp INTEGER NOT NULL,
  received_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_logs_received ON logs(received_at);
CREATE INDEX IF NOT EXISTS idx_logs_level_received ON logs(level, received_at);
CREATE INDEX IF NOT EXISTS idx_logs_service_received ON logs(service, received_at);
CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp);

CREATE TABLE IF NOT EXISTS alert_state (
  rule_id TEXT PRIMARY KEY,
  last_fired_at INTEGER NOT NULL,
  last_count INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS alert_fires (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_id TEXT NOT NULL,
  fired_at INTEGER NOT NULL,
  count INTEGER NOT NULL,
  summary TEXT NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS logs_fts USING fts5(
  message,
  service,
  payload,
  content='logs',
  content_rowid='id',
  tokenize="unicode61"
);

CREATE TRIGGER IF NOT EXISTS logs_ai AFTER INSERT ON logs BEGIN
  INSERT INTO logs_fts(rowid, message, service, payload)
  VALUES (new.id, new.message, new.service, coalesce(new.payload, ''));
END;

CREATE TRIGGER IF NOT EXISTS logs_ad AFTER DELETE ON logs BEGIN
  INSERT INTO logs_fts(logs_fts, rowid, message, service, payload)
  VALUES ('delete', old.id, old.message, old.service, coalesce(old.payload, ''));
END;

CREATE TRIGGER IF NOT EXISTS logs_au AFTER UPDATE ON logs BEGIN
  INSERT INTO logs_fts(logs_fts, rowid, message, service, payload)
  VALUES ('delete', old.id, old.message, old.service, coalesce(old.payload, ''));
  INSERT INTO logs_fts(rowid, message, service, payload)
  VALUES (new.id, new.message, new.service, coalesce(new.payload, ''));
END;
`;

function encodePayload(payload: unknown): string | null {
  if (payload === undefined || payload === null) return null;
  return JSON.stringify(payload);
}

function decodePayload(payload: string | null): unknown {
  if (payload == null) return null;
  try {
    return JSON.parse(payload) as unknown;
  } catch {
    return null;
  }
}

function toPublic(row: LogRow): PublicLog {
  return {
    id: row.id,
    level: row.level,
    service: row.service,
    message: row.message,
    payload: decodePayload(row.payload),
    timestamp: new Date(row.timestamp).toISOString(),
    receivedAt: new Date(row.received_at).toISOString(),
  };
}

function toSample(row: Pick<LogRow, 'id' | 'level' | 'service' | 'message' | 'timestamp'>): AlertSample {
  return {
    id: row.id,
    level: row.level,
    service: row.service,
    message: row.message,
    timestamp: new Date(row.timestamp).toISOString(),
  };
}

export class LogStore {
  private readonly db: Database.Database;
  private readonly cache = new Map<string, Database.Statement>();
  private readonly insertStmt: Database.Statement;
  private readonly afterStmt: Database.Statement;
  private readonly servicesStmt: Database.Statement;
  private readonly stateGetStmt: Database.Statement;
  private readonly stateSetStmt: Database.Statement;
  private readonly fireStmt: Database.Statement;
  private readonly firesStmt: Database.Statement;

  constructor(db: Database.Database) {
    this.db = db;
    this.insertStmt = db.prepare(
      `INSERT INTO logs (level, service, message, payload, timestamp, received_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
    );
    this.afterStmt = db.prepare(
      `SELECT id, level, service, message, payload, timestamp, received_at
       FROM logs WHERE id > ? ORDER BY id ASC LIMIT ?`,
    );
    this.servicesStmt = db.prepare(
      `SELECT service, COUNT(*) AS count
       FROM logs
       GROUP BY service
       ORDER BY count DESC, service ASC
       LIMIT 200`,
    );
    this.stateGetStmt = db.prepare(
      `SELECT last_fired_at, last_count FROM alert_state WHERE rule_id = ?`,
    );
    this.stateSetStmt = db.prepare(
      `INSERT INTO alert_state (rule_id, last_fired_at, last_count)
       VALUES (?, ?, ?)
       ON CONFLICT(rule_id) DO UPDATE SET
         last_fired_at = excluded.last_fired_at,
         last_count = excluded.last_count`,
    );
    this.fireStmt = db.prepare(
      `INSERT INTO alert_fires (rule_id, fired_at, count, summary) VALUES (?, ?, ?, ?)`,
    );
    this.firesStmt = db.prepare(
      `SELECT id, rule_id, fired_at, count, summary FROM alert_fires ORDER BY id DESC LIMIT ?`,
    );
  }

  private stmt(sql: string): Database.Statement {
    const existing = this.cache.get(sql);
    if (existing) return existing;
    const prepared = this.db.prepare(sql);
    this.cache.set(sql, prepared);
    return prepared;
  }

  insertLog(input: ValidLog, receivedAt: number): PublicLog {
    const payload = encodePayload(input.payload);
    const info = this.insertStmt.run(
      input.level,
      input.service,
      input.message,
      payload,
      input.timestamp,
      receivedAt,
    );
    return {
      id: Number(info.lastInsertRowid),
      level: input.level,
      service: input.service,
      message: input.message,
      payload: input.payload ?? null,
      timestamp: new Date(input.timestamp).toISOString(),
      receivedAt: new Date(receivedAt).toISOString(),
    };
  }

  search(params: SearchParams): PublicLog[] {
    if (params.impossible) return [];
    const where: string[] = [];
    const values: Array<string | number | null> = [];
    const prefix = params.ftsQuery ? 'logs.' : '';

    if (params.ftsQuery) {
      where.push('logs_fts MATCH ?');
      values.push(params.ftsQuery);
    }
    where.push(`(? IS NULL OR ${prefix}service = ?)`);
    values.push(params.service, params.service);
    where.push(`(? IS NULL OR ${prefix}level = ?)`);
    values.push(params.level, params.level);
    where.push(`(? IS NULL OR ${prefix}id < ?)`);
    values.push(params.beforeId, params.beforeId);

    const sql = params.ftsQuery
      ? `SELECT logs.id, logs.level, logs.service, logs.message, logs.payload, logs.timestamp, logs.received_at
         FROM logs
         JOIN logs_fts ON logs_fts.rowid = logs.id
         WHERE ${where.join(' AND ')}
         ORDER BY logs.id DESC
         LIMIT ?`
      : `SELECT id, level, service, message, payload, timestamp, received_at
         FROM logs
         WHERE ${where.join(' AND ')}
         ORDER BY id DESC
         LIMIT ?`;
    values.push(params.limit);
    const rows = this.stmt(sql).all(...values) as LogRow[];
    return rows.map(toPublic);
  }

  logsAfter(id: number, limit: number): PublicLog[] {
    const rows = this.afterStmt.all(id, limit) as LogRow[];
    return rows.map(toPublic);
  }

  listServices(): ServiceCount[] {
    const rows = this.servicesStmt.all() as ServiceRow[];
    return rows.map((row) => ({ service: row.service, count: row.count }));
  }

  countMatching(match: AlertMatch, since: number): number {
    const { sql, values } = matchFilter(match, since);
    const row = this.stmt(`SELECT COUNT(*) AS c FROM logs WHERE ${sql}`).get(...values) as CountRow;
    return row.c;
  }

  sampleMatching(match: AlertMatch, since: number, limit: number): AlertSample[] {
    const { sql, values } = matchFilter(match, since);
    values.push(limit);
    const rows = this.stmt(
      `SELECT id, level, service, message, timestamp FROM logs WHERE ${sql} ORDER BY id DESC LIMIT ?`,
    ).all(...values) as Array<Pick<LogRow, 'id' | 'level' | 'service' | 'message' | 'timestamp'>>;
    return rows.map(toSample);
  }

  getAlertState(ruleId: string): AlertState | null {
    const row = this.stateGetStmt.get(ruleId) as StateRow | undefined;
    if (!row) return null;
    return { lastFiredAt: row.last_fired_at, lastCount: row.last_count };
  }

  setAlertState(ruleId: string, lastFiredAt: number, lastCount: number): void {
    this.stateSetStmt.run(ruleId, lastFiredAt, lastCount);
  }

  recordFire(ruleId: string, firedAt: number, count: number, summary: string): void {
    this.fireStmt.run(ruleId, firedAt, count, summary);
  }

  listFires(limit = 20): AlertFire[] {
    const rows = this.firesStmt.all(limit) as FireRow[];
    return rows.map((row) => ({
      id: row.id,
      ruleId: row.rule_id,
      firedAt: row.fired_at,
      count: row.count,
      summary: row.summary,
    }));
  }

  purgeOlderThan(days: number, now = Date.now()): number {
    const cutoff = now - days * 86_400_000;
    const deleted = this.db
      .prepare('DELETE FROM logs WHERE timestamp < ? OR received_at < ?')
      .run(cutoff, cutoff);
    this.db.prepare('DELETE FROM alert_fires WHERE fired_at < ?').run(cutoff);
    try {
      this.db.pragma('incremental_vacuum');
    } catch {
      // Databases created without incremental auto_vacuum ignore this cleanup.
    }
    return deleted.changes;
  }

  close(): void {
    this.db.pragma('wal_checkpoint(TRUNCATE)');
    this.db.close();
  }
}

function matchFilter(match: AlertMatch, since: number): { sql: string; values: Array<string | number | null> } {
  const values: Array<string | number | null> = [since];
  const clauses = ['received_at >= ?'];
  clauses.push('(? IS NULL OR level = ?)');
  values.push(match.level, match.level);
  clauses.push('(? IS NULL OR service = ?)');
  values.push(match.service, match.service);
  clauses.push('(? IS NULL OR instr(lower(message), ?) > 0)');
  values.push(match.messageIncludes, match.messageIncludes?.toLowerCase() ?? null);
  return { sql: clauses.join(' AND '), values };
}

export function openDatabase(file: string): LogStore {
  if (file !== ':memory:') {
    mkdirSync(dirname(file), { recursive: true });
  }
  const db = new Database(file);
  db.pragma('busy_timeout = 4000');
  const existing = db.prepare("SELECT 1 AS ok FROM sqlite_master WHERE type = 'table' AND name = 'logs'").get();
  if (!existing) {
    db.pragma('auto_vacuum = INCREMENTAL');
  }
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('temp_store = MEMORY');
  db.pragma('cache_size = -2000');
  db.exec(SCHEMA);
  return new LogStore(db);
}
