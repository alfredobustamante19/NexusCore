export const DASHBOARD_HTML = `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="dark">
  <meta name="theme-color" content="#09090b">
  <title>NexusLog</title>
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Crect width='16' height='16' rx='3' fill='%2310b981'/%3E%3C/svg%3E">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          fontFamily: {
            sans: ['Segoe UI', 'ui-sans-serif', 'system-ui', 'sans-serif'],
            mono: ['Cascadia Code', 'ui-monospace', 'SFMono-Regular', 'monospace']
          }
        }
      }
    };
  </script>
  <style>
    :root { color-scheme: dark; }
    body { margin: 0; background: #09090b; color: #f4f4f5; font-family: "Segoe UI", sans-serif; }
    .is-hidden { display: none !important; }
    button, input, select { font: inherit; color: inherit; }
    #stream { overflow: auto; }
  </style>
</head>
<body class="min-h-screen bg-zinc-950 text-zinc-100 antialiased">
  <div id="login" class="flex min-h-screen items-center justify-center px-4">
    <form id="login-form" class="w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-900 p-8 shadow-2xl shadow-black/40">
      <div class="mb-6 flex items-center gap-3">
        <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/15 font-semibold text-emerald-400">N</div>
        <div>
          <h1 class="text-xl font-semibold tracking-tight">NexusLog</h1>
          <p class="text-sm text-zinc-400">Sign in with your access token</p>
        </div>
      </div>
      <label class="mb-2 block text-sm text-zinc-300" for="token">Access token</label>
      <input id="token" name="token" type="password" autocomplete="current-password" required class="w-full rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none ring-emerald-500/40 focus:border-emerald-500 focus:ring-2">
      <p id="login-error" class="is-hidden mt-3 text-sm text-red-400" role="alert"></p>
      <button id="login-submit" class="mt-6 w-full rounded-lg bg-emerald-500 px-3 py-2 text-sm font-semibold text-zinc-950 hover:bg-emerald-400 disabled:opacity-60" type="submit">Enter dashboard</button>
      <noscript><p class="mt-4 text-sm text-amber-300">NexusLog needs JavaScript to show the live dashboard.</p></noscript>
    </form>
  </div>

  <div id="app" class="is-hidden flex min-h-screen flex-col">
    <header class="border-b border-zinc-800 bg-zinc-950/90 px-4 py-3">
      <div class="mx-auto flex max-w-7xl items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/15 font-semibold text-emerald-400">N</div>
          <div>
            <h1 class="text-base font-semibold tracking-tight">NexusLog</h1>
            <p class="text-xs text-zinc-500">Live log tail</p>
          </div>
        </div>
        <div class="flex items-center gap-2 text-xs text-zinc-400">
          <span id="status-dot" class="h-2 w-2 rounded-full bg-zinc-600"></span>
          <span id="status-text" role="status">Connecting</span>
        </div>
      </div>
    </header>

    <main class="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-4 px-4 py-4">
      <section class="grid gap-3 md:grid-cols-4">
        <div>
          <label class="mb-1 block text-xs uppercase tracking-wide text-zinc-500" for="level">Level</label>
          <select id="level" class="w-full rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm outline-none focus:border-emerald-500">
            <option value="">All levels</option>
            <option>TRACE</option>
            <option>DEBUG</option>
            <option>INFO</option>
            <option>WARN</option>
            <option>ERROR</option>
            <option>FATAL</option>
          </select>
        </div>
        <div>
          <label class="mb-1 block text-xs uppercase tracking-wide text-zinc-500" for="service">Service</label>
          <select id="service" class="w-full rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 text-sm outline-none focus:border-emerald-500">
            <option value="">All services</option>
          </select>
        </div>
        <div class="md:col-span-2">
          <label class="mb-1 block text-xs uppercase tracking-wide text-zinc-500" for="search">Search</label>
          <input id="search" type="search" placeholder="Search messages, services, payloads" autocomplete="off" spellcheck="false" class="w-full rounded-lg border border-zinc-800 bg-zinc-900 px-3 py-2 font-mono text-sm outline-none focus:border-emerald-500">
        </div>
      </section>

      <section class="flex min-h-0 flex-1 flex-col overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900/40">
        <div class="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-800 px-4 py-2 text-xs text-zinc-400">
          <span id="count-label">0 events</span>
          <div class="flex flex-wrap items-center gap-2">
            <button id="jump" type="button" class="is-hidden rounded-md bg-emerald-500/15 px-2 py-1 font-medium text-emerald-300">Latest</button>
            <button id="pause" type="button" class="rounded-md border border-zinc-700 px-2 py-1 hover:bg-zinc-800">Pause</button>
            <button id="clear" type="button" class="rounded-md border border-zinc-700 px-2 py-1 hover:bg-zinc-800">Clear view</button>
            <button id="logout" type="button" class="rounded-md border border-zinc-700 px-2 py-1 hover:bg-zinc-800">Sign out</button>
          </div>
        </div>
        <div id="stream" class="h-[calc(100vh-16rem)] min-h-80">
          <p id="empty" class="px-4 py-8 text-sm text-zinc-500">Waiting for logs.</p>
          <div id="rows"></div>
        </div>
      </section>
      <p class="text-xs text-zinc-600">Press / to focus search. The view keeps the latest 500 lines.</p>
    </main>
  </div>

  <script>
    var loginEl = document.getElementById('login');
    var appEl = document.getElementById('app');
    var loginForm = document.getElementById('login-form');
    var tokenInput = document.getElementById('token');
    var loginError = document.getElementById('login-error');
    var submitBtn = document.getElementById('login-submit');
    var levelSelect = document.getElementById('level');
    var serviceSelect = document.getElementById('service');
    var searchInput = document.getElementById('search');
    var stream = document.getElementById('stream');
    var rows = document.getElementById('rows');
    var emptyEl = document.getElementById('empty');
    var countLabel = document.getElementById('count-label');
    var statusDot = document.getElementById('status-dot');
    var statusText = document.getElementById('status-text');
    var pauseBtn = document.getElementById('pause');
    var clearBtn = document.getElementById('clear');
    var logoutBtn = document.getElementById('logout');
    var jumpBtn = document.getElementById('jump');

    var state = { level: '', service: '', q: '', paused: false };
    var es = null;
    var allowStream = false;
    var servicesTimer = 0;
    var serviceRefreshTimer = 0;
    var reloadTimer = 0;
    var reqToken = 0;
    var seen = new Set();
    var order = [];
    var pending = 0;
    var bulk = false;

    var levelClass = {
      TRACE: 'text-zinc-400 bg-zinc-800',
      DEBUG: 'text-zinc-300 bg-zinc-800',
      INFO: 'text-sky-300 bg-sky-500/10',
      WARN: 'text-amber-300 bg-amber-500/10',
      ERROR: 'text-red-300 bg-red-500/10',
      FATAL: 'text-rose-200 bg-rose-500/15'
    };
    var levelBorder = {
      TRACE: 'border-l-zinc-700',
      DEBUG: 'border-l-zinc-600',
      INFO: 'border-l-sky-500',
      WARN: 'border-l-amber-400',
      ERROR: 'border-l-red-500',
      FATAL: 'border-l-rose-400'
    };

    function el(tag, className) {
      var node = document.createElement(tag);
      if (className) node.className = className;
      return node;
    }

    function formatTime(iso) {
      var d = new Date(iso);
      if (Number.isNaN(d.getTime())) return String(iso);
      function pad(n) { return String(n).padStart(2, '0'); }
      return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    }

    function emptyMessage() {
      if (state.level || state.service || state.q) return 'No logs match these filters.';
      return 'Waiting for logs.';
    }

    function updateCount() {
      var n = rows.childElementCount;
      countLabel.textContent = n + (n === 1 ? ' event' : ' events');
      emptyEl.textContent = emptyMessage();
      if (n === 0) emptyEl.classList.remove('is-hidden');
      else emptyEl.classList.add('is-hidden');
    }

    function hideJump() {
      pending = 0;
      jumpBtn.classList.add('is-hidden');
    }

    function nearBottom() {
      return stream.scrollHeight - stream.scrollTop - stream.clientHeight < 48;
    }

    function remember(id) {
      if (seen.has(id)) return false;
      seen.add(id);
      order.push(id);
      while (order.length > 2000) seen.delete(order.shift());
      return true;
    }

    function passes(log) {
      if (state.level && log.level !== state.level) return false;
      if (state.service && log.service !== state.service) return false;
      if (!state.q) return true;
      var hay = (log.message + ' ' + log.service + ' ' + log.level).toLowerCase();
      if (log.payload !== null && typeof log.payload !== 'undefined') {
        try { hay += ' ' + JSON.stringify(log.payload).toLowerCase(); } catch (err) { hay += ''; }
      }
      var parts = state.q.toLowerCase().split(' ').filter(Boolean);
      for (var i = 0; i < parts.length; i += 1) {
        if (hay.indexOf(parts[i]) === -1) return false;
      }
      return true;
    }

    function renderLog(log) {
      var row = el('article', 'border-b border-l-2 border-zinc-800/80 px-4 py-3 hover:bg-zinc-900/80 ' + (levelBorder[log.level] || 'border-l-zinc-700'));
      var top = el('div', 'mb-1 flex flex-wrap items-center gap-2 text-xs');
      var time = el('time', 'font-mono tabular-nums text-zinc-500');
      time.dateTime = log.timestamp;
      time.title = log.receivedAt || log.timestamp;
      time.textContent = formatTime(log.timestamp);
      var badge = el('span', 'rounded px-1.5 py-0.5 font-medium ' + (levelClass[log.level] || 'bg-zinc-800 text-zinc-300'));
      badge.textContent = log.level;
      var service = el('span', 'font-mono text-emerald-300/90');
      service.textContent = log.service;
      top.append(time, badge, service);
      var message = el('p', 'whitespace-pre-wrap break-words font-mono text-[13px] leading-5 text-zinc-100');
      message.textContent = log.message;
      row.append(top, message);
      if (log.payload !== null && typeof log.payload !== 'undefined') {
        var details = el('details', 'mt-2');
        var summary = el('summary', 'cursor-pointer select-none text-xs text-zinc-500');
        summary.textContent = 'Payload';
        var pre = el('pre', 'mt-2 overflow-x-auto rounded-md bg-zinc-950 p-3 font-mono text-xs leading-5 text-zinc-300');
        var pretty = '';
        try { pretty = JSON.stringify(log.payload, null, 2); } catch (err) { pretty = String(log.payload); }
        if (pretty.length > 8000) pretty = pretty.slice(0, 8000) + ' [truncated]';
        pre.textContent = pretty;
        details.append(summary, pre);
        row.append(details);
      }
      return row;
    }

    function appendLog(log) {
      if (!remember(log.id)) return;
      var stick = bulk || nearBottom();
      rows.appendChild(renderLog(log));
      while (rows.childElementCount > 500) {
        var first = rows.firstChild;
        if (!first) break;
        rows.removeChild(first);
      }
      updateCount();
      if (bulk) return;
      if (stick) {
        stream.scrollTop = stream.scrollHeight;
        hideJump();
      } else {
        pending += 1;
        jumpBtn.textContent = pending + ' new';
        jumpBtn.classList.remove('is-hidden');
      }
    }

    function setOnline(online) {
      if (state.paused) {
        statusText.textContent = 'Paused';
        statusDot.className = 'h-2 w-2 rounded-full bg-amber-400';
        return;
      }
      statusText.textContent = online ? 'Live' : 'Reconnecting';
      statusDot.className = 'h-2 w-2 rounded-full ' + (online ? 'bg-emerald-400' : 'bg-amber-400');
    }

    async function loadServices() {
      var res = await fetch('/api/v1/services', { credentials: 'same-origin' });
      if (res.status === 401) { showLogin(); return; }
      if (!res.ok) return;
      var data = await res.json();
      var current = serviceSelect.value;
      serviceSelect.replaceChildren();
      var all = document.createElement('option');
      all.value = '';
      all.textContent = 'All services';
      serviceSelect.append(all);
      var services = data.services || [];
      for (var i = 0; i < services.length; i += 1) {
        var item = services[i];
        var opt = document.createElement('option');
        opt.value = item.service;
        opt.textContent = item.service + ' (' + item.count + ')';
        serviceSelect.append(opt);
      }
      serviceSelect.value = current;
      if (serviceSelect.value !== current) {
        serviceSelect.value = '';
        state.service = '';
      }
    }

    async function loadLogs() {
      var token = reqToken + 1;
      reqToken = token;
      var params = new URLSearchParams();
      params.set('limit', '200');
      if (state.level) params.set('level', state.level);
      if (state.service) params.set('service', state.service);
      if (state.q) params.set('q', state.q);
      var res = await fetch('/api/v1/logs?' + params.toString(), { credentials: 'same-origin' });
      if (token !== reqToken) return;
      if (res.status === 401) { showLogin(); return; }
      if (!res.ok) {
        emptyEl.textContent = 'Could not load logs.';
        emptyEl.classList.remove('is-hidden');
        return;
      }
      var data = await res.json();
      if (token !== reqToken) return;
      bulk = true;
      seen = new Set();
      order = [];
      hideJump();
      rows.replaceChildren();
      var list = (data.logs || []).slice().reverse();
      for (var i = 0; i < list.length; i += 1) appendLog(list[i]);
      bulk = false;
      stream.scrollTop = stream.scrollHeight;
      updateCount();
    }

    function stopStream() {
      allowStream = false;
      if (es) {
        es.close();
        es = null;
      }
    }

    function noteService(name) {
      if (!name) return;
      var options = serviceSelect.options;
      for (var i = 0; i < options.length; i += 1) {
        if (options[i].value === name) return;
      }
      if (serviceRefreshTimer) return;
      serviceRefreshTimer = setTimeout(function () {
        serviceRefreshTimer = 0;
        loadServices();
      }, 200);
    }

    function startStream() {
      stopStream();
      allowStream = true;
      es = new EventSource('/api/v1/stream');
      es.addEventListener('hello', function () { setOnline(true); });
      es.addEventListener('log', function (ev) {
        if (!allowStream) return;
        try {
          var log = JSON.parse(ev.data);
          noteService(log.service);
          if (state.paused) return;
          if (passes(log)) appendLog(log);
        } catch (err) { return; }
      });
      es.onerror = function () {
        if (allowStream) setOnline(false);
      };
    }

    function showLogin() {
      stopStream();
      if (servicesTimer) clearInterval(servicesTimer);
      servicesTimer = 0;
      if (serviceRefreshTimer) clearTimeout(serviceRefreshTimer);
      serviceRefreshTimer = 0;
      appEl.classList.add('is-hidden');
      loginEl.classList.remove('is-hidden');
      tokenInput.focus();
    }

    async function showApp() {
      loginEl.classList.add('is-hidden');
      appEl.classList.remove('is-hidden');
      await loadServices();
      await loadLogs();
      startStream();
      if (servicesTimer) clearInterval(servicesTimer);
      servicesTimer = setInterval(loadServices, 30000);
    }

    loginForm.addEventListener('submit', async function (ev) {
      ev.preventDefault();
      loginError.classList.add('is-hidden');
      var token = tokenInput.value.trim();
      if (!token) {
        loginError.textContent = 'Enter your access token.';
        loginError.classList.remove('is-hidden');
        return;
      }
      submitBtn.disabled = true;
      try {
        var res = await fetch('/api/v1/session', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ token: token })
        });
        if (!res.ok) {
          loginError.textContent = 'That token was rejected.';
          loginError.classList.remove('is-hidden');
          return;
        }
        tokenInput.value = '';
        await showApp();
      } catch (err) {
        loginError.textContent = 'Could not reach NexusLog.';
        loginError.classList.remove('is-hidden');
      } finally {
        submitBtn.disabled = false;
      }
    });

    levelSelect.addEventListener('change', function () {
      state.level = levelSelect.value;
      loadLogs();
    });
    serviceSelect.addEventListener('change', function () {
      state.service = serviceSelect.value;
      loadLogs();
    });
    searchInput.addEventListener('input', function () {
      state.q = searchInput.value.trim();
      clearTimeout(reloadTimer);
      reloadTimer = setTimeout(loadLogs, 250);
    });
    pauseBtn.addEventListener('click', function () {
      state.paused = !state.paused;
      pauseBtn.textContent = state.paused ? 'Resume' : 'Pause';
      if (state.paused) setOnline(false);
      else {
        setOnline(es && es.readyState === 1);
        loadLogs();
      }
    });
    clearBtn.addEventListener('click', function () {
      seen = new Set();
      order = [];
      hideJump();
      rows.replaceChildren();
      updateCount();
    });
    logoutBtn.addEventListener('click', async function () {
      await fetch('/api/v1/logout', { method: 'POST', credentials: 'same-origin' });
      showLogin();
    });
    jumpBtn.addEventListener('click', function () {
      stream.scrollTop = stream.scrollHeight;
      hideJump();
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key !== '/') return;
      var tag = document.activeElement && document.activeElement.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (appEl.classList.contains('is-hidden')) return;
      ev.preventDefault();
      searchInput.focus();
    });

    async function boot() {
      try {
        var res = await fetch('/api/v1/session', { credentials: 'same-origin' });
        if (res.ok) await showApp();
        else showLogin();
      } catch (err) {
        showLogin();
      }
    }
    boot();
  </script>
</body>
</html>
`;
