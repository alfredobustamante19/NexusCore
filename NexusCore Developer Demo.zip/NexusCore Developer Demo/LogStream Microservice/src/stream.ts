import type { PublicLog } from './types.js';

export interface StreamClient {
  write(chunk: string): boolean;
}

export interface StreamHub {
  add(client: StreamClient): boolean;
  remove(client: StreamClient): void;
  broadcast(log: PublicLog): void;
  size(): number;
  close(): void;
}

export function formatLogEvent(log: PublicLog): string {
  return `id: ${log.id}\nevent: log\ndata: ${JSON.stringify(log)}\n\n`;
}

function writeOrDrop(clients: Set<StreamClient>, client: StreamClient, frame: string): void {
  try {
    client.write(frame);
  } catch {
    clients.delete(client);
  }
}

export function createStreamHub(maxClients: number): StreamHub {
  const clients = new Set<StreamClient>();
  const timer = setInterval(() => {
    const frame = `event: ping\ndata: ${JSON.stringify({ ts: Date.now() })}\n\n`;
    for (const client of clients) writeOrDrop(clients, client, frame);
  }, 15_000);
  timer.unref?.();

  return {
    add(client: StreamClient): boolean {
      if (clients.size >= maxClients) return false;
      clients.add(client);
      return true;
    },
    remove(client: StreamClient): void {
      clients.delete(client);
    },
    broadcast(log: PublicLog): void {
      const frame = formatLogEvent(log);
      for (const client of clients) writeOrDrop(clients, client, frame);
    },
    size(): number {
      return clients.size;
    },
    close(): void {
      clearInterval(timer);
      clients.clear();
    },
  };
}
