import { readFileSync, statSync } from 'node:fs';
import type { LogStore } from './db.js';
import { normalizeLevel, type Level } from './levels.js';
import type {
  AlertMatch,
  AlertRule,
  AlertSample,
  DiscordTarget,
  MiniLogger,
  NotifyTarget,
  PublicLog,
  TelegramTarget,
  WebhookTarget,
} from './types.js';

const HOP_BY_HOP = new Set([
  'host',
  'content-length',
  'content-type',
  'transfer-encoding',
  'connection',
  'keep-alive',
  'upgrade',
  'user-agent',
]);

const silentLogger: MiniLogger = {
  info() {},
  warn() {},
  error() {},
};

export interface AlertEngineOptions {
  store: LogStore;
  alertsPath: string;
  now?: () => number;
  fetchImpl?: typeof fetch;
  telegramApiBase?: string;
  log?: MiniLogger;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function isHttpUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
}

function summaryText(rule: AlertRule, count: number, samples: AlertSample[]): string {
  const lines = [
    `NexusLog alert: ${rule.description}`,
    `${count} matching logs in ${rule.windowSeconds}s (threshold > ${rule.threshold}).`,
  ];
  for (const sample of samples) {
    lines.push(`- [${sample.level}] ${sample.service}: ${sample.message.slice(0, 240)}`);
  }
  return lines.join('\n');
}

function escapeHtml(value: string): string {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}

function headerMap(value: unknown, log: MiniLogger, ruleId: string): Record<string, string> | null {
  if (value == null) return {};
  if (!isRecord(value)) {
    log.warn(`Alert rule ${ruleId} has invalid webhook headers`);
    return null;
  }
  const headers: Record<string, string> = {};
  for (const [name, raw] of Object.entries(value)) {
    if (!/^[A-Za-z0-9-]{1,64}$/.test(name) || HOP_BY_HOP.has(name.toLowerCase())) continue;
    if (typeof raw !== 'string' || raw.length > 512) {
      log.warn(`Alert rule ${ruleId} skipped header ${name}`);
      continue;
    }
    headers[name] = raw;
  }
  return headers;
}

function parseTarget(value: unknown, log: MiniLogger, ruleId: string): NotifyTarget | null {
  if (!isRecord(value) || typeof value.type !== 'string') return null;
  if (value.type === 'webhook' || value.type === 'discord') {
    if (typeof value.url !== 'string' || !isHttpUrl(value.url)) {
      log.warn(`Alert rule ${ruleId} has an invalid ${value.type} URL`);
      return null;
    }
    if (value.type === 'discord') {
      const target: DiscordTarget = { type: 'discord', url: value.url };
      return target;
    }
    const headers = headerMap(value.headers, log, ruleId);
    if (!headers) return null;
    const target: WebhookTarget = { type: 'webhook', url: value.url, headers };
    return target;
  }
  if (value.type === 'telegram') {
    if (typeof value.botToken !== 'string' || !/^\d+:[A-Za-z0-9_-]+$/.test(value.botToken)) {
      log.warn(`Alert rule ${ruleId} has an invalid Telegram bot token`);
      return null;
    }
    if (typeof value.chatId !== 'string' || !/^(?:-?\d+|@[A-Za-z0-9_]{4,})$/.test(value.chatId)) {
      log.warn(`Alert rule ${ruleId} has an invalid Telegram chat id`);
      return null;
    }
    const target: TelegramTarget = { type: 'telegram', botToken: value.botToken, chatId: value.chatId };
    return target;
  }
  log.warn(`Alert rule ${ruleId} has an unknown notifier type`);
  return null;
}

function parseMatch(value: unknown, log: MiniLogger, ruleId: string): AlertMatch | null {
  if (value == null) return { level: null, service: null, messageIncludes: null };
  if (!isRecord(value)) {
    log.warn(`Alert rule ${ruleId} has an invalid match object`);
    return null;
  }
  let level: Level | null = null;
  if (value.level != null && value.level !== '' && value.level !== '*') {
    if (typeof value.level !== 'string') return null;
    level = normalizeLevel(value.level);
    if (!level) {
      log.warn(`Alert rule ${ruleId} has an invalid match level`);
      return null;
    }
  }
  let service: string | null = null;
  if (value.service != null && value.service !== '' && value.service !== '*') {
    if (typeof value.service !== 'string' || value.service.trim().length === 0 || value.service.length > 120) {
      log.warn(`Alert rule ${ruleId} has an invalid match service`);
      return null;
    }
    service = value.service.trim();
  }
  let messageIncludes: string | null = null;
  if (value.messageIncludes != null && value.messageIncludes !== '') {
    if (typeof value.messageIncludes !== 'string' || value.messageIncludes.length > 200) {
      log.warn(`Alert rule ${ruleId} has an invalid messageIncludes`);
      return null;
    }
    messageIncludes = value.messageIncludes;
  }
  return { level, service, messageIncludes };
}

export function parseAlertRules(body: unknown, log: MiniLogger = silentLogger): AlertRule[] {
  if (!isRecord(body) || !Array.isArray(body.rules)) {
    log.error('alerts.json must be an object with a rules array');
    return [];
  }
  const rules: AlertRule[] = [];
  for (const entry of body.rules) {
    if (rules.length >= 20) {
      log.warn('Ignoring alert rules beyond the first 20');
      break;
    }
    if (!isRecord(entry) || typeof entry.id !== 'string' || !/^[A-Za-z0-9._-]{1,64}$/.test(entry.id)) {
      log.warn('Skipping an alert rule with an invalid id');
      continue;
    }
    const threshold = entry.threshold;
    const windowSeconds = entry.windowSeconds;
    const cooldownSeconds = entry.cooldownSeconds ?? 300;
    if (typeof threshold !== 'number' || !Number.isInteger(threshold) || threshold < 0 || threshold > 1_000_000) {
      log.warn(`Alert rule ${entry.id} has an invalid threshold`);
      continue;
    }
    if (
      typeof windowSeconds !== 'number' ||
      !Number.isInteger(windowSeconds) ||
      windowSeconds < 1 ||
      windowSeconds > 86_400
    ) {
      log.warn(`Alert rule ${entry.id} has an invalid windowSeconds`);
      continue;
    }
    if (
      typeof cooldownSeconds !== 'number' ||
      !Number.isInteger(cooldownSeconds) ||
      cooldownSeconds < 0 ||
      cooldownSeconds > 86_400
    ) {
      log.warn(`Alert rule ${entry.id} has an invalid cooldownSeconds`);
      continue;
    }
    const match = parseMatch(entry.match, log, entry.id);
    if (!match) continue;
    if (!Array.isArray(entry.notify)) {
      log.warn(`Alert rule ${entry.id} is missing notify targets`);
      continue;
    }
    const notify: NotifyTarget[] = [];
    for (const target of entry.notify) {
      if (notify.length >= 5) break;
      const parsed = parseTarget(target, log, entry.id);
      if (parsed) notify.push(parsed);
    }
    if (notify.length === 0) {
      log.warn(`Alert rule ${entry.id} has no valid notify targets`);
      continue;
    }
    const description =
      typeof entry.description === 'string' && entry.description.trim()
        ? entry.description.trim().slice(0, 200)
        : entry.id;
    rules.push({
      id: entry.id,
      enabled: entry.enabled !== false,
      description,
      match,
      threshold,
      windowSeconds,
      cooldownSeconds,
      notify,
    });
  }
  return rules;
}

function matches(rule: AlertRule, log: PublicLog): boolean {
  if (rule.match.level && rule.match.level !== log.level) return false;
  if (rule.match.service && rule.match.service !== log.service) return false;
  if (rule.match.messageIncludes) {
    if (!log.message.toLowerCase().includes(rule.match.messageIncludes.toLowerCase())) return false;
  }
  return true;
}

export class AlertEngine {
  private readonly store: LogStore;
  private readonly alertsPath: string;
  private readonly now: () => number;
  private readonly fetchImpl: typeof fetch;
  private readonly telegramApiBase: string;
  private readonly log: MiniLogger;
  private cached: AlertRule[] = [];
  private loadedMtime = Number.NaN;
  private missingWarned = false;

  constructor(options: AlertEngineOptions) {
    this.store = options.store;
    this.alertsPath = options.alertsPath;
    this.now = options.now ?? (() => Date.now());
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.telegramApiBase = (options.telegramApiBase ?? 'https://api.telegram.org').replace(/\/$/, '');
    this.log = options.log ?? silentLogger;
  }

  load(): AlertRule[] {
    let mtime = Number.NaN;
    try {
      mtime = statSync(this.alertsPath).mtimeMs;
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (code === 'ENOENT') {
        if (!this.missingWarned) {
          this.log.warn(`No alert rules loaded. ${this.alertsPath} was not found.`);
          this.missingWarned = true;
        }
        this.cached = [];
        this.loadedMtime = Number.NaN;
        return this.cached;
      }
      this.log.error(`Failed to stat alert rules: ${err instanceof Error ? err.message : String(err)}`);
      return this.cached;
    }

    if (mtime === this.loadedMtime) return this.cached;
    try {
      const parsed: unknown = JSON.parse(readFileSync(this.alertsPath, 'utf8'));
      this.cached = parseAlertRules(parsed, this.log);
      this.loadedMtime = mtime;
      this.missingWarned = false;
    } catch (err) {
      this.log.error(`Failed to read alert rules: ${err instanceof Error ? err.message : String(err)}`);
    }
    return this.cached;
  }

  async onLog(log: PublicLog): Promise<void> {
    const now = this.now();
    for (const rule of this.load()) {
      if (!rule.enabled || !matches(rule, log)) continue;
      const since = now - rule.windowSeconds * 1000;
      const count = this.store.countMatching(rule.match, since);
      if (count <= rule.threshold) continue;
      const state = this.store.getAlertState(rule.id);
      if (state && now - state.lastFiredAt < rule.cooldownSeconds * 1000) continue;

      // Reserve the cooldown before any network await so concurrent inserts cannot double-fire.
      this.store.setAlertState(rule.id, now, count);
      const samples = this.store.sampleMatching(rule.match, since, 3);
      const delivered = await this.dispatch(rule, count, samples, now);
      if (!delivered) {
        this.store.setAlertState(rule.id, now - rule.cooldownSeconds * 1000 + 15_000, count);
        this.log.error(`Alert ${rule.id} was not delivered`);
        continue;
      }
      const summary = summaryText(rule, count, samples);
      this.store.recordFire(rule.id, now, count, summary);
      this.log.warn(`Alert ${rule.id} fired (${count} logs / ${rule.windowSeconds}s)`);
    }
  }

  private async dispatch(rule: AlertRule, count: number, samples: AlertSample[], now: number): Promise<boolean> {
    const results = await Promise.all(
      rule.notify.map((target) => this.send(target, rule, count, samples, now)),
    );
    return results.some(Boolean);
  }

  private async send(
    target: NotifyTarget,
    rule: AlertRule,
    count: number,
    samples: AlertSample[],
    now: number,
  ): Promise<boolean> {
    const text = summaryText(rule, count, samples);
    let url = target.type === 'telegram'
      ? `${this.telegramApiBase}/bot${target.botToken}/sendMessage`
      : target.url;
    let body: unknown;
    const headers: Record<string, string> = {
      'content-type': 'application/json',
      'user-agent': 'NexusLog/1.0',
    };

    if (target.type === 'webhook') {
      body = {
        source: 'NexusLog',
        version: 1,
        ruleId: rule.id,
        description: rule.description,
        count,
        threshold: rule.threshold,
        windowSeconds: rule.windowSeconds,
        firedAt: new Date(now).toISOString(),
        text,
        samples,
      };
      Object.assign(headers, target.headers);
      headers['content-type'] = 'application/json';
      headers['user-agent'] = 'NexusLog/1.0';
    } else if (target.type === 'discord') {
      body = {
        content: text.slice(0, 1900),
        allowed_mentions: { parse: [] },
      };
    } else {
      body = {
        chat_id: target.chatId,
        text: escapeHtml(text).slice(0, 4000),
        parse_mode: 'HTML',
      };
    }

    try {
      const response = await this.fetchImpl(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(5000),
        redirect: 'follow',
      });
      if (!response.ok) {
        this.log.error(`Alert ${rule.id} ${target.type} delivery returned HTTP ${response.status}`);
        return false;
      }
      return true;
    } catch {
      this.log.error(`Alert ${rule.id} ${target.type} delivery failed`);
      return false;
    }
  }
}
