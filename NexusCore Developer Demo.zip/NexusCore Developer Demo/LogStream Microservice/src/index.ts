#!/usr/bin/env node
import { realpathSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { startRetentionJob } from './cleanup.js';
import { loadConfig } from './config.js';
import { openDatabase } from './db.js';
import { loadEnvFile } from './env.js';

function isDirectRun(): boolean {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return realpathSync(entry) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

async function main(): Promise<void> {
  const major = Number(process.versions.node.split('.')[0]);
  if (!Number.isFinite(major) || major < 20) {
    throw new Error('NexusLog requires Node.js 20 or newer');
  }

  loadEnvFile(path.resolve(process.cwd(), '.env'));
  const config = loadConfig();
  const store = openDatabase(config.dbPath);
  const stopRetention = startRetentionJob(
    store,
    config.retentionDays,
    config.cleanupIntervalMinutes,
  );
  const app = createApp({
    config,
    store,
    logger: {
      level: config.logLevel,
      redact: ['req.headers.authorization', 'req.headers.cookie'],
    },
  });

  let closing = false;
  const shutdown = async (signal: string): Promise<void> => {
    if (closing) return;
    closing = true;
    app.log.info(`Shutting down (${signal})`);
    stopRetention();
    await app.close();
    store.close();
  };

  process.on('SIGINT', () => {
    void shutdown('SIGINT').then(() => process.exit(0));
  });
  process.on('SIGTERM', () => {
    void shutdown('SIGTERM').then(() => process.exit(0));
  });

  await app.listen({ port: config.port, host: config.host });
  app.log.info(`NexusLog listening on http://${config.host}:${config.port}`);
}

if (isDirectRun()) {
  main().catch((err: unknown) => {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`NexusLog failed to start: ${message}`);
    process.exit(1);
  });
}
