export interface RateLimiter {
  allow(key: string): boolean;
  stop(): void;
}

export function createRateLimiter(limitPerMinute: number): RateLimiter {
  if (limitPerMinute <= 0) {
    return { allow: () => true, stop() {} };
  }

  const hits = new Map<string, number[]>();
  const timer = setInterval(() => {
    const cutoff = Date.now() - 60_000;
    for (const [key, stamps] of hits) {
      const next = stamps.filter((stamp) => stamp >= cutoff);
      if (next.length === 0) hits.delete(key);
      else hits.set(key, next);
    }
  }, 60_000);
  timer.unref?.();

  return {
    allow(key: string): boolean {
      const now = Date.now();
      const cutoff = now - 60_000;
      const next = (hits.get(key) ?? []).filter((stamp) => stamp >= cutoff);
      if (next.length >= limitPerMinute) {
        hits.set(key, next);
        return false;
      }
      next.push(now);
      hits.set(key, next);
      return true;
    },
    stop() {
      clearInterval(timer);
      hits.clear();
    },
  };
}
