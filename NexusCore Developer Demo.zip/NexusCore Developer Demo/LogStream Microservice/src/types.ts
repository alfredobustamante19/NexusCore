import type { Level } from './levels.js';

export interface MiniLogger {
  info(message: string): void;
  warn(message: string): void;
  error(message: string): void;
}

export interface PublicLog {
  id: number;
  level: string;
  service: string;
  message: string;
  payload: unknown;
  timestamp: string;
  receivedAt: string;
}

export interface ValidLog {
  level: Level;
  service: string;
  message: string;
  payload: unknown;
  timestamp: number;
}

export interface SearchParams {
  service: string | null;
  level: Level | null;
  ftsQuery: string | null;
  impossible: boolean;
  limit: number;
  beforeId: number | null;
}

export interface AlertMatch {
  level: Level | null;
  service: string | null;
  messageIncludes: string | null;
}

export interface WebhookTarget {
  type: 'webhook';
  url: string;
  headers: Record<string, string>;
}

export interface DiscordTarget {
  type: 'discord';
  url: string;
}

export interface TelegramTarget {
  type: 'telegram';
  botToken: string;
  chatId: string;
}

export type NotifyTarget = WebhookTarget | DiscordTarget | TelegramTarget;

export interface AlertRule {
  id: string;
  enabled: boolean;
  description: string;
  match: AlertMatch;
  threshold: number;
  windowSeconds: number;
  cooldownSeconds: number;
  notify: NotifyTarget[];
}

export interface AlertSample {
  id: number;
  level: string;
  service: string;
  message: string;
  timestamp: string;
}

export interface AlertState {
  lastFiredAt: number;
  lastCount: number;
}

export interface AlertFire {
  id: number;
  ruleId: string;
  firedAt: number;
  count: number;
  summary: string;
}

export interface ServiceCount {
  service: string;
  count: number;
}

export type ParseResult<T> = { ok: true; value: T } | { ok: false; error: string };
