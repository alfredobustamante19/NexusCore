import { LEVEL_LIST, normalizeLevel, type Level } from './levels.js';
import type { ParseResult, SearchParams, ValidLog } from './types.js';

const SERVICE_MAX = 120;
const MESSAGE_MAX = 16_000;
const QUERY_MAX = 200;
const MIN_TIMESTAMP = Date.UTC(2000, 0, 1);
const MAX_FUTURE_SKEW_MS = 24 * 60 * 60 * 1000;

function fail<T>(error: string): ParseResult<T> {
  return { ok: false, error };
}

function parseTimestamp(value: unknown, now: number): ParseResult<number> {
  if (value == null) return { ok: true, value: now };
  let ms: number;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return fail('timestamp is invalid');
    ms = value < 1e12 ? Math.round(value * 1000) : Math.round(value);
  } else if (typeof value === 'string' && value.trim()) {
    const trimmed = value.trim();
    if (/^\d+(\.\d+)?$/.test(trimmed)) {
      const numeric = Number(trimmed);
      if (!Number.isFinite(numeric)) return fail('timestamp is invalid');
      ms = numeric < 1e12 ? Math.round(numeric * 1000) : Math.round(numeric);
    } else {
      ms = Date.parse(trimmed);
    }
  } else {
    return fail('timestamp must be an ISO-8601 string or unix time');
  }
  if (!Number.isFinite(ms)) return fail('timestamp is invalid');
  if (ms < MIN_TIMESTAMP || ms > now + MAX_FUTURE_SKEW_MS) return fail('timestamp is out of range');
  return { ok: true, value: ms };
}

export function parseLogBody(body: unknown, now: number): ParseResult<ValidLog> {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return fail('Body must be a JSON object');
  }
  const record = body as Record<string, unknown>;

  if (typeof record.level !== 'string') {
    return fail(`level must be one of ${LEVEL_LIST}`);
  }
  const level: Level | null = normalizeLevel(record.level);
  if (!level) return fail(`level must be one of ${LEVEL_LIST}`);

  if (typeof record.service !== 'string' || record.service.trim().length === 0) {
    return fail('service is required');
  }
  const service = record.service.trim();
  if (service.length > SERVICE_MAX) return fail('service is too long');
  if (/[\u0000-\u001F\u007F]/.test(service)) return fail('service contains invalid characters');

  if (typeof record.message !== 'string' || record.message.trim().length === 0) {
    return fail('message is required');
  }
  const message = record.message.trim();
  if (message.length > MESSAGE_MAX) return fail('message is too long');
  if (message.includes('\0')) return fail('message contains invalid characters');

  let payload: unknown = null;
  if (Object.prototype.hasOwnProperty.call(record, 'payload') && record.payload !== undefined) {
    payload = record.payload;
  }

  const timestamp = parseTimestamp(record.timestamp, now);
  if (!timestamp.ok) return timestamp;

  return {
    ok: true,
    value: { level, service, message, payload, timestamp: timestamp.value },
  };
}

function readQueryString(value: unknown, field: string): ParseResult<string | null> {
  if (value == null || value === '') return { ok: true, value: null };
  if (typeof value !== 'string') return fail(`${field} must be a string`);
  return { ok: true, value };
}

export function toFtsQuery(input: string): string | null {
  const tokens = input.match(/[\p{L}\p{N}_.:/@+-]+/gu);
  if (!tokens || tokens.length === 0) return null;
  return tokens
    .slice(0, 16)
    .map((token) => `"${token.replaceAll('"', '')}"`)
    .join(' AND ');
}

export function parseSearchQuery(query: unknown): ParseResult<SearchParams> {
  if (!query || typeof query !== 'object' || Array.isArray(query)) {
    return fail('invalid query');
  }
  const raw = query as Record<string, unknown>;

  const serviceResult = readQueryString(raw.service, 'service');
  if (!serviceResult.ok) return serviceResult;
  let service = serviceResult.value;
  if (service) {
    service = service.trim();
    if (!service) service = null;
    else if (service.length > SERVICE_MAX) return fail('service is too long');
  }

  const levelResult = readQueryString(raw.level, 'level');
  if (!levelResult.ok) return levelResult;
  let level: Level | null = null;
  if (levelResult.value) {
    level = normalizeLevel(levelResult.value);
    if (!level) return fail(`level must be one of ${LEVEL_LIST}`);
  }

  const textResult = readQueryString(raw.q, 'q');
  if (!textResult.ok) return textResult;
  const text = textResult.value?.trim() ?? '';
  if (text.length > QUERY_MAX) return fail('q is too long');
  const ftsQuery = text ? toFtsQuery(text) : null;
  const impossible = text.length > 0 && ftsQuery == null;

  let limit = 100;
  if (raw.limit != null && raw.limit !== '') {
    if (typeof raw.limit !== 'string' || !/^\d+$/.test(raw.limit)) return fail('limit must be an integer');
    limit = Number(raw.limit);
    if (limit < 1 || limit > 500) return fail('limit must be between 1 and 500');
  }

  let beforeId: number | null = null;
  if (raw.before != null && raw.before !== '') {
    if (typeof raw.before !== 'string' || !/^\d+$/.test(raw.before)) return fail('before must be an integer');
    beforeId = Number(raw.before);
    if (!Number.isSafeInteger(beforeId) || beforeId <= 0) return fail('before must be an integer');
  }

  return {
    ok: true,
    value: { service, level, ftsQuery, impossible, limit, beforeId },
  };
}
