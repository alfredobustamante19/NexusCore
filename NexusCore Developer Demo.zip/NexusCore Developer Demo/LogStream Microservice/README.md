# NexusLog

NexusLog is a single-process log aggregation and alerting service. Applications post JSON logs to it, operators watch them in a dark dashboard, and local alert rules send webhook, Discord, or Telegram notifications. Storage is a SQLite file. There is no Elasticsearch, Redis, or Docker requirement.

The production runtime is Node.js 20+ with two dependencies: [Fastify](https://fastify.dev/) and [better-sqlite3](https://github.com/WiseLibs/better-sqlite3). Logs are not buffered in the process; SQLite is the store, and the page cache is capped at 2 MB. `npm start` also caps the V8 old-space heap at 48 MB. On Windows 11 with Node.js 24, a quiet process using that cap measured about 36 MB of private memory. The Windows working set was about 66 MB because it includes shared Node and system libraries. Without the heap cap, private memory was about 62 MB.

## Requirements

- Node.js 20 or newer
- npm 10 or newer
- A compiler toolchain only if `better-sqlite3` has no prebuilt binary for your platform (Windows, macOS, and common Linux glibc builds usually install from a prebuild)

## Install

```bash
npm ci
cp .env.example .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
node --eval "import { randomBytes } from 'node:crypto'; console.log(randomBytes(32).toString('hex'))"
```

Put that value in `.env` as `NEXUS_TOKEN`. The placeholder in `.env.example` is rejected on startup.

```bash
npm test
npm run build
npm start
```

`npm start` runs `node --max-old-space-size=48 dist/index.js`. The process reads `.env` from the working directory and does not override variables that are already set. Open `http://127.0.0.1:8787/` and sign in with the same token.

A release zip already contains `dist/`. On a server you can skip the TypeScript compile and omit dev dependencies:

```bash
npm ci --omit=dev
node --max-old-space-size=48 dist/index.js
```

`better-sqlite3` is native and is **not** inside the zip. `npm ci` downloads or builds it for the machine that will run NexusLog.

## Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `HOST` | `127.0.0.1` | Bind address. Use `0.0.0.0` to listen on every interface. |
| `PORT` | `8787` | HTTP port. |
| `NEXUS_TOKEN` | required | Bearer token for ingestion, the API, and the dashboard session. 16–512 characters. |
| `DB_PATH` | `./data/nexuslog.sqlite` | SQLite file. The directory is created on startup. Relative paths use the working directory. |
| `LOG_RETENTION_DAYS` | `14` | Delete logs whose event time or receive time is older than this many days. |
| `CLEANUP_INTERVAL_MINUTES` | `60` | How often the purge job runs. It also runs once at startup. |
| `ALERTS_PATH` | `./alerts.json` | Alert rule file. Edits are picked up on the next ingested log when the file mtime changes. |
| `BODY_LIMIT_BYTES` | `262144` | Maximum JSON body for `POST /api/v1/log`. |
| `RATE_LIMIT_PER_MINUTE` | `300` | Per-IP limit for ingestion. `0` disables it. Session login is capped at 30/minute when this is enabled. |
| `SSE_MAX_CLIENTS` | `100` | Maximum live dashboard streams. Extra clients receive HTTP 503. |
| `COOKIE_SECURE` | `false` | Set `true` when the site is served over HTTPS. |
| `LOG_LEVEL` | `info` | `trace`, `debug`, `info`, `warn`, `error`, `fatal`, or `silent`. |

Run one process per database file. SQLite has a single writer, so PM2 `instances` must stay at 1.

## Authentication

All log data requires the bearer token:

```http
Authorization: Bearer <NEXUS_TOKEN>
```

The dashboard shell at `/` is static and contains no logs. Signing in `POST`s the token to `/api/v1/session`, which sets an `HttpOnly`, `SameSite=Strict` cookie named `nexus_session`. The live stream uses that cookie because browser `EventSource` cannot set an `Authorization` header. Send the header from collectors instead of putting the token in a query string.

`GET /healthz` is unauthenticated and returns `{"ok":true}` so process managers can probe the process without the token.

## Ingestion API

`POST /api/v1/log`

```bash
curl -sS -X POST http://127.0.0.1:8787/api/v1/log \
  -H "Authorization: Bearer $NEXUS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"level":"ERROR","service":"billing","message":"payment failed","payload":{"invoice":"42"}}'
```

PowerShell:

```powershell
$headers = @{ Authorization = "Bearer $env:NEXUS_TOKEN" }
$body = @{
  level = "ERROR"
  service = "billing"
  message = "payment failed"
  payload = @{ invoice = "42" }
} | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8787/api/v1/log -Headers $headers -ContentType "application/json" -Body $body
```

Request fields:

| Field | Required | Notes |
| --- | --- | --- |
| `level` | yes | `TRACE`, `DEBUG`, `INFO`, `WARN`, `ERROR`, `FATAL`. Case-insensitive. `warning` and `err` are accepted aliases. |
| `service` | yes | 1–120 characters. No ASCII control characters. Leading and trailing space is trimmed. |
| `message` | yes | 1–16,000 characters. |
| `payload` | no | Any JSON value. Stored and returned as JSON. Omitted and `null` are stored as SQL `NULL`. |
| `timestamp` | no | ISO-8601 string, unix seconds, or unix milliseconds. Defaults to the server clock. Values before 2000-01-01 or more than 24 hours in the future are rejected. |

Response `201`:

```json
{ "id": 1, "accepted": true }
```

Errors are `{"error":"..."}` with status `400` (validation), `401` (auth), `413` (body too large), or `429` (rate limit, `Retry-After: 60`).

## Query API

`GET /api/v1/logs`

| Query | Notes |
| --- | --- |
| `service` | Exact service name. |
| `level` | Same level names and aliases as ingestion. |
| `q` | Full-text search across message, service, and payload. Up to 16 words, combined with AND. Matching is case-insensitive. |
| `limit` | 1–500, default 100. |
| `before` | Return rows with an id lower than this cursor (older rows). |

Results are newest first.

```bash
curl -sS -H "Authorization: Bearer $NEXUS_TOKEN" \
  "http://127.0.0.1:8787/api/v1/logs?service=billing&level=ERROR&q=invoice&limit=50"
```

```json
{
  "logs": [
    {
      "id": 1,
      "level": "ERROR",
      "service": "billing",
      "message": "payment failed",
      "payload": { "invoice": "42" },
      "timestamp": "2026-10-07T18:00:00.000Z",
      "receivedAt": "2026-10-07T18:00:01.123Z"
    }
  ],
  "nextBefore": null
}
```

When `logs.length === limit`, `nextBefore` is the oldest id on that page. Request `&before=<nextBefore>` for the next page.

`GET /api/v1/services` returns `{ "services": [{ "service": "billing", "count": 2 }] }`.

`timestamp` is the event time from the client. `receivedAt` is when NexusLog stored the row. Alert windows and the live stream use receive time, so a client with a skewed clock cannot hide a burst or stretch one across the window.

## Live stream

`GET /api/v1/stream` is a Server-Sent Events response.

```bash
curl -N -H "Authorization: Bearer $NEXUS_TOKEN" http://127.0.0.1:8787/api/v1/stream
```

Events:

- `hello` — the connection is up
- `log` — one log object, same shape as the query API, with an SSE `id`
- `ping` — a keepalive every 15 seconds

On reconnect the browser sends `Last-Event-ID`. NexusLog replays up to 200 logs with a greater id, then continues live. The dashboard deduplicates by id.

## Dashboard

`GET /` serves one HTML file. Tailwind is loaded from `https://cdn.tailwindcss.com`. A small fallback stylesheet keeps the page readable if that host is unreachable. The page can filter by level and service, full-text search, pause the tail, and keep the latest 500 DOM rows. Log text is written with `textContent`, not HTML interpolation.

The content security policy allows the Tailwind CDN and inline scripts. `unsafe-eval` is there because the Tailwind browser build compiles utilities in the page. Do not put untrusted HTML in front of this origin.

## Alert rules

`alerts.json` is trusted local configuration. There is no API to change webhooks. A rule fires when the number of matching logs **received in the window is greater than `threshold`**. The shipped example uses `threshold: 5`, so the sixth `ERROR` inside 60 seconds fires, and `enabled` is `false` until you add real endpoints.

```json
{
  "rules": [
    {
      "id": "error-spike",
      "enabled": true,
      "description": "Fire when more than 5 ERROR logs arrive within 60 seconds",
      "match": {
        "level": "ERROR",
        "service": "billing",
        "messageIncludes": "payment"
      },
      "threshold": 5,
      "windowSeconds": 60,
      "cooldownSeconds": 300,
      "notify": [
        {
          "type": "webhook",
          "url": "https://example.com/hooks/nexuslog",
          "headers": { "X-Token": "replace-me" }
        },
        {
          "type": "discord",
          "url": "https://discord.com/api/webhooks/REPLACE/REPLACE"
        },
        {
          "type": "telegram",
          "botToken": "123456:REPLACE_WITH_BOT_TOKEN",
          "chatId": "123456789"
        }
      ]
    }
  ]
}
```

Match fields are optional. Omit `service` or set it to `*` to count every service. `messageIncludes` is a case-insensitive substring of the message. `threshold` may be `0`, which fires on every matching log. `windowSeconds` is 1–86400. `cooldownSeconds` is 0–86400. After a successful delivery the rule stays quiet until the cooldown ends. A failed delivery is retried on a later matching log, with about 15 seconds of backoff so a dead endpoint is not called on every line.

Up to 20 rules are loaded, with up to 5 targets each. Invalid rules are skipped and logged. A broken JSON file keeps the previous good rules.

Webhook body:

```json
{
  "source": "NexusLog",
  "version": 1,
  "ruleId": "error-spike",
  "description": "Fire when more than 5 ERROR logs arrive within 60 seconds",
  "count": 6,
  "threshold": 5,
  "windowSeconds": 60,
  "firedAt": "2026-10-07T18:00:00.000Z",
  "text": "NexusLog alert: ...",
  "samples": [
    {
      "id": 10,
      "level": "ERROR",
      "service": "billing",
      "message": "payment failed",
      "timestamp": "2026-10-07T18:00:00.000Z"
    }
  ]
}
```

Samples include the latest three matching messages. Payloads are not copied into notifications, because payloads often hold ids or secrets you do not want on a chat webhook. The message text itself is included.

Discord receives `{ "content": "<text>", "allowed_mentions": { "parse": [] } }`. Mentions in log lines are not parsed. Telegram receives `sendMessage` with `parse_mode: HTML` and escaped text. Create a bot with BotFather for the token, and use the numeric chat id (or `@channel`) the bot is allowed to post to.

Notifier URLs must be `http:` or `https:`. Redirects are followed. Each attempt times out after 5 seconds. Ingestion does not wait for the notifier; the HTTP `201` returns after the log is stored and the cooldown slot is reserved.

## Retention

On startup, and then every `CLEANUP_INTERVAL_MINUTES`, NexusLog deletes rows where `timestamp` or `receivedAt` is older than `LOG_RETENTION_DAYS`, and deletes alert history on the same cutoff. Alert cooldown state is kept. Copy the SQLite file only after stopping the process, or use SQLite's backup API. A WAL file may sit beside the database while the process is running.

## systemd

```ini
[Unit]
Description=NexusLog
After=network.target

[Service]
Type=simple
User=nexuslog
Group=nexuslog
WorkingDirectory=/opt/nexuslog
EnvironmentFile=/opt/nexuslog/.env
ExecStart=/usr/bin/node --max-old-space-size=48 /opt/nexuslog/dist/index.js
Restart=on-failure
RestartSec=2
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=/opt/nexuslog/data
MemoryMax=128M

[Install]
WantedBy=multi-user.target
```

`MemoryMax` is a cgroup ceiling above the normal footprint, not the expected steady-state size. Install the unit, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now nexuslog
sudo systemctl status nexuslog
```

Logs from the service itself go to journald through stdout (`journalctl -u nexuslog -f`). Those lines are pino JSON and are separate from the logs stored in SQLite.

## PM2

From the NexusLog directory, with `.env` in place:

```bash
pm2 start dist/index.js --name nexuslog --node-args="--max-old-space-size=48" --max-memory-restart 80M
pm2 save
pm2 startup
```

Keep `instances` at 1 and `exec_mode` at `fork`. Do not cluster the same SQLite file.

## Operations

- Rotate the token by changing `NEXUS_TOKEN` and restarting. Old cookies stop matching.
- `GET /healthz` is the probe. It does not read the database.
- Bind `127.0.0.1` and put a reverse proxy in front if you need TLS. Set `COOKIE_SECURE=true` in that case.
- Alert delivery failures and firings are written to the process log. Successful firings are also stored in the `alert_fires` table.
- Full-text search uses SQLite FTS5. Weird punctuation in `q` is stripped down to words before it reaches the index.

## Development

```bash
npm test
npm run build
```

Tests use Vitest and temporary SQLite files. They cover ingestion validation and auth, full-text search, filters, pagination, retention, alert thresholds, cooldowns, failed deliveries, Discord and Telegram payload shapes, and the SSE stream.

## Project layout

```text
src/           TypeScript source
dist/          Compiler output
tests/         Vitest suites
alerts.json    Sample rules, disabled
.env.example   Configuration template
```

## License

MIT.
