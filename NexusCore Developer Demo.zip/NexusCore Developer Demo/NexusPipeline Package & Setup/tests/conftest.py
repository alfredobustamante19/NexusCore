"""Shared fixtures for the API tests."""

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.engine import Orchestrator
from app.main import create_app


async def noop_sleep(_seconds: float) -> None:
    return None


def make_settings(directory: Path, **overrides) -> Settings:
    database = directory / overrides.pop("db_name", "test.db")
    values = {
        "database_url": f"sqlite:///{database.as_posix()}",
        "api_token": "",
        "enable_echo": True,
        "url_allowlist": "",
        "max_steps": 50,
        "max_response_bytes": 1_048_576,
        "log_level": "WARNING",
    }
    values.update(overrides)
    return Settings(**values)


@contextmanager
def open_client(
    directory: Path,
    *,
    transport: httpx.AsyncBaseTransport | None = None,
    sleep=None,
    **overrides,
) -> Iterator[TestClient]:
    settings = make_settings(directory, **overrides)
    application = create_app(settings)
    if transport is not None or sleep is not None:
        application.state.orchestrator = Orchestrator(
            transport=transport,
            sleep=sleep or noop_sleep,
            max_response_bytes=settings.max_response_bytes,
            url_allowlist=settings.allowed_hosts(),
        )
    with TestClient(application) as client:
        yield client


@pytest.fixture
def client(tmp_path: Path) -> Iterator[TestClient]:
    with open_client(tmp_path) as test_client:
        yield test_client
