"""Path extraction used to pull fields out of step responses."""

import pytest

from app.extract import ExtractError, extract_value


def test_dot_notation_reads_nested_values():
    document = {"data": {"items": [{"id": "a1"}, {"id": "b2"}]}}
    assert extract_value(document, "data.items.0.id") == "a1"
    assert extract_value(document, "data.items.1.id") == "b2"


def test_jsonpath_index_and_bracket_key():
    document = {"user-id": 9, "items": [{"id": "a1"}]}
    assert extract_value(document, "$.items[0].id") == "a1"
    assert extract_value(document, "$['user-id']") == 9


def test_jsonpath_wildcard_returns_every_match():
    document = {"items": [{"id": "a"}, {"id": "b"}]}
    assert extract_value(document, "$.items[*].id") == ["a", "b"]


def test_missing_path_raises():
    with pytest.raises(ExtractError):
        extract_value({"data": {}}, "data.id")
    with pytest.raises(ExtractError):
        extract_value({"items": []}, "$.items[0].id")
    with pytest.raises(ExtractError):
        extract_value({}, "")
