"""CRUD, execution, and history endpoints."""

import json

import httpx

from tests.conftest import noop_sleep, open_client


def _pipeline(name: str = "Orders", **extra) -> dict:
    body = {
        "name": name,
        "description": "Create then confirm",
        "is_active": True,
        "steps": [
            {
                "id": "create_user",
                "name": "Create user",
                "method": "POST",
                "url": "https://example.test/users",
                "headers": {"Authorization": "Bearer secret"},
                "body": {"email": "{{input.email}}"},
                "body_mode": "json",
                "timeout_seconds": 5,
                "retries": 0,
                "extract": {"user_id": "id"},
            },
            {
                "id": "create_order",
                "name": "Create order",
                "method": "POST",
                "url": "https://example.test/orders",
                "headers": {"X-User": "{{steps.create_user.extract.user_id}}"},
                "body": {"user_id": "{{steps.create_user.extract.user_id}}"},
                "body_mode": "json",
                "timeout_seconds": 5,
                "retries": 0,
                "extract": {"order_id": "$.id"},
            },
        ],
    }
    body.update(extra)
    return body


def _transport() -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/users":
            assert request.headers["authorization"] == "Bearer secret"
            return httpx.Response(201, json={"id": "user-7"})
        if request.url.path == "/orders":
            assert json.loads(request.content)["user_id"] == "user-7"
            assert request.headers["x-user"] == "user-7"
            return httpx.Response(200, json={"id": "order-7"})
        return httpx.Response(404, json={"error": "missing"})

    return httpx.MockTransport(handler)


def test_dashboard_health_and_echo(client):
    page = client.get("/")
    assert page.status_code == 200
    assert "Pipeline Engine" in page.text
    assert page.headers["content-type"].startswith("text/html")

    health = client.get("/api/health")
    assert health.json() == {"status": "ok"}

    echo = client.post("/api/echo", json={"name": "Ada"}, headers={"X-Record-Id": "rec-1"})
    assert echo.status_code == 200
    payload = echo.json()
    assert payload["received"] == {"name": "Ada"}
    assert payload["headers_seen"]["x-record-id"] == "rec-1"
    assert payload["id"]


def test_crud_run_and_history(tmp_path):
    with open_client(tmp_path, transport=_transport(), sleep=noop_sleep) as client:
        created = client.post("/api/pipelines", json=_pipeline())
        assert created.status_code == 201
        pipeline = created.json()
        assert pipeline["name"] == "Orders"
        assert pipeline["created_at"].endswith("+00:00")
        assert isinstance(pipeline["steps_config_json"], str)
        stored = json.loads(pipeline["steps_config_json"])
        assert [step["id"] for step in stored] == ["create_user", "create_order"]
        assert len(pipeline["steps"]) == 2

        listed = client.get("/api/pipelines")
        assert listed.status_code == 200
        assert [item["id"] for item in listed.json()] == [pipeline["id"]]

        renamed = client.patch(f"/api/pipelines/{pipeline['id']}", json={"name": "Orders v2"})
        assert renamed.status_code == 200
        assert renamed.json()["name"] == "Orders v2"

        missing = client.post("/api/pipelines/missing/run", json={"input": {}})
        assert missing.status_code == 404

        run = client.post(
            f"/api/pipelines/{pipeline['id']}/run",
            json={"input": {"email": "a@b.c"}},
        )
        assert run.status_code == 200
        body = run.json()
        assert body["status"] == "success"
        assert body["pipeline_id"] == pipeline["id"]
        assert body["duration_ms"] >= 0
        assert body["triggered_at"].endswith("+00:00")
        assert isinstance(body["execution_trace_json"], str)
        assert [step["status"] for step in body["trace"]] == ["success", "success"]
        assert body["trace"][0]["extracted"]["user_id"] == "user-7"
        assert body["trace"][1]["extracted"]["order_id"] == "order-7"
        assert body["trace"][0]["attempts"][0]["request"]["headers"]["Authorization"] == "***"
        assert "secret" not in body["execution_trace_json"]

        second = client.post(f"/api/pipelines/{pipeline['id']}/run", json={})
        assert second.status_code == 200
        assert second.json()["status"] == "failed"

        history = client.get(f"/api/pipelines/{pipeline['id']}/runs")
        assert history.status_code == 200
        rows = history.json()
        assert [row["id"] for row in rows] == [second.json()["id"], body["id"]]
        assert rows[0]["status"] == "failed"

        fetched = client.get(f"/api/runs/{body['id']}")
        assert fetched.status_code == 200
        assert fetched.json()["status"] == "success"

        deleted = client.delete(f"/api/pipelines/{pipeline['id']}")
        assert deleted.status_code == 204
        assert client.get(f"/api/pipelines/{pipeline['id']}").status_code == 404
        assert client.get(f"/api/runs/{body['id']}").status_code == 404


def test_validation_inactive_pipeline_and_json_definition(tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/ping":
            return httpx.Response(204)
        return httpx.Response(404, json={"error": "missing"})

    with open_client(tmp_path, transport=httpx.MockTransport(handler), sleep=noop_sleep) as client:
        duplicate = client.post(
            "/api/pipelines",
            json=_pipeline(
                steps=[
                    {"id": "same", "name": "A", "method": "GET", "url": "https://example.test/a"},
                    {"id": "same", "name": "B", "method": "GET", "url": "https://example.test/b"},
                ]
            ),
        )
        assert duplicate.status_code == 400
        assert "duplicate" in duplicate.json()["detail"]

        created = client.post("/api/pipelines", json=_pipeline(name="Draft", is_active=False, steps=[]))
        assert created.status_code == 201
        pipeline_id = created.json()["id"]
        refused = client.post(f"/api/pipelines/{pipeline_id}/run", json={"input": {}})
        assert refused.status_code == 409
        assert client.get(f"/api/pipelines/{pipeline_id}/runs").json() == []

        replaced = client.put(
            f"/api/pipelines/{pipeline_id}",
            json={
                "name": "From JSON",
                "description": "",
                "is_active": True,
                "steps_config_json": json.dumps(
                    [
                        {
                            "id": "ping",
                            "name": "Ping",
                            "method": "GET",
                            "url": "https://example.test/ping",
                            "retries": 0,
                            "timeout_seconds": 1,
                        }
                    ]
                ),
            },
        )
        assert replaced.status_code == 200
        assert replaced.json()["steps"][0]["id"] == "ping"

        executed = client.post(f"/api/pipelines/{pipeline_id}/run", json={"input": {}})
        assert executed.status_code == 200
        assert executed.json()["status"] == "success"
        assert executed.json()["trace"][0]["attempts"][0]["response"]["status_code"] == 204


def test_api_token_and_disabled_echo(tmp_path):
    with open_client(tmp_path, api_token="secret", enable_echo=False, db_name="auth.db") as client:
        assert client.get("/api/health").status_code == 200
        assert client.get("/api/pipelines").status_code == 401
        assert client.get("/api/pipelines", headers={"X-API-Key": "nope"}).status_code == 401
        allowed = client.get("/api/pipelines", headers={"Authorization": "Bearer secret"})
        assert allowed.status_code == 200
        assert allowed.json() == []
        assert client.post("/api/echo", json={"name": "Ada"}).status_code == 404
