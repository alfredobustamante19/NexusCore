"""Execution engine: injection, retries, timeouts, and trace redaction."""

import asyncio
import json

import httpx

from app.engine import Orchestrator, public_url
from app.schemas import StepConfig


def _step(payload: dict) -> StepConfig:
    return StepConfig.model_validate(payload)


def _run(steps: list[dict], handler, *, trigger=None, allowlist=None, sleep=None, max_bytes=1024):
    delays: list[float] = []

    async def record_sleep(seconds: float) -> None:
        delays.append(seconds)
        if sleep is not None:
            await sleep(seconds)

    orchestrator = Orchestrator(
        transport=httpx.MockTransport(handler),
        sleep=record_sleep,
        max_response_bytes=max_bytes,
        url_allowlist=allowlist or [],
    )
    result = asyncio.run(orchestrator.execute([_step(step) for step in steps], trigger or {}))
    return result, delays


def test_second_step_receives_extracted_values():
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        if request.url.path == "/users":
            assert request.headers["authorization"] == "Bearer secret"
            body = json.loads(request.content)
            assert body == {"email": "a@b.c"}
            return httpx.Response(201, json={"id": 42, "profile": {"email": "a@b.c"}})
        if request.url.path == "/orders":
            assert request.headers["x-user"] == "42"
            assert request.url.params["user"] == "42"
            assert json.loads(request.content) == {"user_id": 42, "sku": "widget-abc"}
            return httpx.Response(200, json={"id": "order-1"})
        return httpx.Response(404, json={"error": "unexpected"})

    result, delays = _run(
        [
            {
                "id": "create_user",
                "name": "Create user",
                "method": "POST",
                "url": "https://example.test/users",
                "headers": {"Authorization": "Bearer secret"},
                "body": {"email": "{{input.email}}"},
                "body_mode": "json",
                "retries": 0,
                "extract": {"user_id": "$.id"},
            },
            {
                "id": "create_order",
                "name": "Create order",
                "method": "POST",
                "url": "https://example.test/orders",
                "headers": {"X-User": "{{steps.create_user.extract.user_id}}"},
                "query": {"user": "{{steps.create_user.extract.user_id}}", "api_key": "hidden"},
                "body": {
                    "user_id": "{{steps.create_user.extract.user_id}}",
                    "sku": "widget-{{input.sku}}",
                },
                "body_mode": "json",
                "retries": 0,
                "extract": {"order_id": "id"},
            },
        ],
        handler,
        trigger={"email": "a@b.c", "sku": "abc"},
    )

    assert result["status"] == "success"
    assert delays == []
    assert len(seen) == 2
    assert result["trace"][0]["extracted"] == {"user_id": 42}
    assert result["trace"][1]["extracted"] == {"order_id": "order-1"}
    assert result["trace"][0]["attempts"][0]["request"]["headers"]["Authorization"] == "***"
    assert result["trace"][1]["attempts"][0]["request"]["query"]["api_key"] == "***"
    assert result["trace"][1]["attempts"][0]["request"]["body"]["user_id"] == 42


def test_retry_uses_exponential_backoff_then_succeeds():
    calls = {"count": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        if calls["count"] == 1:
            return httpx.Response(503, json={"error": "busy"})
        return httpx.Response(200, json={"ok": True})

    result, delays = _run(
        [
            {
                "id": "flaky",
                "name": "Flaky",
                "method": "GET",
                "url": "https://example.test/health",
                "retries": 2,
                "retry_backoff_seconds": 0.5,
            }
        ],
        handler,
    )
    assert result["status"] == "success"
    assert calls["count"] == 2
    assert delays == [0.5]
    assert result["trace"][0]["attempts"][0]["error"] == "HTTP 503"
    assert result["trace"][0]["attempts"][0]["retry_delay_ms"] == 500
    assert result["trace"][0]["attempts"][1]["response"]["status_code"] == 200


def test_backoff_is_capped():
    def handler(_request: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("slow")

    result, delays = _run(
        [
            {
                "id": "slow",
                "name": "Slow",
                "method": "GET",
                "url": "https://example.test/slow",
                "timeout_seconds": 1,
                "retries": 2,
                "retry_backoff_seconds": 20,
            }
        ],
        handler,
    )
    assert result["status"] == "failed"
    assert delays == [20, 30]
    assert "timed out after 1s" in result["trace"][0]["error"]


def test_client_error_does_not_retry_and_skips_later_steps():
    calls = {"count": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(400, json={"error": "nope"})

    result, delays = _run(
        [
            {
                "id": "first",
                "name": "First",
                "method": "POST",
                "url": "https://example.test/first",
                "retries": 3,
            },
            {
                "id": "second",
                "name": "Second",
                "method": "GET",
                "url": "https://example.test/second",
            },
        ],
        handler,
    )
    assert calls["count"] == 1
    assert delays == []
    assert [step["status"] for step in result["trace"]] == ["failed", "skipped"]
    assert result["status"] == "failed"


def test_continue_on_error_runs_the_next_step():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/first":
            return httpx.Response(400, json={"error": "nope"})
        return httpx.Response(200, json={"id": "kept"})

    result, _delays = _run(
        [
            {
                "id": "first",
                "name": "First",
                "method": "POST",
                "url": "https://example.test/first",
                "retries": 0,
                "continue_on_error": True,
            },
            {
                "id": "second",
                "name": "Second",
                "method": "GET",
                "url": "https://example.test/second",
                "retries": 0,
                "extract": {"id": "id"},
            },
        ],
        handler,
    )
    assert [step["status"] for step in result["trace"]] == ["failed", "success"]
    assert result["status"] == "failed"
    assert result["trace"][1]["extracted"] == {"id": "kept"}


def test_template_and_extract_failures_are_not_retried():
    calls = {"count": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, json={"ok": True})

    missing, _delays = _run(
        [
            {
                "id": "needs_input",
                "name": "Needs input",
                "method": "POST",
                "url": "https://example.test/items",
                "body": {"name": "{{input.name}}"},
                "retries": 3,
            }
        ],
        handler,
        trigger={},
    )
    assert calls["count"] == 0
    assert "input.name" in missing["trace"][0]["error"]

    calls["count"] = 0
    extracted, delays = _run(
        [
            {
                "id": "read",
                "name": "Read",
                "method": "GET",
                "url": "https://example.test/items",
                "retries": 3,
                "extract": {"id": "id"},
            }
        ],
        handler,
    )
    assert calls["count"] == 1
    assert delays == []
    assert "extract 'id' failed" in extracted["trace"][0]["error"]
    assert extracted["trace"][0]["attempts"][0]["response"]["status_code"] == 200


def test_allowlist_and_oversized_responses():
    calls = {"count": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, content=b"0123456789abcdef", headers={"content-type": "text/plain"})

    blocked, _delays = _run(
        [{"id": "go", "name": "Go", "method": "GET", "url": "https://evil.test/x", "retries": 2}],
        handler,
        allowlist=["example.test"],
    )
    assert calls["count"] == 0
    assert "PIPELINE_URL_ALLOWLIST" in blocked["trace"][0]["error"]

    oversized, delays = _run(
        [{"id": "go", "name": "Go", "method": "GET", "url": "https://example.test/x", "retries": 2}],
        handler,
        max_bytes=8,
    )
    assert calls["count"] == 1
    assert delays == []
    assert "byte limit" in oversized["trace"][0]["error"]


def test_public_url_strips_userinfo():
    assert public_url("https://user:secret@example.test/v1") == "https://example.test/v1"
    assert public_url("https://example.test/v1") == "https://example.test/v1"


def test_trace_omits_url_credentials():
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(204)

    result, _delays = _run(
        [
            {
                "id": "go",
                "name": "Go",
                "method": "GET",
                "url": "https://user:secret@example.test/private",
                "retries": 0,
            }
        ],
        handler,
    )
    assert result["status"] == "success"
    assert result["trace"][0]["attempts"][0]["request"]["url"] == "https://example.test/private"
