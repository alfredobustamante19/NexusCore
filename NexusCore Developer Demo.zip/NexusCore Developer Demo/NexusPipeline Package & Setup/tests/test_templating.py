"""Template rendering keeps JSON types when a placeholder is the whole value."""

import pytest

from app.templating import TemplateError, render_value


def test_whole_placeholder_preserves_type():
    context = {"input": {"id": 7, "tags": ["a"]}, "steps": {}}
    assert render_value("{{input.id}}", context) == 7
    assert render_value("{{ input.tags }}", context) == ["a"]


def test_mixed_placeholder_is_stringified():
    context = {"input": {"id": 7, "profile": {"name": "Ada"}}}
    assert render_value("user-{{input.id}}", context) == "user-7"
    assert render_value("{{input.profile}}", context) == {"name": "Ada"}
    assert render_value("name={{input.profile}}", context) == 'name={"name":"Ada"}'


def test_nested_structures_are_rendered():
    context = {"input": {"email": "a@b.c"}}
    rendered = render_value(
        {"user": {"email": "{{input.email}}"}, "notes": ["{{input.email}}"]},
        context,
    )
    assert rendered == {"user": {"email": "a@b.c"}, "notes": ["a@b.c"]}


def test_missing_variable_raises():
    with pytest.raises(TemplateError, match="input.missing"):
        render_value("{{input.missing}}", {"input": {}})
