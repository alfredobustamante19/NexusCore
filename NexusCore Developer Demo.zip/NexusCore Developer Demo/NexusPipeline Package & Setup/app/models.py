"""SQLModel tables for pipeline definitions and run history."""

from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import Column, ForeignKey, String
from sqlmodel import Field, SQLModel


def utcnow() -> datetime:
    """Timezone-aware UTC timestamp. SQLModel rejects naive datetimes."""

    return datetime.now(timezone.utc)


class Pipeline(SQLModel, table=True):
    """Ordered sequence of HTTP calls stored as JSON text."""

    __tablename__ = "pipeline"

    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    name: str = Field(index=True, max_length=200)
    description: str = Field(default="")
    steps_config_json: str
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=utcnow, index=True)


class PipelineRun(SQLModel, table=True):
    """One execution of a pipeline, including the step-by-step trace."""

    __tablename__ = "pipeline_run"

    id: str = Field(default_factory=lambda: str(uuid4()), primary_key=True)
    pipeline_id: str = Field(
        sa_column=Column(String, ForeignKey("pipeline.id", ondelete="CASCADE"), nullable=False, index=True)
    )
    status: str = Field(index=True, max_length=16)
    execution_trace_json: str = Field(default="[]")
    duration_ms: int = Field(default=0)
    triggered_at: datetime = Field(default_factory=utcnow, index=True)
