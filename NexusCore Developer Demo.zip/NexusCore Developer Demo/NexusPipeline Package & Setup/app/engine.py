"""Sequential HTTP orchestration with extraction, injection, and retries."""

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import httpx

from app.extract import ExtractError, extract_value
from app.schemas import StepConfig
from app.templating import TemplateError, render_value

logger = logging.getLogger("pipeline.engine")

MAX_BACKOFF_SECONDS = 30.0
TRACE_VALUE_LIMIT = 65_536
_SENSITIVE_HEADER_NAMES = {
    "authorization",
    "proxy-authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-api-token",
}
_SENSITIVE_QUERY_PARTS = ("token", "secret", "password", "api_key", "apikey")


class StepFailure(Exception):
    """A step failed. ``retryable`` controls exponential backoff."""

    def __init__(self, message: str, *, retryable: bool) -> None:
        super().__init__(message)
        self.retryable = retryable


class Orchestrator:
    """Execute an ordered list of HTTP steps.

    Pass ``transport`` and ``sleep`` from tests to avoid real network calls
    and real backoff waits. Production uses the defaults.
    """

    def __init__(
        self,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        sleep=None,
        max_response_bytes: int = 1_048_576,
        url_allowlist: list[str] | None = None,
    ) -> None:
        self.transport = transport
        self.sleep = sleep or _async_sleep
        self.max_response_bytes = max_response_bytes
        self.url_allowlist = [host.lower() for host in (url_allowlist or [])]

    async def execute(
        self,
        steps: list[StepConfig],
        trigger_input: dict[str, Any] | None = None,
        *,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        context: dict[str, Any] = {"input": trigger_input or {}, "steps": {}}
        trace: list[dict[str, Any]] = []
        if not steps:
            return {
                "status": "failed",
                "trace": [
                    {
                        "step_index": 0,
                        "step_id": "",
                        "step_name": "",
                        "status": "failed",
                        "attempts": [],
                        "extracted": {},
                        "error": "pipeline has no steps",
                    }
                ],
            }

        async with httpx.AsyncClient(
            transport=self.transport,
            follow_redirects=False,
            timeout=httpx.Timeout(120.0),
            headers={"User-Agent": "pipeline-engine/1.0"},
        ) as client:
            stop = False
            for index, step in enumerate(steps):
                if stop:
                    trace.append(_skipped_step(index, step))
                    continue
                result = await self._execute_step(client, step, index, context, run_id)
                trace.append(result)
                if result["status"] == "failed" and not step.continue_on_error:
                    stop = True

        status = "failed" if any(item["status"] == "failed" for item in trace) else "success"
        return {"status": status, "trace": trace}

    async def _execute_step(
        self,
        client: httpx.AsyncClient,
        step: StepConfig,
        index: int,
        context: dict[str, Any],
        run_id: str | None,
    ) -> dict[str, Any]:
        attempts: list[dict[str, Any]] = []
        try:
            rendered = _render_request(step, context, run_id, self.url_allowlist)
        except (TemplateError, StepFailure) as exc:
            message = str(exc)
            attempts.append(_attempt(1, request=None, response=None, error=message, duration_ms=0))
            return _step_result(index, step, "failed", attempts, {}, message)

        success_payload: dict[str, Any] | None = None
        failure_message = "step failed"
        for attempt_index in range(step.retries + 1):
            attempt_number = attempt_index + 1
            started = time.perf_counter()
            response_snapshot: dict[str, Any] | None = None
            try:
                response = await client.request(
                    rendered["method"],
                    rendered["url"],
                    headers=rendered["headers"] or None,
                    params=rendered["query"] or None,
                    json=rendered["json_body"],
                    content=rendered["text_body"],
                    data=rendered["form_body"],
                    timeout=httpx.Timeout(step.timeout_seconds),
                    follow_redirects=step.follow_redirects,
                )
                text, parsed = _decode_response(response, self.max_response_bytes)
                response_snapshot = {
                    "status_code": response.status_code,
                    "headers": redact_headers(dict(response.headers)),
                    "body": clip_value(text),
                    "json": clip_value(parsed),
                }
                outcome = _classify_status(response.status_code, step)
                if outcome == "retry":
                    raise StepFailure(f"HTTP {response.status_code}", retryable=True)
                if outcome == "fatal":
                    raise StepFailure(f"HTTP {response.status_code}", retryable=False)
                extracted = _extract_fields(parsed, step)
                duration_ms = _elapsed_ms(started)
                attempts.append(
                    _attempt(
                        attempt_number,
                        request=rendered["snapshot"],
                        response=response_snapshot,
                        error=None,
                        duration_ms=duration_ms,
                    )
                )
                success_payload = {
                    "status_code": response.status_code,
                    "json": parsed,
                    "body": text,
                    "headers": response_snapshot["headers"],
                    "extract": extracted,
                }
                break
            except StepFailure as exc:
                failure_message = str(exc)
                retryable = exc.retryable
                duration_ms = _elapsed_ms(started)
            except httpx.TimeoutException:
                failure_message = f"timed out after {step.timeout_seconds:g}s"
                retryable = True
                duration_ms = _elapsed_ms(started)
            except httpx.TransportError as exc:
                failure_message = f"connection error: {exc}"
                retryable = True
                duration_ms = _elapsed_ms(started)
            except httpx.HTTPError as exc:
                failure_message = f"request error: {exc}"
                retryable = False
                duration_ms = _elapsed_ms(started)

            delay = _backoff_delay(step, attempt_index) if retryable and attempt_index < step.retries else None
            attempts.append(
                _attempt(
                    attempt_number,
                    request=rendered["snapshot"],
                    response=response_snapshot,
                    error=failure_message,
                    duration_ms=duration_ms,
                    retry_delay_ms=None if delay is None else int(delay * 1000),
                )
            )
            logger.info(
                "step %s attempt %s failed (%s)",
                step.id,
                attempt_number,
                failure_message,
            )
            if delay is None:
                break
            await self.sleep(delay)

        if success_payload is None:
            return _step_result(index, step, "failed", attempts, {}, failure_message)

        snapshot = success_payload
        context["steps"][step.id] = snapshot
        context["steps"][str(index)] = snapshot
        logger.info("step %s completed with HTTP %s", step.id, snapshot["status_code"])
        return _step_result(index, step, "success", attempts, snapshot["extract"], None)


def redact_headers(headers: dict[str, str]) -> dict[str, str]:
    redacted: dict[str, str] = {}
    for key, value in headers.items():
        lowered = key.lower()
        if (
            lowered in _SENSITIVE_HEADER_NAMES
            or lowered.endswith("-token")
            or lowered.endswith("-secret")
            or "password" in lowered
        ):
            redacted[key] = "***"
        else:
            redacted[key] = value
    return redacted


def redact_query(query: dict[str, str]) -> dict[str, str]:
    redacted: dict[str, str] = {}
    for key, value in query.items():
        lowered = key.lower()
        if any(part in lowered for part in _SENSITIVE_QUERY_PARTS):
            redacted[key] = "***"
        else:
            redacted[key] = value
    return redacted


def clip_value(value: Any, limit: int = TRACE_VALUE_LIMIT) -> Any:
    """Keep stored traces readable when a payload is very large."""

    if value is None:
        return None
    try:
        encoded = value if isinstance(value, str) else json.dumps(value, default=str)
    except (TypeError, ValueError):
        encoded = str(value)
    if len(encoded) <= limit:
        return value
    return {"_truncated": True, "preview": encoded[:limit]}


def public_url(url: str) -> str:
    """Drop userinfo so traces do not store URL credentials."""

    parts = urlsplit(url)
    if not (parts.username or parts.password):
        return url
    host = parts.hostname or ""
    if ":" in host:
        host = f"[{host}]"
    if parts.port:
        host = f"{host}:{parts.port}"
    return urlunsplit((parts.scheme, host, parts.path, parts.query, parts.fragment))


async def _async_sleep(seconds: float) -> None:
    import asyncio

    await asyncio.sleep(seconds)


def _render_request(
    step: StepConfig,
    context: dict[str, Any],
    run_id: str | None,
    allowlist: list[str],
) -> dict[str, Any]:
    url = render_value(step.url, context)
    headers = render_value(dict(step.headers), context)
    query = render_value(dict(step.query), context)
    body = render_value(step.body, context)
    if not isinstance(url, str) or not url.strip():
        raise StepFailure("rendered URL must be a non-empty string", retryable=False)
    _ensure_allowed_url(url, allowlist)
    header_map = _stringify_map(headers, label="headers")
    query_map = _stringify_map(query, label="query")
    if run_id and "X-Pipeline-Run-Id" not in header_map:
        header_map["X-Pipeline-Run-Id"] = run_id
    if "X-Pipeline-Step" not in header_map:
        header_map["X-Pipeline-Step"] = step.id

    json_body = None
    text_body = None
    form_body = None
    if step.body_mode == "json" and body is not None:
        json_body = body
    elif step.body_mode == "text" and body is not None:
        text_body = body if isinstance(body, str) else json.dumps(body, default=str)
    elif step.body_mode == "form":
        if body is None:
            form_body = {}
        elif not isinstance(body, dict):
            raise StepFailure("form body must be an object", retryable=False)
        else:
            form_body = _stringify_map(body, label="form body")

    snapshot_body = body if step.body_mode != "none" else None
    return {
        "method": step.method,
        "url": url,
        "headers": header_map,
        "query": query_map,
        "json_body": json_body,
        "text_body": text_body,
        "form_body": form_body,
        "snapshot": {
            "method": step.method,
            "url": public_url(url),
            "headers": redact_headers(header_map),
            "query": redact_query(query_map),
            "body": clip_value(snapshot_body),
        },
    }


def _ensure_allowed_url(url: str, allowlist: list[str]) -> None:
    parts = urlsplit(url)
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        raise StepFailure(f"rendered URL is not an absolute http(s) URL: {url}", retryable=False)
    if not allowlist:
        return
    host = (parts.hostname or "").lower()
    if host not in allowlist:
        raise StepFailure(f"host '{host}' is not in PIPELINE_URL_ALLOWLIST", retryable=False)


def _stringify_map(value: Any, *, label: str) -> dict[str, str]:
    if not isinstance(value, dict):
        raise StepFailure(f"rendered {label} must be an object", retryable=False)
    rendered: dict[str, str] = {}
    for key, item in value.items():
        if isinstance(item, (dict, list)):
            item = json.dumps(item, default=str)
        rendered[str(key)] = "" if item is None else str(item)
    return rendered


def _decode_response(response: httpx.Response, max_bytes: int) -> tuple[str, Any]:
    content = response.content
    if len(content) > max_bytes:
        raise StepFailure(
            f"response body is {len(content)} bytes, over the {max_bytes} byte limit",
            retryable=False,
        )
    encoding = response.encoding or "utf-8"
    text = content.decode(encoding, errors="replace")
    if not text:
        return text, None
    content_type = response.headers.get("content-type", "")
    if "json" in content_type.lower() or text.lstrip()[:1] in {"{", "["}:
        try:
            return text, json.loads(text)
        except json.JSONDecodeError:
            return text, None
    return text, None


def _classify_status(status_code: int, step: StepConfig) -> str:
    if step.expected_status is not None:
        if status_code in step.expected_status:
            return "ok"
        if status_code in step.retry_on_status:
            return "retry"
        return "fatal"
    if 200 <= status_code < 300:
        return "ok"
    if status_code in step.retry_on_status:
        return "retry"
    return "fatal"


def _extract_fields(parsed: Any, step: StepConfig) -> dict[str, Any]:
    if not step.extract:
        return {}
    if parsed is None:
        raise StepFailure("response is not JSON, so extract paths cannot be read", retryable=False)
    extracted: dict[str, Any] = {}
    for name, path in step.extract.items():
        try:
            extracted[name] = extract_value(parsed, path)
        except ExtractError as exc:
            raise StepFailure(f"extract '{name}' failed: {exc}", retryable=False) from exc
    return extracted


def _backoff_delay(step: StepConfig, attempt_index: int) -> float:
    delay = step.retry_backoff_seconds * (2**attempt_index)
    return min(delay, MAX_BACKOFF_SECONDS)


def _elapsed_ms(started: float) -> int:
    return int((time.perf_counter() - started) * 1000)


def _attempt(
    attempt: int,
    *,
    request: dict[str, Any] | None,
    response: dict[str, Any] | None,
    error: str | None,
    duration_ms: int,
    retry_delay_ms: int | None = None,
) -> dict[str, Any]:
    return {
        "attempt": attempt,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "duration_ms": duration_ms,
        "request": request,
        "response": response,
        "error": error,
        "retry_delay_ms": retry_delay_ms,
    }


def _step_result(
    index: int,
    step: StepConfig,
    status: str,
    attempts: list[dict[str, Any]],
    extracted: dict[str, Any],
    error: str | None,
) -> dict[str, Any]:
    return {
        "step_index": index,
        "step_id": step.id,
        "step_name": step.name,
        "status": status,
        "attempts": attempts,
        "extracted": extracted,
        "error": error,
    }


def _skipped_step(index: int, step: StepConfig) -> dict[str, Any]:
    return _step_result(
        index,
        step,
        "skipped",
        [],
        {},
        "skipped because a previous step failed",
    )

