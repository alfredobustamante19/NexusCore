"""Self-hosted sequential API orchestration."""

__version__ = "1.0.0"
