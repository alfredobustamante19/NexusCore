const state = {
  pipelines: [],
  draft: null,
  mode: "visual",
  runs: [],
  activeRun: null,
  token: sessionStorage.getItem("pipeline_api_token") || "",
  busy: false,
};

const fieldClass =
  "w-full border border-stone-300 bg-white px-2 py-1.5 text-sm text-stone-900 outline-none focus:border-teal-700";
const monoField =
  "w-full border border-stone-300 bg-white px-2 py-1.5 font-mono text-sm text-stone-900 outline-none focus:border-teal-700";
const smallBtn =
  "border border-stone-300 bg-white px-2 py-1 text-xs font-medium text-stone-700 hover:bg-stone-50";

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("token-input").value = state.token;
  document.getElementById("new-pipeline").addEventListener("click", () => openDraft(blankDraft()));
  document.getElementById("empty-new").addEventListener("click", () => openDraft(blankDraft()));
  document.getElementById("empty-example").addEventListener("click", () => openDraft(echoDraft(null)));
  document.getElementById("load-example").addEventListener("click", () => {
    const current = state.draft;
    openDraft(echoDraft(current && current.id));
    if (current && current.name) {
      state.draft.name = current.name;
      document.getElementById("pipeline-name").value = current.name;
    }
  });
  document.getElementById("add-step").addEventListener("click", () => guard(addStep));
  document.getElementById("save-pipeline").addEventListener("click", () => guard(async () => {
    setBusy(true, "Saving…");
    await savePipeline();
  }));
  document.getElementById("run-button").addEventListener("click", () => guard(runPipeline));
  document.getElementById("delete-pipeline").addEventListener("click", () => guard(deletePipeline));
  document.getElementById("export-pipeline").addEventListener("click", () => guard(exportPipeline));
  document.getElementById("import-pipeline").addEventListener("click", () => document.getElementById("import-file").click());
  document.getElementById("import-file").addEventListener("change", (event) => guard(() => importPipeline(event)));
  document.getElementById("save-token").addEventListener("click", () => guard(saveToken));
  document.getElementById("mode-visual").addEventListener("click", () => guard(() => setMode("visual")));
  document.getElementById("mode-json").addEventListener("click", () => guard(() => setMode("json")));
  document.getElementById("pipeline-list").addEventListener("click", (event) => {
    const button = event.target.closest("[data-pipeline-id]");
    if (!button) return;
    guard(() => selectPipeline(button.dataset.pipelineId));
  });
  document.getElementById("history").addEventListener("click", (event) => {
    const button = event.target.closest("[data-run-id]");
    if (!button) return;
    const run = state.runs.find((item) => item.id === button.dataset.runId);
    if (!run) return;
    state.activeRun = run;
    renderTrace(run);
    renderHistory();
  });
  const steps = document.getElementById("steps");
  steps.addEventListener("input", onStepEdit);
  steps.addEventListener("change", onStepEdit);
  steps.addEventListener("click", onStepClick);
  renderTrace(null);
  renderHistory();
  guard(boot);
});

async function boot() {
  await refreshHealth();
  await loadPipelines();
}

async function refreshHealth() {
  const status = document.getElementById("health-status");
  try {
    await api("/api/health");
    status.textContent = "Engine online";
    status.className = "text-xs text-teal-300";
  } catch (error) {
    status.textContent = "Engine unreachable";
    status.className = "text-xs text-red-300";
    throw error;
  }
}

async function loadPipelines() {
  state.pipelines = await api("/api/pipelines");
  renderList();
}

function renderList() {
  const list = document.getElementById("pipeline-list");
  const items = [];
  if (state.draft && !state.draft.id) {
    items.push(listButton("", state.draft.name || "Unsaved draft", "Draft", true));
  }
  for (const pipeline of state.pipelines) {
    const selected = Boolean(state.draft && state.draft.id === pipeline.id);
    const label = pipeline.is_active ? `${pipeline.steps.length} steps` : "Inactive";
    items.push(listButton(pipeline.id, pipeline.name, label, selected));
  }
  list.innerHTML = items.length
    ? items.join("")
    : '<p class="px-2 py-3 text-sm text-stone-500">No pipelines yet.</p>';
}

function listButton(id, name, meta, selected) {
  const selectedClass = selected ? "bg-stone-800 text-white" : "text-stone-200 hover:bg-stone-900";
  const data = id ? `data-pipeline-id="${esc(id)}"` : "data-pipeline-id=\"\"";
  return `<button type="button" ${data} class="block w-full px-2 py-2 text-left ${selectedClass}">
    <span class="block truncate text-sm font-medium">${esc(name)}</span>
    <span class="block text-xs text-stone-400">${esc(meta)}</span>
  </button>`;
}

function openDraft(draft) {
  state.draft = draft;
  state.mode = "visual";
  state.activeRun = null;
  state.runs = [];
  document.getElementById("empty-state").classList.add("hidden");
  document.getElementById("workspace").classList.remove("hidden");
  document.getElementById("pipeline-name").value = draft.name;
  document.getElementById("pipeline-description").value = draft.description;
  document.getElementById("pipeline-active").checked = draft.is_active;
  if (draft.rawStepsJson) {
    state.mode = "json";
    document.getElementById("steps-json").value = draft.rawStepsJson;
  } else {
    document.getElementById("steps-json").value = "";
  }
  clearBanner();
  applyMode();
  renderSteps();
  renderTrace(null);
  renderHistory();
  renderList();
  if (draft.id) {
    guard(loadRuns);
  }
}

async function selectPipeline(id) {
  if (!id) return;
  const pipeline = await api(`/api/pipelines/${id}`);
  openDraft(draftFromPipeline(pipeline));
  if (pipeline.definition_error) {
    showBanner(pipeline.definition_error, false);
  }
}

function blankDraft() {
  return {
    id: null,
    name: "",
    description: "",
    is_active: true,
    steps: [editorStep({ id: "step_1", name: "Step 1", method: "GET" })],
  };
}

function echoDraft(id) {
  const origin = window.location.origin;
  return {
    id: id || null,
    name: "Echo chain",
    description: "Create a record, then confirm it with the id extracted from step 1.",
    is_active: true,
    steps: [
      editorStep({
        id: "create_record",
        name: "Create record",
        method: "POST",
        url: `${origin}/api/echo`,
        headers: { "Content-Type": "application/json" },
        body: { name: "{{input.name}}", role: "engineer" },
        body_mode: "json",
        timeout_seconds: 10,
        retries: 2,
        retry_backoff_seconds: 0.25,
        extract: { record_id: "id", name: "received.name" },
      }),
      editorStep({
        id: "confirm_record",
        name: "Confirm record",
        method: "POST",
        url: `${origin}/api/echo`,
        headers: {
          "Content-Type": "application/json",
          "X-Record-Id": "{{steps.create_record.extract.record_id}}",
        },
        body: {
          parent_id: "{{steps.create_record.extract.record_id}}",
          name: "{{steps.create_record.extract.name}}",
        },
        body_mode: "json",
        timeout_seconds: 10,
        retries: 1,
        retry_backoff_seconds: 0.25,
        extract: { confirmation_id: "$.id" },
      }),
    ],
  };
}

function draftFromPipeline(pipeline) {
  const draft = {
    id: pipeline.id,
    name: pipeline.name,
    description: pipeline.description || "",
    is_active: pipeline.is_active,
    steps: (pipeline.steps || []).map((step) => editorStep(step)),
  };
  if (pipeline.definition_error) {
    draft.rawStepsJson = formatStoredJson(pipeline.steps_config_json);
  }
  return draft;
}

function formatStoredJson(raw) {
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch (error) {
    return raw || "[]";
  }
}

function editorStep(partial) {
  const source = partial || {};
  return {
    id: source.id || "step_1",
    name: source.name || "Step",
    method: source.method || "POST",
    url: source.url || "",
    headerRows: rowsFrom(source.headers),
    queryRows: rowsFrom(source.query),
    bodyText: bodyToText(source.body),
    bodyMode: source.body_mode || source.bodyMode || "json",
    timeout: source.timeout_seconds ?? source.timeout ?? 30,
    retries: source.retries ?? 2,
    backoff: source.retry_backoff_seconds ?? source.backoff ?? 0.5,
    retryOnStatus: codesToText(source.retry_on_status, "408, 429, 500, 502, 503, 504"),
    expectedStatus: codesToText(source.expected_status, ""),
    followRedirects: Boolean(source.follow_redirects ?? source.followRedirects),
    extractRows: rowsFrom(source.extract),
    continueOnError: Boolean(source.continue_on_error ?? source.continueOnError),
  };
}

function rowsFrom(value) {
  if (Array.isArray(value)) return value.map((row) => ({ key: row.key || "", value: row.value || "" }));
  return Object.entries(value || {}).map(([key, item]) => ({ key, value: String(item) }));
}

function bodyToText(body) {
  if (body === null || body === undefined) return "";
  if (typeof body === "string") return body;
  return JSON.stringify(body, null, 2);
}

function codesToText(value, fallback) {
  if (Array.isArray(value)) return value.join(", ");
  if (typeof value === "string") return value;
  return fallback;
}

function renderSteps() {
  const root = document.getElementById("steps");
  if (!state.draft.steps.length) {
    root.innerHTML = '<p class="border border-dashed border-stone-300 bg-white px-3 py-6 text-sm text-stone-500">No steps yet. Add one to start the sequence.</p>';
    return;
  }
  root.innerHTML = state.draft.steps.map((step, index) => stepCard(step, index, state.draft.steps.length)).join("");
}

function stepCard(step, index, total) {
  return `<details open data-step-card data-step-index="${index}" class="border border-stone-300 bg-white">
    <summary data-summary class="flex items-center gap-3 bg-stone-100 px-3 py-2 text-sm">${esc(summaryText(step, index))}</summary>
    <div class="space-y-3 px-3 py-3">
      <div class="flex flex-wrap gap-2">
        <button type="button" data-action="move-up" class="${smallBtn}" ${index === 0 ? "disabled" : ""}>Move up</button>
        <button type="button" data-action="move-down" class="${smallBtn}" ${index === total - 1 ? "disabled" : ""}>Move down</button>
        <button type="button" data-action="duplicate-step" class="${smallBtn}">Duplicate</button>
        <button type="button" data-action="remove-step" class="${smallBtn}">Remove</button>
      </div>
      <div class="grid gap-3 md:grid-cols-2">
        <label class="block text-sm">Name<input data-field="name" value="${esc(step.name)}" class="${fieldClass} mt-1" /></label>
        <label class="block text-sm">Step id<input data-field="id" value="${esc(step.id)}" spellcheck="false" class="${monoField} mt-1" /></label>
      </div>
      <label class="block text-sm">URL<input data-field="url" value="${esc(step.url)}" spellcheck="false" class="${monoField} mt-1" /></label>
      <div class="grid gap-3 md:grid-cols-4">
        <label class="block text-sm">Method
          <select data-field="method" class="${fieldClass} mt-1">${methodOptions(step.method)}</select>
        </label>
        <label class="block text-sm">Timeout (s)<input data-field="timeout" type="number" min="0.1" max="120" step="0.1" value="${esc(step.timeout)}" class="${fieldClass} mt-1" /></label>
        <label class="block text-sm">Retries<input data-field="retries" type="number" min="0" max="8" step="1" value="${esc(step.retries)}" class="${fieldClass} mt-1" /></label>
        <label class="block text-sm">Backoff (s)<input data-field="backoff" type="number" min="0" max="30" step="0.1" value="${esc(step.backoff)}" class="${fieldClass} mt-1" /></label>
      </div>
      ${mapBlock("Headers", "headers", step.headerRows, "Header name", "Value")}
      ${mapBlock("Query", "query", step.queryRows, "Query name", "Value")}
      <div class="grid gap-3 md:grid-cols-[10rem_minmax(0,1fr)]">
        <label class="block text-sm">Body
          <select data-field="body-mode" class="${fieldClass} mt-1">${bodyModeOptions(step.bodyMode)}</select>
        </label>
        <label class="block text-sm">Payload<textarea data-field="body" rows="6" spellcheck="false" class="${monoField} mt-1">${esc(step.bodyText)}</textarea></label>
      </div>
      ${mapBlock("Extract", "extract", step.extractRows, "name", "data.id or $.data.id")}
      <div class="grid gap-3 md:grid-cols-2">
        <label class="block text-sm">Retry on status<input data-field="retry-on" value="${esc(step.retryOnStatus)}" class="${monoField} mt-1" /></label>
        <label class="block text-sm">Expected status (optional)<input data-field="expected" value="${esc(step.expectedStatus)}" placeholder="200, 201" class="${monoField} mt-1" /></label>
      </div>
      <label class="flex items-center gap-2 text-sm"><input data-field="continue" type="checkbox" ${step.continueOnError ? "checked" : ""} class="size-4 accent-teal-800" />Continue on error</label>
      <label class="flex items-center gap-2 text-sm"><input data-field="follow-redirects" type="checkbox" ${step.followRedirects ? "checked" : ""} class="size-4 accent-teal-800" />Follow redirects</label>
    </div>
  </details>`;
}

function mapBlock(title, kind, rows, keyPlaceholder, valuePlaceholder) {
  const visible = rows.filter((row) => row.key || row.value);
  visible.push({ key: "", value: "" });
  const rendered = visible
    .map((row, index) => rowHtml(kind, row, keyPlaceholder, valuePlaceholder, index === visible.length - 1 && !row.key && !row.value))
    .join("");
  return `<fieldset>
    <legend class="mb-2 text-sm font-medium">${title}</legend>
    <div data-kind="${kind}" class="space-y-2">${rendered}</div>
  </fieldset>`;
}

function rowHtml(kind, row, keyPlaceholder, valuePlaceholder, blank) {
  return `<div data-row-kind="${kind}" class="grid grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto] gap-2">
    <input data-field="key" value="${esc(row.key)}" placeholder="${esc(keyPlaceholder)}" spellcheck="false" class="${monoField}" />
    <input data-field="value" value="${esc(row.value)}" placeholder="${esc(valuePlaceholder)}" spellcheck="false" class="${monoField}" />
    <button type="button" data-action="remove-row" class="${smallBtn} ${blank ? "invisible" : ""}">Remove</button>
  </div>`;
}

function methodOptions(current) {
  return ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]
    .map((method) => `<option value="${method}" ${method === current ? "selected" : ""}>${method}</option>`)
    .join("");
}

function bodyModeOptions(current) {
  return ["json", "text", "form", "none"]
    .map((mode) => `<option value="${mode}" ${mode === current ? "selected" : ""}>${mode}</option>`)
    .join("");
}

function summaryText(step, index) {
  return `${index + 1}  ${step.method || "GET"}  ${step.name || "Untitled"}  ${step.url || "No URL"}`;
}

function onStepEdit(event) {
  const card = event.target.closest("[data-step-card]");
  if (!card || !state.draft) return;
  maybeAppendBlank(event.target);
  const index = Number(card.dataset.stepIndex);
  state.draft.steps[index] = readCard(card);
  const summary = card.querySelector("[data-summary]");
  if (summary) summary.textContent = summaryText(state.draft.steps[index], index);
}

function maybeAppendBlank(target) {
  const row = target.closest("[data-row-kind]");
  if (!row || (target.dataset.field !== "key" && target.dataset.field !== "value")) return;
  const list = row.parentElement;
  const rows = [...list.querySelectorAll(":scope > [data-row-kind]")];
  const last = rows[rows.length - 1];
  if (row === last && last.querySelector("[data-field='key']").value.trim()) {
    last.querySelector("[data-action='remove-row']").classList.remove("invisible");
    const kind = last.dataset.rowKind;
    const placeholders = kind === "extract" ? ["name", "data.id or $.data.id"] : ["name", "value"];
    list.insertAdjacentHTML("beforeend", rowHtml(kind, { key: "", value: "" }, placeholders[0], placeholders[1], true));
  }
}

function onStepClick(event) {
  const button = event.target.closest("[data-action]");
  if (!button || !state.draft) return;
  const action = button.dataset.action;
  if (action === "remove-row") {
    const row = button.closest("[data-row-kind]");
    const list = row.parentElement;
    const kind = row.dataset.rowKind;
    row.remove();
    if (!list.querySelector("[data-row-kind]")) {
      const placeholders = kind === "extract" ? ["name", "data.id or $.data.id"] : ["name", "value"];
      list.insertAdjacentHTML("beforeend", rowHtml(kind, { key: "", value: "" }, placeholders[0], placeholders[1], true));
    }
    onStepEdit({ target: list });
    return;
  }
  const card = button.closest("[data-step-card]");
  const index = Number(card.dataset.stepIndex);
  if (action === "move-up") moveStep(index, -1);
  if (action === "move-down") moveStep(index, 1);
  if (action === "duplicate-step") duplicateStep(index);
  if (action === "remove-step") removeStep(index);
}

function moveStep(index, delta) {
  syncDraftFromDom();
  const next = index + delta;
  if (next < 0 || next >= state.draft.steps.length) return;
  const steps = state.draft.steps;
  const [item] = steps.splice(index, 1);
  steps.splice(next, 0, item);
  renderSteps();
}

function duplicateStep(index) {
  syncDraftFromDom();
  const copy = structuredClone(state.draft.steps[index]);
  copy.id = nextStepId(state.draft.steps, copy.id);
  copy.name = `${copy.name} copy`;
  state.draft.steps.splice(index + 1, 0, copy);
  renderSteps();
}

function removeStep(index) {
  syncDraftFromDom();
  state.draft.steps.splice(index, 1);
  renderSteps();
}

function addStep() {
  if (state.mode === "json") setMode("visual");
  syncDraftFromDom();
  const id = nextStepId(state.draft.steps, "step");
  state.draft.steps.push(editorStep({ id, name: `Step ${state.draft.steps.length + 1}`, method: "POST" }));
  renderSteps();
}

function nextStepId(steps, base) {
  const ids = new Set(steps.map((step) => step.id));
  const root = String(base || "step").replace(/_\d+$/, "") || "step";
  let n = steps.length + 1;
  let candidate = `${root}_${n}`;
  while (ids.has(candidate)) {
    n += 1;
    candidate = `${root}_${n}`;
  }
  return candidate;
}

function setMode(mode) {
  if (!state.draft || mode === state.mode) return;
  if (mode === "json") {
    syncDraftFromDom();
    const apiSteps = state.draft.steps.map((step, index) => toApiStep(step, index));
    document.getElementById("steps-json").value = JSON.stringify(apiSteps, null, 2);
  } else {
    const parsed = JSON.parse(document.getElementById("steps-json").value || "[]");
    if (!Array.isArray(parsed)) throw new Error("Steps JSON must be an array");
    state.draft.steps = parsed.map((step) => editorStep(step));
    renderSteps();
  }
  state.mode = mode;
  applyMode();
}

function applyMode() {
  const visual = state.mode === "visual";
  document.getElementById("visual-panel").classList.toggle("hidden", !visual);
  document.getElementById("json-panel").classList.toggle("hidden", visual);
  document.getElementById("add-step").classList.toggle("hidden", !visual);
  styleModeButton(document.getElementById("mode-visual"), visual);
  styleModeButton(document.getElementById("mode-json"), !visual);
}

function styleModeButton(button, active) {
  button.className = active
    ? "bg-stone-900 px-3 py-1.5 text-sm font-medium text-white"
    : "bg-white px-3 py-1.5 text-sm font-medium text-stone-700";
}

function syncDraftFromDom() {
  if (!state.draft) return;
  state.draft.name = document.getElementById("pipeline-name").value;
  state.draft.description = document.getElementById("pipeline-description").value;
  state.draft.is_active = document.getElementById("pipeline-active").checked;
  if (state.mode !== "visual") return;
  const cards = [...document.querySelectorAll("[data-step-card]")];
  if (!cards.length && state.draft.steps.length) return;
  state.draft.steps = cards.map((card) => readCard(card));
}

function readCard(card) {
  const value = (field) => {
    const element = card.querySelector(`[data-field="${field}"]`);
    return element ? element.value : "";
  };
  return {
    id: value("id"),
    name: value("name"),
    method: value("method"),
    url: value("url"),
    headerRows: readRows(card, "headers"),
    queryRows: readRows(card, "query"),
    bodyText: value("body"),
    bodyMode: value("body-mode"),
    timeout: value("timeout"),
    retries: value("retries"),
    backoff: value("backoff"),
    retryOnStatus: value("retry-on"),
    expectedStatus: value("expected"),
    followRedirects: card.querySelector("[data-field='follow-redirects']").checked,
    extractRows: readRows(card, "extract"),
    continueOnError: card.querySelector("[data-field='continue']").checked,
  };
}

function readRows(card, kind) {
  return [...card.querySelectorAll(`[data-row-kind="${kind}"]`)]
    .map((row) => ({
      key: row.querySelector("[data-field='key']").value,
      value: row.querySelector("[data-field='value']").value,
    }))
    .filter((row) => row.key.trim() || row.value.trim());
}

function currentApiSteps() {
  if (state.mode === "json") {
    const parsed = JSON.parse(document.getElementById("steps-json").value || "[]");
    if (!Array.isArray(parsed)) throw new Error("Steps JSON must be an array");
    return parsed;
  }
  syncDraftFromDom();
  return state.draft.steps.map((step, index) => toApiStep(step, index));
}

function toApiStep(step, index) {
  const label = `Step ${index + 1} (${step.name || step.id || "untitled"})`;
  let body = null;
  try {
    if (step.bodyMode === "json" || step.bodyMode === "form") {
      const text = String(step.bodyText || "").trim();
      if (text) body = JSON.parse(text);
      else if (step.bodyMode === "form") body = {};
    } else if (step.bodyMode === "text") {
      body = step.bodyText;
    }
  } catch (error) {
    throw new Error(`${label} body is not valid JSON`);
  }
  if (!String(step.url || "").trim()) throw new Error(`${label} needs a URL`);
  return {
    id: String(step.id || "").trim(),
    name: String(step.name || "").trim(),
    method: step.method,
    url: String(step.url || "").trim(),
    headers: rowsToObject(step.headerRows, label),
    query: rowsToObject(step.queryRows, label),
    body,
    body_mode: step.bodyMode,
    timeout_seconds: Number(step.timeout),
    retries: Number(step.retries),
    retry_backoff_seconds: Number(step.backoff),
    retry_on_status: parseCodes(step.retryOnStatus, false, label),
    expected_status: parseCodes(step.expectedStatus, true, label),
    follow_redirects: Boolean(step.followRedirects),
    extract: rowsToObject(step.extractRows, label),
    continue_on_error: Boolean(step.continueOnError),
  };
}

function rowsToObject(rows, label) {
  const result = {};
  for (const row of rows || []) {
    const key = String(row.key || "").trim();
    if (!key) {
      if (String(row.value || "").trim()) throw new Error(`${label} has a row with a value and no name`);
      continue;
    }
    result[key] = row.value;
  }
  return result;
}

function parseCodes(text, emptyAsNull, label) {
  const parts = String(text || "")
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);
  if (!parts.length) return emptyAsNull ? null : [];
  return parts.map((part) => {
    const number = Number(part);
    if (!Number.isInteger(number)) throw new Error(`${label} has an invalid status code "${part}"`);
    return number;
  });
}

async function savePipeline() {
  const steps = currentApiSteps();
  const body = {
    name: document.getElementById("pipeline-name").value.trim(),
    description: document.getElementById("pipeline-description").value.trim(),
    is_active: document.getElementById("pipeline-active").checked,
    steps,
  };
  if (!body.name) throw new Error("Name is required");
  const saved = state.draft.id
    ? await api(`/api/pipelines/${state.draft.id}`, { method: "PUT", body: JSON.stringify(body) })
    : await api("/api/pipelines", { method: "POST", body: JSON.stringify(body) });
  state.draft = draftFromPipeline(saved);
  state.mode = "visual";
  document.getElementById("pipeline-name").value = saved.name;
  document.getElementById("pipeline-description").value = saved.description || "";
  document.getElementById("pipeline-active").checked = saved.is_active;
  applyMode();
  renderSteps();
  await loadPipelines();
  showBanner("Saved.", true);
  return saved;
}

async function runPipeline() {
  const raw = document.getElementById("run-input").value.trim() || "{}";
  let input;
  try {
    input = JSON.parse(raw);
  } catch (error) {
    throw new Error("Trigger input is not valid JSON");
  }
  if (input === null || Array.isArray(input) || typeof input !== "object") {
    throw new Error("Trigger input must be a JSON object");
  }
  setBusy(true, "Running…");
  await savePipeline();
  const run = await api(`/api/pipelines/${state.draft.id}/run`, {
    method: "POST",
    body: JSON.stringify({ input }),
  });
  state.activeRun = run;
  renderTrace(run);
  await loadRuns();
  if (run.status === "success") showBanner("Run finished successfully.", true);
  else showBanner("Run failed. The trace lists the step and the error.", false);
}

async function loadRuns() {
  const id = state.draft && state.draft.id;
  if (!id) {
    state.runs = [];
    renderHistory();
    return;
  }
  const runs = await api(`/api/pipelines/${id}/runs`);
  if (!state.draft || state.draft.id !== id) return;
  state.runs = runs;
  renderHistory();
}

async function deletePipeline() {
  if (!state.draft) return;
  if (!state.draft.id) {
    state.draft = null;
    document.getElementById("workspace").classList.add("hidden");
    document.getElementById("empty-state").classList.remove("hidden");
    await loadPipelines();
    return;
  }
  const confirmed = await confirmAction(`Delete "${state.draft.name}"? Run history for this pipeline is removed too.`);
  if (!confirmed) return;
  await api(`/api/pipelines/${state.draft.id}`, { method: "DELETE" });
  state.draft = null;
  state.runs = [];
  state.activeRun = null;
  document.getElementById("workspace").classList.add("hidden");
  document.getElementById("empty-state").classList.remove("hidden");
  await loadPipelines();
}

function exportPipeline() {
  const steps = currentApiSteps();
  const payload = {
    name: document.getElementById("pipeline-name").value.trim(),
    description: document.getElementById("pipeline-description").value.trim(),
    is_active: document.getElementById("pipeline-active").checked,
    steps,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${(payload.name || "pipeline").replace(/\s+/g, "-").toLowerCase()}.pipeline.json`;
  link.click();
  URL.revokeObjectURL(link.href);
}

async function importPipeline(event) {
  const file = event.target.files && event.target.files[0];
  event.target.value = "";
  if (!file) return;
  const parsed = JSON.parse(await file.text());
  const steps = Array.isArray(parsed) ? parsed : parsed.steps;
  if (!Array.isArray(steps)) throw new Error("Import JSON must be a pipeline object or a steps array");
  const draft = {
    id: state.draft ? state.draft.id : null,
    name: parsed.name || (state.draft && state.draft.name) || "Imported pipeline",
    description: parsed.description || "",
    is_active: parsed.is_active !== false,
    steps: steps.map((step) => editorStep(step)),
  };
  openDraft(draft);
  showBanner("Imported into the editor. Save to keep it.", true);
}

function renderTrace(run) {
  const root = document.getElementById("trace");
  if (!run) {
    root.innerHTML = '<p class="text-sm text-stone-500">Run a pipeline to inspect each request, response, extracted value, and error.</p>';
    return;
  }
  const steps = Array.isArray(run.trace) ? run.trace : [];
  root.innerHTML = `
    <div class="flex items-center justify-between gap-2">
      <h2 class="text-sm font-semibold tracking-wide text-stone-500 uppercase">Execution trace</h2>
      ${pill(run.status)}
    </div>
    <p class="font-mono text-xs text-stone-500">${esc(run.id)} · ${esc(String(run.duration_ms))} ms</p>
    ${steps.map(renderStepTrace).join("")}`;
}

function renderStepTrace(step) {
  const attempts = Array.isArray(step.attempts) ? step.attempts : [];
  const extracted = step.extracted && Object.keys(step.extracted).length ? prettyBlock("Extracted", step.extracted) : "";
  return `<article class="border border-stone-300 bg-white">
    <header class="flex flex-wrap items-center gap-2 border-b border-stone-200 px-3 py-2">
      <span class="text-xs text-stone-500">${esc(String((step.step_index ?? 0) + 1))}</span>
      <strong class="text-sm">${esc(step.step_name || "Step")}</strong>
      <code class="text-xs text-stone-500">${esc(step.step_id || "")}</code>
      ${pill(step.status)}
    </header>
    <div class="space-y-2 px-3 py-3">
      ${step.error ? `<p class="text-sm text-red-800">${esc(step.error)}</p>` : ""}
      ${extracted}
      ${attempts.map(renderAttempt).join("")}
    </div>
  </article>`;
}

function renderAttempt(attempt) {
  const response = attempt.response;
  const status = response && response.status_code !== undefined ? `HTTP ${response.status_code}` : "No response";
  const request = attempt.request;
  const title = request ? `${request.method} ${request.url}` : "Request was not sent";
  return `<details class="border border-stone-200 bg-stone-50" open>
    <summary class="px-2 py-1.5 text-xs font-medium">Attempt ${esc(String(attempt.attempt))} · ${esc(status)} · ${esc(String(attempt.duration_ms))} ms</summary>
    <div class="space-y-2 px-2 py-2">
      <p class="break-all font-mono text-xs">${esc(title)}</p>
      ${attempt.error ? `<p class="text-xs text-red-800">${esc(attempt.error)}</p>` : ""}
      ${attempt.retry_delay_ms !== null && attempt.retry_delay_ms !== undefined ? `<p class="text-xs text-stone-500">Waited ${esc(String(attempt.retry_delay_ms))} ms before the next attempt.</p>` : ""}
      ${request ? prettyBlock("Request", request) : ""}
      ${response ? prettyBlock("Response", response) : ""}
    </div>
  </details>`;
}

function prettyBlock(title, value) {
  return `<div>
    <p class="text-xs font-medium tracking-wide text-stone-500 uppercase">${esc(title)}</p>
    <pre class="mt-1 max-h-64 overflow-auto border border-stone-200 bg-white p-2 text-xs leading-relaxed">${esc(pretty(value))}</pre>
  </div>`;
}

function renderHistory() {
  const root = document.getElementById("history");
  if (!state.runs.length) {
    root.innerHTML = '<p class="text-sm text-stone-500">No runs yet.</p>';
    return;
  }
  root.innerHTML = state.runs
    .map((run) => {
      const selected = state.activeRun && state.activeRun.id === run.id ? "border-teal-700" : "border-stone-300";
      return `<button type="button" data-run-id="${esc(run.id)}" class="block w-full border ${selected} bg-white px-2 py-2 text-left hover:bg-stone-100">
        <span class="flex items-center justify-between gap-2">${pill(run.status)}<span class="font-mono text-xs text-stone-500">${esc(String(run.duration_ms))} ms</span></span>
        <span class="mt-1 block text-xs text-stone-500">${esc(formatTime(run.triggered_at))}</span>
      </button>`;
    })
    .join("");
}

function pill(status) {
  const tone =
    status === "success"
      ? "bg-emerald-100 text-emerald-900"
      : status === "failed"
        ? "bg-red-100 text-red-900"
        : status === "running"
          ? "bg-amber-100 text-amber-950"
          : "bg-stone-200 text-stone-700";
  return `<span class="inline-flex px-1.5 py-0.5 text-xs font-medium uppercase ${tone}">${esc(status || "unknown")}</span>`;
}

function pretty(value) {
  if (typeof value === "string") return value;
  return JSON.stringify(value, null, 2);
}

function formatTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value || "");
  return date.toLocaleString();
}

function confirmAction(message) {
  const dialog = document.getElementById("confirm-dialog");
  document.getElementById("confirm-message").textContent = message;
  dialog.showModal();
  return new Promise((resolve) => {
    dialog.addEventListener(
      "close",
      () => {
        resolve(dialog.returnValue === "confirm");
      },
      { once: true },
    );
  });
}

async function saveToken() {
  state.token = document.getElementById("token-input").value.trim();
  sessionStorage.setItem("pipeline_api_token", state.token);
  await boot();
  showBanner("Token saved in this browser session.", true);
}

function setBusy(busy, label) {
  state.busy = busy;
  for (const element of document.querySelectorAll("[data-busy]")) element.disabled = busy;
  document.getElementById("run-button").textContent = busy && label === "Running…" ? "Running…" : "Run pipeline";
  document.getElementById("save-pipeline").textContent = busy && label === "Saving…" ? "Saving…" : "Save";
}

function showBanner(message, ok) {
  const banner = document.getElementById("banner");
  banner.textContent = message;
  banner.className = ok
    ? "border-b border-emerald-200 bg-emerald-50 px-4 py-2 text-sm text-emerald-950 md:px-6"
    : "border-b border-red-200 bg-red-50 px-4 py-2 text-sm text-red-950 md:px-6";
}

function clearBanner() {
  const banner = document.getElementById("banner");
  banner.textContent = "";
  banner.className = "hidden px-4 py-2 text-sm md:px-6";
}

async function guard(work) {
  try {
    await work();
  } catch (error) {
    showBanner(error.message || "Request failed", false);
  } finally {
    if (state.busy) setBusy(false);
  }
}

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (state.token) headers.set("Authorization", `Bearer ${state.token}`);
  const response = await fetch(path, { ...options, headers });
  if (response.status === 204) return null;
  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (error) {
      data = { detail: text };
    }
  }
  if (!response.ok) {
    const message = formatDetail(data && data.detail) || response.statusText;
    throw new Error(message);
  }
  return data;
}

function formatDetail(detail) {
  if (!detail) return "";
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((item) => {
        const location = Array.isArray(item.loc) ? item.loc.filter((part) => part !== "body").join(".") : "";
        return location ? `${location}: ${item.msg}` : item.msg;
      })
      .join("\n");
  }
  return JSON.stringify(detail);
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]);
}
