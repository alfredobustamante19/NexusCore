"""FastAPI application entrypoint."""

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app import __version__
from app.config import Settings, get_settings
from app.database import init_db, make_engine
from app.engine import Orchestrator
from app.routes import router

STATIC_DIR = Path(__file__).resolve().parent / "static"


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        init_db(app.state.db_engine)
        yield
        app.state.db_engine.dispose()

    app = FastAPI(
        title="Pipeline Engine",
        version=__version__,
        summary="Self-hosted sequential API orchestration.",
        lifespan=lifespan,
    )
    app.state.settings = settings
    app.state.db_engine = make_engine(settings.database_url)
    app.state.orchestrator = Orchestrator(
        max_response_bytes=settings.max_response_bytes,
        url_allowlist=settings.allowed_hosts(),
    )
    app.include_router(router)
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/", include_in_schema=False)
    def dashboard() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=False)
