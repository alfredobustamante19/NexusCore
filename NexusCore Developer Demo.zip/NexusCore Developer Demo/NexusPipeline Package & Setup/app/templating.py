"""Substitute ``{{path}}`` placeholders from a pipeline context.

A placeholder that is the entire string keeps the resolved Python value, so a
JSON body can receive numbers, objects, and lists. A placeholder mixed into
other text is stringified.
"""

import json
import re
from typing import Any

from app.extract import ExtractError, extract_value

_PLACEHOLDER = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")


class TemplateError(ValueError):
    """Raised when a placeholder cannot be resolved."""


def render_value(value: Any, context: dict[str, Any]) -> Any:
    if isinstance(value, str):
        return _render_string(value, context)
    if isinstance(value, dict):
        return {key: render_value(item, context) for key, item in value.items()}
    if isinstance(value, list):
        return [render_value(item, context) for item in value]
    return value


def _render_string(value: str, context: dict[str, Any]) -> Any:
    matches = list(_PLACEHOLDER.finditer(value))
    if not matches:
        return value
    if len(matches) == 1 and matches[0].span() == (0, len(value)):
        return _resolve(matches[0].group(1), context)

    def _replace(match: re.Match[str]) -> str:
        resolved = _resolve(match.group(1), context)
        if resolved is None:
            return ""
        if isinstance(resolved, (dict, list)):
            return json.dumps(resolved, separators=(",", ":"), default=str)
        return str(resolved)

    return _PLACEHOLDER.sub(_replace, value)


def _resolve(expression: str, context: dict[str, Any]) -> Any:
    path = expression.strip()
    try:
        return extract_value(context, path)
    except ExtractError as exc:
        raise TemplateError(f"template variable '{path}' could not be resolved: {exc}") from exc
