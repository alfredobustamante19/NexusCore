"""Request and response models, including the step definition schema."""

import re
from datetime import datetime, timezone
from typing import Any, Literal
from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict, Field, field_serializer, field_validator, model_validator

HttpMethod = Literal["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]
BodyMode = Literal["json", "text", "form", "none"]
_STEP_ID = r"^[A-Za-z_][A-Za-z0-9_-]{0,63}$"
_DEFAULT_RETRY_STATUSES = [408, 429, 500, 502, 503, 504]


def isoformat_utc(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.isoformat()


class StepConfig(BaseModel):
    """One HTTP call in a pipeline.

    ``extract`` maps a name to a dot path (``data.user.id``) or a JSONPath
    (``$.data.user.id``). Later steps read those names from the template
    context as ``{{steps.<id>.extract.<name>}}``.
    """

    model_config = ConfigDict(extra="forbid")

    id: str = Field(pattern=_STEP_ID)
    name: str = Field(min_length=1, max_length=200)
    method: HttpMethod = "GET"
    url: str = Field(min_length=1, max_length=4000)
    headers: dict[str, str] = Field(default_factory=dict)
    query: dict[str, str] = Field(default_factory=dict)
    body: Any = None
    body_mode: BodyMode = "json"
    timeout_seconds: float = Field(default=30, gt=0, le=120)
    retries: int = Field(default=2, ge=0, le=8)
    retry_backoff_seconds: float = Field(default=0.5, ge=0, le=30)
    retry_on_status: list[int] = Field(default_factory=lambda: list(_DEFAULT_RETRY_STATUSES))
    expected_status: list[int] | None = None
    follow_redirects: bool = False
    extract: dict[str, str] = Field(default_factory=dict)
    continue_on_error: bool = False

    @field_validator("id", "name", "url", mode="before")
    @classmethod
    def _strip_text(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.strip()
        return value

    @field_validator("method", mode="before")
    @classmethod
    def _upper_method(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.strip().upper()
        return value

    @field_validator("headers", "query", mode="before")
    @classmethod
    def _stringify_maps(cls, value: Any) -> Any:
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise ValueError("must be an object of scalar values")
        rendered: dict[str, str] = {}
        for key, item in value.items():
            if isinstance(item, (dict, list)):
                raise ValueError(f"value for '{key}' must be a scalar")
            rendered[str(key).strip()] = "" if item is None else str(item)
        return rendered

    @field_validator("extract", mode="before")
    @classmethod
    def _clean_extract(cls, value: Any) -> Any:
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise ValueError("extract must be an object of name -> path")
        cleaned: dict[str, str] = {}
        for key, item in value.items():
            name = str(key).strip()
            path = "" if item is None else str(item).strip()
            if not name or not path:
                raise ValueError("extract names and paths must be non-empty")
            cleaned[name] = path
        return cleaned

    @field_validator("headers", "query", "extract")
    @classmethod
    def _cap_maps(cls, value: dict[str, str], info) -> dict[str, str]:
        if len(value) > 40:
            raise ValueError(f"{info.field_name} supports at most 40 entries")
        if any(not key for key in value):
            raise ValueError(f"{info.field_name} keys must be non-empty")
        if info.field_name == "extract":
            for name in value:
                if re.fullmatch(_STEP_ID, name) is None:
                    raise ValueError(
                        f"extract name '{name}' must start with a letter or underscore "
                        "and contain only letters, numbers, underscores, and hyphens"
                    )
        return value

    @field_validator("expected_status", mode="before")
    @classmethod
    def _empty_expected(cls, value: Any) -> Any:
        if value in ("", [], None):
            return None
        return value

    @field_validator("retry_on_status", "expected_status")
    @classmethod
    def _status_codes(cls, value: list[int] | None) -> list[int] | None:
        if value is None:
            return None
        return _validate_status_codes(value)

    @model_validator(mode="after")
    def _url_shape(self) -> "StepConfig":
        if "{{" in self.url:
            return self
        parsed = urlparse(self.url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("url must be an absolute http(s) URL, or contain a {{ template }}")
        return self


class PipelineCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=4000)
    steps: list[StepConfig] | None = None
    steps_config_json: str | None = None
    is_active: bool = True

    @field_validator("name", "description", mode="before")
    @classmethod
    def _strip(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.strip()
        return value

    @model_validator(mode="after")
    def _has_definition(self) -> "PipelineCreate":
        if self.steps is None and self.steps_config_json is None:
            raise ValueError("provide steps or steps_config_json")
        return self


class PipelineUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=4000)
    steps: list[StepConfig] | None = None
    steps_config_json: str | None = None
    is_active: bool | None = None

    @field_validator("name", "description", mode="before")
    @classmethod
    def _strip(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.strip()
        return value


class PipelineRead(BaseModel):
    id: str
    name: str
    description: str
    steps_config_json: str
    steps: list[StepConfig]
    is_active: bool
    created_at: datetime
    definition_error: str | None = None

    @field_serializer("created_at")
    def _serialize_created_at(self, value: datetime) -> str:
        return isoformat_utc(value)


class RunRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    input: dict[str, Any] = Field(default_factory=dict)


class PipelineRunRead(BaseModel):
    id: str
    pipeline_id: str
    status: str
    execution_trace_json: str
    trace: list[dict[str, Any]]
    duration_ms: int
    triggered_at: datetime

    @field_serializer("triggered_at")
    def _serialize_triggered_at(self, value: datetime) -> str:
        return isoformat_utc(value)


def _validate_status_codes(codes: list[int]) -> list[int]:
    cleaned: list[int] = []
    for code in codes:
        if isinstance(code, bool) or not isinstance(code, int):
            raise ValueError("status codes must be integers")
        if code < 100 or code > 599:
            raise ValueError(f"invalid HTTP status code {code}")
        if code not in cleaned:
            cleaned.append(code)
    return cleaned
