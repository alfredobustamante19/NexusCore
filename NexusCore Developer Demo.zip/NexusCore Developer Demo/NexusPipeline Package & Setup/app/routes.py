"""HTTP API for pipeline definitions, runs, and the local echo sink."""

import json
import logging
import secrets
import time
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlmodel import Session, col, delete, select

from app.config import Settings
from app.database import get_session
from app.definitions import dumps_steps, parse_steps_json, steps_from_write
from app.engine import Orchestrator
from app.models import Pipeline, PipelineRun, utcnow
from app.schemas import (
    PipelineCreate,
    PipelineRead,
    PipelineRunRead,
    PipelineUpdate,
    RunRequest,
    StepConfig,
)

logger = logging.getLogger("pipeline.api")
router = APIRouter()


def get_settings(request: Request) -> Settings:
    return request.app.state.settings


def get_orchestrator(request: Request) -> Orchestrator:
    return request.app.state.orchestrator


def require_api_token(request: Request, settings: Settings = Depends(get_settings)) -> None:
    expected = settings.api_token
    if not expected:
        return
    presented = _presented_token(request)
    if not presented or not secrets.compare_digest(presented, expected):
        raise HTTPException(status_code=401, detail="invalid or missing API token")


@router.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/api/echo")
async def echo(request: Request, settings: Settings = Depends(get_settings)) -> dict[str, Any]:
    """Local sink used by the bundled two-step example. It stores nothing."""

    if not settings.enable_echo:
        raise HTTPException(status_code=404, detail="echo endpoint is disabled")
    raw = await request.body()
    content_type = request.headers.get("content-type", "")
    received: Any
    if not raw:
        received = None
    elif "json" in content_type.lower():
        try:
            received = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=400, detail=f"invalid JSON body: {exc}") from exc
    else:
        received = raw.decode("utf-8", errors="replace")
    visible_headers = {
        key: value
        for key, value in request.headers.items()
        if key.lower() in {"content-type", "x-record-id", "x-pipeline-step", "x-pipeline-run-id"}
    }
    return {
        "id": str(uuid4()),
        "received": received,
        "query": dict(request.query_params),
        "headers_seen": visible_headers,
    }


@router.get("/api/pipelines", response_model=list[PipelineRead])
def list_pipelines(
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> list[PipelineRead]:
    rows = session.exec(select(Pipeline).order_by(Pipeline.created_at.desc())).all()
    return [_to_pipeline_read(row) for row in rows]


@router.post("/api/pipelines", response_model=PipelineRead, status_code=201)
def create_pipeline(
    payload: PipelineCreate,
    request: Request,
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> PipelineRead:
    steps = _steps_or_400(payload, request.app.state.settings.max_steps)
    row = Pipeline(
        name=payload.name,
        description=payload.description,
        steps_config_json=dumps_steps(steps),
        is_active=payload.is_active,
    )
    session.add(row)
    session.commit()
    session.refresh(row)
    return _to_pipeline_read(row)


@router.get("/api/pipelines/{pipeline_id}", response_model=PipelineRead)
def get_pipeline(
    pipeline_id: str,
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> PipelineRead:
    return _to_pipeline_read(_get_pipeline(session, pipeline_id))


@router.put("/api/pipelines/{pipeline_id}", response_model=PipelineRead)
def replace_pipeline(
    pipeline_id: str,
    payload: PipelineCreate,
    request: Request,
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> PipelineRead:
    row = _get_pipeline(session, pipeline_id)
    steps = _steps_or_400(payload, request.app.state.settings.max_steps)
    row.name = payload.name
    row.description = payload.description
    row.steps_config_json = dumps_steps(steps)
    row.is_active = payload.is_active
    session.add(row)
    session.commit()
    session.refresh(row)
    return _to_pipeline_read(row)


@router.patch("/api/pipelines/{pipeline_id}", response_model=PipelineRead)
def update_pipeline(
    pipeline_id: str,
    payload: PipelineUpdate,
    request: Request,
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> PipelineRead:
    row = _get_pipeline(session, pipeline_id)
    if payload.name is not None:
        row.name = payload.name
    if payload.description is not None:
        row.description = payload.description
    if payload.is_active is not None:
        row.is_active = payload.is_active
    if payload.steps is not None or payload.steps_config_json is not None:
        steps = _steps_or_400(payload, request.app.state.settings.max_steps)
        row.steps_config_json = dumps_steps(steps or [])
    session.add(row)
    session.commit()
    session.refresh(row)
    return _to_pipeline_read(row)


@router.delete("/api/pipelines/{pipeline_id}", status_code=204)
def delete_pipeline(
    pipeline_id: str,
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> Response:
    row = _get_pipeline(session, pipeline_id)
    session.exec(delete(PipelineRun).where(col(PipelineRun.pipeline_id) == row.id))
    session.delete(row)
    session.commit()
    return Response(status_code=204)


@router.get("/api/pipelines/{pipeline_id}/runs", response_model=list[PipelineRunRead])
def list_runs(
    pipeline_id: str,
    limit: int = 50,
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> list[PipelineRunRead]:
    _get_pipeline(session, pipeline_id)
    bounded = min(max(limit, 1), 200)
    rows = session.exec(
        select(PipelineRun)
        .where(PipelineRun.pipeline_id == pipeline_id)
        .order_by(PipelineRun.triggered_at.desc())
        .limit(bounded)
    ).all()
    return [_to_run_read(row) for row in rows]


@router.get("/api/runs/{run_id}", response_model=PipelineRunRead)
def get_run(
    run_id: str,
    session: Session = Depends(get_session),
    _: None = Depends(require_api_token),
) -> PipelineRunRead:
    row = session.get(PipelineRun, run_id)
    if row is None:
        raise HTTPException(status_code=404, detail="run not found")
    return _to_run_read(row)


@router.post("/api/pipelines/{pipeline_id}/run", response_model=PipelineRunRead)
async def run_pipeline(
    pipeline_id: str,
    request: Request,
    payload: RunRequest | None = None,
    orchestrator: Orchestrator = Depends(get_orchestrator),
    _: None = Depends(require_api_token),
) -> PipelineRunRead:
    # Open a short session, then close it before any outbound HTTP so SQLite
    # is not locked for the whole sequence.
    with Session(request.app.state.db_engine) as session:
        pipeline = _get_pipeline(session, pipeline_id)
        if not pipeline.is_active:
            raise HTTPException(status_code=409, detail="pipeline is inactive")
        try:
            steps = parse_steps_json(
                pipeline.steps_config_json,
                max_steps=request.app.state.settings.max_steps,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        if not steps:
            raise HTTPException(status_code=400, detail="pipeline has no steps")

        trigger_input = (payload or RunRequest()).input
        if len(json.dumps(trigger_input, default=str)) > 200_000:
            raise HTTPException(status_code=400, detail="trigger input is too large")
        run = PipelineRun(
            pipeline_id=pipeline.id,
            status="running",
            execution_trace_json="[]",
            duration_ms=0,
            triggered_at=utcnow(),
        )
        session.add(run)
        session.commit()
        session.refresh(run)
        run_id = run.id

    started = time.perf_counter()
    try:
        result = await orchestrator.execute(steps, trigger_input, run_id=run_id)
        status = result["status"]
        trace = result["trace"]
    except Exception as exc:
        logger.exception("pipeline run %s crashed", run_id)
        status = "failed"
        trace = [
            {
                "step_index": 0,
                "step_id": "",
                "step_name": "",
                "status": "failed",
                "attempts": [],
                "extracted": {},
                "error": f"engine error: {exc}",
            }
        ]
    duration_ms = int((time.perf_counter() - started) * 1000)

    with Session(request.app.state.db_engine) as write_session:
        stored = write_session.get(PipelineRun, run_id)
        if stored is None:
            raise HTTPException(status_code=500, detail="run record disappeared")
        stored.status = status
        stored.execution_trace_json = json.dumps(trace, default=str)
        stored.duration_ms = duration_ms
        write_session.add(stored)
        write_session.commit()
        write_session.refresh(stored)
        logger.info("pipeline %s run %s %s in %sms", pipeline_id, run_id, status, duration_ms)
        return _to_run_read(stored)


def _presented_token(request: Request) -> str:
    header = request.headers.get("authorization", "")
    if header.lower().startswith("bearer "):
        return header[7:].strip()
    return request.headers.get("x-api-key", "").strip()


def _get_pipeline(session: Session, pipeline_id: str) -> Pipeline:
    row = session.get(Pipeline, pipeline_id)
    if row is None:
        raise HTTPException(status_code=404, detail="pipeline not found")
    return row


def _steps_or_400(payload: PipelineCreate | PipelineUpdate, max_steps: int) -> list[StepConfig]:
    try:
        steps = steps_from_write(payload, max_steps=max_steps)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if steps is None:
        raise HTTPException(status_code=400, detail="provide steps or steps_config_json")
    return steps


def _to_pipeline_read(row: Pipeline) -> PipelineRead:
    error: str | None = None
    steps: list[StepConfig] = []
    try:
        steps = parse_steps_json(row.steps_config_json, max_steps=10_000)
    except ValueError as exc:
        error = str(exc)
    return PipelineRead(
        id=row.id,
        name=row.name,
        description=row.description,
        steps_config_json=row.steps_config_json,
        steps=steps,
        is_active=row.is_active,
        created_at=row.created_at,
        definition_error=error,
    )


def _to_run_read(row: PipelineRun) -> PipelineRunRead:
    try:
        trace = json.loads(row.execution_trace_json or "[]")
        if not isinstance(trace, list):
            trace = []
    except json.JSONDecodeError:
        trace = []
    return PipelineRunRead(
        id=row.id,
        pipeline_id=row.pipeline_id,
        status=row.status,
        execution_trace_json=row.execution_trace_json,
        trace=trace,
        duration_ms=row.duration_ms,
        triggered_at=row.triggered_at,
    )
