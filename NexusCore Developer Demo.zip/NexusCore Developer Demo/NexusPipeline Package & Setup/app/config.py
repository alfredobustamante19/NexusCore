"""Runtime configuration loaded from the environment."""

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT_DIR = Path(__file__).resolve().parent.parent
DEFAULT_DATABASE_PATH = ROOT_DIR / "data" / "pipelines.db"


class Settings(BaseSettings):
    """Operator-facing settings.

    Every field can be set with a ``PIPELINE_`` environment variable.
    ``PIPELINE_API_TOKEN`` left empty keeps the management API open, which
    matches a local install. Set it before exposing the process to a network.
    """

    model_config = SettingsConfigDict(
        env_prefix="PIPELINE_",
        env_file=".env",
        extra="ignore",
    )

    database_url: str = f"sqlite:///{DEFAULT_DATABASE_PATH.as_posix()}"
    api_token: str = ""
    enable_echo: bool = True
    url_allowlist: str = ""
    max_steps: int = 50
    max_response_bytes: int = 1_048_576
    log_level: str = "INFO"

    def allowed_hosts(self) -> list[str]:
        return [part.strip().lower() for part in self.url_allowlist.split(",") if part.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
