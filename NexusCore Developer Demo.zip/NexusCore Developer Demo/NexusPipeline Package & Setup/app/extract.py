"""Dot-notation and JSONPath extraction for JSON responses.

Supported paths:

* Dot notation: ``data.items.0.id``
* JSONPath subset: ``$.data.items[0].id``, ``$.items[*].id``, ``$['user-id']``
"""

from typing import Any


class ExtractError(ValueError):
    """Raised when a path does not match the document."""


def extract_value(data: Any, path: str) -> Any:
    """Return the value at ``path``.

    A JSONPath that uses ``[*]`` returns a list of every match. A path with no
    wildcard returns the single matched value.
    """

    cleaned = path.strip()
    if not cleaned:
        raise ExtractError("path is empty")
    if cleaned.startswith("$"):
        return _extract_jsonpath(data, cleaned)
    return _extract_dot(data, cleaned)


def _extract_dot(data: Any, path: str) -> Any:
    current = data
    for part in path.split("."):
        if part == "":
            raise ExtractError(f"empty segment in '{path}'")
        if isinstance(current, dict):
            if part not in current:
                raise ExtractError(f"key '{part}' not found in '{path}'")
            current = current[part]
            continue
        if isinstance(current, list):
            if not part.isdigit():
                raise ExtractError(f"expected a list index in '{path}', found '{part}'")
            index = int(part)
            if index >= len(current):
                raise ExtractError(f"index {index} is out of range in '{path}'")
            current = current[index]
            continue
        raise ExtractError(f"cannot read '{part}' from a {type(current).__name__} in '{path}'")
    return current


def _extract_jsonpath(data: Any, path: str) -> Any:
    tokens, saw_wildcard = _tokenize_jsonpath(path)
    current_nodes = [data]
    for kind, value in tokens:
        next_nodes: list[Any] = []
        for node in current_nodes:
            if kind == "key":
                if isinstance(node, dict) and value in node:
                    next_nodes.append(node[value])
            elif kind == "index":
                if isinstance(node, list) and 0 <= value < len(node):
                    next_nodes.append(node[value])
            elif kind == "wild":
                if isinstance(node, list):
                    next_nodes.extend(node)
                elif isinstance(node, dict):
                    next_nodes.extend(node.values())
        current_nodes = next_nodes
    if not current_nodes:
        raise ExtractError(f"no match for '{path}'")
    if saw_wildcard:
        return current_nodes
    if len(current_nodes) == 1:
        return current_nodes[0]
    return current_nodes


def _tokenize_jsonpath(path: str) -> tuple[list[tuple[str, Any]], bool]:
    if not path.startswith("$"):
        raise ExtractError("JSONPath must start with '$'")
    tokens: list[tuple[str, Any]] = []
    saw_wildcard = False
    pos = 1
    length = len(path)
    while pos < length:
        char = path[pos]
        if char == ".":
            pos += 1
            start = pos
            while pos < length and _is_name_char(path[pos]):
                pos += 1
            if start == pos:
                raise ExtractError(f"expected a property name in '{path}'")
            tokens.append(("key", path[start:pos]))
            continue
        if char == "[":
            end = path.find("]", pos)
            if end == -1:
                raise ExtractError(f"unclosed bracket in '{path}'")
            body = path[pos + 1 : end].strip()
            if body == "*":
                tokens.append(("wild", None))
                saw_wildcard = True
            elif body.isdigit():
                tokens.append(("index", int(body)))
            elif len(body) >= 2 and body[0] == body[-1] and body[0] in {"'", '"'}:
                tokens.append(("key", body[1:-1]))
            else:
                raise ExtractError(f"unsupported bracket '{body}' in '{path}'")
            pos = end + 1
            continue
        raise ExtractError(f"cannot parse JSONPath near '{path[pos:]}'")
    return tokens, saw_wildcard


def _is_name_char(char: str) -> bool:
    return char.isalnum() or char in {"_", "-"}
