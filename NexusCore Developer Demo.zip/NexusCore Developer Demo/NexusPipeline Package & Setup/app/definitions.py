"""Parse and serialize pipeline step documents."""

import json

from pydantic import ValidationError

from app.schemas import PipelineCreate, PipelineUpdate, StepConfig


def dumps_steps(steps: list[StepConfig]) -> str:
    payload = [step.model_dump(mode="json") for step in steps]
    return json.dumps(payload, separators=(",", ":"))


def parse_steps_json(raw: str, *, max_steps: int) -> list[StepConfig]:
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"steps_config_json is not valid JSON: {exc.msg}") from exc
    if not isinstance(data, list):
        raise ValueError("steps_config_json must be a JSON array")
    return validate_steps(data, max_steps=max_steps)


def validate_steps(data: list, *, max_steps: int) -> list[StepConfig]:
    if len(data) > max_steps:
        raise ValueError(f"a pipeline can contain at most {max_steps} steps")
    try:
        steps = [StepConfig.model_validate(item) for item in data]
    except ValidationError as exc:
        raise ValueError(_format_validation(exc)) from exc
    duplicates = sorted({step.id for step in steps if sum(item.id == step.id for item in steps) > 1})
    if duplicates:
        raise ValueError(f"duplicate step ids: {', '.join(duplicates)}")
    encoded = dumps_steps(steps)
    if len(encoded) > 500_000:
        raise ValueError("pipeline definition is too large")
    return steps


def steps_from_write(payload: PipelineCreate | PipelineUpdate, *, max_steps: int) -> list[StepConfig] | None:
    """Return validated steps, or None when a partial update does not touch them."""

    if payload.steps is None and payload.steps_config_json is None:
        return None
    if payload.steps is not None:
        return validate_steps([step.model_dump(mode="json") for step in payload.steps], max_steps=max_steps)
    return parse_steps_json(payload.steps_config_json or "", max_steps=max_steps)


def _format_validation(exc: ValidationError) -> str:
    parts: list[str] = []
    for error in exc.errors():
        location = ".".join(str(item) for item in error.get("loc", ()))
        message = error.get("msg", "invalid value")
        parts.append(f"{location}: {message}" if location else message)
    return "; ".join(parts) or "invalid step configuration"
