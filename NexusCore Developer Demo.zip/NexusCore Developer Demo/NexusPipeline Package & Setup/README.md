# Pipeline Engine

Self-hosted API orchestration. A pipeline is an ordered list of HTTP calls. The engine runs step 1, pulls fields out of its JSON response with dot notation or JSONPath, injects those values into step 2, and continues down the list. Every attempt is stored, so you can see the rendered request, the response, and the error that stopped a run.

The dashboard is served by the same process as the API. SQLite is the database. Nothing in the default install calls out to a hosted control plane.

## Capabilities

- Create, read, update, and delete pipeline definitions.
- Run a pipeline and get the execution trace back from `POST /api/pipelines/{id}/run`.
- Keep run history on `GET /api/pipelines/{id}/runs`.
- Retry failed attempts with exponential backoff, and cap each attempt with its own timeout.
- Stop the sequence when a step fails, or keep going when that step sets `continue_on_error`.
- Optional API token and an optional host allowlist.

## Project layout

```
app/main.py          FastAPI app, dashboard, and static files
app/routes.py        CRUD, run, history, health, and the local echo sink
app/engine.py        Sequential runner, retries, timeouts, trace redaction
app/extract.py       Dot notation and a JSONPath subset
app/templating.py    {{path}} substitution
app/models.py        Pipeline and PipelineRun tables
app/schemas.py       Step schema and API models
app/definitions.py   Validation of the stored step array
app/database.py      SQLite engine and sessions
app/config.py        Environment settings
app/static/          Dashboard (Tailwind CSS)
app/styles/input.css Tailwind source
examples/            A two-step pipeline you can import
tests/               Engine and API tests
```

## Requirements

- Python 3.11 or newer
- Node.js is only needed if you change dashboard classes and want to rebuild `app/static/app.css`. The compiled stylesheet is already in the project.

## Run it locally

From the `pipeline-engine` directory.

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements-dev.txt
.venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

macOS or Linux:

```bash
python -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
```

`requirements-dev.txt` includes pytest. A runtime-only install is `pip install -r requirements.txt`.

Open [http://127.0.0.1:8000](http://127.0.0.1:8000) for the dashboard and [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) for the generated API reference.

The SQLite file is created at `data/pipelines.db`. That directory is gitignored.

### Try the echo chain

The dashboard button **Load echo example** builds a two-step pipeline against `POST /api/echo` on this same server. The trigger box already contains `{"name": "Ada"}`. **Run pipeline** saves the definition and executes it.

Step 1 posts the trigger name and extracts `id` as `record_id`. Step 2 sends that id in the JSON body and in the `X-Record-Id` header. The trace shows both rendered requests and the extracted values.

The same definition is in `examples/echo-pipeline.json`.

```bash
curl -s http://127.0.0.1:8000/api/pipelines -H "Content-Type: application/json" -d @examples/echo-pipeline.json
```

Use the `id` from that response:

```bash
curl -s -X POST http://127.0.0.1:8000/api/pipelines/PIPELINE_ID/run -H "Content-Type: application/json" -d "{\"input\":{\"name\":\"Ada\"}}"
```

On Windows PowerShell, `curl` is an alias for `Invoke-WebRequest`. Call `curl.exe` when you want the commands above.

### Tests

```powershell
.venv\Scripts\python -m pytest
```

```bash
.venv/bin/pytest
```

## Docker

The image expects `app/static/app.css` to already be built, which it is in this tree. Rebuild the stylesheet before `docker build` if you edit Tailwind classes. See [Dashboard styles](#dashboard-styles).

```bash
docker compose up --build
```

That publishes port 8000 and stores SQLite in the `pipeline-data` volume at `/data/pipelines.db`.

Without Compose:

```bash
docker build -t pipeline-engine .
docker run --rm -p 8000:8000 -v pipeline-data:/data pipeline-engine
```

Set a token when the port is reachable beyond your own machine:

```bash
docker run --rm -p 8000:8000 \
  -e PIPELINE_API_TOKEN=change-me \
  -e PIPELINE_ENABLE_ECHO=false \
  -v pipeline-data:/data \
  pipeline-engine
```

The container healthcheck calls `GET /api/health`.

## Configuration

Settings are read from the environment and from a `.env` file in the working directory. Prefix every variable with `PIPELINE_`. See `.env.example`.

| Variable | Default | Purpose |
| --- | --- | --- |
| `PIPELINE_DATABASE_URL` | `sqlite:///<project>/data/pipelines.db` | SQLAlchemy database URL. SQLite is the supported database. |
| `PIPELINE_API_TOKEN` | empty | When set, `/api/pipelines` and `/api/runs` require `Authorization: Bearer <token>` or `X-API-Key`. Health stays open. |
| `PIPELINE_ENABLE_ECHO` | `true` | `POST /api/echo` is a local sink for the bundled example. Set `false` to remove it. |
| `PIPELINE_URL_ALLOWLIST` | empty | Comma-separated hostnames. Empty allows any host. A value such as `api.internal,127.0.0.1` rejects every other host before the request is sent. |
| `PIPELINE_MAX_STEPS` | `50` | Maximum steps stored on one pipeline. |
| `PIPELINE_MAX_RESPONSE_BYTES` | `1048576` | Largest response body a step will accept. Larger bodies fail that step. |
| `PIPELINE_LOG_LEVEL` | `INFO` | Python log level. |

The dashboard stores an API token in `sessionStorage` for the current browser session. It is sent as a bearer token. Leave the field blank when the server has no token configured.

## Pipeline document

`Pipeline.steps_config_json` is a JSON array. Order is execution order. The write API accepts either a `steps` array or a `steps_config_json` string. If both are sent, `steps` is stored.

```json
{
  "name": "Create order",
  "description": "Create a user, then an order for that user.",
  "is_active": true,
  "steps": [
    {
      "id": "create_user",
      "name": "Create user",
      "method": "POST",
      "url": "https://api.example.com/users",
      "headers": {"Authorization": "Bearer <token>"},
      "query": {},
      "body": {"email": "{{input.email}}"},
      "body_mode": "json",
      "timeout_seconds": 10,
      "retries": 2,
      "retry_backoff_seconds": 0.5,
      "retry_on_status": [408, 429, 500, 502, 503, 504],
      "expected_status": null,
      "follow_redirects": false,
      "extract": {"user_id": "$.id"},
      "continue_on_error": false
    },
    {
      "id": "create_order",
      "name": "Create order",
      "method": "POST",
      "url": "https://api.example.com/orders",
      "headers": {"X-User": "{{steps.create_user.extract.user_id}}"},
      "body": {"user_id": "{{steps.create_user.extract.user_id}}", "sku": "{{input.sku}}"},
      "body_mode": "json",
      "timeout_seconds": 10,
      "retries": 0,
      "extract": {"order_id": "id"}
    }
  ]
}
```

Step fields:

| Field | Meaning |
| --- | --- |
| `id` | Stable name used by later templates. Letters, numbers, `_`, and `-`. Must be unique in the pipeline. |
| `method` | `GET`, `POST`, `PUT`, `PATCH`, `DELETE`, `HEAD`, or `OPTIONS`. |
| `url` | Absolute `http` or `https` URL. Templates are allowed. |
| `headers`, `query` | String maps. Templates are rendered before the call. |
| `body` | JSON value, string, or null. |
| `body_mode` | `json`, `text`, `form`, or `none`. |
| `timeout_seconds` | Per-attempt timeout from 0.1 to 120 seconds. |
| `retries` | Extra attempts after the first failure. 0 through 8. |
| `retry_backoff_seconds` | Base delay. Attempt 1 waits `base`, attempt 2 waits `2 * base`, then `4 * base`, capped at 30 seconds. |
| `retry_on_status` | Status codes that are retried. Other 4xx responses fail immediately. |
| `expected_status` | When set, only these codes count as success. |
| `follow_redirects` | Off by default. |
| `extract` | Map of name to a dot path or JSONPath, read from the response JSON. |
| `continue_on_error` | When true, later steps still run after this step fails. The run status is still `failed`. |

Inactive pipelines refuse `POST /run` with HTTP 409. A pipeline with no steps returns HTTP 400.

## Templating

Placeholders use `{{path}}` against this context:

```json
{
  "input": {"email": "a@example.com"},
  "steps": {
    "create_user": {
      "status_code": 201,
      "json": {"id": 42},
      "extract": {"user_id": 42},
      "headers": {},
      "body": "{\"id\": 42}"
    },
    "0": "same object as create_user"
  }
}
```

Useful paths:

- `{{input.email}}` is the object sent to `POST /api/pipelines/{id}/run`.
- `{{steps.create_user.extract.user_id}}` is a value you extracted.
- `{{steps.create_user.json.id}}` reads the response JSON directly.
- `{{steps.0.json.id}}` addresses a step by its zero-based index.

A placeholder that is the entire value keeps its JSON type, so `"user_id": "{{steps.create_user.extract.user_id}}"` is sent as a number when the extracted value is a number. Text around a placeholder is stringified: `"widget-{{input.sku}}"`.

A missing path fails that step immediately and is not retried.

## Extraction

`extract` runs only after a successful response. The response must be JSON.

Dot notation walks objects and list indexes: `data.items.0.id`.

The JSONPath subset accepts:

- `$.data.items[0].id`
- `$['user-id']` and `$["user-id"]` for keys that are awkward in dot notation
- `$.items[*].id`, which returns a list of every match

A path that matches nothing fails the step and is not retried.

## Retries, timeouts, and traces

Each attempt uses `httpx` with the step timeout. These failures are retried when attempts remain:

- timeout
- connection error
- a status in `retry_on_status`

Other HTTP errors, template errors, extract errors, disallowed hosts, and oversized bodies fail immediately.

The delay after failure number `n` (starting at 0) is `min(retry_backoff_seconds * 2^n, 30)`.

A failed step skips every step after it unless `continue_on_error` is true. Skipped steps are recorded in the trace with status `skipped`.

Run status is one of `running`, `success`, or `failed`. `POST /run` waits until the sequence finishes, then returns the final row. While the call is in flight the row is stored as `running`, so a concurrent history request can observe it. `duration_ms` is the wall time of the whole sequence, including backoff.

Traces redact `Authorization`, `Cookie`, `Set-Cookie`, `X-API-Key`, headers whose names end in `-token` or `-secret`, query keys that look like tokens or passwords, and userinfo embedded in URLs. Rendered bodies are stored so you can debug them. Treat `data/pipelines.db` as sensitive.

Each outbound request also gets `X-Pipeline-Run-Id` and `X-Pipeline-Step` unless the step already set those headers.

## HTTP API

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/health` | Liveness. Always open. |
| `POST` | `/api/echo` | Local debug sink used by the example. Disable with `PIPELINE_ENABLE_ECHO=false`. |
| `GET` | `/api/pipelines` | List pipelines, newest first. |
| `POST` | `/api/pipelines` | Create a pipeline. |
| `GET` | `/api/pipelines/{id}` | Fetch one pipeline, including parsed `steps`. |
| `PUT` | `/api/pipelines/{id}` | Replace name, description, steps, and `is_active`. |
| `PATCH` | `/api/pipelines/{id}` | Update any of those fields. |
| `DELETE` | `/api/pipelines/{id}` | Delete the pipeline and its runs. |
| `POST` | `/api/pipelines/{id}/run` | Execute. Body is `{"input": {}}`. Returns the run, including `execution_trace_json` and a parsed `trace`. |
| `GET` | `/api/pipelines/{id}/runs?limit=50` | History, newest first. `limit` is capped at 200. |
| `GET` | `/api/runs/{id}` | Fetch one run. |

`Pipeline` rows store `id`, `name`, `description`, `steps_config_json`, `is_active`, and `created_at`. `PipelineRun` rows store `id`, `pipeline_id`, `status`, `execution_trace_json`, `duration_ms`, and `triggered_at`. Timestamps are UTC.

## Dashboard

The page at `/` is a single document styled with Tailwind:

- The sidebar lists pipelines and holds the optional API token.
- **Visual** edits each step: method, URL, headers, query, body, extract paths, timeout, retries, and backoff. Move steps up or down to change the order.
- **JSON** edits the same `steps` array directly. The server validates it on save.
- **Run pipeline** saves, executes, and renders the trace: each attempt, the rendered request, the response, extracted fields, and the error.
- **Run history** reloads any stored trace.
- **Import** and **Export** move a pipeline document as JSON.

## Dashboard styles

Tailwind v4 compiles `app/styles/input.css` into `app/static/app.css`. After changing classes in `app/static/index.html` or `app/static/app.js`:

```bash
npm install
npm run build:css
```

Commit the generated CSS. The Python process and the Docker image do not run Node.

## Security

This process sends HTTP requests to the URLs stored in pipeline definitions. That includes private addresses when you point a step at an internal API. That is the product: you are the operator, and you choose the targets.

Before exposing the port:

1. Set `PIPELINE_API_TOKEN`.
2. Set `PIPELINE_URL_ALLOWLIST` to the hosts this install is allowed to call.
3. Set `PIPELINE_ENABLE_ECHO=false` unless you still want the local debug sink.
4. Keep the SQLite volume private. Traces contain rendered request bodies.

Only `http` and `https` URLs are called. Other schemes fail the step.
