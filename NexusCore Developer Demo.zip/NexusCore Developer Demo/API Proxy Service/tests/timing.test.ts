import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { tokensEqual } from '../src/util/timingSafeEqual.js';

describe('admin token comparison', () => {
  it('matches equal strings and rejects different lengths without throwing', () => {
    assert.equal(tokensEqual('test-token-1234', 'test-token-1234'), true);
    assert.equal(tokensEqual('test-token-1234', 'test-token-1235'), false);
    assert.equal(tokensEqual('a', 'ab'), false);
    assert.equal(tokensEqual('', 'x'), false);
  });
});
