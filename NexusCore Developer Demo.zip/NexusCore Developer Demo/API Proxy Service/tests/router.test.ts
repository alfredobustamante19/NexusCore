import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { buildUpstreamUrl, prefixMatches, RouteTable, splitUrl } from '../src/proxy/router.js';
import { testRoute } from './helpers.js';

describe('router', () => {
  const billing = testRoute({
    id: 'billing',
    prefix: '/billing',
    target: 'http://127.0.0.1:4010',
    methods: ['GET', 'POST'],
  });
  const billingV2 = testRoute({
    id: 'billingV2',
    prefix: '/billing/v2',
    target: 'http://127.0.0.1:4020',
    stripPrefix: false,
  });
  const table = new RouteTable([billing, billingV2]);

  it('matches the longest prefix and rejects a partial segment', () => {
    assert.equal(prefixMatches('/billing', '/billing'), true);
    assert.equal(prefixMatches('/billing/invoices', '/billing'), true);
    assert.equal(prefixMatches('/billingv2', '/billing'), false);
    const v2 = table.match('GET', '/billing/v2/tax');
    assert.equal(v2.type, 'route');
    if (v2.type === 'route') assert.equal(v2.route.id, 'billingV2');
    const match = table.match('GET', '/billing/invoices');
    assert.equal(match.type, 'route');
    if (match.type === 'route') assert.equal(match.route.id, 'billing');
    assert.equal(table.match('GET', '/other').type, 'none');
  });

  it('returns the allowed methods when the prefix matches but the verb does not', () => {
    const match = table.match('DELETE', '/billing/invoices');
    assert.equal(match.type, 'method');
    if (match.type === 'method') assert.deepEqual(match.allow, ['GET', 'POST']);
  });

  it('builds the upstream URL with and without the prefix', () => {
    assert.equal(
      buildUpstreamUrl(billing, '/billing/invoices', 'q=red+shoes'),
      'http://127.0.0.1:4010/invoices?q=red+shoes',
    );
    assert.equal(buildUpstreamUrl(billing, '/billing', ''), 'http://127.0.0.1:4010/');
    assert.equal(
      buildUpstreamUrl(billingV2, '/billing/v2/tax', ''),
      'http://127.0.0.1:4020/billing/v2/tax',
    );
  });

  it('splits the raw URL without decoding the query', () => {
    assert.deepEqual(splitUrl('/billing/search?q=red+shoes'), {
      path: '/billing/search',
      query: 'q=red+shoes',
    });
    assert.deepEqual(splitUrl('/billing'), { path: '/billing', query: '' });
  });
});
