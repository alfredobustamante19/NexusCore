import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { ResponseCache } from '../src/cache/responseCache.js';

describe('response cache', () => {
  it('expires entries and evicts the oldest when full', () => {
    const cache = new ResponseCache(2);
    cache.set('a', entry('a', 0, 1_000));
    cache.set('b', entry('b', 0, 1_000));
    assert.equal(cache.get('a', 10)?.body.toString(), 'a');
    cache.set('c', entry('c', 10, 1_000));
    assert.equal(cache.get('b', 10), undefined);
    assert.equal(cache.get('a', 10)?.body.toString(), 'a');
    assert.equal(cache.get('a', 1_000), undefined);
    assert.equal(cache.size, 1);
  });

  it('ignores a non-positive ttl', () => {
    const cache = new ResponseCache(2);
    cache.set('a', entry('a', 0, 0));
    assert.equal(cache.size, 0);
  });
});

function entry(body: string, storedAt: number, ttlMs: number) {
  return {
    statusCode: 200,
    contentType: 'application/json',
    body: Buffer.from(body),
    storedAt,
    ttlMs,
  };
}
