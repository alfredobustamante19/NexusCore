import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { backoffDelay } from '../src/retry/backoff.js';

describe('exponential backoff', () => {
  const policy = { baseDelayMs: 10, maxDelayMs: 100 };

  it('uses the full exponential delay when jitter is at the top of the range', () => {
    assert.equal(backoffDelay(0, policy, () => 1), 10);
    assert.equal(backoffDelay(1, policy, () => 1), 20);
    assert.equal(backoffDelay(2, policy, () => 1), 40);
    assert.equal(backoffDelay(3, policy, () => 1), 80);
    assert.equal(backoffDelay(4, policy, () => 1), 100);
    assert.equal(backoffDelay(10, policy, () => 1), 100);
  });

  it('uses half the exponential delay when jitter is at the bottom of the range', () => {
    assert.equal(backoffDelay(0, policy, () => 0), 5);
    assert.equal(backoffDelay(1, policy, () => 0), 10);
    assert.equal(backoffDelay(3, policy, () => 0), 40);
  });

  it('stays inside the equal-jitter window', () => {
    const delay = backoffDelay(2, policy, () => 0.25);
    assert.ok(delay >= 20 && delay <= 40, `expected 20..40, got ${delay}`);
  });

  it('rejects a negative retry index', () => {
    assert.throws(() => backoffDelay(-1, policy, () => 1), /retryIndex/);
  });
});
