import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { CircuitBreaker } from '../src/circuit/breaker.js';
import type { CircuitPolicy, CircuitState } from '../src/types.js';

function policy(over: Partial<CircuitPolicy> = {}): CircuitPolicy {
  return {
    failureThreshold: 3,
    successThreshold: 2,
    openDurationMs: 1_000,
    halfOpenMaxProbes: 1,
    ...over,
  };
}

describe('circuit breaker', () => {
  it('moves CLOSED -> OPEN -> HALF_OPEN -> CLOSED', () => {
    let now = 5_000;
    const transitions: Array<[CircuitState, CircuitState]> = [];
    const breaker = new CircuitBreaker(policy(), () => now, (from, to) => {
      transitions.push([from, to]);
    });

    assert.equal(breaker.recordFailure(), 'CLOSED');
    assert.equal(breaker.recordFailure(), 'CLOSED');
    assert.deepEqual(breaker.tryAcquire(), { allowed: true, state: 'CLOSED' });
    assert.equal(breaker.recordSuccess(), 'CLOSED');
    assert.equal(breaker.snapshot().consecutiveFailures, 0);

    assert.equal(breaker.recordFailure(), 'CLOSED');
    assert.equal(breaker.recordFailure(), 'CLOSED');
    assert.equal(breaker.recordFailure(), 'OPEN');
    assert.equal(breaker.snapshot().totalTrips, 1);
    assert.equal(breaker.snapshot().openedAt, 5_000);
    assert.deepEqual(breaker.tryAcquire(), { allowed: false, state: 'OPEN' });

    now = 5_999;
    assert.deepEqual(breaker.tryAcquire(), { allowed: false, state: 'OPEN' });

    now = 6_000;
    assert.deepEqual(breaker.tryAcquire(), { allowed: true, state: 'HALF_OPEN' });
    assert.deepEqual(breaker.tryAcquire(), { allowed: false, state: 'HALF_OPEN' });
    assert.equal(breaker.recordSuccess(), 'HALF_OPEN');
    assert.equal(breaker.snapshot().consecutiveSuccesses, 1);
    assert.deepEqual(breaker.tryAcquire(), { allowed: true, state: 'HALF_OPEN' });
    assert.equal(breaker.recordSuccess(), 'CLOSED');
    assert.equal(breaker.snapshot().openedAt, null);
    assert.equal(breaker.snapshot().consecutiveFailures, 0);

    assert.deepEqual(transitions, [
      ['CLOSED', 'OPEN'],
      ['OPEN', 'HALF_OPEN'],
      ['HALF_OPEN', 'CLOSED'],
    ]);
  });

  it('reopens immediately when a half-open probe fails and waits for a new cooldown', () => {
    let now = 0;
    const breaker = new CircuitBreaker(
      policy({ failureThreshold: 1, successThreshold: 2, openDurationMs: 100 }),
      () => now,
    );
    assert.equal(breaker.recordFailure(), 'OPEN');
    now = 100;
    assert.equal(breaker.tryAcquire().state, 'HALF_OPEN');
    assert.equal(breaker.recordSuccess(), 'HALF_OPEN');
    assert.equal(breaker.tryAcquire().allowed, true);
    assert.equal(breaker.recordFailure(), 'OPEN');
    assert.equal(breaker.snapshot().consecutiveSuccesses, 0);
    assert.equal(breaker.snapshot().totalTrips, 2);
    assert.equal(breaker.tryAcquire().allowed, false);

    now = 199;
    assert.equal(breaker.tryAcquire().state, 'OPEN');
    now = 200;
    assert.equal(breaker.tryAcquire().state, 'HALF_OPEN');
    assert.equal(breaker.recordSuccess(), 'HALF_OPEN');
    assert.equal(breaker.recordSuccess(), 'CLOSED');
  });

  it('ignores results recorded while the breaker is open', () => {
    const breaker = new CircuitBreaker(policy({ failureThreshold: 1 }), () => 10);
    breaker.recordFailure();
    assert.equal(breaker.recordFailure(), 'OPEN');
    assert.equal(breaker.recordSuccess(), 'OPEN');
    assert.equal(breaker.snapshot().totalTrips, 1);
    assert.equal(breaker.snapshot().consecutiveFailures, 1);
  });

  it('allows the configured number of simultaneous half-open probes', () => {
    let now = 0;
    const breaker = new CircuitBreaker(
      policy({ failureThreshold: 1, halfOpenMaxProbes: 2, successThreshold: 1 }),
      () => now,
    );
    breaker.recordFailure();
    now = 1_000;
    assert.equal(breaker.tryAcquire().allowed, true);
    assert.equal(breaker.tryAcquire().allowed, true);
    assert.equal(breaker.tryAcquire().allowed, false);
    breaker.recordSuccess();
    assert.equal(breaker.snapshot().state, 'CLOSED');
  });

  it('replaces itself only when the policy changes', () => {
    const first = policy();
    const breaker = new CircuitBreaker(first, () => 0);
    assert.equal(breaker.sameOptions(policy()), true);
    assert.equal(breaker.sameOptions(policy({ failureThreshold: 9 })), false);
  });
});
