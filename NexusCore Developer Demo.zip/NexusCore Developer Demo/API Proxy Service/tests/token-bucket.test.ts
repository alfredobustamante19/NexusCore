import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { TokenBucketLimiter } from '../src/ratelimit/tokenBucket.js';
import { clock } from './helpers.js';

describe('token bucket', () => {
  it('allows a burst up to capacity and then rejects', () => {
    const time = clock(1_000);
    const limiter = new TokenBucketLimiter(2, 0, time.now);
    assert.equal(limiter.tryRemove('a').allowed, true);
    const second = limiter.tryRemove('a');
    assert.equal(second.allowed, true);
    assert.equal(second.remaining, 0);
    const denied = limiter.tryRemove('a');
    assert.equal(denied.allowed, false);
    assert.equal(denied.retryAfterMs, -1);
    assert.equal(denied.limit, 2);
  });

  it('refills continuously and isolates keys', () => {
    const time = clock(0);
    const limiter = new TokenBucketLimiter(1, 2, time.now);
    assert.equal(limiter.tryRemove('alpha').allowed, true);
    assert.equal(limiter.tryRemove('beta').allowed, true);
    assert.equal(limiter.tryRemove('alpha').allowed, false);

    time.advance(250);
    const partial = limiter.tryRemove('alpha');
    assert.equal(partial.allowed, false);
    assert.ok(partial.retryAfterMs > 0 && partial.retryAfterMs <= 300);

    time.advance(250);
    assert.equal(limiter.tryRemove('alpha').allowed, true);
    assert.equal(limiter.tryRemove('beta').remaining, 0);
  });

  it('does not grant tokens when the clock moves backwards', () => {
    const time = clock(5_000);
    const limiter = new TokenBucketLimiter(1, 10, time.now);
    assert.equal(limiter.tryRemove('ip').allowed, true);
    time.set(1_000);
    assert.equal(limiter.tryRemove('ip').allowed, false);
  });

  it('evicts the least recently used key when the map is full', () => {
    const limiter = new TokenBucketLimiter(1, 0, () => 0, 2);
    assert.equal(limiter.tryRemove('a').allowed, true);
    assert.equal(limiter.tryRemove('b').allowed, true);
    assert.equal(limiter.tryRemove('c').allowed, true);
    assert.equal(limiter.trackedKeys(), 2);
    assert.equal(limiter.tryRemove('a').allowed, true);
    assert.equal(limiter.tryRemove('c').allowed, false);
  });
});
