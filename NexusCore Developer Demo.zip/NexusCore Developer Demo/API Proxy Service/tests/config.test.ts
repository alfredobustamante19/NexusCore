import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { describe, it } from 'node:test';
import { ConfigError, loadConfig, loadRoutes, parseConfig, parseRoutes } from '../src/config.js';
import { buildServer } from '../src/server.js';
import { createTestConfig, projectRoot } from './helpers.js';

const route = {
  id: 'billing',
  prefix: '/billing',
  target: 'http://127.0.0.1:4010',
  fallback: { statusCode: 503, body: { error: 'upstream_unavailable' } },
};

describe('configuration', () => {
  it('loads the shipped files and applies route defaults', async () => {
    const config = await loadConfig(path.join(projectRoot, 'config.json'));
    const routes = await loadRoutes(path.join(projectRoot, 'routes.json'), config);
    assert.equal(routes.length, 3);

    const catalog = routes.find((item) => item.id === 'catalog');
    assert.ok(catalog);
    assert.equal(catalog.timeoutMs, 800);
    assert.equal(catalog.cacheTtlMs, 5_000);
    assert.equal(catalog.retries.maxRetries, 2);
    assert.deepEqual(catalog.retries.retryOn, [500, 502, 503, 504]);
    assert.equal(catalog.circuit.failureThreshold, 5);
    assert.equal(catalog.circuit.successThreshold, 2);
    assert.equal(catalog.stripPrefix, true);

    const quotes = routes.find((item) => item.id === 'quotes');
    assert.ok(quotes);
    assert.equal(quotes.circuit.failureThreshold, 3);
    assert.equal(quotes.circuit.openDurationMs, 30_000);
    assert.equal(quotes.circuit.successThreshold, 2);
    assert.equal(quotes.circuit.halfOpenMaxProbes, 1);
    assert.equal(quotes.rateLimit?.capacity, 20);
    assert.equal(quotes.rateLimit?.keyBy, 'apiKey');
    assert.equal(quotes.timeoutMs, 2_000);
  });

  it('serves health and the dashboard from the shipped configuration', async () => {
    const config = await loadConfig(path.join(projectRoot, 'config.json'));
    config.server.logLevel = 'silent';
    const routes = await loadRoutes(path.join(projectRoot, 'routes.json'), config);
    const app = await buildServer({ config, routes });
    try {
      const health = await app.inject({ method: 'GET', url: '/nexus-health' });
      assert.equal(health.statusCode, 200);
      assert.equal(health.json().service, 'NexusCircuit');

      const board = await app.inject({ method: 'GET', url: '/nexus-metrics' });
      assert.equal(board.statusCode, 200);
      assert.match(board.headers['content-type'] ?? '', /text\/html/);
      assert.match(board.body, /NexusCircuit/);
      assert.match(board.body, /\/nexus-metrics\/data/);

      const data = await app.inject({ method: 'GET', url: '/nexus-metrics/data' });
      assert.equal(data.statusCode, 200);
      assert.equal(data.json().routes.length, 3);
      assert.equal(data.json().routes[0].state, 'CLOSED');
    } finally {
      await app.close();
    }
  });

  it('rejects malformed files and unsafe route definitions', async () => {
    const config = createTestConfig();
    const dir = await mkdtemp(path.join(tmpdir(), 'nexus-config-'));
    try {
      const file = path.join(dir, 'bad.json');
      await writeFile(file, '{', 'utf8');
      await assert.rejects(loadConfig(file), ConfigError);
    } finally {
      await rm(dir, { recursive: true, force: true });
    }

    assert.throws(
      () => parseRoutes({ routes: [{ ...route, target: 'ftp://example.com' }] }, config),
      /http or https/,
    );
    assert.throws(
      () => parseRoutes({ routes: [{ ...route, target: 'http://user:pass@127.0.0.1:9' }] }, config),
      /credentials/,
    );
    assert.throws(
      () => parseRoutes({
        routes: [
          route,
          { ...route, id: 'other', prefix: '/billing' },
        ],
      }, config),
      /duplicated/,
    );
    assert.throws(
      () => parseRoutes({ routes: [{ ...route, prefix: '/nexus-metrics' }] }, config),
      /reserved/,
    );
    assert.throws(
      () => parseRoutes({
        routes: [{
          ...route,
          retries: { retryOn: [404] },
        }],
      }, config),
      /500 to 599/,
    );
    assert.throws(() => parseConfig({ server: {} }, 'config'), /unknown field|must be/);
    assert.throws(
      () => parseConfig({
        ...config,
        admin: { ...config.admin, token: 'short' },
      }),
      /at least 8/,
    );
  });

  it('fills a partial retry override from defaults', () => {
    const [parsed] = parseRoutes({
      routes: [{
        ...route,
        retries: { maxRetries: 1 },
      }],
    }, createTestConfig());
    assert.ok(parsed);
    assert.equal(parsed.retries.maxRetries, 1);
    assert.equal(parsed.retries.baseDelayMs, 10);
    assert.deepEqual(parsed.retries.retryOn, [500, 502, 503, 504]);
  });
});
