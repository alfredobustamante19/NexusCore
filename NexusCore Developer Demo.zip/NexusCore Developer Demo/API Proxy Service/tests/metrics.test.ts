import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { LatencyWindow } from '../src/metrics/collector.js';

describe('latency window', () => {
  it('reports nearest-rank percentiles and a lifetime average', () => {
    const window = new LatencyWindow(10);
    for (const sample of [10, 20, 30, 40]) window.record(sample);
    const summary = window.summary();
    assert.equal(summary.count, 4);
    assert.equal(summary.window, 4);
    assert.equal(summary.avgMs, 25);
    assert.equal(summary.p50Ms, 20);
    assert.equal(summary.p95Ms, 40);
    assert.equal(summary.p99Ms, 40);
    assert.equal(summary.maxMs, 40);
  });

  it('keeps only the configured number of recent samples', () => {
    const window = new LatencyWindow(2);
    window.record(1);
    window.record(2);
    window.record(3);
    const summary = window.summary();
    assert.equal(summary.count, 3);
    assert.equal(summary.window, 2);
    assert.equal(summary.avgMs, 2);
    assert.equal(summary.maxMs, 3);
  });

  it('returns zeros before any samples', () => {
    assert.deepEqual(new LatencyWindow(4).summary(), {
      count: 0,
      window: 0,
      avgMs: 0,
      p50Ms: 0,
      p95Ms: 0,
      p99Ms: 0,
      maxMs: 0,
    });
  });
});
