import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { buildForwardHeaders, sanitizeResponseHeaders } from '../src/proxy/headers.js';

const base = {
  requestId: 'req-1',
  requestIdHeader: 'x-request-id',
  clientIp: '203.0.113.8',
  host: 'gateway.internal',
  proto: 'https',
  userAgent: 'NexusCircuit/1.0',
};

describe('proxy headers', () => {
  it('strips hop-by-hop headers, listed connection tokens, and spoofed gateway headers', () => {
    const headers = buildForwardHeaders(
      {
        host: 'evil.example',
        connection: 'close, x-custom-hop',
        'x-custom-hop': 'drop-me',
        'x-nexus-circuit': 'OPEN',
        accept: 'application/json',
        'x-forwarded-for': '198.51.100.4',
        'user-agent': 'client',
      },
      { ...base, trustProxy: false },
    );
    assert.equal(headers.host, undefined);
    assert.equal(headers.connection, undefined);
    assert.equal(headers['x-custom-hop'], undefined);
    assert.equal(headers['x-nexus-circuit'], undefined);
    assert.equal(headers.accept, 'application/json');
    assert.equal(headers['user-agent'], 'client');
    assert.equal(headers['x-forwarded-for'], '203.0.113.8');
    assert.equal(headers['x-forwarded-host'], 'gateway.internal');
    assert.equal(headers['x-forwarded-proto'], 'https');
    assert.equal(headers['x-request-id'], 'req-1');
  });

  it('appends to x-forwarded-for only when the proxy chain is trusted', () => {
    const headers = buildForwardHeaders(
      { 'x-forwarded-for': '198.51.100.4' },
      { ...base, trustProxy: true },
    );
    assert.equal(headers['x-forwarded-for'], '198.51.100.4, 203.0.113.8');
    assert.equal(headers['user-agent'], 'NexusCircuit/1.0');
  });

  it('keeps each set-cookie and drops content-length', () => {
    const headers = sanitizeResponseHeaders({
      'content-type': 'application/json',
      'content-length': '12',
      connection: 'close',
      'set-cookie': ['a=1', 'b=2'],
      'x-upstream': 'billing',
      'x-nexus-cache': 'hit',
    });
    assert.deepEqual(headers, [
      ['content-type', 'application/json'],
      ['set-cookie', 'a=1'],
      ['set-cookie', 'b=2'],
      ['x-upstream', 'billing'],
    ]);
  });
});
