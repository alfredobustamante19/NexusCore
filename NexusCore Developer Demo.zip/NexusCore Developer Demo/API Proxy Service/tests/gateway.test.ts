import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { describe, it } from 'node:test';
import type { FastifyInstance } from 'fastify';
import { loadConfig, loadRoutes } from '../src/config.js';
import {
  clock,
  createTestApp,
  createTestConfig,
  startMock,
  testRoute,
  type MockUpstream,
} from './helpers.js';

describe('gateway integration', { concurrency: 1, timeout: 15_000 }, () => {
  it('proxies a request, strips the prefix, and forwards the query and request id', async () => {
    const upstream = await startMock((hit) => ({
      body: JSON.stringify({ path: hit.path, query: hit.query, requestId: hit.headers['x-request-id'] }),
      headers: {
        'content-type': 'application/json',
        'x-upstream': 'billing',
      },
    }));
    const app = await createTestApp({
      routes: [testRoute({ id: 'billing', prefix: '/billing', target: upstream.baseUrl })],
    });
    try {
      const res = await app.inject({
        method: 'GET',
        url: '/billing/invoices?q=red+shoes',
        headers: { 'x-request-id': 'abc-123' },
      });
      assert.equal(res.statusCode, 200);
      assert.deepEqual(res.json(), {
        path: '/invoices',
        query: 'q=red+shoes',
        requestId: 'abc-123',
      });
      assert.equal(res.headers['x-request-id'], 'abc-123');
      assert.equal(res.headers['x-nexus-route'], 'billing');
      assert.equal(res.headers['x-nexus-circuit'], 'CLOSED');
      assert.equal(res.headers['x-upstream'], 'billing');
      assert.equal(upstream.hits[0]?.headers['x-forwarded-for'], '127.0.0.1');
      assert.equal(upstream.hits[0]?.headers['x-nexus-circuit'], undefined);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('forwards a POST body and echoes upstream bytes', async () => {
    const upstream = await startMock((hit) => ({
      status: 201,
      body: hit.body,
      headers: { 'content-type': 'application/json' },
    }));
    const app = await createTestApp({
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: upstream.baseUrl,
        methods: ['POST'],
      })],
    });
    try {
      const res = await app.inject({
        method: 'POST',
        url: '/billing/charges',
        headers: { 'content-type': 'application/json' },
        payload: JSON.stringify({ amount: 15 }),
      });
      assert.equal(res.statusCode, 201);
      assert.deepEqual(res.json(), { amount: 15 });
      assert.equal(upstream.hits[0]?.path, '/charges');
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('returns 404 and 405 without calling upstream', async () => {
    const upstream = await startMock(() => ({ body: '{"ok":true}' }));
    const app = await createTestApp({
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: upstream.baseUrl,
        methods: ['GET'],
      })],
    });
    try {
      const missing = await app.inject({ method: 'GET', url: '/nope' });
      assert.equal(missing.statusCode, 404);
      assert.equal(missing.json().error, 'no_route');

      const denied = await app.inject({ method: 'POST', url: '/billing/invoices' });
      assert.equal(denied.statusCode, 405);
      assert.equal(denied.headers.allow, 'GET');
      assert.deepEqual(denied.json().allow, ['GET']);
      assert.equal(upstream.hits.length, 0);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('forwards client errors and does not retry them or trip the breaker', async () => {
    const upstream = await startMock(() => ({
      status: 404,
      body: JSON.stringify({ error: 'missing' }),
    }));
    const app = await createTestApp({
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: upstream.baseUrl,
        retries: {
          maxRetries: 2,
          baseDelayMs: 10,
          maxDelayMs: 100,
          retryOn: [500, 502, 503, 504],
          retryUnsafeMethods: false,
        },
        circuit: { failureThreshold: 1, successThreshold: 1, openDurationMs: 5_000, halfOpenMaxProbes: 1 },
      })],
    });
    try {
      const res = await app.inject({ method: 'GET', url: '/billing/missing' });
      assert.equal(res.statusCode, 404);
      assert.equal(res.json().error, 'missing');
      assert.equal(upstream.hits.length, 1);
      assert.equal(res.headers['x-nexus-circuit'], 'CLOSED');
      const metrics = await app.inject({ method: 'GET', url: '/nexus-metrics/data' });
      const route = metrics.json().routes.find((item: { id: string }) => item.id === 'billing');
      assert.equal(route.failures, 0);
      assert.equal(route.successes, 1);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('retries idempotent 5xx calls with exponential delays and keeps the breaker closed when one succeeds', async () => {
    const delays: number[] = [];
    const upstream = await startMock((_hit, hits) => {
      if (hits.length <= 2) return { status: 503, body: JSON.stringify({ error: 'busy' }) };
      return { body: JSON.stringify({ ok: true }) };
    });
    const app = await createTestApp({
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: upstream.baseUrl,
        retries: {
          maxRetries: 2,
          baseDelayMs: 10,
          maxDelayMs: 100,
          retryOn: [500, 502, 503, 504],
          retryUnsafeMethods: false,
        },
        circuit: { failureThreshold: 1, successThreshold: 1, openDurationMs: 5_000, halfOpenMaxProbes: 1 },
      })],
      sleep: async (ms) => {
        delays.push(ms);
      },
      random: () => 1,
    });
    try {
      const res = await app.inject({ method: 'GET', url: '/billing/invoice' });
      assert.equal(res.statusCode, 200);
      assert.equal(res.json().ok, true);
      assert.equal(res.headers['x-nexus-retries'], '2');
      assert.equal(res.headers['x-nexus-circuit'], 'CLOSED');
      assert.deepEqual(delays, [10, 20]);
      assert.equal(upstream.hits.length, 3);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('does not retry unsafe methods unless the route opts in', async () => {
    const upstream = await startMock(() => ({ status: 503, body: '{"error":"busy"}' }));
    let blocked: FastifyInstance | undefined;
    let allowed: FastifyInstance | undefined;
    try {
      blocked = await createTestApp({
        routes: [testRoute({
          id: 'billing',
          prefix: '/billing',
          target: upstream.baseUrl,
          retries: {
            maxRetries: 2,
            baseDelayMs: 5,
            maxDelayMs: 20,
            retryOn: [503],
            retryUnsafeMethods: false,
          },
        })],
        sleep: async () => {
          throw new Error('should not sleep');
        },
      });
      const blockedRes = await blocked.inject({
        method: 'POST',
        url: '/billing/charges',
        headers: { 'content-type': 'application/json' },
        payload: '{}',
      });
      assert.equal(blockedRes.statusCode, 503);
      assert.equal(upstream.hits.length, 1);

      allowed = await createTestApp({
        routes: [testRoute({
          id: 'billing',
          prefix: '/billing',
          target: upstream.baseUrl,
          retries: {
            maxRetries: 1,
            baseDelayMs: 5,
            maxDelayMs: 20,
            retryOn: [503],
            retryUnsafeMethods: true,
          },
        })],
        sleep: async () => undefined,
      });
      const allowedRes = await allowed.inject({
        method: 'POST',
        url: '/billing/charges',
        headers: { 'content-type': 'application/json' },
        payload: '{}',
      });
      assert.equal(allowedRes.statusCode, 503);
      assert.equal(allowedRes.headers['x-nexus-retries'], '1');
      assert.equal(upstream.hits.length, 3);
    } finally {
      await blocked?.close();
      await allowed?.close();
      await upstream.close();
    }
  });

  it('trips CLOSED -> OPEN, sheds load, then probes HALF_OPEN and closes', async () => {
    const time = clock(1_000_000);
    let fail = true;
    const upstream = await startMock((hit) => {
      if (hit.path === '/boom' && fail) return { status: 500, body: '{"error":"boom"}' };
      return { body: JSON.stringify({ path: hit.path }) };
    });
    const app = await createTestApp({
      now: time.now,
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: upstream.baseUrl,
        circuit: { failureThreshold: 3, successThreshold: 1, openDurationMs: 5_000, halfOpenMaxProbes: 1 },
      })],
    });
    try {
      for (let i = 0; i < 3; i += 1) {
        const res = await app.inject({ method: 'GET', url: '/billing/boom' });
        assert.equal(res.statusCode, 500);
        assert.equal(res.headers['x-nexus-circuit'], i < 2 ? 'CLOSED' : 'OPEN');
      }
      assert.equal(upstream.hits.length, 3);

      const shed = await app.inject({ method: 'GET', url: '/billing/boom' });
      assert.equal(shed.statusCode, 503);
      assert.equal(shed.json().error, 'upstream_unavailable');
      assert.equal(shed.json().service, 'billing');
      assert.equal(shed.headers['x-nexus-circuit'], 'OPEN');
      assert.equal(shed.headers['x-nexus-fallback'], 'static');
      assert.equal(upstream.hits.length, 3);

      time.advance(4_999);
      const stillOpen = await app.inject({ method: 'GET', url: '/billing/boom' });
      assert.equal(stillOpen.statusCode, 503);
      assert.equal(upstream.hits.length, 3);

      time.advance(1);
      fail = false;
      const probe = await app.inject({ method: 'GET', url: '/billing/boom' });
      assert.equal(probe.statusCode, 200);
      assert.equal(probe.headers['x-nexus-circuit'], 'CLOSED');
      assert.equal(upstream.hits.length, 4);

      const again = await app.inject({ method: 'GET', url: '/billing/invoices' });
      assert.equal(again.statusCode, 200);
      assert.equal(again.json().path, '/invoices');
      assert.equal(upstream.hits.length, 5);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('opens again when the half-open probe fails and does not retry that probe', async () => {
    const time = clock(0);
    const delays: number[] = [];
    const upstream = await startMock(() => ({ status: 500, body: '{"error":"boom"}' }));
    const app = await createTestApp({
      now: time.now,
      sleep: async (ms) => {
        delays.push(ms);
      },
      random: () => 1,
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: upstream.baseUrl,
        retries: {
          maxRetries: 2,
          baseDelayMs: 10,
          maxDelayMs: 100,
          retryOn: [500],
          retryUnsafeMethods: false,
        },
        circuit: { failureThreshold: 1, successThreshold: 1, openDurationMs: 5_000, halfOpenMaxProbes: 1 },
      })],
    });
    try {
      const first = await app.inject({ method: 'GET', url: '/billing/boom' });
      assert.equal(first.statusCode, 500);
      assert.equal(first.headers['x-nexus-circuit'], 'OPEN');
      assert.equal(upstream.hits.length, 3);
      assert.deepEqual(delays, [10, 20]);

      const shed = await app.inject({ method: 'GET', url: '/billing/boom' });
      assert.equal(shed.statusCode, 503);
      assert.equal(upstream.hits.length, 3);

      time.advance(5_000);
      const probe = await app.inject({ method: 'GET', url: '/billing/boom' });
      assert.equal(probe.statusCode, 500);
      assert.equal(probe.headers['x-nexus-retries'], '0');
      assert.equal(probe.headers['x-nexus-circuit'], 'OPEN');
      assert.equal(upstream.hits.length, 4);
      assert.deepEqual(delays, [10, 20]);

      const shedAgain = await app.inject({ method: 'GET', url: '/billing/boom' });
      assert.equal(shedAgain.statusCode, 503);
      assert.equal(upstream.hits.length, 4);

      const metrics = await app.inject({
        method: 'GET',
        url: '/nexus-metrics',
        headers: { accept: 'application/json' },
      });
      const route = metrics.json().routes[0];
      assert.equal(route.state, 'OPEN');
      assert.equal(route.failures, 2);
      assert.equal(route.shortCircuits, 2);
      assert.equal(route.failureRate, 1);
      assert.equal(route.cooldownRemainingMs, 5_000);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('serves a cached GET while the circuit is open and the static fallback after the ttl', async () => {
    const time = clock(0);
    const upstream = await startMock((hit) => {
      if (hit.path === '/item') return { body: JSON.stringify({ n: 1 }) };
      return { status: 500, body: '{"error":"boom"}' };
    });
    const app = await createTestApp({
      now: time.now,
      routes: [testRoute({
        id: 'catalog',
        prefix: '/catalog',
        target: upstream.baseUrl,
        cacheTtlMs: 1_000,
        circuit: { failureThreshold: 1, successThreshold: 1, openDurationMs: 60_000, halfOpenMaxProbes: 1 },
      })],
    });
    try {
      const warm = await app.inject({ method: 'GET', url: '/catalog/item' });
      assert.equal(warm.statusCode, 200);
      const boom = await app.inject({ method: 'GET', url: '/catalog/fail' });
      assert.equal(boom.statusCode, 500);

      const cached = await app.inject({ method: 'GET', url: '/catalog/item' });
      assert.equal(cached.statusCode, 200);
      assert.deepEqual(cached.json(), { n: 1 });
      assert.equal(cached.headers['x-nexus-cache'], 'hit');
      assert.equal(cached.headers['x-nexus-fallback'], 'cache');
      assert.equal(cached.headers['x-nexus-circuit'], 'OPEN');
      assert.equal(upstream.hits.filter((hit) => hit.path === '/item').length, 1);

      time.advance(1_000);
      const expired = await app.inject({ method: 'GET', url: '/catalog/item' });
      assert.equal(expired.statusCode, 503);
      assert.equal(expired.json().error, 'upstream_unavailable');
      assert.equal(expired.headers['x-nexus-fallback'], 'static');
      assert.equal(upstream.hits.filter((hit) => hit.path === '/item').length, 1);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('does not cache a no-store response', async () => {
    const upstream = await startMock((hit) => {
      if (hit.path === '/secret') {
        return {
          body: JSON.stringify({ secret: true }),
          headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
        };
      }
      return { status: 500, body: '{"error":"boom"}' };
    });
    const app = await createTestApp({
      routes: [testRoute({
        id: 'catalog',
        prefix: '/catalog',
        target: upstream.baseUrl,
        cacheTtlMs: 60_000,
        circuit: { failureThreshold: 1, successThreshold: 1, openDurationMs: 60_000, halfOpenMaxProbes: 1 },
      })],
    });
    try {
      const warm = await app.inject({ method: 'GET', url: '/catalog/secret' });
      assert.equal(warm.statusCode, 200);
      const boom = await app.inject({ method: 'GET', url: '/catalog/fail' });
      assert.equal(boom.statusCode, 500);
      const shed = await app.inject({ method: 'GET', url: '/catalog/secret' });
      assert.equal(shed.statusCode, 503);
      assert.equal(shed.headers['x-nexus-fallback'], 'static');
      assert.equal(upstream.hits.filter((hit) => hit.path === '/secret').length, 1);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('returns the static fallback when the upstream times out or the body is too large', async () => {
    const slow = await startMock(() => ({ body: '{"ok":true}', delayMs: 400 }));
    const time = clock(0);
    const slowApp = await createTestApp({
      now: time.now,
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: slow.baseUrl,
        timeoutMs: 50,
        circuit: { failureThreshold: 1, successThreshold: 1, openDurationMs: 5_000, halfOpenMaxProbes: 1 },
      })],
    });
    try {
      const res = await slowApp.inject({ method: 'GET', url: '/billing/slow' });
      assert.equal(res.statusCode, 503);
      assert.equal(res.json().error, 'upstream_unavailable');
      assert.equal(res.headers['x-nexus-circuit'], 'OPEN');
      assert.equal(res.headers['x-nexus-fallback'], 'static');
    } finally {
      await closeAll(slowApp, slow);
    }

    const huge = await startMock(() => ({ body: 'x'.repeat(80) }));
    const hugeApp = await createTestApp({
      config: createTestConfig({ proxy: { maxResponseBytes: 32 } }),
      routes: [testRoute({
        id: 'billing',
        prefix: '/billing',
        target: huge.baseUrl,
        circuit: { failureThreshold: 2, successThreshold: 1, openDurationMs: 5_000, halfOpenMaxProbes: 1 },
      })],
    });
    try {
      const res = await hugeApp.inject({ method: 'GET', url: '/billing/blob' });
      assert.equal(res.statusCode, 503);
      assert.equal(res.headers['x-nexus-circuit'], 'CLOSED');
      const metrics = await hugeApp.inject({ method: 'GET', url: '/nexus-metrics/data' });
      assert.equal(metrics.json().routes[0].failures, 1);
    } finally {
      await closeAll(hugeApp, huge);
    }
  });

  it('enforces a token bucket per api key and reports remaining tokens', async () => {
    const time = clock(0);
    const upstream = await startMock(() => ({ body: '{"ok":true}' }));
    const app = await createTestApp({
      now: time.now,
      config: createTestConfig({
        rateLimit: { enabled: true, capacity: 2, refillPerSecond: 1, keyBy: 'apiKey' },
      }),
      routes: [testRoute({ id: 'billing', prefix: '/billing', target: upstream.baseUrl })],
    });
    try {
      const first = await app.inject({
        method: 'GET',
        url: '/billing/a',
        headers: { 'x-api-key': 'alpha' },
      });
      assert.equal(first.statusCode, 200);
      assert.equal(first.headers['x-ratelimit-limit'], '2');
      assert.equal(first.headers['x-ratelimit-remaining'], '1');

      const second = await app.inject({
        method: 'GET',
        url: '/billing/a',
        headers: { 'x-api-key': 'alpha' },
      });
      assert.equal(second.statusCode, 200);

      const blocked = await app.inject({
        method: 'GET',
        url: '/billing/a',
        headers: { 'x-api-key': 'alpha' },
      });
      assert.equal(blocked.statusCode, 429);
      assert.equal(blocked.json().error, 'rate_limited');
      assert.equal(blocked.headers['retry-after'], '1');
      assert.equal(upstream.hits.length, 2);

      const other = await app.inject({
        method: 'GET',
        url: '/billing/a',
        headers: { 'x-api-key': 'beta' },
      });
      assert.equal(other.statusCode, 200);

      time.advance(1_000);
      const refilled = await app.inject({
        method: 'GET',
        url: '/billing/a',
        headers: { 'x-api-key': 'alpha' },
      });
      assert.equal(refilled.statusCode, 200);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('applies a tighter per-route bucket on top of the global one', async () => {
    const upstream = await startMock(() => ({ body: '{"ok":true}' }));
    const app = await createTestApp({
      config: createTestConfig({
        rateLimit: { enabled: true, capacity: 10, refillPerSecond: 0, keyBy: 'ip' },
      }),
      routes: [testRoute({
        id: 'quotes',
        prefix: '/quotes',
        target: upstream.baseUrl,
        rateLimit: { capacity: 1, refillPerSecond: 0, keyBy: 'ip' },
      })],
    });
    try {
      const ok = await app.inject({ method: 'GET', url: '/quotes/usd' });
      assert.equal(ok.statusCode, 200);
      assert.equal(ok.headers['x-ratelimit-limit'], '1');
      const limited = await app.inject({ method: 'GET', url: '/quotes/usd' });
      assert.equal(limited.statusCode, 429);
      assert.equal(upstream.hits.length, 1);
    } finally {
      await closeAll(app, upstream);
    }
  });

  it('reloads the route table and resets rate limit buckets', async () => {
    const dir = await mkdtemp(path.join(tmpdir(), 'nexus-reload-'));
    const first = await startMock(() => ({ body: JSON.stringify({ from: 'a' }) }));
    const second = await startMock(() => ({ body: JSON.stringify({ from: 'b' }) }));
    const configPath = path.join(dir, 'config.json');
    const routesPath = path.join(dir, 'routes.json');
    const config = createTestConfig({ admin: { token: 'test-token-1234' } });
    const writeRoutes = (target: string) => writeFile(routesPath, JSON.stringify({
      routes: [{
        id: 'billing',
        prefix: '/billing',
        target,
        fallback: { statusCode: 503, body: { error: 'upstream_unavailable', service: 'billing' } },
      }],
    }), 'utf8');

    let app: FastifyInstance | undefined;
    try {
      await writeFile(configPath, JSON.stringify(config), 'utf8');
      await writeRoutes(first.baseUrl);
      const loaded = await loadConfig(configPath);
      const routes = await loadRoutes(routesPath, loaded);
      app = await createTestApp({
        config: loaded,
        routes,
        paths: { config: configPath, routes: routesPath },
      });

      const denied = await app.inject({ method: 'POST', url: '/nexus-admin/reload' });
      assert.equal(denied.statusCode, 401);

      const initial = await app.inject({ method: 'GET', url: '/billing/ping' });
      assert.equal(initial.json().from, 'a');

      await writeRoutes(second.baseUrl);
      const reloaded = await app.inject({
        method: 'POST',
        url: '/nexus-admin/reload',
        headers: { 'x-nexus-admin-token': 'test-token-1234' },
      });
      assert.equal(reloaded.statusCode, 200);
      assert.equal(reloaded.json().routes, 1);
      const moved = await app.inject({ method: 'GET', url: '/billing/ping' });
      assert.equal(moved.json().from, 'b');

      await writeFile(routesPath, '{', 'utf8');
      const rejected = await app.inject({
        method: 'POST',
        url: '/nexus-admin/reload',
        headers: { 'x-nexus-admin-token': 'test-token-1234' },
      });
      assert.equal(rejected.statusCode, 400);
      const unchanged = await app.inject({ method: 'GET', url: '/billing/ping' });
      assert.equal(unchanged.json().from, 'b');
    } finally {
      await app?.close();
      await first.close();
      await second.close();
      await rm(dir, { recursive: true, force: true });
    }
  });

  it('rejects an oversized request body', async () => {
    const upstream = await startMock(() => ({ body: '{"ok":true}' }));
    const app = await createTestApp({
      config: createTestConfig({ server: { bodyLimitBytes: 32 } }),
      routes: [testRoute({ id: 'billing', prefix: '/billing', target: upstream.baseUrl })],
    });
    try {
      const res = await app.inject({
        method: 'POST',
        url: '/billing/charges',
        headers: { 'content-type': 'application/json' },
        payload: JSON.stringify({ blob: 'x'.repeat(80) }),
      });
      assert.equal(res.statusCode, 413);
      assert.equal(res.json().error, 'payload_too_large');
      assert.equal(upstream.hits.length, 0);
    } finally {
      await closeAll(app, upstream);
    }
  });
});

async function closeAll(app: FastifyInstance, upstream: MockUpstream): Promise<void> {
  await app.close();
  await upstream.close();
}
