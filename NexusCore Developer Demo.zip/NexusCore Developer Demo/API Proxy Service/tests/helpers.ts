import { createServer, type IncomingMessage } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type { FastifyInstance } from 'fastify';
import { buildServer } from '../src/server.js';
import type {
  AppConfig,
  CircuitPolicy,
  RetryPolicy,
  RouteRule,
} from '../src/types.js';

export const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const defaultRetry = (): RetryPolicy => ({
  maxRetries: 0,
  baseDelayMs: 10,
  maxDelayMs: 100,
  retryOn: [500, 502, 503, 504],
  retryUnsafeMethods: false,
});

const defaultCircuit = (): CircuitPolicy => ({
  failureThreshold: 3,
  successThreshold: 1,
  openDurationMs: 5_000,
  halfOpenMaxProbes: 1,
});

export function createTestConfig(patch?: {
  rateLimit?: Partial<AppConfig['rateLimit']>;
  proxy?: Partial<AppConfig['proxy']>;
  admin?: Partial<AppConfig['admin']>;
  metrics?: Partial<AppConfig['metrics']>;
  server?: Partial<AppConfig['server']>;
}): AppConfig {
  const config: AppConfig = {
    server: {
      host: '127.0.0.1',
      port: 0,
      bodyLimitBytes: 1_048_576,
      requestIdHeader: 'x-request-id',
      logLevel: 'silent',
      trustProxy: false,
      keepAliveTimeoutMs: 72_000,
      ...patch?.server,
    },
    rateLimit: {
      enabled: false,
      capacity: 100,
      refillPerSecond: 100,
      keyBy: 'ipOrApiKey',
      apiKeyHeader: 'x-api-key',
      ...patch?.rateLimit,
    },
    metrics: {
      enabled: true,
      path: '/nexus-metrics',
      sampleSize: 64,
      ...patch?.metrics,
    },
    admin: {
      token: '',
      reloadPath: '/nexus-admin/reload',
      ...patch?.admin,
    },
    proxy: {
      poolConnections: 8,
      keepAliveTimeoutMs: 4_000,
      maxCacheEntries: 100,
      maxResponseBytes: 1_048_576,
      ...patch?.proxy,
    },
    defaults: {
      stripPrefix: true,
      timeoutMs: 500,
      cacheTtlMs: 0,
      retries: defaultRetry(),
      circuit: defaultCircuit(),
    },
  };
  return config;
}

export function testRoute(
  over: Partial<RouteRule> & Pick<RouteRule, 'id' | 'prefix' | 'target'>,
): RouteRule {
  const route: RouteRule = {
    id: over.id,
    prefix: over.prefix,
    target: over.target,
    stripPrefix: over.stripPrefix ?? true,
    timeoutMs: over.timeoutMs ?? 500,
    cacheTtlMs: over.cacheTtlMs ?? 0,
    retries: over.retries ?? defaultRetry(),
    circuit: over.circuit ?? defaultCircuit(),
    fallback: over.fallback ?? {
      statusCode: 503,
      body: { error: 'upstream_unavailable', service: over.id },
    },
  };
  if (over.methods) route.methods = over.methods;
  if (over.rateLimit) route.rateLimit = over.rateLimit;
  return route;
}

export function createTestApp(options: {
  routes: RouteRule[];
  config?: AppConfig;
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  paths?: { config: string; routes: string };
}): Promise<FastifyInstance> {
  return buildServer({
    config: options.config ?? createTestConfig(),
    routes: options.routes,
    deps: {
      now: options.now,
      sleep: options.sleep,
      random: options.random,
    },
    paths: options.paths,
  });
}

export interface MockHit {
  method: string;
  path: string;
  query: string;
  body: Buffer;
  headers: IncomingMessage['headers'];
}

export interface MockReply {
  status?: number;
  body?: string | Buffer;
  headers?: Record<string, string>;
  delayMs?: number;
}

export interface MockUpstream {
  baseUrl: string;
  hits: MockHit[];
  close: () => Promise<void>;
}

export async function startMock(
  handler: (hit: MockHit, hits: readonly MockHit[]) => MockReply | Promise<MockReply>,
): Promise<MockUpstream> {
  const hits: MockHit[] = [];
  const server = createServer((req, res) => {
    req.on('error', () => undefined);
    res.on('error', () => undefined);
    readBody(req)
      .then(async (body) => {
        const url = new URL(req.url ?? '/', 'http://127.0.0.1');
        const hit: MockHit = {
          method: req.method ?? 'GET',
          path: url.pathname,
          query: url.search.startsWith('?') ? url.search.slice(1) : '',
          body,
          headers: req.headers,
        };
        hits.push(hit);
        const reply = await handler(hit, hits);
        if (reply.delayMs && reply.delayMs > 0) {
          await new Promise((resolve) => setTimeout(resolve, reply.delayMs));
        }
        if (res.destroyed) return;
        const payload = Buffer.isBuffer(reply.body) ? reply.body : Buffer.from(reply.body ?? '');
        res.writeHead(reply.status ?? 200, reply.headers ?? { 'content-type': 'application/json; charset=utf-8' });
        res.end(payload);
      })
      .catch(() => {
        if (!res.headersSent) res.writeHead(500);
        res.end();
      });
  });

  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => resolve());
  });
  const address = server.address();
  if (!address || typeof address === 'string') throw new Error('mock upstream has no port');
  return {
    baseUrl: `http://127.0.0.1:${address.port}`,
    hits,
    close: () =>
      new Promise((resolve, reject) => {
        server.close((error) => (error ? reject(error) : resolve()));
      }),
  };
}

function readBody(req: IncomingMessage): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer | string) => {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

export interface Clock {
  now: () => number;
  advance: (ms: number) => void;
  set: (value: number) => void;
}

export function clock(start = 0): Clock {
  let current = start;
  return {
    now: () => current,
    advance: (ms: number) => {
      current += ms;
    },
    set: (value: number) => {
      current = value;
    },
  };
}
