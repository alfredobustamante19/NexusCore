import type { CircuitPolicy, CircuitState } from '../types.js';

export interface CircuitSnapshot {
  state: CircuitState;
  consecutiveFailures: number;
  consecutiveSuccesses: number;
  halfOpenInFlight: number;
  totalTrips: number;
  openedAt: number | null;
  openDurationMs: number;
}

export type TransitionListener = (from: CircuitState, to: CircuitState) => void;

/**
 * Consecutive-failure breaker.
 * CLOSED forwards traffic and trips after `failureThreshold` failed outcomes.
 * OPEN sheds traffic until `openDurationMs` has elapsed.
 * HALF_OPEN lets `halfOpenMaxProbes` calls through. `successThreshold`
 * successes close the breaker; any failure opens it again.
 *
 * A failed outcome is one client request after its retries are finished,
 * not each individual upstream attempt.
 */
export class CircuitBreaker {
  private state: CircuitState = 'CLOSED';
  private consecutiveFailures = 0;
  private consecutiveSuccesses = 0;
  private halfOpenInFlight = 0;
  private totalTrips = 0;
  private openedAt: number | null = null;

  constructor(
    private readonly options: CircuitPolicy,
    private readonly now: () => number = Date.now,
    private readonly onTransition: TransitionListener = () => undefined,
  ) {}

  sameOptions(options: CircuitPolicy): boolean {
    return (
      this.options.failureThreshold === options.failureThreshold &&
      this.options.successThreshold === options.successThreshold &&
      this.options.openDurationMs === options.openDurationMs &&
      this.options.halfOpenMaxProbes === options.halfOpenMaxProbes
    );
  }

  snapshot(): CircuitSnapshot {
    return {
      state: this.state,
      consecutiveFailures: this.consecutiveFailures,
      consecutiveSuccesses: this.consecutiveSuccesses,
      halfOpenInFlight: this.halfOpenInFlight,
      totalTrips: this.totalTrips,
      openedAt: this.openedAt,
      openDurationMs: this.options.openDurationMs,
    };
  }

  tryAcquire(): { allowed: boolean; state: CircuitState } {
    this.moveToHalfOpenIfDue();
    if (this.state === 'OPEN') {
      return { allowed: false, state: 'OPEN' };
    }
    if (this.state === 'HALF_OPEN') {
      if (this.halfOpenInFlight >= this.options.halfOpenMaxProbes) {
        return { allowed: false, state: 'HALF_OPEN' };
      }
      this.halfOpenInFlight += 1;
      return { allowed: true, state: 'HALF_OPEN' };
    }
    return { allowed: true, state: 'CLOSED' };
  }

  recordSuccess(): CircuitState {
    if (this.state === 'OPEN') return this.state;
    if (this.state === 'HALF_OPEN') {
      this.halfOpenInFlight = Math.max(0, this.halfOpenInFlight - 1);
      this.consecutiveSuccesses += 1;
      this.consecutiveFailures = 0;
      if (this.consecutiveSuccesses >= this.options.successThreshold) {
        this.transitionToClosed();
      }
      return this.state;
    }
    this.consecutiveFailures = 0;
    return this.state;
  }

  recordFailure(): CircuitState {
    if (this.state === 'OPEN') return this.state;
    if (this.state === 'HALF_OPEN') {
      this.halfOpenInFlight = Math.max(0, this.halfOpenInFlight - 1);
      this.consecutiveSuccesses = 0;
      this.transitionToOpen();
      return this.state;
    }
    this.consecutiveSuccesses = 0;
    this.consecutiveFailures += 1;
    if (this.consecutiveFailures >= this.options.failureThreshold) {
      this.transitionToOpen();
    }
    return this.state;
  }

  private moveToHalfOpenIfDue(): void {
    if (this.state !== 'OPEN' || this.openedAt === null) return;
    if (this.now() - this.openedAt < this.options.openDurationMs) return;
    const from = this.state;
    this.state = 'HALF_OPEN';
    this.consecutiveSuccesses = 0;
    this.halfOpenInFlight = 0;
    this.onTransition(from, 'HALF_OPEN');
  }

  private transitionToOpen(): void {
    const from = this.state;
    this.state = 'OPEN';
    this.openedAt = this.now();
    this.consecutiveSuccesses = 0;
    this.halfOpenInFlight = 0;
    this.totalTrips += 1;
    this.onTransition(from, 'OPEN');
  }

  private transitionToClosed(): void {
    const from = this.state;
    this.state = 'CLOSED';
    this.openedAt = null;
    this.consecutiveFailures = 0;
    this.consecutiveSuccesses = 0;
    this.halfOpenInFlight = 0;
    this.onTransition(from, 'CLOSED');
  }
}
