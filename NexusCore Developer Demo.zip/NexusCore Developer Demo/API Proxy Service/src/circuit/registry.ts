import type { CircuitState, RouteRule } from '../types.js';
import { CircuitBreaker, type CircuitSnapshot, type TransitionListener } from './breaker.js';

export type { CircuitSnapshot };

export interface CircuitTransition {
  routeId: string;
  from: CircuitState;
  to: CircuitState;
}

export class BreakerRegistry {
  private readonly breakers = new Map<string, CircuitBreaker>();

  constructor(
    private readonly now: () => number,
    private readonly onTransition: (event: CircuitTransition) => void,
  ) {}

  sync(routes: readonly RouteRule[]): void {
    const live = new Set(routes.map((route) => route.id));
    for (const id of this.breakers.keys()) {
      if (!live.has(id)) this.breakers.delete(id);
    }
    for (const route of routes) {
      const existing = this.breakers.get(route.id);
      if (!existing || !existing.sameOptions(route.circuit)) {
        this.breakers.set(route.id, this.create(route));
      }
    }
  }

  require(route: RouteRule): CircuitBreaker {
    const existing = this.breakers.get(route.id);
    if (existing) return existing;
    const created = this.create(route);
    this.breakers.set(route.id, created);
    return created;
  }

  snapshot(id: string): CircuitSnapshot | undefined {
    return this.breakers.get(id)?.snapshot();
  }

  private create(route: RouteRule): CircuitBreaker {
    const listener: TransitionListener = (from, to) => {
      this.onTransition({ routeId: route.id, from, to });
    };
    return new CircuitBreaker(route.circuit, this.now, listener);
  }
}

export function cooldownRemaining(snapshot: CircuitSnapshot, now: number): number {
  if (snapshot.state !== 'OPEN' || snapshot.openedAt === null) return 0;
  return Math.max(0, snapshot.openDurationMs - (now - snapshot.openedAt));
}
