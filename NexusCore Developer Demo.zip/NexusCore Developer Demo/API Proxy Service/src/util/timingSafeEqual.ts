import { createHash, timingSafeEqual } from 'node:crypto';

/** Compares two strings without leaking length or content through early return. */
export function tokensEqual(left: string, right: string): boolean {
  const a = createHash('sha256').update(left, 'utf8').digest();
  const b = createHash('sha256').update(right, 'utf8').digest();
  return timingSafeEqual(a, b);
}
