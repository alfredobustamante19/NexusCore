import type { FastifyReply, FastifyRequest } from 'fastify';
import { ResponseCache } from './cache/responseCache.js';
import { BreakerRegistry } from './circuit/registry.js';
import { IDEMPOTENT_METHODS, USER_AGENT } from './constants.js';
import { MetricsCollector } from './metrics/collector.js';
import { buildForwardHeaders, headerValue, sanitizeResponseHeaders } from './proxy/headers.js';
import { buildUpstreamUrl, cacheKey, RouteTable, splitUrl } from './proxy/router.js';
import { UpstreamClient, type UpstreamResult } from './proxy/upstream.js';
import { TokenBucketLimiter, type LimitDecision } from './ratelimit/tokenBucket.js';
import { backoffDelay, sleep } from './retry/backoff.js';
import type { AppConfig, CircuitState, KeyBy, RateLimitConfig, RouteRule } from './types.js';

export interface GatewayLogger {
  debug: (obj: object, msg: string) => void;
  info: (obj: object, msg: string) => void;
  warn: (obj: object, msg: string) => void;
  error: (obj: object, msg: string) => void;
}

export interface GatewayDependencies {
  now: () => number;
  sleep: (ms: number) => Promise<void>;
  random: () => number;
}

export interface GatewayOptions {
  config: AppConfig;
  routes: RouteRule[];
  deps?: Partial<GatewayDependencies>;
  logger?: GatewayLogger;
}

interface HttpOutcome {
  type: 'http';
  result: UpstreamResult;
  retries: number;
  failed: boolean;
  error: string | null;
}

interface NetworkOutcome {
  type: 'network';
  retries: number;
  error: string;
}

type CallOutcome = HttpOutcome | NetworkOutcome;

const silentLogger: GatewayLogger = {
  debug: () => undefined,
  info: () => undefined,
  warn: () => undefined,
  error: () => undefined,
};

export class Gateway {
  private readonly table: RouteTable;
  private readonly breakers: BreakerRegistry;
  private readonly cache: ResponseCache;
  private readonly metrics: MetricsCollector;
  private readonly upstream: UpstreamClient;
  private readonly nowFn: () => number;
  private readonly sleepFn: (ms: number) => Promise<void>;
  private readonly randomFn: () => number;
  private readonly logger: GatewayLogger;
  private readonly routeLimiters = new Map<string, TokenBucketLimiter>();
  private settings: {
    rateLimit: RateLimitConfig;
    maxResponseBytes: number;
    requestIdHeader: string;
    trustProxy: boolean;
  };
  private globalLimiter: TokenBucketLimiter;
  private inFlight = 0;

  constructor(options: GatewayOptions) {
    this.upstream = new UpstreamClient(options.config.proxy);
    this.nowFn = options.deps?.now ?? Date.now;
    this.sleepFn = options.deps?.sleep ?? sleep;
    this.randomFn = options.deps?.random ?? Math.random;
    this.logger = options.logger ?? silentLogger;
    this.settings = {
      rateLimit: options.config.rateLimit,
      maxResponseBytes: options.config.proxy.maxResponseBytes,
      requestIdHeader: options.config.server.requestIdHeader,
      trustProxy: options.config.server.trustProxy,
    };
    this.table = new RouteTable(options.routes);
    this.cache = new ResponseCache(options.config.proxy.maxCacheEntries);
    this.metrics = new MetricsCollector(options.config.metrics.sampleSize);
    this.globalLimiter = this.createGlobalLimiter();
    this.breakers = new BreakerRegistry(this.nowFn, (event) => {
      const fields = { routeId: event.routeId, from: event.from, to: event.to };
      if (event.to === 'OPEN') this.logger.warn(fields, 'circuit opened');
      else this.logger.info(fields, 'circuit transition');
    });
    this.breakers.sync(options.routes);
  }

  async handle(req: FastifyRequest, reply: FastifyReply): Promise<void> {
    const started = this.nowFn();
    const { path, query } = splitUrl(req.raw.url ?? '/');
    const match = this.table.match(req.method, path);

    if (match.type === 'none') {
      this.metrics.recordUnmatched();
      await reply.code(404).send({
        error: 'no_route',
        message: 'No route matched the request',
        path,
        requestId: req.id,
      });
      return;
    }

    if (match.type === 'method') {
      this.metrics.recordMethodNotAllowed();
      await reply.code(405).header('allow', match.allow.join(', ')).send({
        error: 'method_not_allowed',
        message: 'Method is not routed',
        allow: match.allow,
        requestId: req.id,
      });
      return;
    }

    const route = match.route;
    reply.header('x-nexus-route', route.id);
    this.inFlight += 1;
    try {
      if (await this.rejectIfLimited(req, reply, route)) return;

      const breaker = this.breakers.require(route);
      const permit = breaker.tryAcquire();
      if (!permit.allowed) {
        this.metrics.recordShortCircuit(route.id, this.nowFn() - started);
        await this.sendFallback(req, reply, route, path, query, permit.state, 0);
        return;
      }

      let recorded = false;
      try {
        const outcome = await this.callWithRetries(req, route, path, query, permit.state === 'HALF_OPEN');
        const latency = this.nowFn() - started;
        if (outcome.type === 'http') {
          if (outcome.failed) {
            breaker.recordFailure();
            recorded = true;
            this.metrics.recordFailure(
              route.id,
              latency,
              outcome.retries,
              outcome.error ?? 'upstream_error',
              outcome.result.statusCode,
            );
            this.logger.debug(
              { routeId: route.id, status: outcome.result.statusCode, retries: outcome.retries },
              'upstream error status',
            );
          } else {
            breaker.recordSuccess();
            recorded = true;
            this.metrics.recordSuccess(route.id, latency, outcome.retries, outcome.result.statusCode);
            this.maybeCache(route, req.method, path, query, outcome.result);
          }
          this.writeProxyHeaders(reply, breaker.snapshot().state, outcome.retries, 'miss');
          await this.sendUpstream(reply, outcome.result);
          return;
        }

        breaker.recordFailure();
        recorded = true;
        this.metrics.recordFailure(route.id, latency, outcome.retries, outcome.error, null);
        this.logger.warn(
          { routeId: route.id, error: outcome.error, retries: outcome.retries },
          'upstream request failed',
        );
        await this.sendFallback(req, reply, route, path, query, breaker.snapshot().state, outcome.retries);
      } catch (error) {
        if (!recorded) {
          breaker.recordFailure();
          const message = error instanceof Error ? error.message : 'upstream_error';
          this.metrics.recordFailure(route.id, this.nowFn() - started, 0, message, null);
        }
        throw error;
      }
    } finally {
      this.inFlight -= 1;
    }
  }

  metricsSnapshot() {
    return this.metrics.snapshot(
      this.table.list(),
      (id) => this.breakers.snapshot(id),
      this.nowFn(),
      this.inFlight,
    );
  }

  applyReload(routes: readonly RouteRule[], rateLimit: RateLimitConfig, maxResponseBytes: number): void {
    this.table.replace(routes);
    this.breakers.sync(routes);
    this.settings = { ...this.settings, rateLimit, maxResponseBytes };
    this.globalLimiter = this.createGlobalLimiter();
    this.routeLimiters.clear();
  }

  async close(): Promise<void> {
    await this.upstream.close();
  }

  private createGlobalLimiter(): TokenBucketLimiter {
    const policy = this.settings.rateLimit;
    return new TokenBucketLimiter(policy.capacity, policy.refillPerSecond, this.nowFn);
  }

  private async rejectIfLimited(
    req: FastifyRequest,
    reply: FastifyReply,
    route: RouteRule,
  ): Promise<boolean> {
    const global = this.settings.rateLimit;
    if (global.enabled) {
      const decision = this.globalLimiter.tryRemove(this.rateKey(req, global.keyBy));
      if (!decision.allowed) {
        this.metrics.recordRateLimited(route.id);
        await this.sendLimited(req, reply, decision);
        return true;
      }
      if (!route.rateLimit) this.writeLimitHeaders(reply, decision);
    }

    if (!route.rateLimit) return false;
    let limiter = this.routeLimiters.get(route.id);
    if (!limiter) {
      limiter = new TokenBucketLimiter(
        route.rateLimit.capacity,
        route.rateLimit.refillPerSecond,
        this.nowFn,
      );
      this.routeLimiters.set(route.id, limiter);
    }
    const decision = limiter.tryRemove(`${route.id}:${this.rateKey(req, route.rateLimit.keyBy)}`);
    this.writeLimitHeaders(reply, decision);
    if (!decision.allowed) {
      this.metrics.recordRateLimited(route.id);
      await this.sendLimited(req, reply, decision);
      return true;
    }
    return false;
  }

  private async sendLimited(req: FastifyRequest, reply: FastifyReply, decision: LimitDecision): Promise<void> {
    this.writeLimitHeaders(reply, decision);
    await reply.code(429).send({
      error: 'rate_limited',
      message: 'Token bucket exhausted',
      requestId: req.id,
    });
  }

  private writeLimitHeaders(reply: FastifyReply, decision: LimitDecision): void {
    reply.header('x-ratelimit-limit', String(decision.limit));
    reply.header('x-ratelimit-remaining', String(Math.max(0, Math.floor(decision.remaining))));
    if (decision.retryAfterMs > 0) {
      reply.header('retry-after', String(Math.max(1, Math.ceil(decision.retryAfterMs / 1000))));
    }
  }

  private rateKey(req: FastifyRequest, keyBy: KeyBy): string {
    const headerName = this.settings.rateLimit.apiKeyHeader.toLowerCase();
    const raw = req.headers[headerName];
    const apiKey = Array.isArray(raw) ? raw[0] : raw;
    const ip = req.ip || 'unknown';
    if (keyBy === 'ip') return `ip:${ip}`;
    if (keyBy === 'apiKey') return apiKey ? `key:${apiKey}` : `ip:${ip}`;
    return apiKey ? `key:${apiKey}` : `ip:${ip}`;
  }

  private async callWithRetries(
    req: FastifyRequest,
    route: RouteRule,
    path: string,
    query: string,
    halfOpen: boolean,
  ): Promise<CallOutcome> {
    const maxRetries = halfOpen || !this.canRetry(req.method, route) ? 0 : route.retries.maxRetries;
    const headers = buildForwardHeaders(req.headers, {
      requestId: req.id,
      requestIdHeader: this.settings.requestIdHeader,
      clientIp: req.ip || 'unknown',
      host: typeof req.headers.host === 'string' ? req.headers.host : 'unknown',
      proto: req.protocol,
      trustProxy: this.settings.trustProxy,
      userAgent: USER_AGENT,
    });
    const body = Buffer.isBuffer(req.body) && req.body.length > 0 ? req.body : undefined;
    const url = buildUpstreamUrl(route, path, query);
    let retries = 0;
    let lastError = 'upstream_unreachable';

    for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
      if (attempt > 0) {
        const wait = backoffDelay(attempt - 1, route.retries, this.randomFn);
        await this.sleepFn(wait);
        retries += 1;
      }
      try {
        const result = await this.upstream.send(
          url,
          req.method,
          headers,
          body,
          route.timeoutMs,
          this.settings.maxResponseBytes,
        );
        const retryable = route.retries.retryOn.includes(result.statusCode);
        if (retryable && attempt < maxRetries) {
          lastError = `HTTP ${result.statusCode}`;
          continue;
        }
        const failed = result.statusCode >= 500;
        return {
          type: 'http',
          result,
          retries,
          failed,
          error: failed ? `HTTP ${result.statusCode}` : null,
        };
      } catch (error) {
        lastError = error instanceof Error ? error.message : 'upstream_unreachable';
        if (attempt >= maxRetries) {
          return { type: 'network', retries, error: lastError };
        }
      }
    }

    return { type: 'network', retries, error: lastError };
  }

  private canRetry(method: string, route: RouteRule): boolean {
    if (route.retries.maxRetries <= 0) return false;
    if (route.retries.retryUnsafeMethods) return true;
    return IDEMPOTENT_METHODS.has(method);
  }

  private maybeCache(
    route: RouteRule,
    method: string,
    path: string,
    query: string,
    result: UpstreamResult,
  ): void {
    if (route.cacheTtlMs <= 0) return;
    if (method !== 'GET' && method !== 'HEAD') return;
    if (result.statusCode >= 400) return;
    const cacheControl = headerValue(result.headers, 'cache-control');
    if (cacheControl && /no-store|private/i.test(cacheControl)) return;
    this.cache.set(cacheKey(route.id, method, path, query), {
      statusCode: result.statusCode,
      contentType: headerValue(result.headers, 'content-type') ?? 'application/octet-stream',
      body: result.body,
      storedAt: this.nowFn(),
      ttlMs: route.cacheTtlMs,
    });
  }

  private async sendUpstream(reply: FastifyReply, result: UpstreamResult): Promise<void> {
    for (const [name, value] of sanitizeResponseHeaders(result.headers)) {
      reply.header(name, value);
    }
    if (!headerValue(result.headers, 'content-type')) {
      reply.header('content-type', 'application/octet-stream');
    }
    await reply.code(result.statusCode).send(result.body);
  }

  private async sendFallback(
    req: FastifyRequest,
    reply: FastifyReply,
    route: RouteRule,
    path: string,
    query: string,
    state: CircuitState,
    retries: number,
  ): Promise<void> {
    const cached = route.cacheTtlMs > 0
      ? this.cache.get(cacheKey(route.id, req.method, path, query), this.nowFn())
      : undefined;
    if (cached) {
      this.metrics.recordCacheHit(route.id);
      this.writeProxyHeaders(reply, state, retries, 'hit');
      reply.header('x-nexus-fallback', 'cache');
      reply.header('content-type', cached.contentType);
      await reply.code(cached.statusCode).send(cached.body);
      return;
    }
    this.writeProxyHeaders(reply, state, retries, 'miss');
    reply.header('x-nexus-fallback', 'static');
    await reply.code(route.fallback.statusCode).send({
      ...route.fallback.body,
      requestId: req.id,
    });
  }

  private writeProxyHeaders(
    reply: FastifyReply,
    state: CircuitState,
    retries: number,
    cache: 'hit' | 'miss',
  ): void {
    reply.header('x-nexus-circuit', state);
    reply.header('x-nexus-retries', String(retries));
    reply.header('x-nexus-cache', cache);
  }
}
