export const SERVICE_NAME = 'NexusCircuit';
export const VERSION = '1.0.0';
export const HEALTH_PATH = '/nexus-health';
export const USER_AGENT = 'NexusCircuit/1.0';

export const IDEMPOTENT_METHODS = new Set([
  'GET',
  'HEAD',
  'OPTIONS',
  'PUT',
  'DELETE',
]);

export const HTTP_METHODS = [
  'GET',
  'HEAD',
  'POST',
  'PUT',
  'PATCH',
  'DELETE',
  'OPTIONS',
] as const;

export type HttpMethod = (typeof HTTP_METHODS)[number];
