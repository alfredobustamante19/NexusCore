export interface BackoffPolicy {
  baseDelayMs: number;
  maxDelayMs: number;
}

/**
 * Equal-jitter delay before a retry.
 * `retryIndex` 0 is the first retry. The raw exponential delay is capped,
 * then the returned wait is uniform between half of that cap and the cap.
 */
export function backoffDelay(
  retryIndex: number,
  policy: BackoffPolicy,
  random: () => number = Math.random,
): number {
  if (!Number.isInteger(retryIndex) || retryIndex < 0) {
    throw new Error('retryIndex must be an integer >= 0');
  }
  const shift = Math.min(retryIndex, 16);
  const exponential = Math.min(policy.maxDelayMs, policy.baseDelayMs * 2 ** shift);
  const unit = Math.min(1, Math.max(0, random()));
  return Math.round(exponential / 2 + unit * (exponential / 2));
}

export function sleep(ms: number): Promise<void> {
  if (ms <= 0) return Promise.resolve();
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}
