import { readFile } from 'node:fs/promises';
import { HEALTH_PATH, HTTP_METHODS, type HttpMethod } from './constants.js';
import type {
  AdminConfig,
  AppConfig,
  CircuitPolicy,
  FallbackPolicy,
  LogLevel,
  MetricsConfig,
  ProxyConfig,
  RateLimitConfig,
  RateLimitPolicy,
  RetryPolicy,
  RouteDefaults,
  RouteRule,
  ServerConfig,
} from './types.js';

export class ConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ConfigError';
  }
}

const LOG_LEVELS: readonly LogLevel[] = [
  'fatal',
  'error',
  'warn',
  'info',
  'debug',
  'trace',
  'silent',
];

const KEY_BY = ['ip', 'apiKey', 'ipOrApiKey'] as const;

const HEADER_NAME = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
const ROUTE_ID = /^[A-Za-z][A-Za-z0-9_-]{0,63}$/;

export async function loadConfig(file: string): Promise<AppConfig> {
  return parseConfig(await readJson(file), file);
}

export async function loadRoutes(file: string, config: AppConfig): Promise<RouteRule[]> {
  return parseRoutes(await readJson(file), config, file);
}

export function parseConfig(input: unknown, source = 'config'): AppConfig {
  const root = expectObject(input, source);
  assertKnown(
    root,
    ['server', 'rateLimit', 'metrics', 'admin', 'proxy', 'defaults'],
    source,
  );
  const server = parseServer(expectObject(root.server, `${source}.server`), `${source}.server`);
  const rateLimit = parseRateLimit(
    expectObject(root.rateLimit, `${source}.rateLimit`),
    `${source}.rateLimit`,
    true,
  );
  const metrics = parseMetrics(expectObject(root.metrics, `${source}.metrics`), `${source}.metrics`);
  const admin = parseAdmin(expectObject(root.admin, `${source}.admin`), `${source}.admin`);
  const proxy = parseProxy(expectObject(root.proxy, `${source}.proxy`), `${source}.proxy`);
  const defaults = parseDefaults(
    expectObject(root.defaults, `${source}.defaults`),
    `${source}.defaults`,
  );
  assertPathFree(metrics.path, [HEALTH_PATH, admin.reloadPath], `${source}.metrics.path`);
  assertPathFree(admin.reloadPath, [HEALTH_PATH, metrics.path, `${metrics.path}/data`], `${source}.admin.reloadPath`);
  return { server, rateLimit, metrics, admin, proxy, defaults };
}

export function parseRoutes(input: unknown, config: AppConfig, source = 'routes'): RouteRule[] {
  const root = expectObject(input, source);
  assertKnown(root, ['routes'], source);
  if (!Array.isArray(root.routes)) throw new ConfigError(`${source}.routes must be an array`);
  if (root.routes.length > 500) throw new ConfigError(`${source}.routes exceeds 500 entries`);

  const reserved = [HEALTH_PATH, config.metrics.path, `${config.metrics.path}/data`, config.admin.reloadPath];
  const seenIds = new Set<string>();
  const seenPrefixes = new Set<string>();
  const routes: RouteRule[] = [];

  for (let index = 0; index < root.routes.length; index += 1) {
    const path = `${source}.routes[${index}]`;
    const route = parseRoute(root.routes[index], config.defaults, reserved, path);
    if (seenIds.has(route.id)) throw new ConfigError(`${path}.id "${route.id}" is duplicated`);
    if (seenPrefixes.has(route.prefix)) {
      throw new ConfigError(`${path}.prefix "${route.prefix}" is duplicated`);
    }
    seenIds.add(route.id);
    seenPrefixes.add(route.prefix);
    routes.push(route);
  }
  return routes;
}

async function readJson(file: string): Promise<unknown> {
  let text: string;
  try {
    text = await readFile(file, 'utf8');
  } catch (error) {
    const message = error instanceof Error ? error.message : 'unreadable';
    throw new ConfigError(`Cannot read ${file}: ${message}`);
  }
  try {
    return JSON.parse(text) as unknown;
  } catch (error) {
    const message = error instanceof Error ? error.message : 'invalid JSON';
    throw new ConfigError(`Invalid JSON in ${file}: ${message}`);
  }
}

function parseServer(source: Record<string, unknown>, path: string): ServerConfig {
  assertKnown(
    source,
    ['host', 'port', 'bodyLimitBytes', 'requestIdHeader', 'logLevel', 'trustProxy', 'keepAliveTimeoutMs'],
    path,
  );
  const requestIdHeader = readString(source, 'requestIdHeader', path, 1, 64);
  assertHeaderName(requestIdHeader, `${path}.requestIdHeader`);
  return {
    host: readString(source, 'host', path, 1, 255),
    port: readNumber(source, 'port', path, 0, 65_535, true),
    bodyLimitBytes: readNumber(source, 'bodyLimitBytes', path, 1, 50_000_000, true),
    requestIdHeader,
    logLevel: readEnum(source, 'logLevel', path, LOG_LEVELS),
    trustProxy: readBoolean(source, 'trustProxy', path),
    keepAliveTimeoutMs: readNumber(source, 'keepAliveTimeoutMs', path, 1_000, 600_000, true),
  };
}

function parseRateLimit(
  source: Record<string, unknown>,
  path: string,
  global: true,
): RateLimitConfig;
function parseRateLimit(source: Record<string, unknown>, path: string, global: false): RateLimitPolicy;
function parseRateLimit(
  source: Record<string, unknown>,
  path: string,
  global: boolean,
): RateLimitConfig | RateLimitPolicy {
  const allowed = global
    ? ['enabled', 'capacity', 'refillPerSecond', 'keyBy', 'apiKeyHeader']
    : ['capacity', 'refillPerSecond', 'keyBy'];
  assertKnown(source, allowed, path);
  const policy: RateLimitPolicy = {
    capacity: readNumber(source, 'capacity', path, 1, 1_000_000, true),
    refillPerSecond: readNumber(source, 'refillPerSecond', path, 0, 1_000_000, false),
    keyBy: readEnum(source, 'keyBy', path, KEY_BY),
  };
  if (!global) return policy;
  const apiKeyHeader = readString(source, 'apiKeyHeader', path, 1, 64);
  assertHeaderName(apiKeyHeader, `${path}.apiKeyHeader`);
  return {
    ...policy,
    enabled: readBoolean(source, 'enabled', path),
    apiKeyHeader,
  };
}

function parseMetrics(source: Record<string, unknown>, path: string): MetricsConfig {
  assertKnown(source, ['enabled', 'path', 'sampleSize'], path);
  return {
    enabled: readBoolean(source, 'enabled', path),
    path: readAbsolutePath(source, 'path', path),
    sampleSize: readNumber(source, 'sampleSize', path, 16, 8_192, true),
  };
}

function parseAdmin(source: Record<string, unknown>, path: string): AdminConfig {
  assertKnown(source, ['token', 'reloadPath'], path);
  const token = readString(source, 'token', path, 0, 256);
  if (token.length > 0 && token.length < 8) {
    throw new ConfigError(`${path}.token must be empty or at least 8 characters`);
  }
  return {
    token,
    reloadPath: readAbsolutePath(source, 'reloadPath', path),
  };
}

function parseProxy(source: Record<string, unknown>, path: string): ProxyConfig {
  assertKnown(
    source,
    ['poolConnections', 'keepAliveTimeoutMs', 'maxCacheEntries', 'maxResponseBytes'],
    path,
  );
  return {
    poolConnections: readNumber(source, 'poolConnections', path, 1, 1_000, true),
    keepAliveTimeoutMs: readNumber(source, 'keepAliveTimeoutMs', path, 1_000, 600_000, true),
    maxCacheEntries: readNumber(source, 'maxCacheEntries', path, 1, 100_000, true),
    maxResponseBytes: readNumber(source, 'maxResponseBytes', path, 1_024, 50_000_000, true),
  };
}

function parseDefaults(source: Record<string, unknown>, path: string): RouteDefaults {
  assertKnown(source, ['stripPrefix', 'timeoutMs', 'cacheTtlMs', 'retries', 'circuit'], path);
  return {
    stripPrefix: readBoolean(source, 'stripPrefix', path),
    timeoutMs: readNumber(source, 'timeoutMs', path, 10, 120_000, true),
    cacheTtlMs: readNumber(source, 'cacheTtlMs', path, 0, 86_400_000, true),
    retries: parseRetry(expectObject(source.retries, `${path}.retries`), `${path}.retries`),
    circuit: parseCircuit(expectObject(source.circuit, `${path}.circuit`), `${path}.circuit`),
  };
}

function parseRoute(
  input: unknown,
  defaults: RouteDefaults,
  reserved: readonly string[],
  path: string,
): RouteRule {
  const source = expectObject(input, path);
  assertKnown(
    source,
    [
      'id',
      'prefix',
      'target',
      'methods',
      'stripPrefix',
      'timeoutMs',
      'cacheTtlMs',
      'retries',
      'circuit',
      'fallback',
      'rateLimit',
    ],
    path,
  );
  const id = readString(source, 'id', path, 1, 64);
  if (!ROUTE_ID.test(id)) {
    throw new ConfigError(`${path}.id must match ${ROUTE_ID.source}`);
  }
  const prefix = readPrefix(source, 'prefix', path);
  assertPathFree(prefix, reserved, `${path}.prefix`);
  const retries = source.retries === undefined
    ? copyRetry(defaults.retries)
    : parseRetry(expectObject(source.retries, `${path}.retries`), `${path}.retries`, defaults.retries);
  const circuit = source.circuit === undefined
    ? { ...defaults.circuit }
    : parseCircuit(expectObject(source.circuit, `${path}.circuit`), `${path}.circuit`, defaults.circuit);

  const route: RouteRule = {
    id,
    prefix,
    target: readTarget(source, 'target', path),
    stripPrefix: readOptionalBoolean(source, 'stripPrefix', path) ?? defaults.stripPrefix,
    timeoutMs: readOptionalNumber(source, 'timeoutMs', path, 10, 120_000, true) ?? defaults.timeoutMs,
    cacheTtlMs: readOptionalNumber(source, 'cacheTtlMs', path, 0, 86_400_000, true) ?? defaults.cacheTtlMs,
    retries,
    circuit,
    fallback: parseFallback(expectObject(source.fallback, `${path}.fallback`), `${path}.fallback`),
  };
  if (source.methods !== undefined) route.methods = parseMethods(source.methods, `${path}.methods`);
  if (source.rateLimit !== undefined) {
    route.rateLimit = parseRateLimit(
      expectObject(source.rateLimit, `${path}.rateLimit`),
      `${path}.rateLimit`,
      false,
    );
  }
  if (route.retries.maxDelayMs < route.retries.baseDelayMs) {
    throw new ConfigError(`${path}.retries.maxDelayMs must be >= baseDelayMs`);
  }
  return route;
}

function parseRetry(
  source: Record<string, unknown>,
  path: string,
  defaults?: RetryPolicy,
): RetryPolicy {
  assertKnown(source, ['maxRetries', 'baseDelayMs', 'maxDelayMs', 'retryOn', 'retryUnsafeMethods'], path);
  const retryOn = source.retryOn === undefined
    ? [...(defaults?.retryOn ?? [])]
    : parseStatusList(source.retryOn, `${path}.retryOn`);
  if (source.retryOn === undefined && !defaults) {
    throw new ConfigError(`${path}.retryOn is required`);
  }
  const policy: RetryPolicy = {
    maxRetries: readOptionalNumber(source, 'maxRetries', path, 0, 5, true) ?? requiredDefault(defaults?.maxRetries, `${path}.maxRetries`),
    baseDelayMs: readOptionalNumber(source, 'baseDelayMs', path, 0, 60_000, true) ?? requiredDefault(defaults?.baseDelayMs, `${path}.baseDelayMs`),
    maxDelayMs: readOptionalNumber(source, 'maxDelayMs', path, 0, 60_000, true) ?? requiredDefault(defaults?.maxDelayMs, `${path}.maxDelayMs`),
    retryOn,
    retryUnsafeMethods: readOptionalBoolean(source, 'retryUnsafeMethods', path) ?? defaults?.retryUnsafeMethods ?? false,
  };
  if (source.retryUnsafeMethods === undefined && !defaults && source.retryUnsafeMethods === undefined) {
    policy.retryUnsafeMethods = false;
  }
  if (policy.maxDelayMs < policy.baseDelayMs) {
    throw new ConfigError(`${path}.maxDelayMs must be >= baseDelayMs`);
  }
  return policy;
}

function parseCircuit(
  source: Record<string, unknown>,
  path: string,
  defaults?: CircuitPolicy,
): CircuitPolicy {
  assertKnown(
    source,
    ['failureThreshold', 'successThreshold', 'openDurationMs', 'halfOpenMaxProbes'],
    path,
  );
  return {
    failureThreshold: readOptionalNumber(source, 'failureThreshold', path, 1, 1_000, true)
      ?? requiredDefault(defaults?.failureThreshold, `${path}.failureThreshold`),
    successThreshold: readOptionalNumber(source, 'successThreshold', path, 1, 100, true)
      ?? requiredDefault(defaults?.successThreshold, `${path}.successThreshold`),
    openDurationMs: readOptionalNumber(source, 'openDurationMs', path, 0, 3_600_000, true)
      ?? requiredDefault(defaults?.openDurationMs, `${path}.openDurationMs`),
    halfOpenMaxProbes: readOptionalNumber(source, 'halfOpenMaxProbes', path, 1, 20, true)
      ?? requiredDefault(defaults?.halfOpenMaxProbes, `${path}.halfOpenMaxProbes`),
  };
}

function parseFallback(source: Record<string, unknown>, path: string): FallbackPolicy {
  assertKnown(source, ['statusCode', 'body'], path);
  const body = source.body;
  if (!isObject(body)) throw new ConfigError(`${path}.body must be a JSON object`);
  const encoded = JSON.stringify(body);
  if (encoded.length > 8_192) throw new ConfigError(`${path}.body exceeds 8192 bytes`);
  return {
    statusCode: readNumber(source, 'statusCode', path, 400, 599, true),
    body,
  };
}

function parseMethods(input: unknown, path: string): HttpMethod[] {
  if (!Array.isArray(input) || input.length === 0) {
    throw new ConfigError(`${path} must be a non-empty array`);
  }
  const methods: HttpMethod[] = [];
  for (const value of input) {
    if (typeof value !== 'string' || !HTTP_METHODS.includes(value as HttpMethod)) {
      throw new ConfigError(`${path} contains an unsupported method`);
    }
    const method = value as HttpMethod;
    if (methods.includes(method)) throw new ConfigError(`${path} contains a duplicate method`);
    methods.push(method);
  }
  return methods;
}

function parseStatusList(input: unknown, path: string): number[] {
  if (!Array.isArray(input) || input.length === 0) {
    throw new ConfigError(`${path} must be a non-empty array`);
  }
  const codes: number[] = [];
  for (const value of input) {
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 500 || value > 599) {
      throw new ConfigError(`${path} only accepts integer status codes from 500 to 599`);
    }
    if (!codes.includes(value)) codes.push(value);
  }
  return codes;
}

function copyRetry(policy: RetryPolicy): RetryPolicy {
  return { ...policy, retryOn: [...policy.retryOn] };
}

function requiredDefault(value: number | undefined, path: string): number {
  if (value === undefined) throw new ConfigError(`${path} is required`);
  return value;
}

function readTarget(source: Record<string, unknown>, key: string, path: string): string {
  const target = readString(source, key, path, 1, 2_048);
  let url: URL;
  try {
    url = new URL(target);
  } catch {
    throw new ConfigError(`${path}.${key} must be an absolute http(s) URL`);
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new ConfigError(`${path}.${key} must use http or https`);
  }
  if (url.username || url.password) {
    throw new ConfigError(`${path}.${key} must not include credentials`);
  }
  return target.replace(/\/+$/, '');
}

function readPrefix(source: Record<string, unknown>, key: string, path: string): string {
  const prefix = readString(source, key, path, 1, 512);
  if (!prefix.startsWith('/')) throw new ConfigError(`${path}.${key} must start with /`);
  if (prefix.length > 1 && prefix.endsWith('/')) {
    throw new ConfigError(`${path}.${key} must not end with /`);
  }
  if (prefix.includes('?') || prefix.includes('#') || prefix.includes(' ')) {
    throw new ConfigError(`${path}.${key} must be a path`);
  }
  return prefix;
}

function readAbsolutePath(source: Record<string, unknown>, key: string, path: string): string {
  const value = readPrefix(source, key, path);
  if (value === '/') throw new ConfigError(`${path}.${key} must not be /`);
  return value;
}

function assertPathFree(value: string, reserved: readonly string[], path: string): void {
  for (const item of reserved) {
    if (value === item) throw new ConfigError(`${path} collides with reserved path ${item}`);
  }
}

function assertHeaderName(value: string, path: string): void {
  if (!HEADER_NAME.test(value)) throw new ConfigError(`${path} is not a valid header name`);
}

function expectObject(input: unknown, path: string): Record<string, unknown> {
  if (!isObject(input)) throw new ConfigError(`${path} must be an object`);
  return input;
}

function isObject(input: unknown): input is Record<string, unknown> {
  return typeof input === 'object' && input !== null && !Array.isArray(input);
}

function assertKnown(source: Record<string, unknown>, allowed: readonly string[], path: string): void {
  for (const key of Object.keys(source)) {
    if (!allowed.includes(key)) throw new ConfigError(`${path} has unknown field "${key}"`);
  }
}

function readString(
  source: Record<string, unknown>,
  key: string,
  path: string,
  min: number,
  max: number,
): string {
  const value = source[key];
  if (typeof value !== 'string') throw new ConfigError(`${path}.${key} must be a string`);
  if (value.length < min || value.length > max) {
    throw new ConfigError(`${path}.${key} length must be between ${min} and ${max}`);
  }
  return value;
}

function readBoolean(source: Record<string, unknown>, key: string, path: string): boolean {
  const value = source[key];
  if (typeof value !== 'boolean') throw new ConfigError(`${path}.${key} must be a boolean`);
  return value;
}

function readOptionalBoolean(
  source: Record<string, unknown>,
  key: string,
  path: string,
): boolean | undefined {
  if (source[key] === undefined) return undefined;
  return readBoolean(source, key, path);
}

function readNumber(
  source: Record<string, unknown>,
  key: string,
  path: string,
  min: number,
  max: number,
  integer: boolean,
): number {
  const value = source[key];
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new ConfigError(`${path}.${key} must be a finite number`);
  }
  if (integer && !Number.isInteger(value)) throw new ConfigError(`${path}.${key} must be an integer`);
  if (value < min || value > max) {
    throw new ConfigError(`${path}.${key} must be between ${min} and ${max}`);
  }
  return value;
}

function readOptionalNumber(
  source: Record<string, unknown>,
  key: string,
  path: string,
  min: number,
  max: number,
  integer: boolean,
): number | undefined {
  if (source[key] === undefined) return undefined;
  return readNumber(source, key, path, min, max, integer);
}

function readEnum<T extends string>(
  source: Record<string, unknown>,
  key: string,
  path: string,
  allowed: readonly T[],
): T {
  const value = source[key];
  if (typeof value !== 'string' || !allowed.includes(value as T)) {
    throw new ConfigError(`${path}.${key} must be one of ${allowed.join(', ')}`);
  }
  return value as T;
}
