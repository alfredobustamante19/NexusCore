import { pathToFileURL } from 'node:url';
import { loadConfig, loadRoutes } from './config.js';
import { buildServer } from './server.js';

export async function main(): Promise<void> {
  const configPath = process.env.NEXUS_CONFIG ?? 'config.json';
  const routesPath = process.env.NEXUS_ROUTES ?? 'routes.json';
  const config = await loadConfig(configPath);
  if (process.env.NEXUS_HOST) config.server.host = process.env.NEXUS_HOST;
  if (process.env.NEXUS_PORT) {
    const port = Number(process.env.NEXUS_PORT);
    if (!Number.isInteger(port) || port < 0 || port > 65_535) {
      throw new Error('NEXUS_PORT must be an integer from 0 to 65535');
    }
    config.server.port = port;
  }
  const routes = await loadRoutes(routesPath, config);
  const app = await buildServer({
    config,
    routes,
    paths: { config: configPath, routes: routesPath },
  });

  const shutdown = async (signal: string): Promise<void> => {
    app.log.info({ signal }, 'shutting down');
    const timer = setTimeout(() => process.exit(1), 10_000);
    timer.unref();
    await app.close();
    clearTimeout(timer);
  };
  process.once('SIGINT', () => {
    void shutdown('SIGINT');
  });
  process.once('SIGTERM', () => {
    void shutdown('SIGTERM');
  });

  await app.listen({ host: config.server.host, port: config.server.port });
  app.log.info(
    {
      host: config.server.host,
      port: config.server.port,
      routes: routes.length,
      metrics: config.metrics.enabled ? config.metrics.path : null,
    },
    'nexuscircuit listening',
  );
}

const entry = process.argv[1];
if (entry && import.meta.url === pathToFileURL(entry).href) {
  main().catch((error: unknown) => {
    const message = error instanceof Error ? (error.stack ?? error.message) : String(error);
    process.stderr.write(`${message}\n`);
    process.exit(1);
  });
}
