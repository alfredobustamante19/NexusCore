import { SERVICE_NAME } from '../constants.js';

export function renderDashboard(dataUrl: string): string {
  const boot = JSON.stringify({ dataUrl, service: SERVICE_NAME }).replace(/</g, '\\u003c');
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title>${SERVICE_NAME}</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #0e1214;
      --panel: #171c1f;
      --line: #2a3338;
      --text: #e7eeea;
      --muted: #93a199;
      --cyan: #7ddec8;
      --closed: #3ecf8e;
      --open: #ff6b6b;
      --half: #f0c14a;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font: 14px/1.45 "Segoe UI", "Helvetica Neue", sans-serif;
      background: var(--bg);
      color: var(--text);
    }
    header, main { width: min(1180px, calc(100% - 32px)); margin: 0 auto; }
    header { padding: 28px 0 8px; display: flex; justify-content: space-between; gap: 16px; align-items: end; }
    h1 { margin: 0; font-size: 22px; letter-spacing: 0.02em; }
    h1 span { color: var(--cyan); font-weight: 650; }
    p.sub { margin: 6px 0 0; color: var(--muted); }
    .controls { display: flex; gap: 12px; align-items: center; color: var(--muted); }
    button, label { font: inherit; }
    button {
      background: var(--panel);
      color: var(--text);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 8px 12px;
      cursor: pointer;
    }
    button:hover { border-color: var(--cyan); }
    .cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 18px 0; }
    .card { background: var(--panel); border: 1px solid var(--line); border-radius: 12px; padding: 14px 16px; }
    .card .k { color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: 0.06em; }
    .card .v { margin-top: 6px; font-size: 22px; font-variant-numeric: tabular-nums; }
    .banner { display: none; margin: 12px 0; padding: 10px 12px; border-radius: 8px; background: #3a2020; color: #ffd0d0; }
    .wrap { overflow-x: auto; border: 1px solid var(--line); border-radius: 12px; background: var(--panel); }
    table { width: 100%; border-collapse: collapse; min-width: 860px; }
    th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--line); vertical-align: middle; }
    th { color: var(--muted); font-size: 12px; font-weight: 650; letter-spacing: 0.04em; text-transform: uppercase; }
    tr:last-child td { border-bottom: 0; }
    .pill { display: inline-block; min-width: 88px; text-align: center; border-radius: 999px; padding: 3px 8px; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; }
    .pill.closed { color: #062216; background: var(--closed); }
    .pill.open { color: #2a0909; background: var(--open); }
    .pill.half { color: #2c2204; background: var(--half); }
    .bar { height: 8px; width: 88px; border-radius: 99px; background: #2c353a; overflow: hidden; display: inline-block; vertical-align: middle; margin-right: 8px; }
    .bar > span { display: block; height: 100%; background: var(--open); }
    .num { font-variant-numeric: tabular-nums; }
    .target { color: var(--muted); font-size: 12px; }
    footer { color: var(--muted); padding: 14px 0 28px; font-size: 12px; }
    @media (max-width: 800px) {
      header { flex-direction: column; align-items: start; }
      .cards { grid-template-columns: 1fr 1fr; }
      header, main { width: min(1180px, calc(100% - 20px)); }
    }
  </style>
</head>
<body>
  <header>
    <div>
      <h1><span>${SERVICE_NAME}</span> gateway</h1>
      <p class="sub" id="subtitle">Loading metrics…</p>
    </div>
    <div class="controls">
      <label><input id="auto" type="checkbox" checked> Auto-refresh</label>
      <button id="refresh" type="button">Refresh</button>
    </div>
  </header>
  <main>
    <div class="banner" id="banner"></div>
    <section class="cards" id="cards"></section>
    <div class="wrap">
      <table>
        <thead>
          <tr>
            <th>Route</th>
            <th>State</th>
            <th>Requests</th>
            <th>Failure rate</th>
            <th>p50</th>
            <th>p95</th>
            <th>p99</th>
            <th>Shed</th>
            <th>Retries</th>
          </tr>
        </thead>
        <tbody id="routes"></tbody>
      </table>
    </div>
    <footer id="foot"></footer>
  </main>
  <script>
    const BOOT = ${boot};
    const banner = document.getElementById('banner');
    const auto = document.getElementById('auto');
    let timer = 0;

    function el(tag, className, text) {
      const node = document.createElement(tag);
      if (className) node.className = className;
      if (text !== undefined) node.textContent = text;
      return node;
    }

    function ms(value) {
      const n = Number(value) || 0;
      return (n >= 10 ? n.toFixed(1) : n.toFixed(2)) + ' ms';
    }

    function pct(value) {
      return ((Number(value) || 0) * 100).toFixed(2) + '%';
    }

    function pill(state, cooldown) {
      const cls = state === 'OPEN' ? 'open' : state === 'HALF_OPEN' ? 'half' : 'closed';
      const label = state === 'HALF_OPEN' ? 'HALF-OPEN' : state;
      const node = el('span', 'pill ' + cls, label);
      if (state === 'OPEN' && cooldown === 0) node.textContent = 'OPEN · PROBE';
      return node;
    }

    function card(label, value) {
      const node = el('article', 'card');
      node.append(el('div', 'k', label), el('div', 'v', value));
      return node;
    }

    function showError(error) {
      banner.style.display = 'block';
      banner.textContent = error instanceof Error ? error.message : String(error);
    }

    function render(data) {
      banner.style.display = 'none';
      const open = data.routes.filter((row) => row.state === 'OPEN').length;
      document.getElementById('subtitle').textContent =
        data.service + ' ' + data.version + ' · ' + data.routes.length + ' routes · ' +
        data.uptimeSec.toFixed(0) + 's uptime';
      const cards = document.getElementById('cards');
      cards.replaceChildren(
        card('In flight', String(data.inFlight)),
        card('Requests', String(data.totals.requests)),
        card('Failure rate', pct(data.totals.failureRate)),
        card('Open circuits', String(open))
      );
      const body = document.getElementById('routes');
      body.replaceChildren();
      for (const row of data.routes) {
        const tr = document.createElement('tr');
        const name = document.createElement('td');
        name.append(el('div', '', row.id), el('div', 'target', row.prefix + ' → ' + row.target));
        const failure = document.createElement('td');
        const bar = el('span', 'bar');
        const fill = document.createElement('span');
        fill.style.width = Math.max(0, Math.min(100, row.failureRate * 100)) + '%';
        bar.append(fill);
        failure.append(bar, el('span', 'num', pct(row.failureRate)));
        tr.append(
          name,
          tdNode(pill(row.state, row.cooldownRemainingMs)),
          td(String(row.requests)),
          failure,
          td(ms(row.latency.p50Ms)),
          td(ms(row.latency.p95Ms)),
          td(ms(row.latency.p99Ms)),
          td(String(row.shortCircuits)),
          td(String(row.retries))
        );
        body.append(tr);
      }
      if (data.routes.length === 0) {
        const tr = document.createElement('tr');
        const tdEmpty = document.createElement('td');
        tdEmpty.colSpan = 9;
        tdEmpty.textContent = 'No routes configured';
        tr.append(tdEmpty);
        body.append(tr);
      }
      const mem = (data.memory.heapUsedBytes / 1048576).toFixed(1);
      document.getElementById('foot').textContent =
        'Heap ' + mem + ' MB · unmatched ' + data.totals.unmatched +
        ' · rate limited ' + data.totals.rateLimited +
        ' · cache hits ' + data.totals.cacheHits +
        ' · percentiles use the latest samples, averages are since boot';
    }

    function td(text) {
      return el('td', 'num', text);
    }

    function tdNode(node) {
      const cell = document.createElement('td');
      cell.append(node);
      return cell;
    }

    async function refresh() {
      const response = await fetch(BOOT.dataUrl, {
        cache: 'no-store',
        headers: { accept: 'application/json' }
      });
      if (!response.ok) throw new Error('Metrics request failed with HTTP ' + response.status);
      render(await response.json());
    }

    function arm() {
      if (timer) clearInterval(timer);
      timer = 0;
      if (auto.checked) timer = setInterval(() => { refresh().catch(showError); }, 1000);
    }

    document.getElementById('refresh').addEventListener('click', () => { refresh().catch(showError); });
    auto.addEventListener('change', arm);
    refresh().then(arm).catch(showError);
  </script>
</body>
</html>`;
}
