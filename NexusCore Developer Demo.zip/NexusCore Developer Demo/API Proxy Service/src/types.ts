import type { HttpMethod } from './constants.js';

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export type KeyBy = 'ip' | 'apiKey' | 'ipOrApiKey';

export type LogLevel = 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace' | 'silent';

export interface RetryPolicy {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  retryOn: number[];
  retryUnsafeMethods: boolean;
}

export interface CircuitPolicy {
  failureThreshold: number;
  successThreshold: number;
  openDurationMs: number;
  halfOpenMaxProbes: number;
}

export interface FallbackPolicy {
  statusCode: number;
  body: Record<string, unknown>;
}

export interface RateLimitPolicy {
  capacity: number;
  refillPerSecond: number;
  keyBy: KeyBy;
}

export interface RouteRule {
  id: string;
  prefix: string;
  target: string;
  methods?: HttpMethod[];
  stripPrefix: boolean;
  timeoutMs: number;
  cacheTtlMs: number;
  retries: RetryPolicy;
  circuit: CircuitPolicy;
  fallback: FallbackPolicy;
  rateLimit?: RateLimitPolicy;
}

export interface ServerConfig {
  host: string;
  port: number;
  bodyLimitBytes: number;
  requestIdHeader: string;
  logLevel: LogLevel;
  trustProxy: boolean;
  keepAliveTimeoutMs: number;
}

export interface RateLimitConfig extends RateLimitPolicy {
  enabled: boolean;
  apiKeyHeader: string;
}

export interface MetricsConfig {
  enabled: boolean;
  path: string;
  sampleSize: number;
}

export interface AdminConfig {
  token: string;
  reloadPath: string;
}

export interface ProxyConfig {
  poolConnections: number;
  keepAliveTimeoutMs: number;
  maxCacheEntries: number;
  maxResponseBytes: number;
}

export interface RouteDefaults {
  stripPrefix: boolean;
  timeoutMs: number;
  cacheTtlMs: number;
  retries: RetryPolicy;
  circuit: CircuitPolicy;
}

export interface AppConfig {
  server: ServerConfig;
  rateLimit: RateLimitConfig;
  metrics: MetricsConfig;
  admin: AdminConfig;
  proxy: ProxyConfig;
  defaults: RouteDefaults;
}
