export interface LimitDecision {
  allowed: boolean;
  limit: number;
  remaining: number;
  retryAfterMs: number;
}

/**
 * In-memory token bucket. Each key starts full. Tokens refill continuously
 * up to `capacity`. Idle keys are evicted once the map exceeds `maxTrackedKeys`,
 * which keeps memory bounded when clients rotate addresses.
 */
export class TokenBucketLimiter {
  private readonly buckets = new Map<string, { tokens: number; updatedAt: number }>();

  constructor(
    private readonly capacity: number,
    private readonly refillPerSecond: number,
    private readonly now: () => number = Date.now,
    private readonly maxTrackedKeys = 65_536,
  ) {
    if (capacity <= 0) throw new Error('capacity must be > 0');
    if (refillPerSecond < 0) throw new Error('refillPerSecond must be >= 0');
    if (maxTrackedKeys < 1) throw new Error('maxTrackedKeys must be >= 1');
  }

  tryRemove(key: string): LimitDecision {
    const now = this.now();
    let bucket = this.buckets.get(key);
    if (!bucket) {
      bucket = { tokens: this.capacity, updatedAt: now };
    } else if (now > bucket.updatedAt) {
      const elapsedSec = (now - bucket.updatedAt) / 1000;
      bucket.tokens = Math.min(this.capacity, bucket.tokens + elapsedSec * this.refillPerSecond);
      bucket.updatedAt = now;
    }

    if (bucket.tokens >= 1) {
      bucket.tokens -= 1;
      this.touch(key, bucket);
      return {
        allowed: true,
        limit: this.capacity,
        remaining: bucket.tokens,
        retryAfterMs: 0,
      };
    }

    const deficit = 1 - bucket.tokens;
    const retryAfterMs =
      this.refillPerSecond === 0 ? -1 : Math.ceil((deficit / this.refillPerSecond) * 1000);
    this.touch(key, bucket);
    return {
      allowed: false,
      limit: this.capacity,
      remaining: bucket.tokens,
      retryAfterMs,
    };
  }

  trackedKeys(): number {
    return this.buckets.size;
  }

  private touch(key: string, bucket: { tokens: number; updatedAt: number }): void {
    this.buckets.delete(key);
    this.buckets.set(key, bucket);
    while (this.buckets.size > this.maxTrackedKeys) {
      const oldest = this.buckets.keys().next().value;
      if (oldest === undefined) break;
      this.buckets.delete(oldest);
    }
  }
}
