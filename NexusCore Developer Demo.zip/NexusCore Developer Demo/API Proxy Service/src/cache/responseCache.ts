export interface CacheEntry {
  statusCode: number;
  contentType: string;
  body: Buffer;
  storedAt: number;
  ttlMs: number;
}

/** Insertion-ordered cache. Reads refresh recency. Expired entries miss. */
export class ResponseCache {
  private readonly entries = new Map<string, CacheEntry>();

  constructor(private maxEntries: number) {
    if (maxEntries < 1) throw new Error('maxEntries must be >= 1');
  }

  get(key: string, now: number): CacheEntry | undefined {
    const entry = this.entries.get(key);
    if (!entry) return undefined;
    if (entry.ttlMs <= 0 || now - entry.storedAt >= entry.ttlMs) {
      this.entries.delete(key);
      return undefined;
    }
    this.entries.delete(key);
    this.entries.set(key, entry);
    return entry;
  }

  set(key: string, entry: CacheEntry): void {
    if (entry.ttlMs <= 0) return;
    this.entries.delete(key);
    this.entries.set(key, entry);
    while (this.entries.size > this.maxEntries) {
      const oldest = this.entries.keys().next().value;
      if (oldest === undefined) break;
      this.entries.delete(oldest);
    }
  }

  resize(maxEntries: number): void {
    if (maxEntries < 1) throw new Error('maxEntries must be >= 1');
    this.maxEntries = maxEntries;
    while (this.entries.size > this.maxEntries) {
      const oldest = this.entries.keys().next().value;
      if (oldest === undefined) break;
      this.entries.delete(oldest);
    }
  }

  get size(): number {
    return this.entries.size;
  }
}
