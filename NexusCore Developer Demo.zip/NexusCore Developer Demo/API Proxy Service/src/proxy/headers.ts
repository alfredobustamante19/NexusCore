import type { IncomingHttpHeaders } from 'node:http';

const HOP_BY_HOP = new Set([
  'connection',
  'keep-alive',
  'proxy-authenticate',
  'proxy-authorization',
  'proxy-connection',
  'te',
  'trailer',
  'trailers',
  'transfer-encoding',
  'upgrade',
  'host',
  'content-length',
]);

function connectionTokens(value: string | string[] | undefined): Set<string> {
  const tokens = new Set<string>();
  const raw = Array.isArray(value) ? value.join(',') : (value ?? '');
  for (const part of raw.split(',')) {
    const name = part.trim().toLowerCase();
    if (name) tokens.add(name);
  }
  return tokens;
}

export function buildForwardHeaders(
  incoming: IncomingHttpHeaders,
  extra: {
    requestId: string;
    requestIdHeader: string;
    clientIp: string;
    host: string;
    proto: string;
    trustProxy: boolean;
    userAgent: string;
  },
): Record<string, string> {
  const listed = connectionTokens(incoming.connection);
  const headers: Record<string, string> = {};
  for (const [key, value] of Object.entries(incoming)) {
    if (value === undefined) continue;
    const lower = key.toLowerCase();
    if (HOP_BY_HOP.has(lower) || listed.has(lower)) continue;
    if (lower.startsWith('x-nexus-')) continue;
    headers[lower] = Array.isArray(value) ? value.join(', ') : value;
  }

  const prior = headers['x-forwarded-for'];
  if (extra.trustProxy && prior) headers['x-forwarded-for'] = `${prior}, ${extra.clientIp}`;
  else headers['x-forwarded-for'] = extra.clientIp;

  headers['x-forwarded-host'] = extra.host;
  headers['x-forwarded-proto'] = extra.proto;
  headers[extra.requestIdHeader.toLowerCase()] = extra.requestId;
  if (!headers['user-agent']) headers['user-agent'] = extra.userAgent;
  return headers;
}

export function sanitizeResponseHeaders(headers: IncomingHttpHeaders): Array<[string, string]> {
  const listed = connectionTokens(headers.connection);
  const out: Array<[string, string]> = [];
  for (const [key, value] of Object.entries(headers)) {
    if (value === undefined) continue;
    const lower = key.toLowerCase();
    if (HOP_BY_HOP.has(lower) || listed.has(lower)) continue;
    if (lower.startsWith('x-nexus-')) continue;
    if (Array.isArray(value)) {
      if (lower === 'set-cookie') {
        for (const cookie of value) out.push([lower, cookie]);
      } else {
        out.push([lower, value.join(', ')]);
      }
      continue;
    }
    out.push([lower, value]);
  }
  return out;
}

export function headerValue(headers: IncomingHttpHeaders, name: string): string | undefined {
  const value = headers[name.toLowerCase()];
  if (Array.isArray(value)) return value[0];
  return value;
}
