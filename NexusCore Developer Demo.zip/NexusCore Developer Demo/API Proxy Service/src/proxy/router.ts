import type { RouteRule } from '../types.js';

export type RouteMatch =
  | { type: 'route'; route: RouteRule }
  | { type: 'method'; allow: string[] }
  | { type: 'none' };

export function prefixMatches(path: string, prefix: string): boolean {
  if (prefix === '/') return path.startsWith('/');
  if (path === prefix) return true;
  const boundary = prefix.endsWith('/') ? prefix : `${prefix}/`;
  return path.startsWith(boundary);
}

export function buildUpstreamUrl(route: RouteRule, path: string, query: string): string {
  const target = route.target.replace(/\/+$/, '');
  let upstreamPath = path;
  if (route.stripPrefix) {
    upstreamPath = path.slice(route.prefix.length);
    if (upstreamPath.length === 0) upstreamPath = '/';
    else if (!upstreamPath.startsWith('/')) upstreamPath = `/${upstreamPath}`;
  }
  return query.length > 0 ? `${target}${upstreamPath}?${query}` : `${target}${upstreamPath}`;
}

export function cacheKey(routeId: string, method: string, path: string, query: string): string {
  return `${routeId}\n${method}\n${path}\n${query}`;
}

export function splitUrl(raw: string): { path: string; query: string } {
  const queryIndex = raw.indexOf('?');
  if (queryIndex === -1) return { path: raw.length > 0 ? raw : '/', query: '' };
  return {
    path: raw.slice(0, queryIndex) || '/',
    query: raw.slice(queryIndex + 1),
  };
}

/** Longest-prefix match. Prefixes are unique, so the first hit is the winner. */
export class RouteTable {
  private routes: RouteRule[];

  constructor(routes: readonly RouteRule[]) {
    this.routes = sortRoutes(routes);
  }

  replace(routes: readonly RouteRule[]): void {
    this.routes = sortRoutes(routes);
  }

  list(): readonly RouteRule[] {
    return this.routes;
  }

  match(method: string, path: string): RouteMatch {
    for (const route of this.routes) {
      if (!prefixMatches(path, route.prefix)) continue;
      if (!route.methods || (route.methods as readonly string[]).includes(method)) {
        return { type: 'route', route };
      }
      return { type: 'method', allow: [...route.methods] };
    }
    return { type: 'none' };
  }
}

function sortRoutes(routes: readonly RouteRule[]): RouteRule[] {
  return [...routes].sort(
    (a, b) => b.prefix.length - a.prefix.length || a.id.localeCompare(b.id),
  );
}
