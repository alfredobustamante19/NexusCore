import { Pool, type Dispatcher } from 'undici';
import type { ProxyConfig } from '../types.js';

export class UpstreamResponseTooLargeError extends Error {
  readonly limit: number;

  constructor(limit: number) {
    super(`upstream response exceeded ${limit} bytes`);
    this.name = 'UpstreamResponseTooLargeError';
    this.limit = limit;
  }
}

export class UpstreamTimeoutError extends Error {
  readonly timeoutMs: number;

  constructor(timeoutMs: number) {
    super(`upstream timed out after ${timeoutMs}ms`);
    this.name = 'UpstreamTimeoutError';
    this.timeoutMs = timeoutMs;
  }
}

export interface UpstreamResult {
  statusCode: number;
  headers: Dispatcher.ResponseData['headers'];
  body: Buffer;
}

interface PoolSettings {
  poolConnections: number;
  keepAliveTimeoutMs: number;
}

/**
 * One keep-alive pool per origin. Pools are created on first use and closed
 * with the server. Per-call header and body timeouts come from the route.
 */
export class UpstreamClient {
  private readonly pools = new Map<string, Pool>();
  private settings: PoolSettings;

  constructor(proxy: ProxyConfig) {
    this.settings = {
      poolConnections: proxy.poolConnections,
      keepAliveTimeoutMs: proxy.keepAliveTimeoutMs,
    };
  }

  async send(
    absoluteUrl: string,
    method: string,
    headers: Record<string, string>,
    body: Buffer | undefined,
    timeoutMs: number,
    maxResponseBytes: number,
  ): Promise<UpstreamResult> {
    const url = new URL(absoluteUrl);
    const origin = `${url.protocol}//${url.host}`;
    const pool = this.poolFor(origin);
    const path = `${url.pathname}${url.search}`;
    const controller = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);

    try {
      const response = await pool.request({
        path,
        method: method as Dispatcher.HttpMethod,
        headers,
        body,
        signal: controller.signal,
        headersTimeout: timeoutMs,
        bodyTimeout: timeoutMs,
      });
      const payload = await readLimited(response.body, maxResponseBytes);
      if (timedOut) throw new UpstreamTimeoutError(timeoutMs);
      return {
        statusCode: response.statusCode,
        headers: response.headers,
        body: payload,
      };
    } catch (error) {
      if (error instanceof UpstreamResponseTooLargeError) throw error;
      if (timedOut || isAbortError(error)) throw new UpstreamTimeoutError(timeoutMs);
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  async close(): Promise<void> {
    const closing = [...this.pools.values()].map((pool) => pool.close());
    this.pools.clear();
    await Promise.all(closing);
  }

  private poolFor(origin: string): Pool {
    const existing = this.pools.get(origin);
    if (existing) return existing;
    const pool = new Pool(origin, {
      connections: this.settings.poolConnections,
      pipelining: 1,
      keepAliveTimeout: this.settings.keepAliveTimeoutMs,
    });
    this.pools.set(origin, pool);
    return pool;
  }
}

function isAbortError(error: unknown): boolean {
  if (typeof error !== 'object' || error === null) return false;
  const name = 'name' in error ? error.name : undefined;
  const code = 'code' in error ? error.code : undefined;
  return name === 'AbortError' || code === 'UND_ERR_ABORTED' || code === 'ABORT_ERR';
}

async function readLimited(body: Dispatcher.ResponseData['body'], max: number): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let total = 0;
  try {
    for await (const chunk of body) {
      const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      total += buffer.length;
      if (total > max) {
        throw new UpstreamResponseTooLargeError(max);
      }
      chunks.push(buffer);
    }
  } catch (error) {
    body.destroy();
    throw error;
  }
  if (chunks.length === 0) return Buffer.alloc(0);
  if (chunks.length === 1) {
    const only = chunks[0];
    return only ?? Buffer.alloc(0);
  }
  return Buffer.concat(chunks);
}
