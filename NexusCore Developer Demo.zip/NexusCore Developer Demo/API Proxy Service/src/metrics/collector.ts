import type { CircuitState } from '../types.js';
import { SERVICE_NAME, VERSION } from '../constants.js';
import { cooldownRemaining, type CircuitSnapshot } from '../circuit/registry.js';

export interface LatencySummary {
  count: number;
  window: number;
  avgMs: number;
  p50Ms: number;
  p95Ms: number;
  p99Ms: number;
  maxMs: number;
}

export interface RouteMetrics {
  id: string;
  prefix: string;
  target: string;
  state: CircuitState;
  consecutiveFailures: number;
  consecutiveSuccesses: number;
  halfOpenInFlight: number;
  totalTrips: number;
  openedAt: number | null;
  cooldownRemainingMs: number;
  requests: number;
  successes: number;
  failures: number;
  shortCircuits: number;
  rateLimited: number;
  retries: number;
  cacheHits: number;
  failureRate: number;
  shedRate: number;
  lastError: string | null;
  lastStatus: number | null;
  latency: LatencySummary;
}

export interface MetricsSnapshot {
  service: typeof SERVICE_NAME;
  version: string;
  uptimeSec: number;
  now: number;
  inFlight: number;
  memory: { rssBytes: number; heapUsedBytes: number };
  totals: {
    requests: number;
    successes: number;
    failures: number;
    shortCircuits: number;
    rateLimited: number;
    retries: number;
    cacheHits: number;
    unmatched: number;
    methodNotAllowed: number;
    failureRate: number;
  };
  routes: RouteMetrics[];
}

interface RouteIdentity {
  id: string;
  prefix: string;
  target: string;
}

interface RouteCounters {
  requests: number;
  successes: number;
  failures: number;
  shortCircuits: number;
  rateLimited: number;
  retries: number;
  cacheHits: number;
  lastError: string | null;
  lastStatus: number | null;
  latency: LatencyWindow;
}

/**
 * Fixed ring of the most recent samples.
 * Percentiles and max use the ring. The average uses every sample since boot.
 */
export class LatencyWindow {
  private readonly samples: Float64Array;
  private pos = 0;
  private seen = 0;
  private sum = 0;
  private count = 0;

  constructor(private readonly capacity: number) {
    this.samples = new Float64Array(capacity);
  }

  record(ms: number): void {
    this.count += 1;
    this.sum += ms;
    this.samples[this.pos] = ms;
    this.pos = (this.pos + 1) % this.capacity;
    if (this.seen < this.capacity) this.seen += 1;
  }

  summary(): LatencySummary {
    if (this.seen === 0) {
      return { count: 0, window: 0, avgMs: 0, p50Ms: 0, p95Ms: 0, p99Ms: 0, maxMs: 0 };
    }
    const copy = Array.from(this.samples.subarray(0, this.seen));
    copy.sort((a, b) => a - b);
    const maxMs = copy[copy.length - 1] ?? 0;
    return {
      count: this.count,
      window: this.seen,
      avgMs: this.sum / this.count,
      p50Ms: percentile(copy, 0.5),
      p95Ms: percentile(copy, 0.95),
      p99Ms: percentile(copy, 0.99),
      maxMs,
    };
  }
}

function percentile(sorted: readonly number[], p: number): number {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.max(0, Math.ceil(p * sorted.length) - 1));
  return sorted[index] ?? 0;
}

function rate(part: number, whole: number): number {
  if (whole <= 0) return 0;
  return part / whole;
}

export class MetricsCollector {
  private readonly routes = new Map<string, RouteCounters>();
  private unmatched = 0;
  private methodNotAllowed = 0;
  private readonly startedAt = Date.now();

  constructor(private readonly sampleSize: number) {}

  recordUnmatched(): void {
    this.unmatched += 1;
  }

  recordMethodNotAllowed(): void {
    this.methodNotAllowed += 1;
  }

  recordRateLimited(routeId: string): void {
    const counters = this.counters(routeId);
    counters.requests += 1;
    counters.rateLimited += 1;
  }

  recordShortCircuit(routeId: string, latencyMs: number): void {
    const counters = this.counters(routeId);
    counters.requests += 1;
    counters.shortCircuits += 1;
    counters.latency.record(latencyMs);
  }

  recordSuccess(routeId: string, latencyMs: number, retries: number, status: number): void {
    const counters = this.counters(routeId);
    counters.requests += 1;
    counters.successes += 1;
    counters.retries += retries;
    counters.lastStatus = status;
    counters.lastError = null;
    counters.latency.record(latencyMs);
  }

  recordFailure(
    routeId: string,
    latencyMs: number,
    retries: number,
    error: string,
    status: number | null,
  ): void {
    const counters = this.counters(routeId);
    counters.requests += 1;
    counters.failures += 1;
    counters.retries += retries;
    counters.lastError = error;
    counters.lastStatus = status;
    counters.latency.record(latencyMs);
  }

  recordCacheHit(routeId: string): void {
    this.counters(routeId).cacheHits += 1;
  }

  snapshot(
    identities: readonly RouteIdentity[],
    circuitOf: (id: string) => CircuitSnapshot | undefined,
    now: number,
    inFlight: number,
  ): MetricsSnapshot {
    const rows: RouteMetrics[] = identities.map((identity) => {
      const counters = this.routes.get(identity.id);
      const circuit = circuitOf(identity.id);
      const requests = counters?.requests ?? 0;
      const successes = counters?.successes ?? 0;
      const failures = counters?.failures ?? 0;
      const shortCircuits = counters?.shortCircuits ?? 0;
      const state: CircuitState = circuit?.state ?? 'CLOSED';
      return {
        id: identity.id,
        prefix: identity.prefix,
        target: identity.target,
        state,
        consecutiveFailures: circuit?.consecutiveFailures ?? 0,
        consecutiveSuccesses: circuit?.consecutiveSuccesses ?? 0,
        halfOpenInFlight: circuit?.halfOpenInFlight ?? 0,
        totalTrips: circuit?.totalTrips ?? 0,
        openedAt: circuit?.openedAt ?? null,
        cooldownRemainingMs: circuit ? cooldownRemaining(circuit, now) : 0,
        requests,
        successes,
        failures,
        shortCircuits,
        rateLimited: counters?.rateLimited ?? 0,
        retries: counters?.retries ?? 0,
        cacheHits: counters?.cacheHits ?? 0,
        failureRate: rate(failures, successes + failures),
        shedRate: rate(shortCircuits, requests),
        lastError: counters?.lastError ?? null,
        lastStatus: counters?.lastStatus ?? null,
        latency: counters?.latency.summary() ?? emptyLatency(),
      };
    });

    const totals = rows.reduce(
      (acc, row) => {
        acc.requests += row.requests;
        acc.successes += row.successes;
        acc.failures += row.failures;
        acc.shortCircuits += row.shortCircuits;
        acc.rateLimited += row.rateLimited;
        acc.retries += row.retries;
        acc.cacheHits += row.cacheHits;
        return acc;
      },
      {
        requests: 0,
        successes: 0,
        failures: 0,
        shortCircuits: 0,
        rateLimited: 0,
        retries: 0,
        cacheHits: 0,
        unmatched: this.unmatched,
        methodNotAllowed: this.methodNotAllowed,
        failureRate: 0,
      },
    );
    totals.failureRate = rate(totals.failures, totals.successes + totals.failures);

    const memory = process.memoryUsage();
    return {
      service: SERVICE_NAME,
      version: VERSION,
      uptimeSec: (Date.now() - this.startedAt) / 1000,
      now,
      inFlight,
      memory: { rssBytes: memory.rss, heapUsedBytes: memory.heapUsed },
      totals,
      routes: rows,
    };
  }

  private counters(routeId: string): RouteCounters {
    let existing = this.routes.get(routeId);
    if (!existing) {
      existing = {
        requests: 0,
        successes: 0,
        failures: 0,
        shortCircuits: 0,
        rateLimited: 0,
        retries: 0,
        cacheHits: 0,
        lastError: null,
        lastStatus: null,
        latency: new LatencyWindow(this.sampleSize),
      };
      this.routes.set(routeId, existing);
    }
    return existing;
  }
}

function emptyLatency(): LatencySummary {
  return { count: 0, window: 0, avgMs: 0, p50Ms: 0, p95Ms: 0, p99Ms: 0, maxMs: 0 };
}
