import { randomUUID } from 'node:crypto';
import Fastify, {
  LogController,
  type FastifyInstance,
  type FastifyReply,
  type FastifyRequest,
} from 'fastify';
import { HEALTH_PATH, SERVICE_NAME, VERSION } from './constants.js';
import { ConfigError, loadConfig, loadRoutes } from './config.js';
import { renderDashboard } from './dashboard/render.js';
import { Gateway, type GatewayOptions } from './gateway.js';
import { splitUrl } from './proxy/router.js';
import type { AppConfig, RouteRule } from './types.js';
import { tokensEqual } from './util/timingSafeEqual.js';

const SAFE_REQUEST_ID = /^[\w.-]{1,128}$/;

export interface BuildServerOptions extends GatewayOptions {
  paths?: { config: string; routes: string };
}

declare module 'fastify' {
  interface FastifyInstance {
    gateway: Gateway;
  }
}

export async function buildServer(options: BuildServerOptions): Promise<FastifyInstance> {
  const { config } = options;
  const requestIdHeader = config.server.requestIdHeader.toLowerCase();
  const app = Fastify({
    logger: config.server.logLevel === 'silent' ? false : { level: config.server.logLevel },
    logController: new LogController({ disableRequestLogging: true }),
    trustProxy: config.server.trustProxy,
    bodyLimit: config.server.bodyLimitBytes,
    keepAliveTimeout: config.server.keepAliveTimeoutMs,
    genReqId: (req) => {
      const incoming = req.headers[requestIdHeader];
      if (typeof incoming === 'string' && SAFE_REQUEST_ID.test(incoming)) return incoming;
      return randomUUID();
    },
    return503OnClosing: true,
  });

  const gateway = new Gateway({
    config,
    routes: options.routes,
    deps: options.deps,
    logger: {
      debug: (obj, msg) => app.log.debug(obj, msg),
      info: (obj, msg) => app.log.info(obj, msg),
      warn: (obj, msg) => app.log.warn(obj, msg),
      error: (obj, msg) => app.log.error(obj, msg),
    },
  });
  app.decorate('gateway', gateway);

  app.removeAllContentTypeParsers();
  app.addContentTypeParser('*', { parseAs: 'buffer' }, (_request, body, done) => {
    done(null, body);
  });

  app.addHook('onRequest', async (req, reply) => {
    reply.header(config.server.requestIdHeader, req.id);
  });
  app.addHook('onClose', async () => {
    await gateway.close();
  });

  app.setErrorHandler((error: unknown, req, reply) => {
    req.log.error({ err: error }, 'request failed');
    if (reply.sent) return;
    const statusCode = readStatusCode(error);
    const status = statusCode >= 400 ? statusCode : 500;
    const message = error instanceof Error ? error.message : 'Gateway error';
    void reply.code(status).send({
      error: status === 413 ? 'payload_too_large' : 'gateway_error',
      message: status >= 500 ? 'Gateway error' : message,
      requestId: req.id,
    });
  });

  app.get(HEALTH_PATH, async () => ({
    status: 'ok',
    service: SERVICE_NAME,
    version: VERSION,
  }));

  const reserved = [HEALTH_PATH];
  if (config.metrics.enabled) {
    reserved.push(config.metrics.path, `${config.metrics.path}/data`);
    app.get(config.metrics.path, async (req, reply) => sendMetrics(req, reply, gateway, config));
    app.get(`${config.metrics.path}/data`, async (_req, reply) => {
      return reply.header('cache-control', 'no-store').send(gateway.metricsSnapshot());
    });
  }

  const runtime = { adminToken: config.admin.token };
  if (config.admin.token.length > 0) {
    reserved.push(config.admin.reloadPath);
    app.post(config.admin.reloadPath, async (req, reply) => {
      const header = req.headers['x-nexus-admin-token'];
      const provided = Array.isArray(header) ? (header[0] ?? '') : (header ?? '');
      if (!tokensEqual(provided, runtime.adminToken)) {
        return reply.code(401).send({
          error: 'unauthorized',
          message: 'Admin token rejected',
          requestId: req.id,
        });
      }
      if (!options.paths) {
        return reply.code(503).send({
          error: 'reload_unconfigured',
          message: 'Config paths were not provided to this process',
          requestId: req.id,
        });
      }
      try {
        const next = await loadConfig(options.paths.config);
        const routes = await loadRoutes(options.paths.routes, next);
        gateway.applyReload(routes, next.rateLimit, next.proxy.maxResponseBytes);
        runtime.adminToken = next.admin.token;
        return { reloaded: true, routes: routes.length };
      } catch (error) {
        const message = error instanceof Error ? error.message : 'reload failed';
        const status = error instanceof ConfigError ? 400 : 500;
        return reply.code(status).send({
          error: 'reload_failed',
          message,
          requestId: req.id,
        });
      }
    });
  }

  app.setNotFoundHandler((req, reply) => {
    const { path } = splitUrl(req.raw.url ?? '/');
    if (reserved.some((item) => path === item || path.startsWith(`${item}/`))) {
      return reply.code(404).send({
        error: 'not_found',
        message: 'Not found',
        path,
        requestId: req.id,
      });
    }
    return gateway.handle(req, reply);
  });

  return app;
}

function readStatusCode(error: unknown): number {
  if (typeof error === 'object' && error !== null && 'statusCode' in error) {
    const statusCode = error.statusCode;
    if (typeof statusCode === 'number' && Number.isInteger(statusCode)) return statusCode;
  }
  return 500;
}

function sendMetrics(
  req: FastifyRequest,
  reply: FastifyReply,
  gateway: Gateway,
  config: AppConfig,
): FastifyReply {
  const accept = req.headers.accept ?? '';
  if (accept.includes('application/json')) {
    return reply.header('cache-control', 'no-store').send(gateway.metricsSnapshot());
  }
  return reply
    .type('text/html; charset=utf-8')
    .header('cache-control', 'no-store')
    .header('x-content-type-options', 'nosniff')
    .header('referrer-policy', 'no-referrer')
    .send(renderDashboard(`${config.metrics.path}/data`));
}

export type { RouteRule };
