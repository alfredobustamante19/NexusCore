# NexusCircuit

NexusCircuit is a file-driven API gateway and circuit breaker. It proxies requests to upstream services, sheds traffic when a target is unhealthy, rate-limits clients with a token bucket, and retries transient upstream failures with equal-jitter exponential backoff. Configuration is JSON on disk. There is no database.

The hot path is Fastify plus a keep-alive `undici` pool per origin. Circuit state, counters, and cached responses live in the process.

## Features

- Longest-prefix routing from `routes.json`, with optional prefix stripping and method allow-lists.
- Circuit breaker per route: `CLOSED`, `OPEN`, and `HALF_OPEN`.
- Cached JSON fallback while a breaker is open, otherwise a configured static JSON body.
- Token-bucket limits, global and per route, keyed by IP, API key, or whichever is present.
- Bounded retries for configured 5xx statuses. Unsafe methods are not retried unless a route opts in. Half-open probes are single-shot.
- `/nexus-metrics` dashboard and `/nexus-metrics/data` JSON for the same counters.
- Optional admin reload so route and limiter changes apply without a restart.

## Request path

```mermaid
flowchart LR
  client[Client] --> match[Route match]
  match --> limit[Token bucket]
  limit --> breaker[Circuit breaker]
  breaker -->|OPEN or probe slot full| fallback[Cache or static JSON]
  breaker -->|CLOSED or HALF_OPEN| upstream[Upstream pool]
  upstream -->|retryable 5xx| backoff[Equal-jitter backoff]
  backoff --> upstream
  upstream --> client
  fallback --> client
```

Failure accounting:

| Outcome | Client receives | Breaker |
| --- | --- | --- |
| HTTP 2xx, 3xx, or 4xx | Upstream status and body | Success. Consecutive failures reset. |
| HTTP 5xx after retries | Upstream status and body | One failure for the whole client request. |
| Timeout, disconnect, or oversize body | Cached GET/HEAD if it is fresh, otherwise the static fallback | One failure. |
| Breaker open, or half-open probe slots full | Cached GET/HEAD if it is fresh, otherwise the static fallback | Unchanged. The upstream is not called. |
| Token bucket empty | `429` | Unchanged. The request is rejected before the breaker. |

A 4xx is a client outcome, not an unhealthy upstream. Retries run before the breaker is updated, so a call that fails twice and then succeeds does not move the breaker.

## Requirements

- Node.js 20 or newer. The release build was exercised on Node.js 24.
- No external services. Upstream URLs in the sample routes are local placeholders.

## Quick start

```bash
npm install
npm test
npm run build
npm start
```

The process listens on `0.0.0.0:8080` and reads `config.json` and `routes.json` from the working directory. Override the files or bind address with `NEXUS_CONFIG`, `NEXUS_ROUTES`, `NEXUS_HOST`, and `NEXUS_PORT`.

```bash
curl -s http://127.0.0.1:8080/nexus-health
curl -s http://127.0.0.1:8080/billing/invoices
```

`/billing/invoices` is forwarded to `http://127.0.0.1:4010/invoices`. Until that process is running, failures accumulate and the billing breaker opens. The dashboard is `http://127.0.0.1:8080/nexus-metrics`.

## Configuration

`config.json` holds process settings and the defaults merged into every route. Unknown JSON fields are rejected.

| Section | Role |
| --- | --- |
| `server` | Bind address, body limit, request id header, log level, `trustProxy`, inbound keep-alive. |
| `rateLimit` | Global token bucket. `keyBy` is `ip`, `apiKey`, or `ipOrApiKey`. |
| `metrics` | Dashboard path and latency sample size. |
| `admin` | Reload token. An empty token disables `POST /nexus-admin/reload`. |
| `proxy` | Upstream pool size, pool keep-alive, cache entry cap, maximum buffered response. |
| `defaults` | `stripPrefix`, timeout, cache TTL, retry policy, and breaker policy inherited by routes. |

`trustProxy`, the listen address, the metrics path, and the admin path are fixed at boot. A reload applies routes, inherited defaults, the global rate limit, and `proxy.maxResponseBytes`. Reload also clears token buckets so a new capacity takes effect immediately. Breaker state is kept when the circuit policy is unchanged.

Leave `admin.token` empty unless you set a token of at least 8 characters and send it in `x-nexus-admin-token`. The comparison is constant-time. Do not expose the reload route or the dashboard on a public interface without a network policy in front of them.

When `trustProxy` is false, the gateway overwrites `x-forwarded-for` with the socket address. When it is true, the incoming list is preserved and the trusted client address is appended.

## Route examples

A route needs `id`, `prefix`, `target`, and `fallback`. Everything else is optional and comes from `defaults`.

```json
{
  "id": "billing",
  "prefix": "/billing",
  "target": "http://127.0.0.1:4010",
  "methods": ["GET", "POST"],
  "stripPrefix": true,
  "timeoutMs": 1500,
  "cacheTtlMs": 0,
  "retries": {
    "maxRetries": 2,
    "baseDelayMs": 20,
    "maxDelayMs": 200,
    "retryOn": [500, 502, 503, 504],
    "retryUnsafeMethods": false
  },
  "circuit": {
    "failureThreshold": 5,
    "successThreshold": 2,
    "openDurationMs": 15000,
    "halfOpenMaxProbes": 1
  },
  "fallback": {
    "statusCode": 503,
    "body": {
      "error": "upstream_unavailable",
      "service": "billing",
      "message": "Billing is temporarily unavailable"
    }
  }
}
```

`GET /billing/invoices?status=open` becomes `GET http://127.0.0.1:4010/invoices?status=open`. Prefixes do not match a longer segment: `/billing` does not match `/billingv2`. The longest matching prefix wins. A prefix match with a disallowed method returns `405` and an `Allow` header.

The shipped `catalog` route omits retry and breaker blocks, so it inherits `defaults`, and it caches successful GET/HEAD responses for 5 seconds. `quotes` tightens the breaker and adds its own bucket:

```json
{
  "id": "quotes",
  "prefix": "/quotes",
  "target": "https://quotes.internal",
  "methods": ["GET"],
  "cacheTtlMs": 10000,
  "circuit": { "failureThreshold": 3, "openDurationMs": 30000 },
  "rateLimit": { "capacity": 20, "refillPerSecond": 5, "keyBy": "apiKey" },
  "fallback": {
    "statusCode": 503,
    "body": { "error": "upstream_unavailable", "service": "quotes" }
  }
}
```

A route bucket is checked after the global bucket. Both must allow the request. The API key is read from `rateLimit.apiKeyHeader` (`x-api-key` in the sample). If the key is absent, the gateway falls back to the client IP so anonymous callers do not share one bucket.

Responses include:

| Header | Meaning |
| --- | --- |
| `x-nexus-route` | Matched route id. |
| `x-nexus-circuit` | Breaker state after the request was classified. |
| `x-nexus-retries` | Retries used for this request. |
| `x-nexus-cache` | `hit` or `miss`. |
| `x-nexus-fallback` | `cache` or `static` when the upstream body was not forwarded. |
| `x-ratelimit-limit` / `x-ratelimit-remaining` | Bucket that governed the request. |
| `retry-after` | Whole seconds until a rejected bucket can accept one token. |

## Circuit breaker tuning

State machine:

1. `CLOSED` forwards traffic. A success clears the consecutive failure count.
2. `failureThreshold` consecutive failed requests move the breaker to `OPEN` and start the cooldown.
3. `OPEN` serves cache or the static fallback and does not call upstream.
4. After `openDurationMs`, the next request moves the breaker to `HALF_OPEN` and becomes a probe.
5. `successThreshold` probe successes return to `CLOSED`. Any probe failure returns to `OPEN` and restarts the cooldown.
6. At most `halfOpenMaxProbes` probes run at once. Extra callers are shed.

Start here for an interactive JSON API:

| Knob | Starting point | Move it when |
| --- | --- | --- |
| `failureThreshold` | 5 | The breaker opens on a single blip. Raise it. The breaker waits too long to shed load. Lower it. |
| `openDurationMs` | 15000 | Probes flap. Raise it. Recovery feels slow. Lower it, and raise `successThreshold` to 2. |
| `successThreshold` | 2 | One lucky probe should not restore full traffic. |
| `halfOpenMaxProbes` | 1 | Keep this at 1 unless a single probe cannot represent the upstream. |
| `timeoutMs` | A little above the upstream's healthy p99 | Timeouts dominate the failure count. Raise it. Hung calls occupy pool slots. Lower it. |

The cooldown should be longer than one client's retry budget. With `maxRetries` 2, `baseDelayMs` 20, and `maxDelayMs` 200, the worst retry wait is well under a second, so a 15 second open interval does not expire mid-request.

`halfOpenMaxProbes` greater than 1 lets that many probes run concurrently. The sample routes use 1 so a dead upstream receives a single check.

## Rate limiting

The bucket starts full at `capacity` and refills continuously at `refillPerSecond`, never above capacity. A request costs one token. Set `refillPerSecond` to the sustained rate and `capacity` to the allowed burst.

Example: `capacity` 200 and `refillPerSecond` 100 allows a burst of 200 and then about 100 requests per second. The map tracks up to 65,536 keys and evicts the least recently used key after that, so this is an in-process edge limiter, not a global quota across machines.

## Retries

`retryOn` lists the 5xx statuses worth another attempt. The delay before retry `n` (starting at 0) is equal-jitter over half to all of `min(maxDelayMs, baseDelayMs * 2^n)`.

`POST` and `PATCH` are not retried unless `retryUnsafeMethods` is true, because a retry can double-apply the operation. `GET`, `HEAD`, `OPTIONS`, `PUT`, and `DELETE` are treated as idempotent. A half-open probe never retries.

Cap `maxRetries` at 2 for user-facing traffic. The breaker, not the retry loop, is what stops a dead upstream from being hammered.

## Cache and fallbacks

`cacheTtlMs` greater than 0 stores successful GET and HEAD responses that are not `private` or `no-store`. The cache is used only when the gateway cannot return an upstream response: the breaker is shedding, or the attempt ended in a timeout, a disconnect, or a body over `proxy.maxResponseBytes`. A live 5xx is forwarded so callers still see the upstream error that tripped the breaker. The next call is the one that is shed.

Cache keys are route, method, path, and query string. The cache is an LRU bounded by `proxy.maxCacheEntries`.

## Dashboard

`GET /nexus-metrics` returns a single-page view of route state, failure rate, shed count, retries, and p50/p95/p99 latency. It polls `GET /nexus-metrics/data` once a second. `Accept: application/json` on `/nexus-metrics` returns the same JSON as `/data`.

Percentiles and the max are computed from the most recent `metrics.sampleSize` latencies (nearest rank). The average is cumulative since boot. Latency is recorded for proxied and shed requests, not for token-bucket rejects. Failure rate is `failures / (successes + failures)` and does not treat shed requests as new upstream failures.

`GET /nexus-health` returns `{"status":"ok"}` for the gateway process itself. It does not check upstreams. Use the metrics snapshot for that.

## Operations

Run one process per core behind a load balancer. Breaker state, buckets, and the cache are not shared across processes. That is intentional: coordination would add a network hop to the hot path. A balancer in front of several independent breakers still sheds load; each process just learns about the outage on its own.

Inbound HTTP is HTTP/1.1 with keep-alive. Upstream calls use one `undici` pool per origin (`proxy.poolConnections`, pipelining 1). Size the pool for the concurrency you actually send at that origin. The gateway buffers an upstream body up to `proxy.maxResponseBytes` before responding, which is what makes retries safe: a retry never starts after bytes have been sent to the client.

`SIGINT` and `SIGTERM` stop accepting connections and close pools. The process exits if shutdown takes longer than 10 seconds.

Reload:

```bash
curl -s -X POST http://127.0.0.1:8080/nexus-admin/reload \
  -H "x-nexus-admin-token: $NEXUS_ADMIN_TOKEN"
```

## Benchmark

`npm run bench` compiles nothing by itself. Run `npm run build` first. The script measures the compiled `dist/` server on loopback against a trivial upstream that returns `{"ok":true}`. Rate limiting, retries, and caching are off so the numbers describe proxy overhead rather than policy work.

The table below is the run captured in `bench/last-run.json` on the release host. Repeat the script before using the numbers for capacity planning. A remote upstream will dominate the added hop.

<!-- BENCH:START -->
Measured at 2026-10-07T19:00:38Z on the release host:

| | |
| --- | --- |
| Node.js | v24.16.0 |
| OS | Windows 10.0.26200 |
| CPU | Intel Core i5-10400F @ 2.90GHz, 12 threads |
| Memory | 16 GB |
| Build | compiled `dist/` |
| Payload | `{"ok":true}` |
| Window | 1 s warmup, then 4 s measured |
| Transport | HTTP/1.1 keep-alive on 127.0.0.1 |

| Path | Concurrency | Requests | RPS | p50 | p95 | p99 | Errors |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Direct upstream | 64 | 21,632 | 5,401 | 10.78 ms | 18.26 ms | 28.91 ms | 0 |
| NexusCircuit | 64 | 12,000 | 2,993 | 19.93 ms | 28.99 ms | 39.63 ms | 0 |
| NexusCircuit | 200 | 12,077 | 2,993 | 64.33 ms | 75.71 ms | 133.80 ms | 0 |

At concurrency 64 the gateway added 9.15 ms to the direct p50. Raising concurrency from 64 to 200 did not increase throughput on this host; the same ~3,000 requests/second showed up as queueing delay. Size `proxy.poolConnections` and the in-flight concurrency to the plateau rather than past it.
<!-- BENCH:END -->

How to read them: compare the direct row with the gateway row at the same concurrency. The difference is the cost of the extra hop, header filtering, and the breaker check on this machine. p99 on loopback moves around more than p50.

## Tests

```bash
npm test
```

The suite covers breaker transitions (`CLOSED` to `OPEN` to `HALF_OPEN` and back, including a failed probe), equal-jitter delays, token-bucket refill and key isolation, route matching, and an in-process mock upstream. Integration tests use Fastify's inject API against that mock, so they do not bind a public port. Gateway tests share one file and run serially.

## Project layout

```text
src/            gateway, breaker, limiter, proxy, dashboard
tests/          unit tests and mock-upstream integration tests
bench/          loopback benchmark
config.json     process settings and route defaults
routes.json     sample routes
dist/           tsc output after npm run build
```

## License

MIT. See [LICENSE](LICENSE).
