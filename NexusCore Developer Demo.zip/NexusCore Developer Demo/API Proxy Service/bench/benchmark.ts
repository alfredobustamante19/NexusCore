import { createServer } from 'node:http';
import { writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { fileURLToPath } from 'node:url';
import { buildServer } from '../dist/server.js';

interface PhaseResult {
  name: string;
  concurrency: number;
  requests: number;
  errors: number;
  elapsedSec: number;
  rps: number;
  p50Ms: number;
  p95Ms: number;
  p99Ms: number;
  maxMs: number;
}

const durationMs = 4_000;
const warmupMs = 1_000;

async function main(): Promise<void> {
  const upstream = createServer((_req, res) => {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    res.end('{"ok":true}');
  });
  upstream.keepAliveTimeout = 60_000;
  await listen(upstream);
  const upstreamAddress = upstream.address();
  if (!upstreamAddress || typeof upstreamAddress === 'string') {
    throw new Error('upstream did not bind');
  }
  const directUrl = `http://127.0.0.1:${upstreamAddress.port}/ping`;

  const app = await buildServer({
    config: benchConfig(),
    routes: [{
      id: 'bench',
      prefix: '/api',
      target: `http://127.0.0.1:${upstreamAddress.port}`,
      stripPrefix: true,
      timeoutMs: 5_000,
      cacheTtlMs: 0,
      retries: {
        maxRetries: 0,
        baseDelayMs: 1,
        maxDelayMs: 1,
        retryOn: [500, 502, 503, 504],
        retryUnsafeMethods: false,
      },
      circuit: {
        failureThreshold: 100_000,
        successThreshold: 1,
        openDurationMs: 1_000,
        halfOpenMaxProbes: 1,
      },
      fallback: {
        statusCode: 503,
        body: { error: 'upstream_unavailable', service: 'bench' },
      },
    }],
  });

  try {
    await app.listen({ host: '127.0.0.1', port: 0 });
    const gatewayAddress = app.server.address();
    if (!gatewayAddress || typeof gatewayAddress === 'string') throw new Error('gateway did not bind');
    const gatewayUrl = `http://127.0.0.1:${gatewayAddress.port}/api/ping`;

    await measure(directUrl, 32, warmupMs);
    await measure(gatewayUrl, 32, warmupMs);

    const phases = [
      await measure(directUrl, 64, durationMs, 'direct upstream'),
      await measure(gatewayUrl, 64, durationMs, 'gateway'),
      await measure(gatewayUrl, 200, durationMs, 'gateway'),
    ];

    const cpu = os.cpus()[0];
    const report = {
      measuredAt: new Date().toISOString(),
      runtime: {
        node: process.version,
        platform: `${os.platform()} ${os.release()}`,
        cpu: cpu?.model ?? 'unknown',
        cores: os.cpus().length,
        memoryBytes: os.totalmem(),
      },
      method: {
        payload: '{"ok":true}',
        warmupMs,
        durationMs,
        transport: 'HTTP/1.1 keep-alive on 127.0.0.1',
        gatewayBuild: 'dist/',
        notes: 'Loopback isolates proxy overhead. A remote upstream hop will dominate these numbers.',
      },
      phases,
    };

    const lines = [
      `NexusCircuit benchmark  ${report.runtime.node}  ${report.runtime.platform}`,
      `CPU ${report.runtime.cpu} x${report.runtime.cores}`,
      '',
      pad('path', 20) + pad('conc', 8) + pad('rps', 12) + pad('p50', 10) + pad('p95', 10) + pad('p99', 10) + pad('errors', 8),
    ];
    for (const phase of phases) {
      lines.push(
        pad(phase.name, 20)
        + pad(String(phase.concurrency), 8)
        + pad(phase.rps.toFixed(0), 12)
        + pad(phase.p50Ms.toFixed(2), 10)
        + pad(phase.p95Ms.toFixed(2), 10)
        + pad(phase.p99Ms.toFixed(2), 10)
        + pad(String(phase.errors), 8),
      );
    }
    const direct = phases[0];
    const via = phases[1];
    if (direct && via) {
      lines.push('');
      lines.push(`Added p50 at concurrency 64: ${(via.p50Ms - direct.p50Ms).toFixed(2)} ms`);
    }
    const text = lines.join('\n');
    process.stdout.write(`${text}\n`);

    const out = path.join(path.dirname(fileURLToPath(import.meta.url)), 'last-run.json');
    await writeFile(out, `${JSON.stringify(report, null, 2)}\n`, 'utf8');

    const failed = phases.some((phase) => phase.errors > 0 || phase.requests === 0);
    if (failed) process.exitCode = 1;
  } finally {
    await app.close();
    await new Promise<void>((resolve, reject) => {
      upstream.close((error) => (error ? reject(error) : resolve()));
    });
  }
}

function benchConfig() {
  return {
    server: {
      host: '127.0.0.1',
      port: 0,
      bodyLimitBytes: 1_048_576,
      requestIdHeader: 'x-request-id',
      logLevel: 'silent' as const,
      trustProxy: false,
      keepAliveTimeoutMs: 72_000,
    },
    rateLimit: {
      enabled: false,
      capacity: 1_000_000,
      refillPerSecond: 1_000_000,
      keyBy: 'ip' as const,
      apiKeyHeader: 'x-api-key',
    },
    metrics: { enabled: true, path: '/nexus-metrics', sampleSize: 512 },
    admin: { token: '', reloadPath: '/nexus-admin/reload' },
    proxy: {
      poolConnections: 256,
      keepAliveTimeoutMs: 30_000,
      maxCacheEntries: 100,
      maxResponseBytes: 1_048_576,
    },
    defaults: {
      stripPrefix: true,
      timeoutMs: 5_000,
      cacheTtlMs: 0,
      retries: {
        maxRetries: 0,
        baseDelayMs: 1,
        maxDelayMs: 1,
        retryOn: [500, 502, 503, 504],
        retryUnsafeMethods: false,
      },
      circuit: {
        failureThreshold: 100_000,
        successThreshold: 1,
        openDurationMs: 1_000,
        halfOpenMaxProbes: 1,
      },
    },
  };
}

async function measure(
  url: string,
  concurrency: number,
  windowMs: number,
  name?: string,
): Promise<PhaseResult> {
  const latencies: number[] = [];
  let errors = 0;
  const started = performance.now();
  const deadline = started + windowMs;
  await Promise.all(Array.from({ length: concurrency }, async () => {
    while (performance.now() < deadline) {
      const t0 = performance.now();
      try {
        const response = await fetch(url);
        await response.arrayBuffer();
        if (response.status !== 200) errors += 1;
      } catch {
        errors += 1;
      }
      latencies.push(performance.now() - t0);
    }
  }));
  const elapsedSec = (performance.now() - started) / 1000;
  const sorted = [...latencies].sort((a, b) => a - b);
  return {
    name: name ?? url,
    concurrency,
    requests: latencies.length,
    errors,
    elapsedSec,
    rps: elapsedSec > 0 ? latencies.length / elapsedSec : 0,
    p50Ms: percentile(sorted, 0.5),
    p95Ms: percentile(sorted, 0.95),
    p99Ms: percentile(sorted, 0.99),
    maxMs: sorted[sorted.length - 1] ?? 0,
  };
}

function percentile(sorted: readonly number[], p: number): number {
  if (sorted.length === 0) return 0;
  const index = Math.min(sorted.length - 1, Math.max(0, Math.ceil(p * sorted.length) - 1));
  return sorted[index] ?? 0;
}

function pad(value: string, width: number): string {
  return value.length >= width ? `${value} ` : value + ' '.repeat(width - value.length);
}

function listen(server: ReturnType<typeof createServer>): Promise<void> {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => resolve());
  });
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? (error.stack ?? error.message) : String(error);
  process.stderr.write(`${message}\n`);
  process.exit(1);
});
