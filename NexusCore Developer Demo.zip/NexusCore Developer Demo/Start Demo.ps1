$ErrorActionPreference = "Stop"
$here = $PSScriptRoot
if (Test-Path (Join-Path $here "demo\run_demo.py")) {
    Set-Location $here
    $script = Join-Path $here "demo\run_demo.py"
} else {
    Set-Location (Split-Path -Parent $here)
    $script = Join-Path $here "run_demo.py"
}
if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 $script
    exit $LASTEXITCODE
}
if (Get-Command python -ErrorAction SilentlyContinue) {
    & python $script
    exit $LASTEXITCODE
}
Write-Error "Install Python 3.12 or newer, then run this script again."
exit 1
