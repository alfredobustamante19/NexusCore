"""Bootstrap, sessions, cookies, and the login limiter."""

from tests.conftest import ADMIN_EMAIL, ADMIN_PASSWORD, bearer, register


def test_bootstrap_register_and_me(client):
    open_status = client.get("/api/auth/bootstrap")
    assert open_status.json() == {"bootstrap_open": True}

    body = register(client)
    assert body["token_type"] == "bearer"
    assert body["user"]["role"] == "admin"
    assert body["user"]["email"] == ADMIN_EMAIL
    assert "hashed_password" not in client.get("/api/auth/me", headers=bearer(body["access_token"])).text

    me = client.get("/api/auth/me", headers=bearer(body["access_token"]))
    assert me.status_code == 200
    assert me.json()["id"] == body["user"]["id"]

    closed = client.post(
        "/api/auth/register",
        json={"email": "second@example.com", "password": ADMIN_PASSWORD},
    )
    assert closed.status_code == 403
    assert client.get("/api/auth/bootstrap").json()["bootstrap_open"] is False


def test_login_cookie_and_logout(client):
    register(client)
    client.cookies.clear()
    logged_in = client.post("/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert logged_in.status_code == 200
    assert client.cookies.get("access_token")
    page = client.get("/app")
    assert page.status_code == 200
    assert "Overview" in page.text

    logged_out = client.post(
        "/api/auth/logout",
        headers={"X-CSRF-Token": client.cookies.get("csrf_token")},
    )
    assert logged_out.status_code == 204
    assert client.get("/app", follow_redirects=False).headers["location"].endswith("/login")


def test_login_rejects_unknown_and_inactive_accounts(client):
    token = register(client)["access_token"]
    created = client.post(
        "/api/users",
        headers=bearer(token),
        json={"email": "bea@example.com", "password": "another-secret", "role": "user", "is_active": False},
    )
    assert created.status_code == 201
    client.cookies.clear()
    denied = client.post("/api/auth/login", json={"email": "bea@example.com", "password": "another-secret"})
    assert denied.status_code == 403
    missing = client.post("/api/auth/login", json={"email": "nobody@example.com", "password": "another-secret"})
    assert missing.status_code == 401


def test_login_rate_limit(client):
    register(client)
    client.cookies.clear()
    for _ in range(3):
        failed = client.post("/api/auth/login", json={"email": ADMIN_EMAIL, "password": "wrong-password"})
        assert failed.status_code == 401
    blocked = client.post("/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert blocked.status_code == 429


def test_cookie_writes_require_csrf_and_bearer_does_not(client):
    registered = register(client)
    payload = {"name": "Northwind", "status": "lead", "value": 12.5}
    denied = client.post("/api/customers", json=payload)
    assert denied.status_code == 403

    allowed = client.post(
        "/api/customers",
        json=payload,
        headers={"X-CSRF-Token": client.cookies.get("csrf_token")},
    )
    assert allowed.status_code == 201

    via_bearer = client.post(
        "/api/customers",
        json={"name": "Southwind", "status": "active", "value": 3},
        headers=bearer(registered["access_token"]),
    )
    assert via_bearer.status_code == 201
    assert "hashed_password" not in via_bearer.text


def test_anonymous_pages_redirect_and_health(client):
    redirected = client.get("/app", follow_redirects=False)
    assert redirected.status_code == 303
    assert redirected.headers["location"].endswith("/login")
    login = client.get("/login")
    assert login.status_code == 200
    assert "Sign in" in login.text
    assert "Content-Security-Policy" in login.headers
    health = client.get("/api/health")
    assert health.status_code == 200
    assert health.json() == {"status": "ok"}
    missing = client.get("/api/does-not-exist")
    assert missing.status_code == 404
    assert missing.json()["detail"] == "Not Found"


def test_change_password(client):
    token = register(client)["access_token"]
    changed = client.post(
        "/api/auth/change-password",
        headers=bearer(token),
        json={"current_password": ADMIN_PASSWORD, "new_password": "a-newer-secret"},
    )
    assert changed.status_code == 204
    client.cookies.clear()
    relogin = client.post("/api/auth/login", json={"email": ADMIN_EMAIL, "password": "a-newer-secret"})
    assert relogin.status_code == 200
