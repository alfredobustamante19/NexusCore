"""RBAC, customer CRUD, settings, and the audit trail."""

from tests.conftest import ADMIN_EMAIL, bearer, register


def _user(client, token, role="user", email="bea@example.com"):
    response = client.post(
        "/api/users",
        headers=bearer(token),
        json={"email": email, "password": "bea-password-1", "role": role},
    )
    assert response.status_code == 201, response.text
    return response.json()


def test_user_cannot_change_roles_settings_or_audit(client):
    admin_token = register(client)["access_token"]
    member = _user(client, admin_token)
    client.cookies.clear()
    logged_in = client.post("/api/auth/login", json={"email": member["email"], "password": "bea-password-1"})
    token = logged_in.json()["access_token"]
    headers = bearer(token)

    assert client.get("/api/users", headers=headers).status_code == 200
    assert client.post(
        "/api/users",
        headers=headers,
        json={"email": "cy@example.com", "password": "cy-password-1", "role": "admin"},
    ).status_code == 403
    assert client.patch(f"/api/users/{member['id']}", headers=headers, json={"role": "admin"}).status_code == 403
    assert client.get("/api/audit-logs", headers=headers).status_code == 403
    assert client.put(
        "/api/settings",
        headers=headers,
        json={
            "organization_name": "Nope",
            "support_email": "ops@example.com",
            "maintenance_message": "",
        },
    ).status_code == 403

    created = client.post(
        "/api/customers",
        headers=headers,
        json={"name": "Harbor Co", "status": "active", "value": 80},
    )
    assert created.status_code == 201
    record_id = created.json()["id"]
    updated = client.patch(
        f"/api/customers/{record_id}",
        headers=headers,
        json={"status": "paused", "value": 40},
    )
    assert updated.status_code == 200
    assert updated.json()["status"] == "paused"
    assert client.delete(f"/api/customers/{record_id}", headers=headers).status_code == 204


def test_last_admin_is_protected(client):
    admin = register(client)
    headers = bearer(admin["access_token"])
    admin_id = admin["user"]["id"]

    assert client.delete(f"/api/users/{admin_id}", headers=headers).status_code == 409
    demoted = client.patch(f"/api/users/{admin_id}", headers=headers, json={"role": "user"})
    assert demoted.status_code == 409

    second = _user(client, admin["access_token"], role="admin", email="cy@example.com")
    removed = client.delete(f"/api/users/{second['id']}", headers=headers)
    assert removed.status_code == 204
    still_blocked = client.patch(f"/api/users/{admin_id}", headers=headers, json={"is_active": False})
    assert still_blocked.status_code == 409


def test_customer_search_treats_wildcards_as_text(client):
    headers = bearer(register(client)["access_token"])
    for name in ("100% organic", "Other mill"):
        assert client.post(
            "/api/customers",
            headers=headers,
            json={"name": name, "status": "lead", "value": 1},
        ).status_code == 201
    found = client.get("/api/customers", headers=headers, params={"q": "%"})
    assert found.status_code == 200
    names = [item["name"] for item in found.json()["items"]]
    assert names == ["100% organic"]
    invalid = client.post(
        "/api/customers",
        headers=headers,
        json={"name": "Bad", "status": "archived", "value": -1},
    )
    assert invalid.status_code == 422


def test_settings_and_audit_follow_changes(client):
    admin = register(client)
    headers = bearer(admin["access_token"])
    saved = client.put(
        "/api/settings",
        headers=headers,
        json={
            "organization_name": "North Office",
            "support_email": "desk@example.com",
            "maintenance_message": "Counting the drawers",
        },
    )
    assert saved.status_code == 200
    page = client.get("/app")
    assert "Counting the drawers" in page.text
    assert "North Office" in page.text

    logs = client.get("/api/audit-logs", headers=headers, params={"q": "settings.update"})
    assert logs.status_code == 200
    actions = [item["action"] for item in logs.json()["items"]]
    assert "settings.update" in actions
    assert "auth.register" in [item["action"] for item in client.get("/api/audit-logs", headers=headers).json()["items"]]
    assert logs.json()["items"][0]["user_email"] == ADMIN_EMAIL


def test_duplicate_email_and_short_password(client):
    headers = bearer(register(client)["access_token"])
    payload = {"email": "bea@example.com", "password": "bea-password-1", "role": "user"}
    assert client.post("/api/users", headers=headers, json=payload).status_code == 201
    assert client.post("/api/users", headers=headers, json=payload).status_code == 409
    short = client.post(
        "/api/users",
        headers=headers,
        json={"email": "short@example.com", "password": "tiny", "role": "user"},
    )
    assert short.status_code == 422
