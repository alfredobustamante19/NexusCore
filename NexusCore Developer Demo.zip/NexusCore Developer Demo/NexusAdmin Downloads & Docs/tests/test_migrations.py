"""Alembic creates the same tables the application expects."""

from sqlalchemy import inspect
from sqlmodel import Session

from app.config import get_settings
from app.database import get_engine, reset_engine, run_migrations
from app.models import AppSetting, AuditLog, CustomerRecord, User
from app.seed import seed_settings


def test_upgrade_creates_schema(tmp_path, monkeypatch):
    url = "sqlite:///" + (tmp_path / "migrated.db").as_posix()
    monkeypatch.setenv("DATABASE_URL", url)
    get_settings.cache_clear()
    reset_engine()
    try:
        run_migrations()
        names = set(inspect(get_engine()).get_table_names())
        assert {"users", "audit_logs", "customer_records", "app_settings", "alembic_version"} <= names
        with Session(get_engine()) as session:
            seed_settings(session)
            row = session.get(AppSetting, "organization_name")
            assert row is not None
            assert row.value == "Atrium"
            session.add(User(email="ada@example.com", hashed_password="hash", role="admin"))
            session.add(CustomerRecord(name="North", status="lead", value=1))
            session.add(AuditLog(action="auth.login", ip_address="127.0.0.1", detail="ada@example.com"))
            session.commit()
    finally:
        reset_engine()
        get_settings.cache_clear()
