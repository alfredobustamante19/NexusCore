"""Isolated SQLite databases and a fast password hasher for the suite."""

import os

os.environ["SECRET_KEY"] = "test-secret-key-must-be-32chars-min"
os.environ["AUTO_MIGRATE"] = "false"
os.environ["BCRYPT_ROUNDS"] = "4"
os.environ["LOGIN_MAX_FAILURES"] = "3"
os.environ["DATABASE_URL"] = "sqlite:///./data/pytest-placeholder.db"
os.environ["DEMO_MODE"] = "false"
os.environ.setdefault("ALLOW_INSECURE_SECRET", "false")

import pytest
from fastapi.testclient import TestClient

from app.config import get_settings
from app.database import create_all, get_engine, reset_engine
from app.limiter import reset_limiter
from app.main import app

ADMIN_EMAIL = "ada@example.com"
ADMIN_PASSWORD = "correct-horse"


@pytest.fixture(autouse=True)
def _reset_login_limiter():
    reset_limiter()
    yield
    reset_limiter()


def _open_client(tmp_path, *, demo: bool):
    database = "sqlite:///" + (tmp_path / "test.db").as_posix()
    os.environ["DATABASE_URL"] = database
    os.environ["DEMO_MODE"] = "true" if demo else "false"
    get_settings.cache_clear()
    reset_engine()
    create_all()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        reset_engine()
        os.environ["DEMO_MODE"] = "false"
        get_settings.cache_clear()


@pytest.fixture
def client(tmp_path):
    yield from _open_client(tmp_path, demo=False)


@pytest.fixture
def demo_client(tmp_path):
    yield from _open_client(tmp_path, demo=True)


def register(client: TestClient, email: str = ADMIN_EMAIL, password: str = ADMIN_PASSWORD) -> dict:
    response = client.post("/api/auth/register", json={"email": email, "password": password})
    assert response.status_code == 201, response.text
    return response.json()


def bearer(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}
