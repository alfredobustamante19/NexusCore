"""Demo mode blocks writes, keeps sign-in, and renders the sandbox chrome."""

from app.demo import DEMO_EMAIL, DEMO_PASSWORD, demo_payload
from tests.conftest import bearer


def test_production_login_has_no_demo_chrome(client):
    page = client.get("/login")
    assert page.status_code == 200
    assert "1-Click Demo Login" not in page.text
    assert "Live Demo Mode" not in page.text
    assert 'data-demo="false"' in page.text


def test_demo_login_page_offers_guest_access(demo_client):
    page = demo_client.get("/login")
    assert page.status_code == 200
    assert "1-Click Demo Login" in page.text
    assert "Live Demo Mode (Read Only)" in page.text
    assert "https://whop.com/nexuscore" in page.text
    assert DEMO_EMAIL in page.text
    assert DEMO_PASSWORD in page.text
    assert 'data-demo="true"' in page.text


def test_demo_blocks_mutations_and_keeps_login(demo_client):
    assert demo_client.get("/api/health").status_code == 200

    logged_in = demo_client.post("/api/auth/login", json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD})
    assert logged_in.status_code == 200, logged_in.text
    headers = bearer(logged_in.json()["access_token"])

    settings = demo_client.get("/api/settings", headers=headers)
    assert settings.status_code == 200
    assert settings.json()["organization_name"] == "NexusCore"

    records = demo_client.get("/api/customers", headers=headers)
    assert records.status_code == 200
    body = records.json()
    assert {item["name"] for item in body["items"]} >= {
        "Northwind Freight",
        "Harbor & Co.",
        "Lumen Field",
        "Cedar Audit",
    }
    record_id = body["items"][0]["id"]

    created = demo_client.post(
        "/api/customers",
        headers=headers,
        json={"name": "Smuggled", "status": "lead", "value": 1},
    )
    assert created.status_code == 403
    assert created.json() == demo_payload()

    updated = demo_client.patch(
        f"/api/customers/{record_id}",
        headers=headers,
        json={"status": "closed"},
    )
    assert updated.status_code == 403
    assert updated.json() == demo_payload()
    assert demo_client.delete(f"/api/customers/{record_id}", headers=headers).status_code == 403

    user_create = demo_client.post(
        "/api/users",
        headers=headers,
        json={"email": "new@nexuscore.dev", "password": "another-password", "role": "user"},
    )
    assert user_create.status_code == 403
    assert user_create.json()["error"] == "Demo Mode Active"
    assert user_create.json()["buy_url"] == "https://whop.com/nexuscore"

    settings_write = demo_client.put(
        "/api/settings",
        headers=headers,
        json={
            "organization_name": "Taken Over",
            "support_email": "ops@example.com",
            "maintenance_message": "down",
        },
    )
    assert settings_write.status_code == 403
    assert settings_write.json()["message"] == demo_payload()["message"]

    password = demo_client.post(
        "/api/auth/change-password",
        headers=headers,
        json={"current_password": DEMO_PASSWORD, "new_password": "replacement-password"},
    )
    assert password.status_code == 403

    register = demo_client.post(
        "/api/auth/register",
        json={"email": "second@nexuscore.dev", "password": "another-password"},
    )
    assert register.status_code == 403
    assert register.json() == demo_payload()

    logged_out = demo_client.post("/api/auth/logout", headers=headers)
    assert logged_out.status_code == 204

    again = demo_client.post("/api/auth/login", json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD})
    assert again.status_code == 200


def test_demo_settings_page_locks_destructive_controls(demo_client):
    logged_in = demo_client.post("/api/auth/login", json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD})
    assert logged_in.status_code == 200
    page = demo_client.get("/app/settings")
    assert page.status_code == 200
    for label in ("Delete Microservice", "Rotate API Keys", "Purge Logs", "Save settings", "Update password"):
        assert label in page.text
    assert "Disabled in Demo Mode" in page.text
    assert 'data-demo-lock="true"' in page.text
    assert "Demo Mode Active" in page.text
    assert "Get Full License" in page.text

    people = demo_client.get("/app/users")
    assert people.status_code == 200
    assert "New person" in people.text
    assert 'title="Disabled in Demo Mode"' in people.text
