/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/templates/**/*.html", "./app/static/**/*.js"],
  theme: {
    extend: {
      colors: {
        ink: "#1a1714",
        paper: "#f4f0e6",
        panel: "#fffdf8",
        line: "#e6dfd2",
        moss: {
          DEFAULT: "#1c332b",
          deep: "#12211c",
          soft: "#2c4a3e",
        },
        clay: {
          DEFAULT: "#c4562d",
          deep: "#9a3e1c",
        },
        sage: "#e5efe8",
        gold: "#f3d7a1",
      },
      boxShadow: {
        card: "0 1px 2px rgba(28, 25, 21, 0.04), 0 16px 40px rgba(28, 25, 21, 0.06)",
      },
    },
  },
  plugins: [],
};
