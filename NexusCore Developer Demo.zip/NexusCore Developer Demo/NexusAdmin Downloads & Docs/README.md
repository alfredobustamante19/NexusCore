# Atrium

Self-hosted internal admin console. It ships with signed-in screens for an overview, a sample customer-record table, people, an audit log, and organization settings. The API is FastAPI and SQLModel on SQLite. The interface is server-rendered HTML styled with Tailwind and updated in place through the JSON API.

## Directory layout

```text
admin-dashboard/
├── alembic/                  # schema revisions
│   ├── env.py
│   └── versions/0001_initial.py
├── alembic.ini
├── app/
│   ├── main.py               # app, security headers, CSRF, startup
│   ├── config.py             # environment settings
│   ├── database.py           # engine, sessions, Alembic runner
│   ├── models.py             # User, AuditLog, CustomerRecord, AppSetting
│   ├── schemas.py
│   ├── security.py           # passlib bcrypt-sha256 and JWT cookies
│   ├── deps.py               # current user and admin dependencies
│   ├── routers/              # auth, users, customers, audit, settings, pages
│   ├── templates/            # Tailwind admin screens
│   ├── static/app.css        # compiled Tailwind (rebuild from app/styles)
│   └── static/app.js         # in-page create, edit, and delete
├── tests/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

## Configure

Copy the example environment file and set a real signing key before the process will boot:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

| Variable | Purpose |
| --- | --- |
| `SECRET_KEY` | Signs JWTs. Required, at least 32 characters. The placeholder in `.env.example` is rejected. |
| `DATABASE_URL` | SQLAlchemy URL. Default `sqlite:///./data/atrium.db`. |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | Cookie and bearer lifetime. Default `720`. |
| `COOKIE_SECURE` | Set `true` when the site is served over HTTPS. |
| `AUTO_MIGRATE` | Apply `alembic upgrade head` during startup. Default `true`. |
| `BCRYPT_ROUNDS` | Password hashing cost. Use `12` or higher outside tests. |
| `TRUST_PROXY` | Trust `X-Forwarded-For` for audit IPs. Leave `false` unless a reverse proxy you control sets that header. |
| `CORS_ORIGINS` | Comma-separated origins for a separate frontend. Leave empty for the embedded UI. |
| `ALLOW_INSECURE_SECRET` | Local escape hatch only. Keep `false`. |
| `LOGIN_MAX_FAILURES` | Failed sign-ins allowed per IP per window. Default `8`. |
| `LOGIN_WINDOW_SECONDS` | Rate-limit window. Default `900`. |

`SECRET_KEY` is read from the process environment or from a `.env` file in the project directory.

## Run locally

From this directory, with Python 3.12 or newer:

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
# edit SECRET_KEY
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

macOS or Linux:

```bash
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit SECRET_KEY
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 . Startup creates `data/` if needed, applies migrations when `AUTO_MIGRATE=true`, and inserts default settings. Use one worker. The login limiter lives in process memory, and SQLite writes are serialized on this file.

### Migrations

You can apply revisions yourself and skip the startup hook:

```bash
# AUTO_MIGRATE=false in .env
alembic upgrade head
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

After changing `app/models.py`:

```bash
alembic revision --autogenerate -m "describe the change"
alembic upgrade head
```

Review the generated file before running it. SQLite batch mode is already enabled in `alembic/env.py`.

### First account

`POST /api/auth/register` works only while the user table is empty, and that account is an admin. The sign-in screen shows the same form. After that, registration returns 403 and admins add people from **People**.

There is no seeded password. If you lose the last admin, create a replacement from a shell with the tables already migrated. Do not re-open public registration.

## Deploy with Docker

```bash
cp .env.example .env
# set SECRET_KEY, and COOKIE_SECURE=true behind HTTPS
docker compose up --build -d
```

Compose stores the SQLite file in the `atrium-data` volume and overrides `DATABASE_URL` to `sqlite:////data/atrium.db`. The container runs as uid 1000 with a single Uvicorn worker. The image applies migrations on startup.

Publish the app behind your own TLS terminator. Set `COOKIE_SECURE=true` there. Set `TRUST_PROXY=true` only if that proxy overwrites `X-Forwarded-For`.

A bind-mounted data directory must be writable by uid 1000.

## API

Interactive docs are at `/docs` (Swagger UI loads its scripts from a CDN). The admin pages themselves do not.

| Method | Path | Who |
| --- | --- | --- |
| `POST` | `/api/auth/register` | Public, only when no users exist |
| `POST` | `/api/auth/login` | Public |
| `POST` | `/api/auth/logout` | Signed in |
| `GET` | `/api/auth/me` | Signed in |
| `POST` | `/api/auth/change-password` | Signed in |
| `GET` | `/api/auth/bootstrap` | Public setup flag |
| `GET` `/POST` `/PATCH` `/DELETE` | `/api/users` | List: signed in. Writes: admin |
| `GET` `/POST` `/PATCH` `/DELETE` | `/api/customers` | Signed in |
| `GET` | `/api/audit-logs` | Admin |
| `GET` `/PUT` | `/api/settings` | Read: signed in. Write: admin |
| `GET` | `/api/dashboard` | Signed in |
| `GET` | `/api/health` | Public |

Login and register set an HTTP-only `access_token` cookie and also return a bearer token:

```bash
curl -s http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"ada@example.com\",\"password\":\"your-password\"}"
```

```bash
curl http://127.0.0.1:8000/api/customers \
  -H "Authorization: Bearer TOKEN"
```

Browser calls send the cookie. Mutating cookie requests must repeat the readable `csrf_token` cookie in the `X-CSRF-Token` header. Bearer requests skip that check because the browser does not attach the token on its own. Passwords are stored with passlib's `bcrypt_sha256` scheme, so the bcrypt backend is used without truncating long passphrases at 72 bytes.

Roles are `admin` and `user`. Only an admin can change a role, create or delete an account, or edit organization settings. The API refuses to demote, disable, or delete the last active admin, and refuses to delete the account you are signed in with.

Customer records are the sample resource: `id`, `name`, `status` (`lead`, `active`, `paused`, `closed`), and `value`, plus timestamps. Copy `app/routers/customers.py` and `CustomerRecord` when you add a real table, then add a revision.

Audit rows record the action, user, IP, time, and a short detail string. Deleting a person keeps the rows and clears `user_id`.

## Interface

Signed-in routes:

- `/app` overview counts
- `/app/customers` record table
- `/app/users` directory
- `/app/audit` audit table (admins)
- `/app/settings` organization banner and your password

Create, edit, and delete run through `fetch` and redraw the table without a full reload. Search boxes wait a short moment and then reload the current page of results.

## Tests

```bash
python -m pytest
```

The suite uses a temporary SQLite file, four bcrypt rounds, and a short login limit. It does not read a developer `.env` over the variables it sets itself.

## Styles

`app/static/app.css` is the compiled stylesheet the app serves, so a Python-only deploy does not need Node. After changing templates or `app/styles/input.css`:

```bash
npm install
npm run build:css
```

## Security notes

- Generate `SECRET_KEY` and keep it out of git. `.env` is ignored.
- Serve one Uvicorn worker.
- Keep `COOKIE_SECURE=true` on HTTPS.
- The admin pages send a strict content security policy. `/docs` is exempt because Swagger UI is loaded from a CDN.
- Failed sign-ins are limited per process and per client IP. Put the app behind one proxy and set `TRUST_PROXY` if you need the original address in the audit log.
- Account emails are stored in lowercase. Duplicate addresses return 409.
