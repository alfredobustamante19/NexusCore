const $ = (selector, root = document) => root.querySelector(selector);

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

function readCookie(name) {
  const prefix = `${name}=`;
  for (const part of document.cookie.split("; ")) {
    if (part.startsWith(prefix)) return decodeURIComponent(part.slice(prefix.length));
  }
  return "";
}

function detailMessage(detail) {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((item) => String(item.msg || "Invalid input").replace(/^Value error,\s*/i, ""))
      .join(" ");
  }
  return "Request failed";
}

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  const method = (options.method || "GET").toUpperCase();
  if (!["GET", "HEAD"].includes(method)) {
    headers.set("X-CSRF-Token", readCookie("csrf_token"));
  }
  let body;
  if (options.body !== undefined) {
    headers.set("Content-Type", "application/json");
    body = JSON.stringify(options.body);
  }
  const response = await fetch(path, { method, headers, body, credentials: "same-origin" });
  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      throw new ApiError("Unexpected response from the server", response.status);
    }
  }
  if (response.status === 401 && document.body.dataset.page !== "login") {
    window.location.assign("/login");
    throw new ApiError("Not authenticated", 401);
  }
  if (!response.ok) {
    if (data && data.error === "Demo Mode Active") {
      showDemoModal(data);
      throw new ApiError(data.message || "Action disabled in live demo.", response.status);
    }
    throw new ApiError(detailMessage(data && data.detail), response.status);
  }
  return data;
}

function demoActive() {
  return document.body.dataset.demo === "true";
}

function showDemoModal(payload) {
  const dialog = $("#demo-dialog");
  if (!dialog) return;
  const message = $("#demo-dialog-message");
  const buy = $("#demo-dialog-buy");
  if (payload && payload.message && message) message.textContent = payload.message;
  if (payload && payload.buy_url && buy) buy.href = payload.buy_url;
  if (!dialog.open) dialog.showModal();
}

function lockDemoControl(button) {
  if (!demoActive() || !button) return;
  button.dataset.demoLock = "true";
  button.title = "Disabled in Demo Mode";
  button.setAttribute("aria-disabled", "true");
  button.classList.add("demo-locked");
}

function initDemoGuards() {
  if (!demoActive()) return;
  document.addEventListener(
    "click",
    (event) => {
      const locked = event.target.closest("[data-demo-lock]");
      if (!locked || locked.closest("#demo-dialog")) return;
      event.preventDefault();
      event.stopPropagation();
      showDemoModal();
    },
    true,
  );
  document.addEventListener(
    "submit",
    (event) => {
      const form = event.target;
      if (!(form instanceof HTMLFormElement) || !form.querySelector("[data-demo-lock]")) return;
      event.preventDefault();
      event.stopPropagation();
      showDemoModal();
    },
    true,
  );
}

function toast(message, kind = "ok") {
  if (kind === "error" && typeof message === "string" && message.includes("Action disabled in live demo")) {
    showDemoModal({ message });
    return;
  }
  const region = $("#toasts");
  if (!region) return;
  const item = document.createElement("div");
  item.className = kind === "error" ? "toast toast-error" : "toast";
  item.textContent = message;
  region.append(item);
  window.setTimeout(() => item.remove(), 3600);
}

function debounce(fn, wait) {
  let timer = 0;
  return (...args) => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => fn(...args), wait);
  };
}

function formatWhen(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function pill(text, tone) {
  const node = document.createElement("span");
  const tones = {
    admin: "pill pill-admin",
    user: "pill pill-user",
    lead: "pill pill-lead",
    active: "pill pill-active",
    paused: "pill pill-paused",
    closed: "pill pill-closed",
    off: "pill pill-off",
  };
  node.className = tones[tone] || "pill pill-off";
  node.textContent = text;
  return node;
}

function cell(text, className = "") {
  const td = document.createElement("td");
  if (className) td.className = className;
  td.textContent = text;
  return td;
}

function emptyRow(colspan, message) {
  const tr = document.createElement("tr");
  const td = document.createElement("td");
  td.colSpan = colspan;
  td.className = "empty-cell";
  td.textContent = message;
  tr.append(td);
  return tr;
}

function confirmAction(message) {
  const dialog = $("#confirm-dialog");
  const text = $("#confirm-text");
  const yes = $("#confirm-yes");
  const no = $("#confirm-no");
  text.textContent = message;
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      yes.removeEventListener("click", onYes);
      no.removeEventListener("click", onNo);
      dialog.removeEventListener("close", onClose);
      if (dialog.open) dialog.close();
      resolve(value);
    };
    const onYes = () => finish(true);
    const onNo = () => finish(false);
    const onClose = () => finish(false);
    yes.addEventListener("click", onYes);
    no.addEventListener("click", onNo);
    dialog.addEventListener("close", onClose);
    dialog.showModal();
  });
}

function renderPager(container, page, state, load) {
  container.replaceChildren();
  const shown = page.items.length
    ? `${page.offset + 1}–${page.offset + page.items.length} of ${page.total}`
    : "0 results";
  const label = document.createElement("p");
  label.className = "text-sm text-black/50";
  label.textContent = shown;
  const actions = document.createElement("div");
  actions.className = "flex gap-2";
  const previous = document.createElement("button");
  previous.type = "button";
  previous.className = "btn btn-ghost";
  previous.textContent = "Previous";
  previous.disabled = page.offset <= 0;
  previous.addEventListener("click", () => {
    state.offset = Math.max(0, state.offset - state.limit);
    load();
  });
  const next = document.createElement("button");
  next.type = "button";
  next.className = "btn btn-ghost";
  next.textContent = "Next";
  next.disabled = page.offset + page.items.length >= page.total;
  next.addEventListener("click", () => {
    state.offset += state.limit;
    load();
  });
  actions.append(previous, next);
  container.append(label, actions);
}

function initShell() {
  initDemoGuards();
  const sidebar = $("#sidebar");
  const scrim = $("#scrim");
  const menu = $("#menu-button");
  if (sidebar && menu && scrim) {
    const close = () => {
      sidebar.classList.add("-translate-x-full");
      scrim.classList.add("hidden");
    };
    menu.addEventListener("click", () => {
      const closed = sidebar.classList.contains("-translate-x-full");
      sidebar.classList.toggle("-translate-x-full", !closed);
      scrim.classList.toggle("hidden", !closed);
    });
    scrim.addEventListener("click", close);
    sidebar.querySelectorAll("a").forEach((link) => link.addEventListener("click", close));
  }
  $("#logout")?.addEventListener("click", async () => {
    try {
      await api("/api/auth/logout", { method: "POST" });
    } catch (error) {
      if (error.status !== 401) toast(error.message, "error");
    }
    window.location.assign("/login");
  });
  document.addEventListener("click", (event) => {
    const closer = event.target.closest("[data-close]");
    if (closer) closer.closest("dialog")?.close();
  });
}

async function initLogin() {
  const panel = $("#bootstrap-panel");
  try {
    const status = await api("/api/auth/bootstrap");
    if (document.body.dataset.demo !== "true" && status.bootstrap_open) panel.classList.remove("hidden");
  } catch {
    panel.classList.add("hidden");
  }
  const demoLogin = $("#demo-login");
  if (demoLogin) {
    demoLogin.addEventListener("click", () => {
      const form = $("#login-form");
      form.email.value = demoLogin.dataset.email || "";
      form.password.value = demoLogin.dataset.password || "";
      form.requestSubmit();
    });
  }
  $("#login-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const error = $("#login-error");
    error.textContent = "";
    const form = event.currentTarget;
    try {
      await api("/api/auth/login", {
        method: "POST",
        body: { email: form.email.value, password: form.password.value },
      });
      window.location.assign("/app");
    } catch (err) {
      error.textContent = err.message;
    }
  });
  $("#register-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const error = $("#register-error");
    error.textContent = "";
    const form = event.currentTarget;
    try {
      await api("/api/auth/register", {
        method: "POST",
        body: { email: form.email.value, password: form.password.value },
      });
      window.location.assign("/app");
    } catch (err) {
      error.textContent = err.message;
    }
  });
}

async function initDashboard() {
  const data = await api("/api/dashboard");
  $("#metric-users").textContent = String(data.users);
  $("#metric-active").textContent = String(data.active_users);
  $("#metric-admins").textContent = String(data.admins);
  $("#metric-customers").textContent = String(data.customers);
  $("#metric-value").textContent = formatNumber(data.pipeline_value);
  $("#metric-audit").textContent = `${data.audit_events_24h} audit events in the last 24 hours`;

  const breakdown = $("#status-breakdown");
  breakdown.replaceChildren();
  if (!data.customers_by_status.length) {
    const p = document.createElement("p");
    p.className = "text-sm text-black/50";
    p.textContent = "No records yet.";
    breakdown.append(p);
  } else {
    const max = Math.max(...data.customers_by_status.map((item) => item.count), 1);
    for (const item of data.customers_by_status) {
      const row = document.createElement("div");
      const head = document.createElement("div");
      head.className = "mb-1 flex items-center justify-between gap-3 text-sm";
      const label = document.createElement("span");
      label.className = "capitalize";
      label.textContent = item.status;
      const count = document.createElement("span");
      count.className = "text-black/50";
      count.textContent = String(item.count);
      head.append(label, count);
      const meter = document.createElement("meter");
      meter.min = "0";
      meter.max = String(max);
      meter.value = String(item.count);
      meter.setAttribute("aria-label", `${item.status} ${item.count}`);
      row.append(head, meter);
      breakdown.append(row);
    }
  }

  const recent = $("#recent-customers");
  recent.replaceChildren();
  if (!data.recent_customers.length) {
    const p = document.createElement("p");
    p.className = "text-sm text-black/50";
    p.textContent = "Records you add will show up here.";
    recent.append(p);
  } else {
    const list = document.createElement("ul");
    list.className = "divide-y divide-line";
    for (const record of data.recent_customers) {
      const item = document.createElement("li");
      item.className = "flex items-center justify-between gap-3 py-3";
      const name = document.createElement("span");
      name.className = "font-medium";
      name.textContent = record.name;
      const meta = document.createElement("span");
      meta.className = "flex items-center gap-3 text-sm";
      meta.append(pill(record.status, record.status));
      const value = document.createElement("span");
      value.textContent = formatNumber(record.value);
      meta.append(value);
      item.append(name, meta);
      list.append(item);
    }
    recent.append(list);
  }

  const audit = $("#recent-audit");
  audit.replaceChildren();
  if (document.body.dataset.role !== "admin") {
    const p = document.createElement("p");
    p.className = "text-sm text-black/50";
    p.textContent = "Audit details are visible to administrators.";
    audit.append(p);
    return;
  }
  if (!data.recent_audit.length) {
    const p = document.createElement("p");
    p.className = "text-sm text-black/50";
    p.textContent = "No events yet.";
    audit.append(p);
    return;
  }
  const list = document.createElement("ul");
  list.className = "divide-y divide-line";
  for (const entry of data.recent_audit) {
    const item = document.createElement("li");
    item.className = "flex flex-wrap items-baseline justify-between gap-2 py-3";
    const action = document.createElement("span");
    action.className = "font-medium";
    action.textContent = entry.action;
    const when = document.createElement("span");
    when.className = "text-xs text-black/40";
    when.textContent = formatWhen(entry.timestamp);
    item.append(action, when);
    list.append(item);
  }
  audit.append(list);
}

function initCustomers() {
  const state = { offset: 0, limit: 20, q: "", status: "" };
  const tbody = $("#customer-rows");
  const dialog = $("#customer-dialog");
  const form = $("#customer-form");
  const error = $("#customer-error");
  let requestId = 0;

  async function load() {
    const current = ++requestId;
    const params = new URLSearchParams({
      limit: String(state.limit),
      offset: String(state.offset),
      q: state.q,
      status: state.status,
    });
    const page = await api(`/api/customers?${params}`);
    if (current !== requestId) return;
    tbody.replaceChildren();
    if (!page.items.length) {
      tbody.append(emptyRow(5, "No records match this view."));
    }
    for (const record of page.items) {
      const tr = document.createElement("tr");
      tr.append(
        cell(record.name, "font-medium"),
        document.createElement("td"),
        cell(formatNumber(record.value)),
        cell(formatWhen(record.updated_at)),
      );
      tr.children[1].append(pill(record.status, record.status));
      const actions = document.createElement("td");
      actions.className = "text-right";
      const edit = document.createElement("button");
      edit.type = "button";
      edit.className = "btn btn-ghost";
      edit.textContent = "Edit";
      edit.addEventListener("click", () => openDialog(record));
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "btn btn-ghost";
      remove.textContent = "Delete";
      remove.addEventListener("click", () => removeRecord(record));
      lockDemoControl(edit);
      lockDemoControl(remove);
      actions.append(edit, remove);
      tr.append(actions);
      tbody.append(tr);
    }
    renderPager($("#customer-pager"), page, state, () => load().catch((err) => toast(err.message, "error")));
  }

  function openDialog(record) {
    error.textContent = "";
    form.reset();
    $("#customer-dialog-title").textContent = record ? "Edit record" : "New record";
    form.elements.record_id.value = record ? record.id : "";
    if (record) {
      form.elements.name.value = record.name;
      form.elements.status.value = record.status;
      form.elements.value.value = String(record.value);
    }
    dialog.showModal();
  }

  async function removeRecord(record) {
    const ok = await confirmAction(`Delete ${record.name}? This cannot be undone.`);
    if (!ok) return;
    try {
      await api(`/api/customers/${record.id}`, { method: "DELETE" });
      toast("Record deleted");
      await load();
    } catch (err) {
      toast(err.message, "error");
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    error.textContent = "";
    const payload = {
      name: form.elements.name.value,
      status: form.elements.status.value,
      value: Number(form.elements.value.value),
    };
    const id = form.elements.record_id.value;
    const button = form.querySelector("[type=submit]");
    button.disabled = true;
    try {
      if (id) await api(`/api/customers/${id}`, { method: "PATCH", body: payload });
      else await api("/api/customers", { method: "POST", body: payload });
      dialog.close();
      toast("Record saved");
      if (!id) state.offset = 0;
      await load();
    } catch (err) {
      error.textContent = err.message;
    } finally {
      button.disabled = false;
    }
  });

  $("#new-customer").addEventListener("click", () => openDialog(null));
  $("#customer-search").addEventListener(
    "input",
    debounce((event) => {
      state.q = event.target.value.trim();
      state.offset = 0;
      load().catch((err) => toast(err.message, "error"));
    }, 250),
  );
  $("#customer-status").addEventListener("change", (event) => {
    state.status = event.target.value;
    state.offset = 0;
    load().catch((err) => toast(err.message, "error"));
  });
  load().catch((err) => toast(err.message, "error"));
}

function initUsers() {
  const admin = document.body.dataset.role === "admin";
  const selfId = document.body.dataset.userId;
  const state = { offset: 0, limit: 20, q: "" };
  const tbody = $("#user-rows");
  const dialog = $("#user-dialog");
  const form = $("#user-form");
  const error = $("#user-error");
  let requestId = 0;

  async function load() {
    const current = ++requestId;
    const params = new URLSearchParams({
      limit: String(state.limit),
      offset: String(state.offset),
      q: state.q,
    });
    const page = await api(`/api/users?${params}`);
    if (current !== requestId) return;
    tbody.replaceChildren();
    if (!page.items.length) tbody.append(emptyRow(5, "No people match this view."));
    for (const user of page.items) {
      const tr = document.createElement("tr");
      tr.append(cell(user.email, "font-medium"));
      const roleCell = document.createElement("td");
      roleCell.append(pill(user.role, user.role));
      const statusCell = document.createElement("td");
      statusCell.append(pill(user.is_active ? "Active" : "Disabled", user.is_active ? "active" : "off"));
      tr.append(roleCell, statusCell, cell(formatWhen(user.created_at)));
      const actions = document.createElement("td");
      actions.className = "text-right";
      if (admin) {
        const edit = document.createElement("button");
        edit.type = "button";
        edit.className = "btn btn-ghost";
        edit.textContent = "Edit";
        edit.addEventListener("click", () => openDialog(user));
        lockDemoControl(edit);
        actions.append(edit);
        if (user.id !== selfId) {
          const remove = document.createElement("button");
          remove.type = "button";
          remove.className = "btn btn-ghost";
          remove.textContent = "Delete";
          remove.addEventListener("click", () => removeUser(user));
          lockDemoControl(remove);
          actions.append(remove);
        }
      }
      tr.append(actions);
      tbody.append(tr);
    }
    renderPager($("#user-pager"), page, state, () => load().catch((err) => toast(err.message, "error")));
  }

  function openDialog(user) {
    error.textContent = "";
    form.reset();
    const editing = Boolean(user);
    $("#user-dialog-title").textContent = editing ? "Edit person" : "New person";
    form.elements.record_id.value = editing ? user.id : "";
    form.elements.password.required = !editing;
    if (editing) {
      form.elements.email.value = user.email;
      form.elements.role.value = user.role;
      form.elements.is_active.checked = user.is_active;
    } else {
      form.elements.is_active.checked = true;
    }
    dialog.showModal();
  }

  async function removeUser(user) {
    const ok = await confirmAction(`Delete ${user.email}? Audit history is kept.`);
    if (!ok) return;
    try {
      await api(`/api/users/${user.id}`, { method: "DELETE" });
      toast("Person deleted");
      await load();
    } catch (err) {
      toast(err.message, "error");
    }
  }

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    error.textContent = "";
    const id = form.elements.record_id.value;
    const payload = {
      email: form.elements.email.value,
      role: form.elements.role.value,
      is_active: form.elements.is_active.checked,
    };
    if (form.elements.password.value) payload.password = form.elements.password.value;
    const button = form.querySelector("[type=submit]");
    button.disabled = true;
    try {
      if (id) await api(`/api/users/${id}`, { method: "PATCH", body: payload });
      else await api("/api/users", { method: "POST", body: payload });
      dialog.close();
      toast("Person saved");
      if (!id) state.offset = 0;
      await load();
    } catch (err) {
      error.textContent = err.message;
    } finally {
      button.disabled = false;
    }
  });

  $("#new-user")?.addEventListener("click", () => openDialog(null));
  $("#user-search").addEventListener(
    "input",
    debounce((event) => {
      state.q = event.target.value.trim();
      state.offset = 0;
      load().catch((err) => toast(err.message, "error"));
    }, 250),
  );
  load().catch((err) => toast(err.message, "error"));
}

function initAudit() {
  if (document.body.dataset.role !== "admin") return;
  const state = { offset: 0, limit: 30, q: "" };
  const tbody = $("#audit-rows");
  let requestId = 0;

  async function load() {
    const current = ++requestId;
    const params = new URLSearchParams({
      limit: String(state.limit),
      offset: String(state.offset),
      q: state.q,
    });
    const page = await api(`/api/audit-logs?${params}`);
    if (current !== requestId) return;
    tbody.replaceChildren();
    if (!page.items.length) tbody.append(emptyRow(5, "No audit events match this view."));
    for (const entry of page.items) {
      const tr = document.createElement("tr");
      tr.append(
        cell(formatWhen(entry.timestamp)),
        cell(entry.action, "font-medium"),
        cell(entry.user_email || "—"),
        cell(entry.ip_address || "—"),
        cell(entry.detail || "—"),
      );
      tbody.append(tr);
    }
    renderPager($("#audit-pager"), page, state, () => load().catch((err) => toast(err.message, "error")));
  }

  $("#audit-search").addEventListener(
    "input",
    debounce((event) => {
      state.q = event.target.value.trim();
      state.offset = 0;
      load().catch((err) => toast(err.message, "error"));
    }, 250),
  );
  load().catch((err) => toast(err.message, "error"));
}

async function initSettings() {
  const form = $("#settings-form");
  try {
    const current = await api("/api/settings");
    form.elements.organization_name.value = current.organization_name;
    form.elements.support_email.value = current.support_email;
    form.elements.maintenance_message.value = current.maintenance_message;
  } catch (error) {
    toast(error.message, "error");
  }
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const error = $("#settings-error");
    error.textContent = "";
    const button = form.querySelector("[type=submit]");
    if (!button) return;
    button.disabled = true;
    try {
      await api("/api/settings", {
        method: "PUT",
        body: {
          organization_name: form.elements.organization_name.value,
          support_email: form.elements.support_email.value,
          maintenance_message: form.elements.maintenance_message.value,
        },
      });
      toast("Settings saved");
      window.setTimeout(() => window.location.reload(), 400);
    } catch (err) {
      error.textContent = err.message;
    } finally {
      button.disabled = false;
    }
  });
  $("#password-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const error = $("#password-error");
    error.textContent = "";
    const passwordForm = event.currentTarget;
    const button = passwordForm.querySelector("[type=submit]");
    button.disabled = true;
    try {
      await api("/api/auth/change-password", {
        method: "POST",
        body: {
          current_password: passwordForm.elements.current_password.value,
          new_password: passwordForm.elements.new_password.value,
        },
      });
      passwordForm.reset();
      toast("Password updated");
    } catch (err) {
      error.textContent = err.message;
    } finally {
      button.disabled = false;
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initShell();
  const pages = {
    login: initLogin,
    dashboard: initDashboard,
    customers: initCustomers,
    users: initUsers,
    audit: initAudit,
    settings: initSettings,
  };
  const start = pages[document.body.dataset.page];
  if (start) {
    Promise.resolve(start()).catch((error) => toast(error.message || "Something went wrong", "error"));
  }
});
