"""Authentication and role dependencies."""

from fastapi import Depends, HTTPException, Request, status
from sqlmodel import Session

from app.config import get_settings
from app.database import get_session
from app.models import ROLE_ADMIN, User
from app.security import decode_access_token


def client_ip(request: Request) -> str:
    settings = get_settings()
    if settings.trust_proxy:
        forwarded = request.headers.get("x-forwarded-for", "")
        if forwarded:
            return forwarded.split(",")[0].strip()[:64]
    if request.client and request.client.host:
        return request.client.host[:64]
    return ""


def extract_token(request: Request) -> str | None:
    """Prefer a bearer token so API clients are not tied to a browser cookie."""
    header = request.headers.get("authorization", "")
    scheme, _, value = header.partition(" ")
    if scheme.lower() == "bearer" and value.strip():
        return value.strip()
    cookie = request.cookies.get(get_settings().cookie_name)
    if cookie:
        return cookie
    return None


def resolve_user(request: Request, session: Session) -> User | None:
    token = extract_token(request)
    if not token:
        return None
    user_id = decode_access_token(token)
    if not user_id:
        return None
    user = session.get(User, user_id)
    if user is None or not user.is_active:
        return None
    return user


def get_current_user(
    request: Request,
    session: Session = Depends(get_session),
) -> User:
    user = resolve_user(request, session)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != ROLE_ADMIN:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin role required")
    return user
