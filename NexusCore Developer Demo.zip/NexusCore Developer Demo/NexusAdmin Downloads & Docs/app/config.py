"""Runtime configuration loaded from the environment and an optional .env file."""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Atrium"
    secret_key: str = "change-me"
    database_url: str = "sqlite:///./data/atrium.db"
    access_token_expire_minutes: int = 720
    cookie_secure: bool = False
    cookie_name: str = "access_token"
    csrf_cookie_name: str = "csrf_token"
    auto_migrate: bool = True
    bcrypt_rounds: int = Field(default=12, ge=4, le=16)
    trust_proxy: bool = False
    cors_origins: str = ""
    allow_insecure_secret: bool = False
    login_max_failures: int = Field(default=8, ge=1, le=50)
    login_window_seconds: int = Field(default=900, ge=30, le=86_400)
    # Public sandbox. Rejects mutating API calls and shows the read-only banner.
    demo_mode: bool = False

    @property
    def sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")


@lru_cache
def get_settings() -> Settings:
    return Settings()


def assert_production_secret(settings: Settings) -> None:
    """Refuse to boot when the signing key is missing or still a placeholder."""
    placeholder = settings.secret_key.strip().lower() in {
        "change-me",
        "changeme",
        "replace-with-a-long-random-string",
        "secret",
        "dev",
        "test",
    }
    if placeholder or len(settings.secret_key) < 32:
        if settings.allow_insecure_secret:
            return
        raise RuntimeError(
            "SECRET_KEY must be a random string of at least 32 characters. "
            "Copy .env.example to .env and generate one before starting Atrium."
        )
