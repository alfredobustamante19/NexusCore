"""Engine, sessions, and Alembic startup."""

from collections.abc import Iterator
from pathlib import Path

from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlmodel import Session, SQLModel, create_engine

from app.config import get_settings

ROOT = Path(__file__).resolve().parents[1]
_engine: Engine | None = None


def ensure_sqlite_parent() -> None:
    settings = get_settings()
    if not settings.sqlite:
        return
    prefix = "sqlite:///"
    if not settings.database_url.startswith(prefix):
        return
    raw = settings.database_url[len(prefix) :]
    if raw in {"", ":memory:"} or raw.startswith(":memory:"):
        return
    Path(raw).parent.mkdir(parents=True, exist_ok=True)


def _sqlite_pragmas(dbapi_connection, _connection_record) -> None:
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.close()


def get_engine() -> Engine:
    global _engine
    if _engine is not None:
        return _engine
    settings = get_settings()
    connect_args = {"check_same_thread": False, "timeout": 30} if settings.sqlite else {}
    engine = create_engine(
        settings.database_url,
        connect_args=connect_args,
        pool_pre_ping=True,
    )
    if settings.sqlite:
        event.listen(engine, "connect", _sqlite_pragmas)
    _engine = engine
    return engine


def reset_engine() -> None:
    """Drop the cached engine. Tests use this between temporary databases."""
    global _engine
    if _engine is not None:
        _engine.dispose()
    _engine = None


def create_all() -> None:
    ensure_sqlite_parent()
    SQLModel.metadata.create_all(get_engine())


def get_session() -> Iterator[Session]:
    session = Session(get_engine())
    try:
        yield session
    finally:
        session.close()


def run_migrations() -> None:
    """Apply Alembic revisions up to head."""
    from alembic import command
    from alembic.config import Config

    ensure_sqlite_parent()
    cfg = Config(str(ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "alembic"))
    cfg.set_main_option("sqlalchemy.url", get_settings().database_url)
    command.upgrade(cfg, "head")
