"""Read-only sandbox for the public demo instance.

DEMO_MODE is the switch. When it is on, mutating API calls are rejected
except sign-in and sign-out, and startup seeds the guest account plus
sample records. The hourly reset script wipes the database and boots the
app again, which runs this seed on an empty volume.
"""

from __future__ import annotations

import logging
import secrets
import sys

from fastapi import Request
from fastapi.responses import JSONResponse
from sqlmodel import Session, func, select

from app.config import assert_production_secret, get_settings
from app.models import ROLE_ADMIN, ROLE_USER, AppSetting, CustomerRecord, User, utcnow
from app.security import hash_password
from app.seed import ORGANIZATION_NAME, SUPPORT_EMAIL

logger = logging.getLogger("atrium")

DEMO_EMAIL = "demo@nexuscore.dev"
DEMO_PASSWORD = "demopassword"
COMPANION_EMAIL = "iris@nexuscore.dev"
BUY_URL = "https://whop.com/nexuscore"
DEMO_ERROR = "Demo Mode Active"
DEMO_MESSAGE = (
    "Action disabled in live demo. Purchase full license to unlock full access."
)

_MUTATING = frozenset({"POST", "PUT", "PATCH", "DELETE"})
# Safe session routes. Logout does not change organization data, and the
# sign-out control has to keep working. Registration and password changes
# stay blocked with every other write.
_EXEMPT_POST = frozenset({
    "/api/auth/login",
    "/api/auth/logout",
})

DEMO_RECORDS = (
    ("Northwind Freight", "active", 12800.0),
    ("Harbor & Co.", "lead", 2400.0),
    ("Lumen Field", "paused", 860.0),
    ("Cedar Audit", "closed", 410.0),
)


def demo_payload() -> dict[str, str]:
    return {"error": DEMO_ERROR, "message": DEMO_MESSAGE, "buy_url": BUY_URL}


def _path(path: str) -> str:
    if len(path) > 1 and path.endswith("/"):
        return path.rstrip("/")
    return path


def demo_block(request: Request) -> JSONResponse | None:
    """Reject state-changing /api calls while DEMO_MODE is on.

    Reads stay open so a buyer can walk the console. Writes are refused
    across the API, which is what protects user management, records,
    organization settings, and any later route for keys, webhooks,
    billing, or resets. POST /api/auth/login and POST /api/auth/logout
    are the only exceptions.
    """
    if not get_settings().demo_mode:
        return None
    if request.method not in _MUTATING:
        return None
    path = _path(request.url.path)
    if not path.startswith("/api"):
        return None
    if request.method == "POST" and path in _EXEMPT_POST:
        return None
    return JSONResponse(demo_payload(), status_code=403)


def seed_demo(session: Session) -> None:
    """Insert the guest account and sample rows. No-op unless DEMO_MODE is on.

    Existing rows are left in place. The reset script removes the volume,
    so the next boot creates them again. The companion account has a
    random password and exists so the directory is not a single row.
    """
    if not get_settings().demo_mode:
        return

    changed = False
    guest = session.exec(select(User).where(User.email == DEMO_EMAIL)).first()
    if guest is None:
        session.add(
            User(
                email=DEMO_EMAIL,
                hashed_password=hash_password(DEMO_PASSWORD),
                role=ROLE_ADMIN,
                is_active=True,
            )
        )
        changed = True
    elif guest.role != ROLE_ADMIN or not guest.is_active:
        guest.role = ROLE_ADMIN
        guest.is_active = True
        session.add(guest)
        changed = True

    companion = session.exec(select(User).where(User.email == COMPANION_EMAIL)).first()
    if companion is None:
        session.add(
            User(
                email=COMPANION_EMAIL,
                hashed_password=hash_password(secrets.token_urlsafe(32)),
                role=ROLE_USER,
                is_active=True,
            )
        )
        changed = True

    record_count = session.exec(select(func.count(CustomerRecord.id))).one()
    if record_count == 0:
        for name, status, value in DEMO_RECORDS:
            session.add(CustomerRecord(name=name, status=status, value=value))
        changed = True

    if _replace_default(session, ORGANIZATION_NAME, "Atrium", "NexusCore"):
        changed = True
    if _replace_default(session, SUPPORT_EMAIL, "ops@example.com", DEMO_EMAIL):
        changed = True

    if changed:
        session.commit()
        logger.info("demo mode ready guest=%s", DEMO_EMAIL)


def _replace_default(session: Session, key: str, default: str, demo_value: str) -> bool:
    row = session.get(AppSetting, key)
    if row is None or row.value != default:
        return False
    row.value = demo_value
    row.updated_at = utcnow()
    session.add(row)
    return True


def main() -> None:
    """Seed an empty demo database. Used by reset-demo.sh before the server starts."""
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    settings = get_settings()
    if not settings.demo_mode:
        sys.stderr.write("DEMO_MODE is not true; refusing to seed the guest account.\n")
        raise SystemExit(1)
    assert_production_secret(settings)

    from app.database import create_all, get_engine, run_migrations
    from app.seed import seed_settings

    if settings.auto_migrate:
        run_migrations()
    else:
        create_all()
    with Session(get_engine()) as session:
        seed_settings(session)
        seed_demo(session)


if __name__ == "__main__":
    main()
