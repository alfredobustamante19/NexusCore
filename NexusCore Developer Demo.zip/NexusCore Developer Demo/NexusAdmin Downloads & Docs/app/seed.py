"""Default settings inserted once, never overwritten on later boots."""

from sqlmodel import Session

from app.models import AppSetting, utcnow

ORGANIZATION_NAME = "organization_name"
SUPPORT_EMAIL = "support_email"
MAINTENANCE_MESSAGE = "maintenance_message"

DEFAULTS = {
    ORGANIZATION_NAME: "Atrium",
    SUPPORT_EMAIL: "ops@example.com",
    MAINTENANCE_MESSAGE: "",
}


def seed_settings(session: Session) -> None:
    changed = False
    for key, value in DEFAULTS.items():
        if session.get(AppSetting, key) is None:
            session.add(AppSetting(key=key, value=value, updated_at=utcnow()))
            changed = True
    if changed:
        session.commit()


def read_settings(session: Session) -> dict[str, str]:
    found = {key: session.get(AppSetting, key) for key in DEFAULTS}
    return {key: (row.value if row is not None else DEFAULTS[key]) for key, row in found.items()}
