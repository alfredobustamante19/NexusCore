"""Atrium application entrypoint."""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlmodel import Session

from app import __version__
from app.config import assert_production_secret, get_settings
from app.database import get_engine, run_migrations
from app.deps import resolve_user
from app.routers import audit, auth, customers, dashboard, pages, settings, users
from app.routers.pages import render
from app.security import new_csrf_token, tokens_match
from app.demo import demo_block, seed_demo
from app.seed import seed_settings
from app.templating import BASE_DIR

logger = logging.getLogger("atrium")
_MAX_BODY_BYTES = 1_000_000


@asynccontextmanager
async def lifespan(_app: FastAPI):
    settings = get_settings()
    assert_production_secret(settings)
    if settings.auto_migrate:
        run_migrations()
    with Session(get_engine()) as session:
        seed_settings(session)
        seed_demo(session)
    logger.info("atrium ready version=%s demo_mode=%s", __version__, settings.demo_mode)
    yield


def create_app() -> FastAPI:
    cfg = get_settings()
    app = FastAPI(
        title="Atrium",
        summary="Self-hosted internal admin dashboard",
        version=__version__,
        lifespan=lifespan,
    )
    origins = [item.strip() for item in cfg.cors_origins.split(",") if item.strip()]
    if origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    @app.middleware("http")
    async def guard(request: Request, call_next):
        blocked = demo_block(request)
        if blocked is not None:
            _apply_security_headers(request, blocked)
            return blocked
        if _csrf_required(request) and not _csrf_ok(request):
            return JSONResponse({"detail": "CSRF validation failed"}, status_code=403)
        length = request.headers.get("content-length")
        if length is not None and length.isdigit() and int(length) > _MAX_BODY_BYTES:
            return JSONResponse({"detail": "Request body is too large"}, status_code=413)
        response = await call_next(request)
        _apply_security_headers(request, response)
        return response

    app.include_router(auth.router)
    app.include_router(users.router)
    app.include_router(customers.router)
    app.include_router(audit.router)
    app.include_router(settings.router)
    app.include_router(dashboard.router)
    app.include_router(pages.router)
    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

    @app.get("/api/health", tags=["health"])
    def health():
        with Session(get_engine()) as session:
            session.connection().exec_driver_sql("SELECT 1")
        return {"status": "ok"}

    @app.get("/", include_in_schema=False)
    def root(request: Request):
        with Session(get_engine()) as session:
            if resolve_user(request, session) is not None:
                return RedirectResponse("/app", status_code=303)
        return RedirectResponse("/login", status_code=303)

    @app.exception_handler(404)
    async def not_found(request: Request, exc: HTTPException):
        detail = exc.detail if isinstance(exc.detail, str) else "Not found"
        if request.url.path.startswith("/api"):
            return JSONResponse({"detail": detail}, status_code=404)
        with Session(get_engine()) as session:
            user = resolve_user(request, session)
            return render(request, session, "not_found.html", "missing", user, status_code=404)

    return app


def _apply_security_headers(request: Request, response) -> None:
    _ensure_csrf_cookie(request, response)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    if not _docs_path(request.url.path):
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self'; script-src 'self'; "
            "img-src 'self'; connect-src 'self'; base-uri 'self'; form-action 'self'; "
            "frame-ancestors 'none'"
        )


def _docs_path(path: str) -> bool:
    return path in {"/docs", "/redoc", "/openapi.json"} or path.startswith("/docs/") or path.startswith("/redoc/")


def _csrf_required(request: Request) -> bool:
    if request.method in {"GET", "HEAD", "OPTIONS"}:
        return False
    if not request.url.path.startswith("/api"):
        return False
    authorization = request.headers.get("authorization", "")
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() == "bearer" and token.strip():
        return False
    return bool(request.cookies.get(get_settings().cookie_name))


def _csrf_ok(request: Request) -> bool:
    settings = get_settings()
    return tokens_match(
        request.cookies.get(settings.csrf_cookie_name, ""),
        request.headers.get("x-csrf-token", ""),
    )


def _ensure_csrf_cookie(request: Request, response) -> None:
    settings = get_settings()
    name = settings.csrf_cookie_name
    prefix = f"{name}=".encode()
    for key, value in response.raw_headers:
        if key.lower() == b"set-cookie" and value.startswith(prefix):
            return
    if request.cookies.get(name):
        return
    response.set_cookie(
        name,
        new_csrf_token(),
        httponly=False,
        secure=settings.cookie_secure,
        samesite="lax",
        max_age=settings.access_token_expire_minutes * 60,
        path="/",
    )


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000)
