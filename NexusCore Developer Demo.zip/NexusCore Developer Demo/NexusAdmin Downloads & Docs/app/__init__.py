"""Atrium, a self-hosted internal admin console."""

__version__ = "1.0.0"
