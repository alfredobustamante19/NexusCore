"""SQLModel tables for accounts, audit history, records, and settings."""

from datetime import datetime, timezone
from uuid import uuid4

from sqlmodel import Field, SQLModel

ROLE_ADMIN = "admin"
ROLE_USER = "user"
ROLES = {ROLE_ADMIN, ROLE_USER}

CUSTOMER_STATUSES = {"lead", "active", "paused", "closed"}


def utcnow() -> datetime:
    """UTC timestamps. SQLModel stores them as UTC and restores the offset on read."""
    return datetime.now(timezone.utc)


def new_id() -> str:
    return str(uuid4())


class User(SQLModel, table=True):
    __tablename__ = "users"

    id: str = Field(default_factory=new_id, primary_key=True)
    email: str = Field(index=True, unique=True, max_length=320)
    hashed_password: str
    role: str = Field(default=ROLE_USER, max_length=32)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=utcnow, index=True)


class AuditLog(SQLModel, table=True):
    __tablename__ = "audit_logs"

    id: str = Field(default_factory=new_id, primary_key=True)
    user_id: str | None = Field(default=None, foreign_key="users.id", index=True)
    action: str = Field(index=True, max_length=128)
    ip_address: str = Field(default="", max_length=64)
    detail: str = Field(default="", max_length=500)
    timestamp: datetime = Field(default_factory=utcnow, index=True)


class CustomerRecord(SQLModel, table=True):
    __tablename__ = "customer_records"

    id: str = Field(default_factory=new_id, primary_key=True)
    name: str = Field(index=True, max_length=200)
    status: str = Field(default="lead", index=True, max_length=32)
    value: float = Field(default=0)
    created_at: datetime = Field(default_factory=utcnow, index=True)
    updated_at: datetime = Field(default_factory=utcnow)


class AppSetting(SQLModel, table=True):
    __tablename__ = "app_settings"

    key: str = Field(primary_key=True, max_length=64)
    value: str = Field(default="")
    updated_at: datetime = Field(default_factory=utcnow)
