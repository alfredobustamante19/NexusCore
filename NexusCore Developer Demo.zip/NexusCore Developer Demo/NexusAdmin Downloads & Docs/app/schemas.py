"""Request and response models. Table objects are never returned directly."""

from datetime import datetime, timezone
from typing import Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_serializer, field_validator

from app.models import CUSTOMER_STATUSES, ROLES

T = TypeVar("T")
RoleName = Literal["admin", "user"]
CustomerStatus = Literal["lead", "active", "paused", "closed"]


def as_utc(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    else:
        value = value.astimezone(timezone.utc)
    return value.isoformat()


def _clean_password(value: str) -> str:
    if len(value) > 128 or len(value.strip()) < 10:
        raise ValueError("Password must be 10 to 128 characters")
    return value


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    limit: int
    offset: int


class UserPublic(ORMModel):
    id: str
    email: str
    role: str
    is_active: bool
    created_at: datetime

    @field_serializer("created_at")
    def serialize_created_at(self, value: datetime) -> str:
        return as_utc(value)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserPublic


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        return value.strip().lower()


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("password")
    @classmethod
    def password_policy(cls, value: str) -> str:
        return _clean_password(value)


class PasswordChange(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str

    @field_validator("new_password")
    @classmethod
    def password_policy(cls, value: str) -> str:
        return _clean_password(value)


class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role: RoleName = "user"
    is_active: bool = True

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("password")
    @classmethod
    def password_policy(cls, value: str) -> str:
        return _clean_password(value)

    @field_validator("role")
    @classmethod
    def known_role(cls, value: str) -> str:
        if value not in ROLES:
            raise ValueError("Role must be admin or user")
        return value


class UserUpdate(BaseModel):
    email: EmailStr | None = None
    password: str | None = None
    role: RoleName | None = None
    is_active: bool | None = None

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return value.strip().lower()

    @field_validator("password")
    @classmethod
    def password_policy(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _clean_password(value)


class CustomerPublic(ORMModel):
    id: str
    name: str
    status: str
    value: float
    created_at: datetime
    updated_at: datetime

    @field_serializer("created_at", "updated_at")
    def serialize_times(self, value: datetime) -> str:
        return as_utc(value)


class CustomerWrite(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    status: CustomerStatus = "lead"
    value: float = Field(default=0, ge=0, le=1_000_000_000)

    @field_validator("name")
    @classmethod
    def strip_name(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("Name is required")
        return cleaned

    @field_validator("status")
    @classmethod
    def known_status(cls, value: str) -> str:
        if value not in CUSTOMER_STATUSES:
            raise ValueError("Unknown status")
        return value


class CustomerUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    status: CustomerStatus | None = None
    value: float | None = Field(default=None, ge=0, le=1_000_000_000)

    @field_validator("name")
    @classmethod
    def strip_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("Name is required")
        return cleaned


class AuditPublic(BaseModel):
    id: str
    user_id: str | None
    user_email: str | None = None
    action: str
    ip_address: str
    detail: str
    timestamp: datetime

    @field_serializer("timestamp")
    def serialize_timestamp(self, value: datetime) -> str:
        return as_utc(value)


class SettingsPublic(BaseModel):
    organization_name: str
    support_email: str
    maintenance_message: str


class SettingsUpdate(BaseModel):
    organization_name: str = Field(min_length=1, max_length=120)
    support_email: EmailStr
    maintenance_message: str = Field(default="", max_length=500)

    @field_validator("organization_name", "maintenance_message")
    @classmethod
    def strip_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("support_email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        return value.strip().lower()


class StatusCount(BaseModel):
    status: str
    count: int


class DashboardResponse(BaseModel):
    users: int
    active_users: int
    admins: int
    customers: int
    pipeline_value: float
    audit_events_24h: int
    customers_by_status: list[StatusCount]
    recent_customers: list[CustomerPublic]
    recent_audit: list[AuditPublic]
