"""In-process login failure window. Use one server worker with this limiter."""

import threading
import time

from app.config import get_settings

_failures: dict[str, list[float]] = {}
_lock = threading.Lock()


def reset_limiter() -> None:
    with _lock:
        _failures.clear()


def _prune(ip: str, now: float) -> list[float]:
    window = get_settings().login_window_seconds
    return [stamp for stamp in _failures.get(ip, []) if now - stamp < window]


def is_limited(ip: str) -> bool:
    now = time.monotonic()
    with _lock:
        stamps = _prune(ip, now)
        _failures[ip] = stamps
        return len(stamps) >= get_settings().login_max_failures


def register_failure(ip: str) -> None:
    now = time.monotonic()
    with _lock:
        stamps = _prune(ip, now)
        stamps.append(now)
        _failures[ip] = stamps


def clear_failures(ip: str) -> None:
    with _lock:
        _failures.pop(ip, None)
