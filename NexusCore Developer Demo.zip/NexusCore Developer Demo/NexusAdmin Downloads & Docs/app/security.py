"""Password hashing, JWT cookies, and CSRF tokens."""

import secrets
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from passlib.context import CryptContext

from app.config import get_settings

# passlib 1.7.4 reads bcrypt.__about__ and expects >72 byte secrets to truncate.
# bcrypt 4.1+ removed __about__ and raises instead of truncating. Patch both
# before passlib loads the backend so CryptContext can still use bcrypt.
if not hasattr(bcrypt, "__about__"):
    bcrypt.__about__ = type("about", (), {"__version__": getattr(bcrypt, "__version__", "0")})

_bcrypt_hashpw = bcrypt.hashpw


def _hashpw_compat(password, salt):
    if isinstance(password, str):
        password = password.encode("utf-8")
    return _bcrypt_hashpw(password[:72], salt)


bcrypt.hashpw = _hashpw_compat

_context: CryptContext | None = None
_dummy_hash: str | None = None


def get_context() -> CryptContext:
    """bcrypt-sha256 keeps the full passphrase instead of cutting it at 72 bytes."""
    global _context
    if _context is None:
        rounds = get_settings().bcrypt_rounds
        _context = CryptContext(
            schemes=["bcrypt_sha256"],
            deprecated="auto",
            bcrypt_sha256__rounds=rounds,
        )
    return _context


def hash_password(password: str) -> str:
    return get_context().hash(password)


def verify_password(password: str, hashed_password: str | None) -> bool:
    context = get_context()
    if not hashed_password:
        global _dummy_hash
        if _dummy_hash is None:
            _dummy_hash = context.hash("not-a-real-password")
        context.verify(password, _dummy_hash)
        return False
    return bool(context.verify(password, hashed_password))


def create_access_token(user_id: str) -> str:
    settings = get_settings()
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "iat": now,
        "exp": now + timedelta(minutes=settings.access_token_expire_minutes),
    }
    return jwt.encode(payload, settings.secret_key, algorithm="HS256")


def decode_access_token(token: str) -> str | None:
    try:
        payload = jwt.decode(token, get_settings().secret_key, algorithms=["HS256"])
    except jwt.PyJWTError:
        return None
    subject = payload.get("sub")
    if not isinstance(subject, str) or not subject:
        return None
    return subject


def new_csrf_token() -> str:
    return secrets.token_urlsafe(32)


def tokens_match(left: str, right: str) -> bool:
    if not left or not right or len(left) != len(right):
        return False
    return secrets.compare_digest(left, right)


def set_auth_cookies(response, access_token: str, csrf_token: str) -> None:
    settings = get_settings()
    max_age = settings.access_token_expire_minutes * 60
    response.set_cookie(
        settings.cookie_name,
        access_token,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        max_age=max_age,
        path="/",
    )
    response.set_cookie(
        settings.csrf_cookie_name,
        csrf_token,
        httponly=False,
        secure=settings.cookie_secure,
        samesite="lax",
        max_age=max_age,
        path="/",
    )


def clear_auth_cookies(response) -> None:
    settings = get_settings()
    response.delete_cookie(settings.cookie_name, path="/", samesite="lax", secure=settings.cookie_secure)
    response.delete_cookie(
        settings.csrf_cookie_name,
        path="/",
        samesite="lax",
        secure=settings.cookie_secure,
    )
