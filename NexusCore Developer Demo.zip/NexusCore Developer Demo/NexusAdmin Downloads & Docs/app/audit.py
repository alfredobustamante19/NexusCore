"""Append-only audit rows written in the same transaction as the change."""

from sqlmodel import Session

from app.models import AuditLog


def write_audit(
    session: Session,
    *,
    action: str,
    ip_address: str,
    user_id: str | None = None,
    detail: str = "",
) -> AuditLog:
    entry = AuditLog(
        action=action[:128],
        ip_address=(ip_address or "")[:64],
        user_id=user_id,
        detail=(detail or "")[:500],
    )
    session.add(entry)
    return entry
