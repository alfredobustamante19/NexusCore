"""Case-insensitive containment that treats LIKE wildcards as literal text."""

from sqlmodel import func


def contains(column, raw: str):
    escaped = raw.strip().lower().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return func.lower(column).like(f"%{escaped}%", escape="\\")
