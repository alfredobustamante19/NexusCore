"""Login, first-admin bootstrap, session, and password changes."""

import threading

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlmodel import Session, func, select

from app.audit import write_audit
from app.config import get_settings
from app.database import get_session
from app.deps import client_ip, get_current_user
from app.limiter import clear_failures, is_limited, register_failure
from app.models import ROLE_ADMIN, User
from app.schemas import LoginRequest, PasswordChange, RegisterRequest, TokenResponse, UserPublic
from app.security import (
    clear_auth_cookies,
    create_access_token,
    hash_password,
    new_csrf_token,
    set_auth_cookies,
    verify_password,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])
_bootstrap_lock = threading.Lock()


def _issue(response: Response, user: User) -> TokenResponse:
    settings = get_settings()
    token = create_access_token(user.id)
    set_auth_cookies(response, token, new_csrf_token())
    return TokenResponse(
        access_token=token,
        expires_in=settings.access_token_expire_minutes * 60,
        user=UserPublic.model_validate(user),
    )


@router.get("/bootstrap")
def bootstrap_status(session: Session = Depends(get_session)) -> dict[str, bool]:
    count = session.exec(select(func.count(User.id))).one()
    return {"bootstrap_open": count == 0}


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def register(
    body: RegisterRequest,
    request: Request,
    response: Response,
    session: Session = Depends(get_session),
) -> TokenResponse:
    with _bootstrap_lock:
        count = session.exec(select(func.count(User.id))).one()
        if count:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Registration is closed. An administrator must create accounts.",
            )
        user = User(
            email=body.email,
            hashed_password=hash_password(body.password),
            role=ROLE_ADMIN,
            is_active=True,
        )
        session.add(user)
        session.flush()
        write_audit(
            session,
            action="auth.register",
            user_id=user.id,
            ip_address=client_ip(request),
            detail=user.email,
        )
        session.commit()
        session.refresh(user)
    return _issue(response, user)


@router.post("/login", response_model=TokenResponse)
def login(
    body: LoginRequest,
    request: Request,
    response: Response,
    session: Session = Depends(get_session),
) -> TokenResponse:
    ip = client_ip(request)
    if is_limited(ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many login attempts. Try again later.",
            headers={"Retry-After": str(get_settings().login_window_seconds)},
        )
    user = session.exec(select(User).where(User.email == body.email)).first()
    if user is None or not verify_password(body.password, user.hashed_password):
        register_failure(ip)
        write_audit(
            session,
            action="auth.login_failed",
            user_id=user.id if user else None,
            ip_address=ip,
            detail=body.email,
        )
        session.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect email or password")
    if not user.is_active:
        register_failure(ip)
        write_audit(
            session,
            action="auth.login_denied",
            user_id=user.id,
            ip_address=ip,
            detail=user.email,
        )
        session.commit()
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="This account is disabled")
    clear_failures(ip)
    write_audit(session, action="auth.login", user_id=user.id, ip_address=ip, detail=user.email)
    session.commit()
    return _issue(response, user)


@router.get("/me", response_model=UserPublic)
def me(user: User = Depends(get_current_user)) -> User:
    return user


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    request: Request,
    response: Response,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> None:
    write_audit(session, action="auth.logout", user_id=user.id, ip_address=client_ip(request), detail=user.email)
    session.commit()
    clear_auth_cookies(response)


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT)
def change_password(
    body: PasswordChange,
    request: Request,
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Response:
    if not verify_password(body.current_password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Current password is incorrect")
    user.hashed_password = hash_password(body.new_password)
    session.add(user)
    write_audit(
        session,
        action="auth.password_change",
        user_id=user.id,
        ip_address=client_ip(request),
        detail=user.email,
    )
    session.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
