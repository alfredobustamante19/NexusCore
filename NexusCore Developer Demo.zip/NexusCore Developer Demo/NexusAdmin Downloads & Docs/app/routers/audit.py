"""Read API for the audit trail. Writes happen inside the mutating routes."""

from fastapi import APIRouter, Depends, Query
from sqlalchemy import or_
from sqlmodel import Session, func, select

from app.database import get_session
from app.deps import require_admin
from app.models import AuditLog, User
from app.schemas import AuditPublic, Page
from app.search import contains

router = APIRouter(prefix="/api/audit-logs", tags=["audit"])


def _public(entry: AuditLog, email: str | None) -> AuditPublic:
    return AuditPublic(
        id=entry.id,
        user_id=entry.user_id,
        user_email=email,
        action=entry.action,
        ip_address=entry.ip_address,
        detail=entry.detail,
        timestamp=entry.timestamp,
    )


@router.get("", response_model=Page[AuditPublic])
def list_audit_logs(
    q: str = Query(default="", max_length=128),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    _: User = Depends(require_admin),
    session: Session = Depends(get_session),
) -> Page[AuditPublic]:
    filters = []
    if q.strip():
        filters.append(or_(contains(AuditLog.action, q), contains(AuditLog.detail, q)))
    total = session.exec(select(func.count(AuditLog.id)).where(*filters)).one()
    rows = session.exec(
        select(AuditLog).where(*filters).order_by(AuditLog.timestamp.desc()).offset(offset).limit(limit)
    ).all()
    emails: dict[str, str] = {}
    user_ids = {row.user_id for row in rows if row.user_id}
    if user_ids:
        for user in session.exec(select(User).where(User.id.in_(user_ids))).all():
            emails[user.id] = user.email
    return Page(
        items=[_public(row, emails.get(row.user_id or "")) for row in rows],
        total=total,
        limit=limit,
        offset=offset,
    )
