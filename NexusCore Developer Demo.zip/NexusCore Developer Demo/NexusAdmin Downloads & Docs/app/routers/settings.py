"""Organization settings. Reads are open to signed-in users; writes are admin-only."""

from fastapi import APIRouter, Depends, Request
from sqlmodel import Session

from app.audit import write_audit
from app.database import get_session
from app.deps import client_ip, get_current_user, require_admin
from app.models import AppSetting, User, utcnow
from app.schemas import SettingsPublic, SettingsUpdate
from app.seed import MAINTENANCE_MESSAGE, ORGANIZATION_NAME, SUPPORT_EMAIL, read_settings

router = APIRouter(prefix="/api/settings", tags=["settings"])


@router.get("", response_model=SettingsPublic)
def get_settings_view(
    _: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> SettingsPublic:
    current = read_settings(session)
    return SettingsPublic(
        organization_name=current[ORGANIZATION_NAME],
        support_email=current[SUPPORT_EMAIL],
        maintenance_message=current[MAINTENANCE_MESSAGE],
    )


@router.put("", response_model=SettingsPublic)
def update_settings(
    body: SettingsUpdate,
    request: Request,
    actor: User = Depends(require_admin),
    session: Session = Depends(get_session),
) -> SettingsPublic:
    values = {
        ORGANIZATION_NAME: body.organization_name,
        SUPPORT_EMAIL: body.support_email,
        MAINTENANCE_MESSAGE: body.maintenance_message,
    }
    now = utcnow()
    for key, value in values.items():
        row = session.get(AppSetting, key)
        if row is None:
            session.add(AppSetting(key=key, value=value, updated_at=now))
        else:
            row.value = value
            row.updated_at = now
            session.add(row)
    write_audit(
        session,
        action="settings.update",
        user_id=actor.id,
        ip_address=client_ip(request),
        detail=body.organization_name,
    )
    session.commit()
    return SettingsPublic(
        organization_name=body.organization_name,
        support_email=body.support_email,
        maintenance_message=body.maintenance_message,
    )
