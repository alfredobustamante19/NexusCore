"""Server-rendered shells. Record changes go through the JSON API."""

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlmodel import Session

from app import __version__
from app.config import get_settings
from app.database import get_session
from app.demo import BUY_URL, DEMO_EMAIL, DEMO_MESSAGE, DEMO_PASSWORD
from app.deps import resolve_user
from app.seed import MAINTENANCE_MESSAGE, ORGANIZATION_NAME, SUPPORT_EMAIL, read_settings
from app.templating import templates

router = APIRouter(include_in_schema=False)


def render(request: Request, session: Session, name: str, page: str, user, status_code: int = 200, **extra):
    current = read_settings(session)
    settings = get_settings()
    return templates.TemplateResponse(
        request,
        name,
        {
            "page": page,
            "user": user,
            "organization_name": current[ORGANIZATION_NAME],
            "support_email": current[SUPPORT_EMAIL],
            "maintenance_message": current[MAINTENANCE_MESSAGE].strip(),
            "version": __version__,
            "demo_mode": settings.demo_mode,
            "demo_buy_url": BUY_URL,
            "demo_email": DEMO_EMAIL,
            "demo_password": DEMO_PASSWORD if settings.demo_mode else "",
            "demo_message": DEMO_MESSAGE,
            **extra,
        },
        status_code=status_code,
        headers={"Cache-Control": "no-store"},
    )


def _private(request: Request, session: Session, name: str, page: str):
    user = resolve_user(request, session)
    if user is None:
        return RedirectResponse("/login", status_code=303)
    return render(request, session, name, page, user)


@router.get("/login")
def login_page(request: Request, session: Session = Depends(get_session)):
    if resolve_user(request, session) is not None:
        return RedirectResponse("/app", status_code=303)
    return render(request, session, "login.html", "login", None)


@router.get("/app")
def dashboard_page(request: Request, session: Session = Depends(get_session)):
    return _private(request, session, "dashboard.html", "dashboard")


@router.get("/app/customers")
def customers_page(request: Request, session: Session = Depends(get_session)):
    return _private(request, session, "customers.html", "customers")


@router.get("/app/users")
def users_page(request: Request, session: Session = Depends(get_session)):
    return _private(request, session, "users.html", "users")


@router.get("/app/audit")
def audit_page(request: Request, session: Session = Depends(get_session)):
    return _private(request, session, "audit.html", "audit")


@router.get("/app/settings")
def settings_page(request: Request, session: Session = Depends(get_session)):
    return _private(request, session, "settings.html", "settings")
