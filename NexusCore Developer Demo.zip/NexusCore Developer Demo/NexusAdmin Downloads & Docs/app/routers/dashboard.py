"""Aggregate counts for the overview screen."""

from datetime import timedelta

from fastapi import APIRouter, Depends
from sqlmodel import Session, func, select

from app.database import get_session
from app.deps import get_current_user
from app.models import ROLE_ADMIN, AuditLog, CustomerRecord, User, utcnow
from app.routers.audit import _public
from app.schemas import CustomerPublic, DashboardResponse, StatusCount

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("", response_model=DashboardResponse)
def dashboard(
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> DashboardResponse:
    users = session.exec(select(func.count(User.id))).one()
    active_users = session.exec(select(func.count(User.id)).where(User.is_active.is_(True))).one()
    admins = session.exec(
        select(func.count(User.id)).where(User.role == ROLE_ADMIN, User.is_active.is_(True))
    ).one()
    customers = session.exec(select(func.count(CustomerRecord.id))).one()
    pipeline = session.exec(select(func.coalesce(func.sum(CustomerRecord.value), 0))).one()
    since = utcnow() - timedelta(hours=24)
    audit_events = session.exec(
        select(func.count(AuditLog.id)).where(AuditLog.timestamp >= since)
    ).one()
    grouped = session.exec(
        select(CustomerRecord.status, func.count(CustomerRecord.id)).group_by(CustomerRecord.status)
    ).all()
    recent_customers = session.exec(
        select(CustomerRecord).order_by(CustomerRecord.created_at.desc()).limit(6)
    ).all()
    recent_audit = []
    if user.role == ROLE_ADMIN:
        entries = session.exec(select(AuditLog).order_by(AuditLog.timestamp.desc()).limit(6)).all()
        user_ids = {entry.user_id for entry in entries if entry.user_id}
        emails = {}
        if user_ids:
            for row in session.exec(select(User).where(User.id.in_(user_ids))).all():
                emails[row.id] = row.email
        recent_audit = [_public(entry, emails.get(entry.user_id or "")) for entry in entries]
    return DashboardResponse(
        users=users,
        active_users=active_users,
        admins=admins,
        customers=customers,
        pipeline_value=float(pipeline or 0),
        audit_events_24h=audit_events,
        customers_by_status=[StatusCount(status=status, count=count) for status, count in grouped],
        recent_customers=[CustomerPublic.model_validate(row) for row in recent_customers],
        recent_audit=recent_audit,
    )
