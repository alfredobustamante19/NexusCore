"""Sample resource used to demonstrate a full CRUD table."""

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlmodel import Session, func, select

from app.audit import write_audit
from app.database import get_session
from app.deps import client_ip, get_current_user
from app.models import CustomerRecord, User, utcnow
from app.schemas import CustomerPublic, CustomerUpdate, CustomerWrite, Page
from app.search import contains

router = APIRouter(prefix="/api/customers", tags=["customers"])


@router.get("", response_model=Page[CustomerPublic])
def list_customers(
    q: str = Query(default="", max_length=200),
    status_filter: str = Query(default="", alias="status", max_length=32),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    _: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Page[CustomerPublic]:
    filters = []
    if q.strip():
        filters.append(contains(CustomerRecord.name, q))
    if status_filter:
        filters.append(CustomerRecord.status == status_filter)
    total = session.exec(select(func.count(CustomerRecord.id)).where(*filters)).one()
    rows = session.exec(
        select(CustomerRecord)
        .where(*filters)
        .order_by(CustomerRecord.created_at.desc())
        .offset(offset)
        .limit(limit)
    ).all()
    return Page(
        items=[CustomerPublic.model_validate(row) for row in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post("", response_model=CustomerPublic, status_code=status.HTTP_201_CREATED)
def create_customer(
    body: CustomerWrite,
    request: Request,
    actor: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> CustomerRecord:
    record = CustomerRecord(name=body.name, status=body.status, value=body.value)
    session.add(record)
    session.flush()
    write_audit(
        session,
        action="customer.create",
        user_id=actor.id,
        ip_address=client_ip(request),
        detail=f"{record.name} status={record.status}",
    )
    session.commit()
    session.refresh(record)
    return record


@router.get("/{record_id}", response_model=CustomerPublic)
def get_customer(
    record_id: str,
    _: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> CustomerRecord:
    record = session.get(CustomerRecord, record_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Record not found")
    return record


@router.patch("/{record_id}", response_model=CustomerPublic)
def update_customer(
    record_id: str,
    body: CustomerUpdate,
    request: Request,
    actor: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> CustomerRecord:
    record = session.get(CustomerRecord, record_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Record not found")
    changes = body.model_dump(exclude_unset=True)
    if not changes:
        return record
    if "name" in changes:
        record.name = changes["name"]
    if "status" in changes:
        record.status = changes["status"]
    if "value" in changes:
        record.value = changes["value"]
    record.updated_at = utcnow()
    session.add(record)
    write_audit(
        session,
        action="customer.update",
        user_id=actor.id,
        ip_address=client_ip(request),
        detail=f"{record.name} fields={','.join(sorted(changes))}",
    )
    session.commit()
    session.refresh(record)
    return record


@router.delete("/{record_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_customer(
    record_id: str,
    request: Request,
    actor: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> None:
    record = session.get(CustomerRecord, record_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Record not found")
    name = record.name
    session.delete(record)
    write_audit(
        session,
        action="customer.delete",
        user_id=actor.id,
        ip_address=client_ip(request),
        detail=name,
    )
    session.commit()
