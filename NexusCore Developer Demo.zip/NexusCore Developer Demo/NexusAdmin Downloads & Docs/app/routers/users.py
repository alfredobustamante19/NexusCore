"""Account directory. Role and membership changes are limited to admins."""

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, func, select

from app.audit import write_audit
from app.database import get_session
from app.deps import client_ip, get_current_user, require_admin
from app.models import ROLE_ADMIN, AuditLog, User
from app.schemas import Page, UserCreate, UserPublic, UserUpdate
from app.search import contains
from app.security import hash_password

router = APIRouter(prefix="/api/users", tags=["users"])


def _guard_last_admin(
    session: Session,
    user: User,
    *,
    role: str | None = None,
    is_active: bool | None = None,
    deleting: bool = False,
) -> None:
    if user.role != ROLE_ADMIN or not user.is_active:
        return
    next_role = user.role if role is None else role
    next_active = user.is_active if is_active is None else is_active
    if not deleting and next_role == ROLE_ADMIN and next_active:
        return
    others = session.exec(
        select(func.count(User.id)).where(
            User.role == ROLE_ADMIN,
            User.is_active.is_(True),
            User.id != user.id,
        )
    ).one()
    if others < 1:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="At least one active admin is required",
        )


@router.get("", response_model=Page[UserPublic])
def list_users(
    q: str = Query(default="", max_length=320),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    _: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> Page[UserPublic]:
    filters = []
    if q.strip():
        filters.append(contains(User.email, q))
    total = session.exec(select(func.count(User.id)).where(*filters)).one()
    rows = session.exec(
        select(User).where(*filters).order_by(User.created_at.desc()).offset(offset).limit(limit)
    ).all()
    return Page(
        items=[UserPublic.model_validate(row) for row in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.post("", response_model=UserPublic, status_code=status.HTTP_201_CREATED)
def create_user(
    body: UserCreate,
    request: Request,
    actor: User = Depends(require_admin),
    session: Session = Depends(get_session),
) -> User:
    existing = session.exec(select(User).where(User.email == body.email)).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already in use")
    user = User(
        email=body.email,
        hashed_password=hash_password(body.password),
        role=body.role,
        is_active=body.is_active,
    )
    session.add(user)
    try:
        session.flush()
    except IntegrityError as exc:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already in use") from exc
    write_audit(
        session,
        action="user.create",
        user_id=actor.id,
        ip_address=client_ip(request),
        detail=f"{user.email} role={user.role}",
    )
    session.commit()
    session.refresh(user)
    return user


@router.get("/{user_id}", response_model=UserPublic)
def get_user(
    user_id: str,
    _: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> User:
    user = session.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user


@router.patch("/{user_id}", response_model=UserPublic)
def update_user(
    user_id: str,
    body: UserUpdate,
    request: Request,
    actor: User = Depends(require_admin),
    session: Session = Depends(get_session),
) -> User:
    user = session.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    changes = body.model_dump(exclude_unset=True)
    if not changes:
        return user
    _guard_last_admin(
        session,
        user,
        role=changes.get("role"),
        is_active=changes.get("is_active"),
    )
    if "email" in changes and changes["email"] != user.email:
        taken = session.exec(select(User).where(User.email == changes["email"])).first()
        if taken:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already in use")
        user.email = changes["email"]
    if "password" in changes and changes["password"]:
        user.hashed_password = hash_password(changes["password"])
    if "role" in changes:
        user.role = changes["role"]
    if "is_active" in changes:
        user.is_active = changes["is_active"]
    session.add(user)
    write_audit(
        session,
        action="user.update",
        user_id=actor.id,
        ip_address=client_ip(request),
        detail=f"{user.email} fields={','.join(sorted(changes))}",
    )
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already in use") from exc
    session.refresh(user)
    return user


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(
    user_id: str,
    request: Request,
    actor: User = Depends(require_admin),
    session: Session = Depends(get_session),
) -> None:
    user = session.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if user.id == actor.id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="You cannot delete the account you are signed in with",
        )
    _guard_last_admin(session, user, deleting=True)
    email = user.email
    for entry in session.exec(select(AuditLog).where(AuditLog.user_id == user.id)).all():
        entry.user_id = None
        session.add(entry)
    session.flush()
    session.delete(user)
    write_audit(
        session,
        action="user.delete",
        user_id=actor.id,
        ip_address=client_ip(request),
        detail=email,
    )
    session.commit()
