#!/usr/bin/env bash
# Hourly reset for the public sandbox at demo.nexuscore.dev.
#
# Install on the demo host (path is the directory that contains this file
# and docker-compose.yml):
#
#   chmod +x /opt/nexuscore/admin-dashboard/reset-demo.sh
#   0 * * * * /opt/nexuscore/admin-dashboard/reset-demo.sh >> /var/log/nexuscore-demo-reset.log 2>&1
#
# That crontab line runs the script every 60 minutes, at minute 0.
# Set a real SECRET_KEY in .env. The script forces DEMO_MODE=true for the
# restarted stack. Do not install it on a production host.

set -euo pipefail

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export DEMO_MODE=true

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if [[ ! -f "$ROOT/docker-compose.yml" ]]; then
  echo "[demo-reset] docker-compose.yml not found in $ROOT" >&2
  exit 1
fi

exec 9>/tmp/nexuscore-demo-reset.lock
if ! flock -n 9; then
  echo "[demo-reset] another reset is already running" >&2
  exit 0
fi

project="${COMPOSE_PROJECT_NAME:-$(basename "$ROOT")}"

echo "[demo-reset] stopping the stack and deleting volumes"
docker compose down -v

echo "[demo-reset] pruning leftover demo volumes for project ${project}"
docker volume rm -f "${project}_atrium-data" >/dev/null 2>&1 || true
while IFS= read -r volume; do
  [[ -n "$volume" ]] || continue
  docker volume rm -f "$volume" || true
done < <(docker volume ls -q --filter "label=com.docker.compose.project=${project}" || true)

echo "[demo-reset] re-seeding default demo mock data"
if ! docker compose run --rm --no-deps -T -e DEMO_MODE=true atrium python -m app.demo; then
  echo "[demo-reset] explicit seed failed; startup will seed when the server boots" >&2
fi

echo "[demo-reset] starting the stack"
docker compose up -d

echo "[demo-reset] waiting for the API"
ready=0
for _ in $(seq 1 30); do
  if docker compose exec -T atrium python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8000/api/health')" >/dev/null 2>&1; then
    ready=1
    break
  fi
  sleep 2
done

if [[ "$ready" -ne 1 ]]; then
  echo "[demo-reset] atrium did not become healthy" >&2
  exit 1
fi

echo "[demo-reset] demo instance is up"
