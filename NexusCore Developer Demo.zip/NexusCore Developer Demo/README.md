# NexusCore Developer Trial

Local trial of seven products:

- API Proxy Agent
- EnvSync Agent
- LogStream Microservice
- NexusAdmin Downloads & Docs
- NexusCron
- NexusPipeline Package & Setup
- Webhook Router

## Quick start

Python 3.12 or newer and Node.js 24 or newer.

```bash
python demo/run_demo.py
```

On Windows you can run `demo\Start Demo.ps1`. On macOS or Linux, run `./demo/start-demo.sh`.

The console opens at [http://127.0.0.1:7400](http://127.0.0.1:7400). It links to each product and shows the local sign-in values. The first launch installs Python packages into `.demo/venv` and Node packages into the three Node products. Leave the terminal open and stop the trial with Ctrl+C.

Looking for the licensed editions of API Proxy Agent, EnvSync Agent, LogStream Microservice, NexusAdmin Downloads & Docs, NexusCron, NexusPipeline Package & Setup, and Webhook Router? Visit https://nexuscore-store.whop.site
