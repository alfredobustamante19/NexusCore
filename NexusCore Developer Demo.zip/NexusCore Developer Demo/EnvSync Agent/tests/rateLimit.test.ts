import assert from 'node:assert/strict';
import { describe, test } from 'node:test';
import { SlidingWindowRateLimiter } from '../src/rateLimit.ts';
import { api, startServer, stopServer } from './helpers.ts';

describe('rate limiting', { concurrency: false }, () => {
  test('sliding window blocks the next call and resets when the window passes', () => {
    let now = 1_000_000;
    const limiter = new SlidingWindowRateLimiter({ limit: 2, windowMs: 1000, now: () => now });
    const first = limiter.check('pull:10.0.0.1');
    const second = limiter.check('pull:10.0.0.1');
    const third = limiter.check('pull:10.0.0.1');
    assert.equal(first.allowed, true);
    assert.equal(first.remaining, 1);
    assert.equal(second.allowed, true);
    assert.equal(second.remaining, 0);
    assert.equal(third.allowed, false);
    assert.equal(third.remaining, 0);
    assert.ok(third.retryAfterMs > 0 && third.retryAfterMs <= 1000);
    assert.equal(limiter.check('push:10.0.0.1').allowed, true);
    now += 1001;
    const after = limiter.check('pull:10.0.0.1');
    assert.equal(after.allowed, true);
    assert.equal(after.remaining, 1);
  });

  test('pull and push endpoints return 429 independently of health checks', async () => {
    const srv = await startServer({
      NEXUSENV_RATE_LIMIT_MAX: '2',
      NEXUSENV_RATE_LIMIT_WINDOW_MS: '60000',
    });
    try {
      const project = await api(srv, '/api/v1/projects', { method: 'POST', body: { name: 'Limited' } });
      const tokenRes = await api(srv, `/api/v1/projects/${project.json.project.id}/tokens`, {
        method: 'POST',
        body: { name: 'ci', environments: ['dev'], permissions: ['write'] },
      });
      const token = tokenRes.json.token.secret as string;
      const envPath = `/api/v1/projects/${project.json.project.id}/env?environment=dev`;
      const secretPath = `/api/v1/projects/${project.json.project.id}/secrets`;

      const pull1 = await api(srv, envPath, { token, cookie: false });
      const pull2 = await api(srv, envPath, { token, cookie: false });
      const pull3 = await api(srv, envPath, { token, cookie: false });
      assert.equal(pull1.status, 200, pull1.text);
      assert.equal(pull2.status, 200, pull2.text);
      assert.equal(pull3.status, 429, pull3.text);
      assert.equal(pull3.json.error.code, 'rate_limited');
      assert.equal(pull3.headers.get('x-ratelimit-remaining'), '0');
      assert.ok(Number(pull3.headers.get('retry-after')) >= 1);

      const health = await api(srv, '/api/v1/health', { cookie: false });
      assert.equal(health.status, 200, health.text);

      const pushBody = { environment: 'dev', secrets: { A: '1' } };
      const push1 = await api(srv, secretPath, { method: 'POST', token, cookie: false, body: pushBody });
      const push2 = await api(srv, secretPath, { method: 'POST', token, cookie: false, body: { environment: 'dev', secrets: { A: '2' } } });
      const push3 = await api(srv, secretPath, { method: 'POST', token, cookie: false, body: { environment: 'dev', secrets: { A: '3' } } });
      assert.equal(push1.status, 201, push1.text);
      assert.equal(push2.status, 201, push2.text);
      assert.equal(push3.status, 429, push3.text);
      assert.equal(push3.json.error.code, 'rate_limited');

      const healthAgain = await api(srv, '/api/v1/health', { cookie: false });
      assert.equal(healthAgain.status, 200, healthAgain.text);

      const audit = await api(srv, '/api/v1/audit?action=pull&limit=50');
      assert.equal(audit.json.logs.some((entry: { success: boolean; detail: string }) => (
        entry.success === false && entry.detail === 'rate limited'
      )), true);
    } finally {
      await stopServer(srv);
    }
  });
});
