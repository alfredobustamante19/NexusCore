import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { describe, test } from 'node:test';
import {
  DecryptionError,
  decryptSecret,
  encryptSecret,
  hashPassword,
  parseMasterKey,
  secretAad,
  verifyPassword,
} from '../src/crypto.ts';

describe('AES-256-GCM secret encryption', () => {
  const key = randomBytes(32);
  const aad = secretAad('prj_123', 'production', 'DATABASE_URL', 4);

  test('round-trips unicode, empty, and long values', () => {
    for (const plaintext of ['', 'hello', 'héllo 🔐', 'k'.repeat(4000), 'line1\nline2']) {
      const encrypted = encryptSecret(key, plaintext, aad);
      assert.equal(decryptSecret(key, encrypted.ciphertext, encrypted.nonce, encrypted.tag, aad), plaintext);
      assert.equal(Buffer.from(encrypted.nonce, 'base64').length, 12);
      assert.equal(Buffer.from(encrypted.tag, 'base64').length, 16);
      assert.equal(Buffer.from(encrypted.ciphertext, 'base64').length, Buffer.byteLength(plaintext));
    }
  });

  test('uses a fresh nonce so identical plaintext does not repeat', () => {
    const first = encryptSecret(key, 'same', aad);
    const second = encryptSecret(key, 'same', aad);
    assert.notEqual(first.nonce, second.nonce);
    assert.notEqual(first.ciphertext, second.ciphertext);
  });

  test('rejects tampered ciphertext, tag, nonce, and truncated blobs', () => {
    const encrypted = encryptSecret(key, 'payload', aad);
    const flipped = Buffer.from(encrypted.ciphertext, 'base64');
    flipped[0] = (flipped[0] ?? 0) ^ 0xff;
    assert.throws(
      () => decryptSecret(key, flipped.toString('base64'), encrypted.nonce, encrypted.tag, aad),
      DecryptionError,
    );
    const tag = Buffer.from(encrypted.tag, 'base64');
    tag[0] = (tag[0] ?? 0) ^ 0xff;
    assert.throws(
      () => decryptSecret(key, encrypted.ciphertext, encrypted.nonce, tag.toString('base64'), aad),
      DecryptionError,
    );
    assert.throws(
      () => decryptSecret(key, encrypted.ciphertext, Buffer.from('short').toString('base64'), encrypted.tag, aad),
      DecryptionError,
    );
    const empty = encryptSecret(key, '', aad);
    const emptyTag = Buffer.from(empty.tag, 'base64');
    emptyTag[1] = (emptyTag[1] ?? 0) ^ 0xff;
    assert.throws(
      () => decryptSecret(key, empty.ciphertext, empty.nonce, emptyTag.toString('base64'), aad),
      DecryptionError,
    );
  });

  test('binds ciphertext to the master key and associated data', () => {
    const encrypted = encryptSecret(key, 'sk_live_example', aad);
    const otherKey = randomBytes(32);
    assert.throws(
      () => decryptSecret(otherKey, encrypted.ciphertext, encrypted.nonce, encrypted.tag, aad),
      DecryptionError,
    );
    const swapped = secretAad('prj_other', 'production', 'DATABASE_URL', 4);
    assert.throws(
      () => decryptSecret(key, encrypted.ciphertext, encrypted.nonce, encrypted.tag, swapped),
      DecryptionError,
    );
    const otherRevision = secretAad('prj_123', 'production', 'DATABASE_URL', 5);
    assert.throws(
      () => decryptSecret(key, encrypted.ciphertext, encrypted.nonce, encrypted.tag, otherRevision),
      DecryptionError,
    );
    const otherName = secretAad('prj_123', 'production', 'OTHER_KEY', 4);
    assert.throws(
      () => decryptSecret(key, encrypted.ciphertext, encrypted.nonce, encrypted.tag, otherName),
      DecryptionError,
    );
  });

  test('accepts 32-byte hex and base64 master keys and rejects weak or short keys', () => {
    const raw = randomBytes(32);
    assert.deepEqual(parseMasterKey(raw.toString('hex')), raw);
    assert.deepEqual(parseMasterKey(raw.toString('base64')), raw);
    assert.throws(() => parseMasterKey('00'.repeat(32)), /not random enough/);
    assert.throws(() => parseMasterKey('abcd'), /64 hex characters|exactly 32 bytes/);
    assert.throws(() => parseMasterKey(Buffer.from('short').toString('base64')), /exactly 32 bytes/);
  });

  test('hashes admin passwords with scrypt and rejects a wrong password', () => {
    const encoded = hashPassword('correct-horse');
    assert.equal(verifyPassword('correct-horse', encoded), true);
    assert.equal(verifyPassword('wrong-horse', encoded), false);
    assert.equal(verifyPassword('correct-horse', 'nope'), false);
    assert.equal(encoded.includes('correct-horse'), false);
  });
});
