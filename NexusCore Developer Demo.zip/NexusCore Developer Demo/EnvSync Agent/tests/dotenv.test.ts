import assert from 'node:assert/strict';
import { describe, test } from 'node:test';
import { formatEnv, parseEnv } from '../src/dotenv.ts';
import { EnvSyntaxError } from '../src/errors.ts';

describe('dotenv formatting', () => {
  test('round-trips values that need quoting', () => {
    const entries = [
      { key: 'PLAIN', value: 'abc_123' },
      { key: 'EMPTY', value: '' },
      { key: 'SPACED', value: 'hello world' },
      { key: 'QUOTED', value: 'say "hi"' },
      { key: 'SLASH', value: 'C:\\temp' },
      { key: 'MULTILINE', value: 'line1\nline2' },
      { key: 'HASH', value: 'keep # this' },
      { key: 'EQUALS', value: 'a=b' },
      { key: 'URL', value: 'postgres://db/app' },
    ];
    assert.deepEqual(parseEnv(formatEnv(entries)), entries);
  });

  test('parses export, comments, and inline comments', () => {
    const parsed = parseEnv(`
# comment
export DATABASE_URL=postgres://localhost/app
TOKEN=abc # comment
EMPTY=
`);
    assert.deepEqual(parsed, [
      { key: 'DATABASE_URL', value: 'postgres://localhost/app' },
      { key: 'TOKEN', value: 'abc' },
      { key: 'EMPTY', value: '' },
    ]);
  });

  test('rejects invalid lines without echoing the secret value', () => {
    assert.throws(
      () => parseEnv('NOT A LINE secret-value-xyz'),
      (error: unknown) => {
        assert.ok(error instanceof EnvSyntaxError);
        assert.equal(error.message.includes('secret-value-xyz'), false);
        assert.match(error.message, /line 1/);
        return true;
      },
    );
    assert.throws(() => parseEnv('1BAD=value'), EnvSyntaxError);
  });
});
