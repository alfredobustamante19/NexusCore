import assert from 'node:assert/strict';
import { after, before, describe, test } from 'node:test';
import { parseEnv } from '../src/dotenv.ts';
import { api, databaseBytes, startServer, stopServer, type Running } from './helpers.ts';

describe('secret versioning', { concurrency: false }, () => {
  let srv: Running;

  before(async () => {
    srv = await startServer();
  });

  after(async () => {
    await stopServer(srv);
  });

  test('snapshots, replaces, restores, and keeps values encrypted at rest', async () => {
    const created = await api(srv, '/api/v1/projects', {
      method: 'POST',
      body: { name: 'Ledger' },
    });
    assert.equal(created.status, 201, created.text);
    const project = created.json.project;
    const tokenRes = await api(srv, `/api/v1/projects/${project.id}/tokens`, {
      method: 'POST',
      body: { name: 'deploy', environments: ['*'], permissions: ['write'] },
    });
    const token = tokenRes.json.token.secret as string;

    const marker = 'nexusenv-plaintext-marker-7c1e9a4b';
    const first = await api(srv, `/api/v1/projects/${project.slug}/secrets`, {
      method: 'POST',
      token,
      cookie: false,
      body: {
        environment: 'production',
        comment: 'initial',
        secrets: [
          { key: 'MARKER_KEY', value: marker },
          { key: 'GREETING', value: 'hello world' },
          { key: 'PEM', value: 'line1\nline2' },
        ],
      },
    });
    assert.equal(first.status, 201, first.text);
    assert.equal(first.json.revision, 1);
    assert.equal(first.json.mode, 'replace');

    const pulled = await api(srv, `/api/v1/projects/${project.id}/env?environment=production`, {
      token,
      cookie: false,
    });
    assert.equal(pulled.status, 200, pulled.text);
    assert.equal(pulled.headers.get('x-nexusenv-revision'), '1');
    assert.match(pulled.headers.get('content-type') || '', /text\/plain/);
    assert.deepEqual(parseEnv(pulled.text), [
      { key: 'MARKER_KEY', value: marker },
      { key: 'GREETING', value: 'hello world' },
      { key: 'PEM', value: 'line1\nline2' },
    ]);

    const bytes = databaseBytes(srv);
    assert.equal(bytes.includes('MARKER_KEY'), true);
    assert.equal(bytes.includes(marker), false);
    assert.equal(bytes.includes('hello world'), false);

    const second = await api(
      srv,
      `/api/v1/projects/${project.id}/secrets?environment=staging&comment=from%20file`,
      {
        method: 'POST',
        token,
        cookie: false,
        contentType: 'text/plain',
        rawBody: 'ONLY_NEW=replaced\n',
      },
    );
    assert.equal(second.status, 201, second.text);
    assert.equal(second.json.environment, 'staging');

    const replaced = await api(srv, `/api/v1/projects/${project.id}/secrets`, {
      method: 'POST',
      token,
      cookie: false,
      body: { environment: 'production', comment: 'rotate', secrets: { ONLY_NEW: 'replaced' } },
    });
    assert.equal(replaced.status, 201, replaced.text);
    assert.equal(replaced.json.revision, 2);

    const current = await api(srv, `/api/v1/projects/${project.id}/env?environment=production&format=json`, {
      token,
      cookie: false,
    });
    assert.deepEqual(current.json.secrets, { ONLY_NEW: 'replaced' });
    assert.equal(current.json.revision, 2);

    const historical = await api(srv, `/api/v1/projects/${project.id}/environments/production/revisions/1`, {
      token,
      cookie: false,
    });
    assert.equal(historical.status, 200, historical.text);
    assert.equal(historical.json.secrets.find((item: { key: string }) => item.key === 'MARKER_KEY').value, marker);

    const empty = await api(srv, `/api/v1/projects/${project.id}/secrets`, {
      method: 'POST',
      token,
      cookie: false,
      body: { environment: 'production', secrets: {} },
    });
    assert.equal(empty.status, 400, empty.text);
    const duplicate = await api(srv, `/api/v1/projects/${project.id}/secrets`, {
      method: 'POST',
      token,
      cookie: false,
      body: {
        environment: 'production',
        secrets: [
          { key: 'A', value: '1' },
          { key: 'A', value: '2' },
        ],
      },
    });
    assert.equal(duplicate.status, 400, duplicate.text);

    const rollback = await api(srv, `/api/v1/projects/${project.id}/environments/production/rollback`, {
      method: 'POST',
      token,
      cookie: false,
      body: { revision: 1 },
    });
    assert.equal(rollback.status, 200, rollback.text);
    assert.equal(rollback.json.restoredFrom, 1);
    assert.equal(rollback.json.revision, 3);

    const restored = await api(srv, `/api/v1/projects/${project.id}/env?environment=production&format=json`, {
      token,
      cookie: false,
    });
    assert.equal(restored.json.revision, 3);
    assert.equal(restored.json.secrets.MARKER_KEY, marker);
    assert.equal(restored.json.secrets.GREETING, 'hello world');
    assert.equal(restored.json.secrets.ONLY_NEW, undefined);

    const stillThere = await api(srv, `/api/v1/projects/${project.id}/environments/production/revisions/2`, {
      token,
      cookie: false,
    });
    assert.equal(stillThere.json.secrets[0].key, 'ONLY_NEW');
    assert.equal(stillThere.json.secrets[0].value, 'replaced');

    const history = await api(srv, `/api/v1/projects/${project.id}/environments/production/revisions`, {
      token,
      cookie: false,
    });
    assert.deepEqual(
      history.json.revisions.map((item: { revision: number }) => item.revision),
      [3, 2, 1],
    );
    assert.equal(history.json.currentRevision, 3);
    assert.match(history.json.revisions[0].comment, /Rollback to revision 1/);

    const audit = await api(srv, `/api/v1/audit?projectId=${project.id}&limit=100`);
    const actions = audit.json.logs.map((entry: { action: string }) => entry.action);
    assert.equal(actions.includes('push'), true);
    assert.equal(actions.includes('pull'), true);
    assert.equal(actions.includes('rollback'), true);
    assert.equal(JSON.stringify(audit.json).includes(marker), false);

    const removed = await api(srv, `/api/v1/projects/${project.id}`, { method: 'DELETE' });
    assert.equal(removed.status, 200, removed.text);
    const remaining = srv.app.db.prepare('SELECT COUNT(*) AS total FROM secrets').get() as { total: number };
    assert.equal(Number(remaining.total), 0);
  });
});
