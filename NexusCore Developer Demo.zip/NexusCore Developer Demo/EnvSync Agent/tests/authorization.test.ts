import assert from 'node:assert/strict';
import { after, before, describe, test } from 'node:test';
import { api, cookieHeader, databaseBytes, startServer, stopServer, type Running } from './helpers.ts';

describe('token authorization', { concurrency: false }, () => {
  let srv: Running;

  before(async () => {
    srv = await startServer();
  });

  after(async () => {
    await stopServer(srv);
  });

  test('serves the admin UI and sets an HttpOnly session cookie', async () => {
    const page = await fetch(`${srv.baseUrl}/`);
    assert.equal(page.status, 200);
    assert.match(await page.text(), /NexusEnv/);
    const login = await api(srv, '/api/v1/admin/login', {
      method: 'POST',
      body: { username: srv.username, password: srv.password },
      cookie: false,
      csrf: false,
    });
    assert.equal(login.status, 200, login.text);
    const raw = login.headers.getSetCookie().join(';');
    assert.match(raw, /HttpOnly/);
    assert.match(raw, /SameSite=Strict/);
    assert.equal(cookieHeader(login.headers).includes('nexusenv_session='), true);

    const bad = await api(srv, '/api/v1/admin/login', {
      method: 'POST',
      body: { username: srv.username, password: 'wrong-password-123' },
      cookie: false,
      csrf: false,
    });
    assert.equal(bad.status, 401, bad.text);
    assert.equal(bad.json.error.message, 'Invalid username or password');
    assert.equal(JSON.stringify(bad.json).includes('wrong-password-123'), false);
  });

  test('requires the CSRF header for cookie mutations and allows bearer calls without it', async () => {
    const blocked = await api(srv, '/api/v1/projects', {
      method: 'POST',
      body: { name: 'Blocked' },
      csrf: false,
    });
    assert.equal(blocked.status, 403, blocked.text);
    assert.equal(blocked.json.error.code, 'csrf');

    const created = await api(srv, '/api/v1/projects', {
      method: 'POST',
      body: { name: 'Billing API', description: 'Card charges' },
    });
    assert.equal(created.status, 201, created.text);
    assert.equal(created.json.project.slug, 'billing-api');
    assert.deepEqual(
      created.json.project.environments.map((item: { name: string }) => item.name),
      ['dev', 'staging', 'production'],
    );
  });

  test('enforces project, environment, and permission scope and writes pull audits', async () => {
    const projectA = await api(srv, '/api/v1/projects', { method: 'POST', body: { name: 'Project A' } });
    const projectB = await api(srv, '/api/v1/projects', { method: 'POST', body: { name: 'Project B' } });
    assert.equal(projectA.status, 201, projectA.text);
    const idA = projectA.json.project.id as string;
    const idB = projectB.json.project.id as string;

    const writeToken = await api(srv, `/api/v1/projects/${idA}/tokens`, {
      method: 'POST',
      body: { name: 'writer', environments: ['production'], permissions: ['write'] },
    });
    const readToken = await api(srv, `/api/v1/projects/${idA}/tokens`, {
      method: 'POST',
      body: { name: 'reader', environments: ['staging'], permissions: ['read'] },
    });
    const prodRead = await api(srv, `/api/v1/projects/${idA}/tokens`, {
      method: 'POST',
      body: { name: 'prod-read', environments: ['production'], permissions: ['read'] },
    });
    assert.equal(writeToken.status, 201, writeToken.text);
    const writer = writeToken.json.token.secret as string;
    const reader = readToken.json.token.secret as string;
    const productionReader = prodRead.json.token.secret as string;

    const seeded = await api(srv, `/api/v1/projects/${idA}/secrets`, {
      method: 'POST',
      token: writer,
      body: { environment: 'production', secrets: { APP_TOKEN: 'seed-value' } },
    });
    assert.equal(seeded.status, 201, seeded.text);

    const missing = await api(srv, `/api/v1/projects/${idA}/env?environment=production`, { cookie: false });
    assert.equal(missing.status, 401, missing.text);

    const pull = await api(srv, `/api/v1/projects/${idA}/env?environment=production`, { token: productionReader, cookie: false });
    assert.equal(pull.status, 200, pull.text);
    assert.match(pull.headers.get('content-type') || '', /text\/plain/);
    assert.match(pull.text, /APP_TOKEN=seed-value/);

    const writeImpliesRead = await api(srv, `/api/v1/projects/${idA}/env?environment=production&format=json`, {
      token: writer,
      cookie: false,
    });
    assert.equal(writeImpliesRead.status, 200, writeImpliesRead.text);
    assert.equal(writeImpliesRead.json.secrets.APP_TOKEN, 'seed-value');

    const readerPush = await api(srv, `/api/v1/projects/${idA}/secrets`, {
      method: 'POST',
      token: reader,
      cookie: false,
      body: { environment: 'staging', secrets: { OTHER: 'x' } },
    });
    assert.equal(readerPush.status, 403, readerPush.text);

    const readerRollback = await api(srv, `/api/v1/projects/${idA}/environments/staging/rollback`, {
      method: 'POST',
      token: reader,
      cookie: false,
      body: { revision: 1 },
    });
    assert.equal(readerRollback.status, 403, readerRollback.text);

    const wrongEnv = await api(srv, `/api/v1/projects/${idA}/env?environment=production`, { token: reader, cookie: false });
    assert.equal(wrongEnv.status, 403, wrongEnv.text);

    const otherProject = await api(srv, `/api/v1/projects/${idB}/env?environment=production`, { token: writer, cookie: false });
    assert.equal(otherProject.status, 404, otherProject.text);

    const unknown = await api(srv, `/api/v1/projects/prj_does_not_exist/env?environment=production`, { cookie: false });
    assert.equal(unknown.status, 401, unknown.text);

    await api(srv, `/api/v1/projects/${idA}/tokens/${readToken.json.token.id}`, { method: 'DELETE' });
    const revoked = await api(srv, `/api/v1/projects/${idA}/env?environment=staging`, { token: reader, cookie: false });
    assert.equal(revoked.status, 401, revoked.text);

    const listed = await api(srv, `/api/v1/projects/${idA}/tokens`);
    assert.equal(JSON.stringify(listed.json).includes(writer), false);
    const bytes = databaseBytes(srv);
    assert.equal(bytes.includes(writer), false);
    assert.equal(bytes.includes(Buffer.from(readToken.json.token.prefix as string)), true);

    const audit = await api(srv, `/api/v1/audit?projectId=${idA}&action=pull&limit=50`);
    assert.equal(audit.status, 200, audit.text);
    const success = audit.json.logs.find((entry: { success: boolean; tokenPrefix: string }) => (
      entry.success && entry.tokenPrefix === prodRead.json.token.prefix
    ));
    assert.ok(success);
    assert.equal(success.ip, '127.0.0.1');
    assert.equal(success.tokenId, prodRead.json.token.id);
    assert.equal(Number.isNaN(Date.parse(success.timestamp)), false);
    assert.ok(Math.abs(Date.now() - Date.parse(success.timestamp)) < 120_000);
    assert.equal(JSON.stringify(audit.json).includes(productionReader), false);
    assert.equal(JSON.stringify(audit.json).includes('seed-value'), false);

    const failed = audit.json.logs.find((entry: { success: boolean; tokenPrefix: string | null }) => (
      entry.success === false && entry.tokenPrefix === readToken.json.token.prefix
    ));
    assert.ok(failed);
  });
});
