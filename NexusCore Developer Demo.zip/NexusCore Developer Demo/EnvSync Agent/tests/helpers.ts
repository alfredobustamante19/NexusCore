import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { mkdtemp, rm } from 'node:fs/promises';
import { createServer, type Server } from 'node:http';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { loadConfig } from '../src/config.ts';
import { createApp, type App } from '../src/server.ts';

export interface Running {
  baseUrl: string;
  app: App;
  server: Server;
  cookie: string;
  tmp: string;
  username: string;
  password: string;
}

export interface ApiResult {
  status: number;
  headers: Headers;
  text: string;
  json: any;
}

interface ApiOptions {
  method?: string;
  body?: unknown;
  rawBody?: string;
  contentType?: string;
  token?: string;
  cookie?: boolean;
  csrf?: boolean;
  headers?: Record<string, string>;
}

export async function startServer(overrides: Record<string, string> = {}): Promise<Running> {
  const tmp = await mkdtemp(path.join(tmpdir(), 'nexusenv-'));
  const password = 'test-password-123';
  const username = 'admin';
  const config = loadConfig({
    NEXUSENV_MASTER_KEY: randomBytes(32).toString('hex'),
    NEXUSENV_ADMIN_USERNAME: username,
    NEXUSENV_ADMIN_PASSWORD: password,
    NEXUSENV_DB_PATH: path.join(tmp, 'test.db'),
    NEXUSENV_HOST: '127.0.0.1',
    NEXUSENV_PORT: '0',
    NEXUSENV_RATE_LIMIT_MAX: '1000',
    NEXUSENV_RATE_LIMIT_WINDOW_MS: '60000',
    ...overrides,
  });
  const app = createApp(config);
  const server = createServer(app.handler);
  try {
    const port = await new Promise<number>((resolve, reject) => {
      server.once('error', reject);
      server.listen(config.port, config.host, () => {
        const address = server.address();
        if (!address || typeof address === 'string') {
          reject(new Error('expected a TCP port'));
          return;
        }
        resolve(address.port);
      });
    });
    const running: Running = {
      baseUrl: `http://127.0.0.1:${port}`,
      app,
      server,
      cookie: '',
      tmp,
      username,
      password,
    };
    const login = await api(running, '/api/v1/admin/login', {
      method: 'POST',
      body: { username, password },
      cookie: false,
      csrf: false,
    });
    if (login.status !== 200) {
      throw new Error(`login failed: ${login.text}`);
    }
    running.cookie = cookieHeader(login.headers);
    return running;
  } catch (error) {
    await closeServer(server, app);
    await rm(tmp, { recursive: true, force: true });
    throw error;
  }
}

export async function stopServer(running: Running): Promise<void> {
  await closeServer(running.server, running.app);
  await rm(running.tmp, { recursive: true, force: true });
}

async function closeServer(server: Server, app: App): Promise<void> {
  await new Promise<void>((resolve) => {
    server.closeAllConnections();
    server.close(() => resolve());
  });
  app.close();
}

export function cookieHeader(headers: Headers): string {
  const cookies = headers.getSetCookie();
  if (cookies.length === 0) {
    throw new Error('expected a set-cookie header');
  }
  return cookies.map((item) => item.split(';')[0] ?? '').join('; ');
}

export async function api(running: Running, requestPath: string, options: ApiOptions = {}): Promise<ApiResult> {
  const headers = new Headers(options.headers);
  const method = options.method ?? 'GET';
  if (options.token) {
    headers.set('authorization', `Bearer ${options.token}`);
  } else if (options.cookie !== false && running.cookie) {
    headers.set('cookie', running.cookie);
  }
  const unsafe = method !== 'GET' && method !== 'HEAD';
  if (unsafe && options.csrf !== false && !options.token) {
    headers.set('x-nexusenv-request', '1');
  }
  let body: string | undefined;
  if (options.rawBody !== undefined) {
    body = options.rawBody;
    if (options.contentType) headers.set('content-type', options.contentType);
  } else if (options.body !== undefined) {
    body = JSON.stringify(options.body);
    if (!headers.has('content-type')) headers.set('content-type', 'application/json');
  }
  const response = await fetch(`${running.baseUrl}${requestPath}`, { method, headers, body });
  const text = await response.text();
  let json: any = null;
  if (text) {
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }
  }
  return { status: response.status, headers: response.headers, text, json };
}

export function databaseBytes(running: Running): Buffer {
  running.app.db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
  const chunks = [readFileSync(running.app.config.dbPath)];
  for (const suffix of ['-wal', '-shm']) {
    const extra = `${running.app.config.dbPath}${suffix}`;
    if (existsSync(extra)) chunks.push(readFileSync(extra));
  }
  return Buffer.concat(chunks);
}
