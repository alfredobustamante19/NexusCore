# NexusEnv

NexusEnv is a self-hosted service for synchronizing `.env` files. One Node.js process stores project environments in SQLite. Secret **values** are encrypted with AES-256-GCM before they are written. A small dark-mode admin UI covers projects, revisions, API tokens, and the access audit.

Runtime dependencies: Node.js 24 or newer. SQLite, HTTP, and cryptography come from Node itself.

## Security architecture

```mermaid
flowchart LR
  Admin[Web admin] -->|session cookie| API[NexusEnv]
  CI[CLI or CI] -->|bearer token| API
  API --> Limit[Rate limiter]
  API --> Auth[Session or token hash]
  API --> Crypt[AES-256-GCM]
  Crypt --> DB[(SQLite ciphertext)]
  API --> Audit[Audit log]
```

| Data | At rest |
| --- | --- |
| Secret values | AES-256-GCM ciphertext, random 12-byte nonce, 16-byte tag |
| Secret names, project names, comments | Plaintext, so the UI can list keys without decrypting every row |
| API tokens | SHA-256 hash only. The secret is returned once at creation |
| Admin password | scrypt (`N=16384`, `r=8`, `p=1`) |
| Master key | Process environment only. It is never written to the database or sent to the browser |
| Sessions | SHA-256 hash of the cookie value. Cookie is `HttpOnly` and `SameSite=Strict` |

Each ciphertext is bound with associated data:

`nexusenv/v1 || project id || environment || secret name || revision`

A blob cannot be moved to another key, environment, project, or revision without failing authentication. SQLite is opened with foreign keys, `synchronous=FULL`, and `secure_delete`.

The service is a single administrator trust boundary. API tokens are the scoped credentials for automation. A token belongs to one project and lists environments (`dev`, `staging`, `production`, a custom name, or `*`) plus `read` and/or `write`. `write` includes `read`. A token presented for a different project receives the same `404` as an unknown project.

Transports: put TLS in front of the process (Caddy, nginx, or `NEXUSENV_TLS_CERT_FILE` / `NEXUSENV_TLS_KEY_FILE`). The API body contains plaintext secret values; encryption at rest does not replace HTTPS. Cookie-authenticated writes require header `X-NexusEnv-Request: 1`. Bearer tokens do not use that header. Credentials in the query string are rejected.

Pull and push each have their own sliding-window limit, keyed by client IP (or the first `X-Forwarded-For` hop when `NEXUSENV_TRUST_PROXY=true`). Login attempts are limited to 10 per 15 minutes per IP. Every secret pull writes an audit row with timestamp, client IP, user agent, token id, and token prefix (or `admin-session`). Failures are recorded too. Audit rows do not contain secret values or raw tokens.

A push replaces the whole environment with the submitted snapshot and stores it as the next revision. Rollback copies an older revision into a new revision, so history stays append-only.

## Requirements

- Node.js 24+
- A 32-byte master key from a CSPRNG
- An admin password of 10 to 256 characters on first boot

## Quick start

```bash
npm ci
npm test
npm run build
```

Generate a master key and start the service:

```bash
# macOS or Linux
export NEXUSENV_MASTER_KEY="$(node -e "process.stdout.write(require('crypto').randomBytes(32).toString('hex'))")"
export NEXUSENV_ADMIN_PASSWORD="replace-with-a-long-password"
npm start
```

```powershell
# Windows PowerShell
$env:NEXUSENV_MASTER_KEY = (node -e "process.stdout.write(require('crypto').randomBytes(32).toString('hex'))")
$env:NEXUSENV_ADMIN_PASSWORD = "replace-with-a-long-password"
npm start
```

Open `http://127.0.0.1:8787`. The default bind address is loopback. The admin password is stored as a scrypt hash on first boot and is not read from the environment again. To reset it, stop the process and remove the `admin_users` and `sessions` rows, or delete the database if you also intend to discard secrets.

Development, without the compile step:

```bash
npm run dev
```

## Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `NEXUSENV_MASTER_KEY` | required | 32 bytes as 64 hex characters or standard/base64url |
| `NEXUSENV_ADMIN_PASSWORD` | required on first boot | Initial administrator password |
| `NEXUSENV_ADMIN_USERNAME` | `admin` | Initial administrator username |
| `NEXUSENV_HOST` | `127.0.0.1` | Bind address. Use `0.0.0.0` behind a proxy |
| `NEXUSENV_PORT` | `8787` | Bind port. `0` lets the OS choose |
| `NEXUSENV_DATA_DIR` | `./data` | Directory for the database when `NEXUSENV_DB_PATH` is unset |
| `NEXUSENV_DB_PATH` | `$DATA_DIR/nexusenv.db` | SQLite file |
| `NEXUSENV_SESSION_TTL_HOURS` | `12` | Admin session lifetime |
| `NEXUSENV_RATE_LIMIT_MAX` | `60` | Requests per window, per IP, separately for pull and push |
| `NEXUSENV_RATE_LIMIT_WINDOW_MS` | `60000` | Rate-limit window |
| `NEXUSENV_COOKIE_SECURE` | `true` when TLS files are set | Set `true` behind an HTTPS proxy |
| `NEXUSENV_TRUST_PROXY` | `false` | Use the first `X-Forwarded-For` address in the audit log |
| `NEXUSENV_TLS_CERT_FILE` | empty | PEM certificate. Set together with the key |
| `NEXUSENV_TLS_KEY_FILE` | empty | PEM private key |

Limits: 200 secrets per snapshot, 16 KiB per value, 2 MiB request body.

Copy `.env.example` to `.env` and fill the two required values. Do not commit `.env`.

## Deployment

Run one process per database file. Shut it down before copying the database so the WAL is checkpointed.

### systemd

`/etc/nexusenv/nexusenv.env` should be mode `0600` and owned by the service user:

```
NEXUSENV_MASTER_KEY=...
NEXUSENV_ADMIN_PASSWORD=...
NEXUSENV_HOST=127.0.0.1
NEXUSENV_DATA_DIR=/var/lib/nexusenv
NEXUSENV_COOKIE_SECURE=true
NEXUSENV_TRUST_PROXY=true
```

```
[Service]
User=nexusenv
WorkingDirectory=/opt/nexusenv
EnvironmentFile=/etc/nexusenv/nexusenv.env
ExecStart=/usr/bin/node /opt/nexusenv/dist/index.js
Restart=on-failure
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/var/lib/nexusenv
```

### Reverse proxy

```
# Caddy
secrets.example.com {
  reverse_proxy 127.0.0.1:8787
}
```

Forward `Host`, `X-Forwarded-For`, and `X-Forwarded-Proto`. Set `NEXUSENV_COOKIE_SECURE=true` and `NEXUSENV_TRUST_PROXY=true`.

### Docker

The image compiles TypeScript in a build stage and runs `node dist/index.js` as the `node` user. Put the master key and admin password in a `.env` file next to the compose file, then:

```bash
docker compose up -d --build
```

The database volume is `nexusenv-data`. TLS still belongs on the proxy unless you mount a certificate and set the TLS file variables.

## Token management

1. Sign in to the admin UI, open a project, and choose **Tokens**.
2. Pick environments and `read` and/or `write`. `*` covers every current and future environment in that project.
3. Copy the `nxe_…` secret immediately. The server stores `SHA-256(token)` and a 12-character prefix (`nxe_` plus 8 characters) for the audit log.
4. Revoke a token from the same screen. Revocation takes effect on the next request. The row is kept so older audit entries still resolve.

Prefer `NEXUSENV_TOKEN` over `--token` when the process list or shell history is shared. A leaked token can be revoked without rotating the master key. Rotating the master key is a decrypt-and-re-encrypt of every revision; this version does not do that automatically. Losing the master key makes stored values unrecoverable.

## HTTP API

Errors:

```json
{ "error": { "code": "unauthorized", "message": "Invalid API token" } }
```

Successful pulls send `X-NexusEnv-Revision` and `Cache-Control: no-store`. The default body is a `.env` file. Add `format=json` for an object. Each push is a full snapshot (`mode: "replace"`).

```bash
BASE=http://127.0.0.1:8787

curl -s "$BASE/api/v1/health"

curl -s -c cookies.txt -H 'content-type: application/json' \
  -d '{"username":"admin","password":"replace-with-a-long-password"}' \
  "$BASE/api/v1/admin/login"

curl -s -b cookies.txt -H 'content-type: application/json' -H 'x-nexusenv-request: 1' \
  -d '{"name":"billing","description":"Billing service"}' \
  "$BASE/api/v1/projects"

# Use the project id from the response.
curl -s -b cookies.txt -H 'content-type: application/json' -H 'x-nexusenv-request: 1' \
  -d '{"name":"prod-read","environments":["production"],"permissions":["read"]}' \
  "$BASE/api/v1/projects/prj_example/tokens"

curl -s -H "authorization: Bearer nxe_example" -H 'content-type: application/json' \
  -d '{"environment":"production","comment":"initial","secrets":{"DATABASE_URL":"postgres://db/app"}}' \
  "$BASE/api/v1/projects/prj_example/secrets"

curl -s -H "authorization: Bearer nxe_example" \
  "$BASE/api/v1/projects/prj_example/env?environment=production"

curl -s -H "authorization: Bearer nxe_example" -H 'content-type: text/plain' \
  --data-binary @.env \
  "$BASE/api/v1/projects/prj_example/secrets?environment=production&comment=from-file"

curl -s -X POST -H "authorization: Bearer nxe_example" -H 'content-type: application/json' \
  -d '{"revision":1}' \
  "$BASE/api/v1/projects/prj_example/environments/production/rollback"

curl -s -b cookies.txt \
  "$BASE/api/v1/audit?projectId=prj_example&limit=50"
```

`GET /api/v1/projects/:id/env` and `POST /api/v1/projects/:id/secrets` are the machine pull and push endpoints. Revision reads of secret values are rate-limited with pulls. Rollbacks are rate-limited with pushes. `429` responses include `Retry-After`.

## CLI

The CLI is compiled to `dist/cli.js`.

```bash
export NEXUSENV_TOKEN="nxe_..."
node dist/cli.js push --project prj_example --env production --file .env --comment "rotate db"
node dist/cli.js pull --project prj_example --env production --out .env.production
```

`--server` defaults to `http://127.0.0.1:8787`. `pull` writes the `.env` document to stdout unless `--out` is set (`0600` on platforms that honor the mode).

## Backup

Stop the service so `close()` can checkpoint the WAL, then copy `nexusenv.db`. Store the master key somewhere else. A backup without the key cannot be decrypted. A key without the database cannot reconstruct the values.

## Development

```bash
npm test          # encryption, dotenv, authorization, versioning, rate limit
npm run typecheck
npm run build
npm run smoke     # boots dist/, pushes through the CLI, pulls the value back
npm run package   # writes NexusEnv-Release.zip without node_modules or .git
```

Tests use temporary SQLite files and loopback ports. They assert that secret values and raw API tokens are absent from the database bytes, that tampered AES-GCM blobs fail closed, that token scope is enforced, that rollback preserves older revisions, and that pull and push return `429` on separate counters.
