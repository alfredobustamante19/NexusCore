import { spawnSync } from 'node:child_process';
import { existsSync, rmSync } from 'node:fs';

const archive = 'NexusEnv-Release.zip';
if (existsSync(archive)) rmSync(archive);

if (!existsSync('dist/index.js') || !existsSync('dist/web/index.html')) {
  console.error('Build dist/ before packaging. Run npm run build.');
  process.exit(1);
}

const result = spawnSync('tar', [
  '-a',
  '-c',
  '-f',
  archive,
  '--exclude',
  'node_modules',
  '--exclude',
  '.git',
  '--exclude',
  'data',
  '--exclude',
  archive,
  '--exclude',
  'probe-tmp',
  '.',
], { stdio: 'inherit' });

if (result.status !== 0) {
  process.exit(result.status ?? 1);
}

const listing = spawnSync('tar', ['-tf', archive], { encoding: 'utf8' });
if (listing.status !== 0) {
  console.error(listing.stderr);
  process.exit(listing.status ?? 1);
}
const names = listing.stdout.split(/\r?\n/);
const forbidden = names.filter((name) => /(^|\/)(node_modules|\.git)(\/|$)/.test(name.replaceAll('\\', '/')));
if (forbidden.length > 0) {
  console.error(`Archive contains excluded paths:\n${forbidden.slice(0, 20).join('\n')}`);
  process.exit(1);
}
for (const required of ['src/index.ts', 'dist/index.js', 'dist/web/index.html', 'README.md', 'package.json']) {
  const found = names.some((name) => name.replaceAll('\\', '/').replace(/^\.\//, '') === required || name.replaceAll('\\', '/').endsWith(`/${required}`));
  if (!found) {
    console.error(`Archive is missing ${required}`);
    process.exit(1);
  }
}
console.log(JSON.stringify({ msg: 'packaged', archive, entries: names.filter(Boolean).length }));
