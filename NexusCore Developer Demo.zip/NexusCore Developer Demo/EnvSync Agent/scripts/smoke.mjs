import { spawn } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';

const tmp = await mkdtemp(path.join(tmpdir(), 'nexusenv-smoke-'));
const password = 'smoke-password-123';
const child = spawn(process.execPath, ['dist/index.js'], {
  env: {
    ...process.env,
    NEXUSENV_MASTER_KEY: randomBytes(32).toString('hex'),
    NEXUSENV_ADMIN_PASSWORD: password,
    NEXUSENV_ADMIN_USERNAME: 'admin',
    NEXUSENV_DB_PATH: path.join(tmp, 'nexusenv.db'),
    NEXUSENV_HOST: '127.0.0.1',
    NEXUSENV_PORT: '0',
    NEXUSENV_RATE_LIMIT_MAX: '1000',
  },
  stdio: ['ignore', 'pipe', 'pipe'],
});

let stdout = '';
let stderr = '';
child.stdout.setEncoding('utf8');
child.stderr.setEncoding('utf8');
child.stdout.on('data', (chunk) => {
  stdout += chunk;
});
child.stderr.on('data', (chunk) => {
  stderr += chunk;
});

try {
  const port = await waitForPort(child);
  const base = `http://127.0.0.1:${port}`;
  const health = await fetch(`${base}/api/v1/health`);
  if (!health.ok) throw new Error(`health ${health.status}`);
  const login = await fetch(`${base}/api/v1/admin/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password }),
  });
  if (!login.ok) throw new Error(await login.text());
  const cookie = login.headers.getSetCookie().map((item) => item.split(';')[0]).join('; ');
  const projectRes = await fetch(`${base}/api/v1/projects`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', cookie, 'x-nexusenv-request': '1' },
    body: JSON.stringify({ name: 'Smoke' }),
  });
  const projectBody = await projectRes.json();
  if (!projectRes.ok) throw new Error(JSON.stringify(projectBody));
  const projectId = projectBody.project.id;
  const tokenRes = await fetch(`${base}/api/v1/projects/${projectId}/tokens`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', cookie, 'x-nexusenv-request': '1' },
    body: JSON.stringify({ name: 'smoke', environments: ['dev'], permissions: ['write'] }),
  });
  const tokenBody = await tokenRes.json();
  if (!tokenRes.ok) throw new Error(JSON.stringify(tokenBody));
  const token = tokenBody.token.secret;
  const envFile = path.join(tmp, 'app.env');
  await writeFile(envFile, 'SMOKE_KEY=smoke-value\n', 'utf8');
  await runCli(['push', '--server', base, '--project', projectId, '--env', 'dev', '--token', token, '--file', envFile, '--comment', 'smoke']);
  const pulled = await runCli(['pull', '--server', base, '--project', projectId, '--env', 'dev', '--token', token]);
  if (!pulled.includes('SMOKE_KEY=smoke-value')) {
    throw new Error(`unexpected pull output: ${pulled}`);
  }
  const page = await fetch(`${base}/`);
  const html = await page.text();
  if (!html.includes('NexusEnv')) throw new Error('admin UI missing from production build');
  console.log(JSON.stringify({ level: 'info', msg: 'smoke ok', port }));
} finally {
  child.kill();
  await new Promise((resolve) => child.once('exit', resolve));
  await rm(tmp, { recursive: true, force: true });
}

function waitForPort(proc) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`startup timeout\n${stdout}\n${stderr}`));
    }, 20_000);
    const check = () => {
      for (const line of stdout.split(/\r?\n/)) {
        if (!line.startsWith('{')) continue;
        try {
          const parsed = JSON.parse(line);
          if (parsed.msg === 'listening') {
            clearTimeout(timer);
            resolve(parsed.port);
            return;
          }
        } catch {
          // Partial JSON line.
        }
      }
    };
    proc.stdout.on('data', check);
    proc.once('exit', (code) => {
      clearTimeout(timer);
      reject(new Error(`server exited ${code}\n${stdout}\n${stderr}`));
    });
  });
}

function runCli(args) {
  return new Promise((resolve, reject) => {
    const cli = spawn(process.execPath, ['dist/cli.js', ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    let err = '';
    cli.stdout.setEncoding('utf8');
    cli.stderr.setEncoding('utf8');
    cli.stdout.on('data', (chunk) => {
      out += chunk;
    });
    cli.stderr.on('data', (chunk) => {
      err += chunk;
    });
    cli.once('exit', (code) => {
      if (code !== 0) reject(new Error(err || out || `cli exited ${code}`));
      else resolve(out);
    });
  });
}
