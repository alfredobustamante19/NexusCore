const state = {
  me: null,
  projects: [],
  project: null,
  environment: null,
  tab: 'secrets',
  secrets: [],
  savedFingerprint: '[]',
  comment: '',
  revisions: [],
  currentRevision: 0,
  tokens: [],
  issuedToken: null,
  audit: [],
  auditTotal: 0,
  auditOffset: 0,
  auditProject: '',
  auditAction: '',
  reveal: false,
};

let ignoreHash = false;
let toastTimer = 0;

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (ch) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]
  ));
}

function toast(message, kind) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.dataset.kind = kind || 'ok';
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3400);
}

function fingerprint(list) {
  return JSON.stringify(list.map((item) => [item.key, item.value]));
}

function collectSecretsFromDom() {
  return [...document.querySelectorAll('.secret-row')].map((row) => ({
    key: row.querySelector('[data-field="key"]').value,
    value: row.querySelector('[data-field="value"]').value,
  }));
}

function syncEditor() {
  if (!document.getElementById('secret-table')) return;
  state.secrets = collectSecretsFromDom();
  const comment = document.getElementById('revision-comment');
  if (comment) state.comment = comment.value;
}

function isDirty() {
  if (!state.project) return false;
  if (document.getElementById('secret-table')) {
    return fingerprint(collectSecretsFromDom()) !== state.savedFingerprint;
  }
  return fingerprint(state.secrets) !== state.savedFingerprint;
}

function sameEditor(hash) {
  if (!state.project || !state.environment) return false;
  return hash.startsWith(`#/projects/${state.project.id}/${state.environment}/`);
}

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  headers.set('X-NexusEnv-Request', '1');
  let body;
  if (options.body !== undefined) {
    headers.set('Content-Type', 'application/json');
    body = JSON.stringify(options.body);
  }
  const response = await fetch(path, {
    method: options.method || 'GET',
    headers,
    body,
    credentials: 'same-origin',
  });
  const text = await response.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch { data = { raw: text }; }
  }
  if (!response.ok) {
    const message = data && data.error && data.error.message ? data.error.message : response.statusText;
    if (response.status === 401 && message === 'Authentication required') {
      state.me = null;
      renderLogin();
    }
    const error = new Error(message);
    error.status = response.status;
    throw error;
  }
  return data;
}

function parseHash() {
  const raw = (location.hash || '#/projects').replace(/^#\//, '');
  const parts = raw.split('/').filter(Boolean).map((part) => {
    try { return decodeURIComponent(part); } catch { return part; }
  });
  if (parts[0] === 'audit') return { name: 'audit' };
  if (parts[0] === 'projects' && parts[1]) {
    return {
      name: 'project',
      id: parts[1],
      env: parts[2] || null,
      tab: ['secrets', 'history', 'tokens'].includes(parts[3]) ? parts[3] : 'secrets',
    };
  }
  return { name: 'projects' };
}

function renderLogin() {
  document.getElementById('app').innerHTML = `
    <div class="login-wrap">
      <section class="login-hero">
        <div class="brand"><span class="mark">N</span> NexusEnv</div>
        <h1>Secrets encrypted before they reach disk.</h1>
        <p class="lede">A self-hosted store for project environments. Values are sealed with AES-256-GCM under the server master key. This browser never receives that key.</p>
        <ul class="points">
          <li>Scoped API tokens for pull and push</li>
          <li>Immutable revisions with rollback</li>
          <li>Access audit for every secret pull</li>
        </ul>
      </section>
      <section class="login-panel">
        <form class="card" id="login-form">
          <h2>Administrator</h2>
          <label class="field"><span>Username</span><input name="username" autocomplete="username" required value="admin" /></label>
          <label class="field"><span>Password</span><input name="password" type="password" autocomplete="current-password" required /></label>
          <button class="primary" type="submit">Sign in</button>
          <p class="tiny" id="health-line">Checking service…</p>
        </form>
      </section>
    </div>`;
  document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector('button');
    button.disabled = true;
    try {
      const data = await api('/api/v1/admin/login', {
        method: 'POST',
        body: {
          username: form.username.value.trim(),
          password: form.password.value,
        },
      });
      state.me = data.username;
      ensureShell();
      if (!location.hash) location.hash = '#/projects';
      await route();
    } catch (error) {
      toast(error.message, 'bad');
      button.disabled = false;
    }
  });
  api('/api/v1/health').then((health) => {
    const line = document.getElementById('health-line');
    if (line) line.textContent = `Service ${health.version} is reachable.`;
  }).catch(() => {
    const line = document.getElementById('health-line');
    if (line) line.textContent = 'The NexusEnv process is not responding.';
  });
}

function ensureShell() {
  if (document.getElementById('main')) return;
  document.getElementById('app').innerHTML = `
    <div class="shell">
      <aside class="side">
        <div class="brand"><span class="mark">N</span> NexusEnv</div>
        <nav>
          <a href="#/projects" data-nav="#/projects">Projects</a>
          <a href="#/audit" data-nav="#/audit">Audit log</a>
        </nav>
        <div class="side-foot">
          <div class="tiny">Signed in as <strong id="who"></strong></div>
          <button type="button" id="logout">Log out</button>
          <details>
            <summary>Change password</summary>
            <form id="password-form" class="field">
              <input name="currentPassword" type="password" autocomplete="current-password" aria-label="Current password" placeholder="Current password" required />
              <input name="newPassword" type="password" autocomplete="new-password" aria-label="New password" placeholder="New password" minlength="10" required />
              <button type="submit">Update password</button>
            </form>
          </details>
        </div>
      </aside>
      <main id="main"></main>
    </div>`;
  document.getElementById('who').textContent = state.me || '';
  document.querySelector('.side').addEventListener('click', (event) => {
    const link = event.target.closest('a[href^="#"]');
    if (!link) return;
    event.preventDefault();
    location.hash = link.getAttribute('href');
  });
  document.getElementById('logout').addEventListener('click', async () => {
    try { await api('/api/v1/admin/logout', { method: 'POST', body: {} }); } catch { /* cleared locally */ }
    state.me = null;
    state.project = null;
    renderLogin();
  });
  document.getElementById('password-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      await api('/api/v1/admin/password', {
        method: 'POST',
        body: {
          currentPassword: form.currentPassword.value,
          newPassword: form.newPassword.value,
        },
      });
      state.me = null;
      toast('Password updated. Sign in again.');
      renderLogin();
    } catch (error) {
      toast(error.message, 'bad');
    }
  });
}

function setNav() {
  document.querySelectorAll('[data-nav]').forEach((link) => {
    const target = link.getAttribute('data-nav');
    const current = location.hash.startsWith(target) && (target !== '#/projects' || !location.hash.startsWith('#/audit'));
    link.setAttribute('aria-current', current ? 'page' : 'false');
  });
}

async function route() {
  if (!state.me) {
    renderLogin();
    return;
  }
  ensureShell();
  setNav();
  const parsed = parseHash();
  const next = location.hash || '#/projects';
  if (isDirty() && !sameEditor(next)) {
    const ok = window.confirm('Discard unsaved secret edits?');
    if (!ok) {
      ignoreHash = true;
      location.hash = `#/projects/${state.project.id}/${state.environment}/${state.tab}`;
      return;
    }
  }
  if (parsed.name === 'audit') {
    syncEditor();
    await renderAudit();
    return;
  }
  if (parsed.name === 'project') {
    const same = state.project && state.project.id === parsed.id && state.environment === parsed.env;
    if (same) {
      syncEditor();
      state.tab = parsed.tab;
      renderProject();
      return;
    }
    state.tab = parsed.tab;
    await loadProject(parsed.id, parsed.env);
    return;
  }
  syncEditor();
  state.project = null;
  await renderProjects();
}

async function renderProjects() {
  const data = await api('/api/v1/projects');
  state.projects = data.projects;
  const main = document.getElementById('main');
  main.innerHTML = `
    <div class="page-head">
      <div>
        <h1>Projects</h1>
        <p class="muted">Each project keeps dev, staging, and production environments. Pushes store a full snapshot.</p>
      </div>
    </div>
    <form class="panel" id="create-project">
      <h2>New project</h2>
      <div class="row">
        <label class="field grow"><span>Name</span><input name="name" maxlength="80" required placeholder="Billing API" /></label>
        <label class="field grow-2"><span>Description</span><input name="description" maxlength="500" placeholder="Optional" /></label>
      </div>
      <button class="primary" type="submit">Create project</button>
    </form>
    <div class="project-grid">
      ${state.projects.map((project) => `
        <button class="project-card" type="button" data-open="${esc(project.id)}">
          <strong>${esc(project.name)}</strong>
          <span class="tiny">${esc(project.slug)}</span>
          <span class="muted">${esc(project.description || 'No description')}</span>
          <span class="env-pills">${project.environments.map((env) => `<span class="badge">${esc(env.name)} r${esc(env.currentRevision)}</span>`).join(' ')}</span>
        </button>`).join('') || '<p class="muted">No projects yet.</p>'}
    </div>`;
  document.getElementById('create-project').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      const created = await api('/api/v1/projects', {
        method: 'POST',
        body: { name: form.name.value, description: form.description.value },
      });
      location.hash = `#/projects/${created.project.id}/dev/secrets`;
    } catch (error) {
      toast(error.message, 'bad');
    }
  });
  main.querySelectorAll('[data-open]').forEach((button) => {
    button.addEventListener('click', () => {
      location.hash = `#/projects/${button.getAttribute('data-open')}/dev/secrets`;
    });
  });
}

async function loadProject(id, preferredEnv) {
  try {
    const data = await api(`/api/v1/projects/${encodeURIComponent(id)}`);
    state.project = data.project;
    const names = data.project.environments.map((env) => env.name);
    state.environment = names.includes(preferredEnv) ? preferredEnv : (names[0] || null);
    if (state.issuedToken && state.issuedToken.projectId !== data.project.id) state.issuedToken = null;
    await loadEnvironment();
    renderProject();
  } catch (error) {
    toast(error.message, 'bad');
    location.hash = '#/projects';
  }
}

async function loadEnvironment() {
  const id = state.project.id;
  const env = state.environment;
  const [envData, revData, tokenData] = await Promise.all([
    api(`/api/v1/projects/${encodeURIComponent(id)}/env?environment=${encodeURIComponent(env)}&format=json`),
    api(`/api/v1/projects/${encodeURIComponent(id)}/environments/${encodeURIComponent(env)}/revisions`),
    api(`/api/v1/projects/${encodeURIComponent(id)}/tokens`),
  ]);
  state.secrets = Object.entries(envData.secrets).map(([key, value]) => ({ key, value }));
  state.savedFingerprint = fingerprint(state.secrets);
  state.comment = '';
  state.currentRevision = envData.revision;
  state.revisions = revData.revisions;
  state.tokens = tokenData.tokens;
  const match = state.project.environments.find((item) => item.name === env);
  if (match) match.currentRevision = envData.revision;
}

function renderProject() {
  const project = state.project;
  const main = document.getElementById('main');
  const activeTokens = state.tokens.filter((token) => !token.revokedAt).length;
  main.innerHTML = `
    <div class="page-head">
      <div>
        <h1>${esc(project.name)}</h1>
        <p class="muted">${esc(project.description || 'No description')} · <span class="mono">${esc(project.id)}</span></p>
      </div>
      <div class="actions">
        <button type="button" id="copy-id">Copy id</button>
        <button type="button" class="danger" id="delete-project">Delete project</button>
      </div>
    </div>
    <div class="switch" id="env-switch">
      ${project.environments.map((env) => `
        <button type="button" data-env="${esc(env.name)}" aria-pressed="${env.name === state.environment}">
          ${esc(env.name)} <span class="tiny">r${esc(env.currentRevision)}</span>
        </button>`).join('')}
    </div>
    <form class="row" id="add-env">
      <input name="name" maxlength="32" placeholder="custom environment" pattern="[a-z][a-z0-9_-]{0,31}" />
      <button type="submit">Add environment</button>
      <button type="button" class="danger" id="delete-env">Delete ${esc(state.environment)}</button>
    </form>
    <div class="tabs" role="tablist">
      <button type="button" data-tab="secrets" aria-selected="${state.tab === 'secrets'}">Secrets (${state.secrets.length})</button>
      <button type="button" data-tab="history" aria-selected="${state.tab === 'history'}">History (${state.revisions.length})</button>
      <button type="button" data-tab="tokens" aria-selected="${state.tab === 'tokens'}">Tokens (${activeTokens})</button>
    </div>
    <section class="panel" id="tab-panel"></section>`;

  document.getElementById('copy-id').addEventListener('click', () => copyText(project.id));
  document.getElementById('delete-project').addEventListener('click', async () => {
    if (!window.confirm(`Delete ${project.name} and all of its secrets?`)) return;
    try {
      await api(`/api/v1/projects/${encodeURIComponent(project.id)}`, { method: 'DELETE' });
      state.project = null;
      location.hash = '#/projects';
    } catch (error) {
      toast(error.message, 'bad');
    }
  });
  document.getElementById('env-switch').addEventListener('click', (event) => {
    const button = event.target.closest('[data-env]');
    if (!button) return;
    location.hash = `#/projects/${project.id}/${button.getAttribute('data-env')}/${state.tab}`;
  });
  document.getElementById('add-env').addEventListener('submit', async (event) => {
    event.preventDefault();
    const name = event.currentTarget.name.value.trim();
    try {
      await api(`/api/v1/projects/${encodeURIComponent(project.id)}/environments`, { method: 'POST', body: { name } });
      location.hash = `#/projects/${project.id}/${name}/secrets`;
      await loadProject(project.id, name);
    } catch (error) {
      toast(error.message, 'bad');
    }
  });
  document.getElementById('delete-env').addEventListener('click', async () => {
    if (!window.confirm(`Delete the ${state.environment} environment and its revisions?`)) return;
    try {
      await api(`/api/v1/projects/${encodeURIComponent(project.id)}/environments/${encodeURIComponent(state.environment)}`, { method: 'DELETE' });
      state.project = null;
      location.hash = `#/projects/${project.id}`;
    } catch (error) {
      toast(error.message, 'bad');
    }
  });
  main.querySelector('.tabs').addEventListener('click', (event) => {
    const button = event.target.closest('[data-tab]');
    if (!button) return;
    location.hash = `#/projects/${project.id}/${state.environment}/${button.getAttribute('data-tab')}`;
  });
  if (state.tab === 'history') renderHistory(document.getElementById('tab-panel'));
  else if (state.tab === 'tokens') renderTokens(document.getElementById('tab-panel'));
  else renderSecrets(document.getElementById('tab-panel'));
}

function renderSecrets(panel) {
  panel.innerHTML = `
    <div class="row">
      <strong>Revision ${esc(state.currentRevision)}</strong>
      <span class="tiny">Saving writes a new encrypted snapshot. Omitted keys are dropped from the new revision and kept in history.</span>
    </div>
    <div class="actions">
      <button type="button" id="add-secret">Add key</button>
      <button type="button" id="toggle-reveal">${state.reveal ? 'Hide values' : 'Reveal values'}</button>
    </div>
    <div class="scroll">
      <table id="secret-table">
        <thead><tr><th>Key</th><th>Value</th><th></th></tr></thead>
        <tbody>
          ${state.secrets.map((secret, index) => `
            <tr class="secret-row" data-i="${index}">
              <td><input class="key-input" data-field="key" spellcheck="false" autocomplete="off" value="${esc(secret.key)}" /></td>
              <td><textarea class="${state.reveal ? '' : 'masked'}" data-field="value" spellcheck="false" autocomplete="off">${esc(secret.value)}</textarea></td>
              <td><button type="button" data-remove="${index}">Remove</button></td>
            </tr>`).join('') || '<tr><td colspan="3" class="muted">No secrets in this revision.</td></tr>'}
        </tbody>
      </table>
    </div>
    <label class="field"><span>Revision comment</span><input id="revision-comment" maxlength="500" value="${esc(state.comment)}" placeholder="rotate database password" /></label>
    <button class="primary" type="button" id="save-secrets">Save revision</button>`;

  document.getElementById('add-secret').addEventListener('click', () => {
    syncEditor();
    state.secrets.push({ key: '', value: '' });
    renderSecrets(panel);
    const inputs = panel.querySelectorAll('[data-field="key"]');
    const last = inputs[inputs.length - 1];
    if (last) last.focus();
  });
  panel.querySelectorAll('[data-remove]').forEach((button) => {
    button.addEventListener('click', () => {
      syncEditor();
      state.secrets.splice(Number(button.getAttribute('data-remove')), 1);
      renderSecrets(panel);
    });
  });
  document.getElementById('toggle-reveal').addEventListener('click', () => {
    syncEditor();
    state.reveal = !state.reveal;
    renderSecrets(panel);
  });
  document.getElementById('save-secrets').addEventListener('click', async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    const secrets = collectSecretsFromDom().map((item) => ({ key: item.key.trim(), value: item.value })).filter((item) => item.key || item.value);
    if (secrets.length === 0 || secrets.some((item) => !item.key)) {
      toast('Add at least one secret key before saving.', 'bad');
      button.disabled = false;
      return;
    }
    try {
      const result = await api(`/api/v1/projects/${encodeURIComponent(state.project.id)}/secrets`, {
        method: 'POST',
        body: {
          environment: state.environment,
          comment: document.getElementById('revision-comment').value,
          secrets,
        },
      });
      toast(`Saved revision ${result.revision}`);
      await loadEnvironment();
      renderProject();
    } catch (error) {
      toast(error.message, 'bad');
      button.disabled = false;
    }
  });
}

function renderHistory(panel) {
  panel.innerHTML = `
    <p class="tiny">Rollback copies an older revision into a new revision. Earlier revisions stay available.</p>
    <div class="scroll"><table>
      <thead><tr><th>Rev</th><th>When</th><th>Actor</th><th>Keys</th><th>Comment</th><th></th></tr></thead>
      <tbody>
        ${state.revisions.map((rev) => `
          <tr>
            <td class="mono">${esc(rev.revision)}${rev.revision === state.currentRevision ? ' <span class="badge ok">current</span>' : ''}</td>
            <td>${esc(formatTime(rev.createdAt))}</td>
            <td>${esc(rev.actorLabel)}</td>
            <td>${esc(rev.keyCount)}</td>
            <td>${esc(rev.comment || '')}</td>
            <td>${rev.revision === state.currentRevision ? '' : `<button type="button" data-restore="${esc(rev.revision)}">Restore</button>`}</td>
          </tr>`).join('') || '<tr><td colspan="6" class="muted">No revisions yet.</td></tr>'}
      </tbody>
    </table></div>
    <pre id="preview" class="mono muted"></pre>`;
  panel.querySelectorAll('[data-restore]').forEach((button) => {
    button.addEventListener('click', async () => {
      const revision = Number(button.getAttribute('data-restore'));
      if (!window.confirm(`Restore revision ${revision} as a new snapshot?`)) return;
      try {
        const result = await api(`/api/v1/projects/${encodeURIComponent(state.project.id)}/environments/${encodeURIComponent(state.environment)}/rollback`, {
          method: 'POST',
          body: { revision },
        });
        toast(`Restored revision ${revision} as ${result.revision}`);
        await loadEnvironment();
        renderProject();
      } catch (error) {
        toast(error.message, 'bad');
      }
    });
  });
}

function renderTokens(panel) {
  const envs = state.project.environments.map((env) => `
    <label class="check"><input type="checkbox" name="env" value="${esc(env.name)}" ${env.name === state.environment ? 'checked' : ''} /> ${esc(env.name)}</label>`).join('');
  const issued = state.issuedToken && state.issuedToken.projectId === state.project.id
    ? `<div class="callout"><strong>Copy this token now. NexusEnv stores only its hash.</strong><input class="token-secret" readonly value="${esc(state.issuedToken.secret)}" /><button type="button" id="copy-token">Copy token</button></div>`
    : '';
  panel.innerHTML = `
    ${issued}
    <form id="create-token" class="stack">
      <h2>New token</h2>
      <label class="field"><span>Name</span><input name="name" maxlength="80" required placeholder="ci-production" /></label>
      <div class="row">${envs}<label class="check"><input type="checkbox" name="env" value="*" /> all environments</label></div>
      <div class="row">
        <label class="check"><input type="checkbox" name="perm" value="read" checked /> read</label>
        <label class="check"><input type="checkbox" name="perm" value="write" /> write</label>
      </div>
      <button class="primary" type="submit">Create token</button>
    </form>
    <div class="scroll"><table>
      <thead><tr><th>Name</th><th>Prefix</th><th>Scope</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${state.tokens.map((token) => `
          <tr>
            <td>${esc(token.name)}</td>
            <td class="mono">${esc(token.prefix)}</td>
            <td>${esc(token.environments.join(', '))} · ${esc(token.permissions.join(', '))}</td>
            <td>${token.revokedAt ? '<span class="badge bad">revoked</span>' : '<span class="badge ok">active</span>'}</td>
            <td>${token.revokedAt ? '' : `<button type="button" data-revoke="${esc(token.id)}">Revoke</button>`}</td>
          </tr>`).join('') || '<tr><td colspan="5" class="muted">No tokens yet.</td></tr>'}
      </tbody>
    </table></div>`;
  const copy = document.getElementById('copy-token');
  if (copy) copy.addEventListener('click', () => copyText(state.issuedToken.secret));
  document.getElementById('create-token').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const environments = [...form.querySelectorAll('input[name="env"]:checked')].map((input) => input.value);
    const permissions = [...form.querySelectorAll('input[name="perm"]:checked')].map((input) => input.value);
    try {
      const created = await api(`/api/v1/projects/${encodeURIComponent(state.project.id)}/tokens`, {
        method: 'POST',
        body: { name: form.name.value, environments, permissions },
      });
      state.issuedToken = { projectId: state.project.id, secret: created.token.secret };
      await loadEnvironment();
      state.tab = 'tokens';
      renderProject();
      toast('Token created');
    } catch (error) {
      toast(error.message, 'bad');
    }
  });
  panel.querySelectorAll('[data-revoke]').forEach((button) => {
    button.addEventListener('click', async () => {
      if (!window.confirm('Revoke this token? Clients using it will fail immediately.')) return;
      try {
        await api(`/api/v1/projects/${encodeURIComponent(state.project.id)}/tokens/${encodeURIComponent(button.getAttribute('data-revoke'))}`, { method: 'DELETE' });
        await loadEnvironment();
        renderProject();
      } catch (error) {
        toast(error.message, 'bad');
      }
    });
  });
}

async function renderAudit() {
  const projects = state.projects.length ? state.projects : (await api('/api/v1/projects')).projects;
  state.projects = projects;
  const params = new URLSearchParams({ limit: '50', offset: String(state.auditOffset) });
  if (state.auditProject) params.set('projectId', state.auditProject);
  if (state.auditAction) params.set('action', state.auditAction);
  const data = await api(`/api/v1/audit?${params.toString()}`);
  state.audit = data.logs;
  state.auditTotal = data.total;
  const main = document.getElementById('main');
  main.innerHTML = `
    <div class="page-head"><div><h1>Audit log</h1><p class="muted">Pulls record the client IP, time, and token prefix. Secret values are not written here.</p></div></div>
    <div class="filters">
      <select id="audit-project">
        <option value="">All projects</option>
        ${projects.map((project) => `<option value="${esc(project.id)}" ${project.id === state.auditProject ? 'selected' : ''}>${esc(project.name)}</option>`).join('')}
      </select>
      <select id="audit-action">
        ${['', 'pull', 'push', 'rollback', 'token_create', 'token_revoke', 'login_success', 'login_failure'].map((action) => `<option value="${action}" ${action === state.auditAction ? 'selected' : ''}>${action || 'All actions'}</option>`).join('')}
      </select>
      <button type="button" id="audit-prev" ${state.auditOffset === 0 ? 'disabled' : ''}>Previous</button>
      <button type="button" id="audit-next" ${state.auditOffset + state.audit.length >= state.auditTotal ? 'disabled' : ''}>Next</button>
      <span class="tiny">${esc(state.auditTotal)} events</span>
    </div>
    <div class="scroll panel"><table>
      <thead><tr><th>Time</th><th>Action</th><th>Project</th><th>Env</th><th>Token</th><th>IP</th><th>Result</th><th>Detail</th></tr></thead>
      <tbody>
        ${data.logs.map((log) => `
          <tr>
            <td>${esc(formatTime(log.timestamp))}</td>
            <td class="mono">${esc(log.action)}</td>
            <td>${esc(log.projectName || '')}</td>
            <td>${esc(log.environment || '')}</td>
            <td class="mono">${esc(log.tokenPrefix || '')}</td>
            <td class="mono">${esc(log.ip)}</td>
            <td>${log.success ? '<span class="badge ok">ok</span>' : '<span class="badge bad">denied</span>'}</td>
            <td>${esc(log.detail)}</td>
          </tr>`).join('') || '<tr><td colspan="8" class="muted">No events.</td></tr>'}
      </tbody>
    </table></div>`;
  document.getElementById('audit-project').addEventListener('change', (event) => {
    state.auditProject = event.target.value;
    state.auditOffset = 0;
    void renderAudit();
  });
  document.getElementById('audit-action').addEventListener('change', (event) => {
    state.auditAction = event.target.value;
    state.auditOffset = 0;
    void renderAudit();
  });
  document.getElementById('audit-prev').addEventListener('click', () => {
    state.auditOffset = Math.max(0, state.auditOffset - 50);
    void renderAudit();
  });
  document.getElementById('audit-next').addEventListener('click', () => {
    state.auditOffset += 50;
    void renderAudit();
  });
}

function formatTime(iso) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleString(undefined, { hour12: false });
}

async function copyText(value) {
  try {
    await navigator.clipboard.writeText(value);
    toast('Copied');
  } catch {
    toast('Copy the value from the field manually.', 'bad');
  }
}

window.addEventListener('hashchange', () => {
  if (ignoreHash) {
    ignoreHash = false;
    return;
  }
  void route().catch((error) => toast(error.message, 'bad'));
});

async function boot() {
  try {
    const session = await api('/api/v1/admin/session');
    state.me = session.username;
    ensureShell();
    if (!location.hash) location.hash = '#/projects';
    await route();
  } catch {
    renderLogin();
  }
}

void boot();
