import type { DatabaseSync } from 'node:sqlite';
import type { Config } from './config.ts';
import { generateSessionToken, hashPassword, sha256Hex, verifyPassword } from './crypto.ts';
import { ApiError } from './errors.ts';
import { LIMITS } from './limits.ts';
import type { Actor } from './types.ts';
import { newId, nowIso } from './util.ts';

interface UserRow {
  id: string;
  username: string;
  password_hash: string;
}

interface SessionRow {
  id: string;
  user_id: string;
  username: string;
  expires_at: string;
}

export function bootstrapAdmin(db: DatabaseSync, config: Config): { created: boolean } {
  const existing = db.prepare('SELECT id FROM admin_users LIMIT 1').get() as { id: string } | undefined;
  if (existing) return { created: false };
  if (!config.adminPassword) {
    throw new Error(
      'No administrator exists. Set NEXUSENV_ADMIN_PASSWORD (10-256 characters) to bootstrap the admin user.',
    );
  }
  db.prepare(
    `INSERT INTO admin_users (id, username, password_hash, created_at) VALUES (?, ?, ?, ?)`,
  ).run(newId('usr'), config.adminUsername, hashPassword(config.adminPassword), nowIso());
  return { created: true };
}

function findUser(db: DatabaseSync, username: string): UserRow | undefined {
  return db
    .prepare('SELECT id, username, password_hash FROM admin_users WHERE username = ?')
    .get(username) as UserRow | undefined;
}

export function loginAdmin(
  db: DatabaseSync,
  username: string,
  password: string,
  ip: string,
  dummyPasswordHash: string,
  sessionTtlMs: number,
): { token: string; username: string; userId: string } | null {
  const user = findUser(db, username);
  const ok = verifyPassword(password, user ? user.password_hash : dummyPasswordHash);
  if (!user || !ok) return null;
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(nowIso());
  const issued = generateSessionToken();
  const stamp = nowIso();
  const expires = new Date(Date.now() + sessionTtlMs).toISOString();
  db.prepare(
    `INSERT INTO sessions (id, user_id, token_hash, expires_at, created_at, ip) VALUES (?, ?, ?, ?, ?, ?)`,
  ).run(newId('ses'), user.id, issued.hash, expires, stamp, ip);
  return { token: issued.secret, username: user.username, userId: user.id };
}

export function readSession(
  db: DatabaseSync,
  sessionToken: string | undefined,
): { sessionId: string; userId: string; username: string } | null {
  if (!sessionToken || sessionToken.length < 20 || sessionToken.length > 200) return null;
  const row = db
    .prepare(
      `SELECT s.id, s.user_id, s.expires_at, u.username
       FROM sessions s
       JOIN admin_users u ON u.id = s.user_id
       WHERE s.token_hash = ?`,
    )
    .get(sha256Hex(sessionToken)) as SessionRow | undefined;
  if (!row) return null;
  if (row.expires_at <= nowIso()) {
    db.prepare('DELETE FROM sessions WHERE id = ?').run(row.id);
    return null;
  }
  return { sessionId: row.id, userId: row.user_id, username: row.username };
}

export function destroySession(db: DatabaseSync, sessionToken: string | undefined): void {
  if (!sessionToken) return;
  db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256Hex(sessionToken));
}

export function changeAdminPassword(
  db: DatabaseSync,
  userId: string,
  currentPassword: string,
  nextPassword: string,
): void {
  if (nextPassword.length < LIMITS.minPasswordLength || nextPassword.length > LIMITS.maxPasswordLength) {
    throw new ApiError(400, 'bad_request', 'New password must be between 10 and 256 characters');
  }
  const user = db
    .prepare('SELECT id, username, password_hash FROM admin_users WHERE id = ?')
    .get(userId) as UserRow | undefined;
  if (!user || !verifyPassword(currentPassword, user.password_hash)) {
    throw new ApiError(401, 'unauthorized', 'Invalid username or password');
  }
  db.prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?').run(hashPassword(nextPassword), userId);
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
}

export function actorFromAdmin(userId: string, username: string): Actor {
  return {
    type: 'admin',
    id: userId,
    label: username,
    tokenPrefix: 'admin-session',
  };
}

export function assertPasswordShape(password: unknown): string {
  if (typeof password !== 'string' || password.length === 0 || password.length > LIMITS.maxPasswordLength) {
    throw new ApiError(400, 'bad_request', 'Password is required');
  }
  return password;
}

export function assertUsernameShape(username: unknown): string {
  if (typeof username !== 'string' || !/^[a-zA-Z0-9._-]{1,64}$/.test(username)) {
    throw new ApiError(400, 'bad_request', 'Invalid username or password');
  }
  return username;
}
