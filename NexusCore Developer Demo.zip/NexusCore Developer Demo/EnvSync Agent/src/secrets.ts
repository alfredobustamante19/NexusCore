import type { DatabaseSync } from 'node:sqlite';
import { writeAudit } from './audit.ts';
import { decryptSecret, encryptSecret, secretAad } from './crypto.ts';
import { withTransaction } from './db.ts';
import { ApiError } from './errors.ts';
import { touchProject } from './projects.ts';
import type { Actor, Environment, Project, RequestMeta } from './types.ts';
import { newId, nowIso } from './util.ts';
import type { SecretInput } from './validate.ts';

interface SecretRow {
  key: string;
  ciphertext: string;
  nonce: string;
  tag: string;
  position: number;
}

interface RevisionRow {
  id: string;
  revision: number;
  comment: string;
  created_at: string;
  actor_type: string;
  actor_id: string;
  actor_label: string;
  key_count: number;
}

export interface RevisionSummary {
  revision: number;
  comment: string;
  createdAt: string;
  actorType: string;
  actorId: string;
  actorLabel: string;
  keyCount: number;
}

export interface StoredSecret extends SecretInput {
  position: number;
}

function nextRevision(db: DatabaseSync, environmentId: string): number {
  const row = db
    .prepare('SELECT COALESCE(MAX(revision), 0) AS revision FROM revisions WHERE environment_id = ?')
    .get(environmentId) as { revision: number } | undefined;
  return Number(row?.revision ?? 0) + 1;
}

function insertSecrets(
  db: DatabaseSync,
  masterKey: Buffer,
  revisionId: string,
  projectId: string,
  environment: string,
  revision: number,
  secrets: SecretInput[],
): void {
  const stmt = db.prepare(
    `INSERT INTO secrets (id, revision_id, position, key, ciphertext, nonce, tag)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  );
  secrets.forEach((secret, index) => {
    const encrypted = encryptSecret(
      masterKey,
      secret.value,
      secretAad(projectId, environment, secret.key, revision),
    );
    stmt.run(newId('sec'), revisionId, index, secret.key, encrypted.ciphertext, encrypted.nonce, encrypted.tag);
  });
}

export function pushSecrets(
  db: DatabaseSync,
  masterKey: Buffer,
  args: {
    project: Project;
    environment: Environment;
    secrets: SecretInput[];
    comment: string;
    actor: Actor;
    meta: RequestMeta;
    audit?: (result: { revision: number; count: number }) => { action: string; detail: string };
  },
): { revision: number; count: number } {
  return withTransaction(db, () => {
    const revision = nextRevision(db, args.environment.id);
    const revisionId = newId('rev');
    const stamp = nowIso();
    db.prepare(
      `INSERT INTO revisions (
        id, project_id, environment_id, revision, comment, created_at, actor_type, actor_id, actor_label
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(
      revisionId,
      args.project.id,
      args.environment.id,
      revision,
      args.comment,
      stamp,
      args.actor.type,
      args.actor.id,
      args.actor.label,
    );
    insertSecrets(
      db,
      masterKey,
      revisionId,
      args.project.id,
      args.environment.name,
      revision,
      args.secrets,
    );
    db.prepare('UPDATE environments SET current_revision = ? WHERE id = ?').run(revision, args.environment.id);
    touchProject(db, args.project.id);
    const result = { revision, count: args.secrets.length };
    const audit = args.audit?.(result) ?? { action: 'push', detail: `stored ${result.count} keys` };
    writeAudit(db, {
      action: audit.action,
      projectId: args.project.id,
      projectName: args.project.name,
      environment: args.environment.name,
      tokenId: args.actor.id,
      tokenPrefix: args.actor.tokenPrefix,
      ip: args.meta.ip,
      userAgent: args.meta.userAgent,
      revision,
      success: true,
      detail: audit.detail,
    });
    return result;
  });
}

export function readSecrets(
  db: DatabaseSync,
  masterKey: Buffer,
  projectId: string,
  environment: string,
  environmentId: string,
  revision: number,
): StoredSecret[] {
  const revisionRow = db
    .prepare('SELECT id FROM revisions WHERE environment_id = ? AND revision = ?')
    .get(environmentId, revision) as { id: string } | undefined;
  if (!revisionRow) {
    throw new ApiError(404, 'not_found', 'Revision not found');
  }
  const rows = db
    .prepare(
      `SELECT key, ciphertext, nonce, tag, position
       FROM secrets WHERE revision_id = ? ORDER BY position ASC`,
    )
    .all(revisionRow.id) as unknown as SecretRow[];
  return rows.map((row) => {
    let value: string;
    try {
      value = decryptSecret(
        masterKey,
        row.ciphertext,
        row.nonce,
        row.tag,
        secretAad(projectId, environment, row.key, revision),
      );
    } catch {
      throw new ApiError(
        500,
        'decrypt_failed',
        'Failed to decrypt a secret. The master key may not match this database.',
      );
    }
    return { key: row.key, value, position: Number(row.position) };
  });
}

export function listRevisions(db: DatabaseSync, environmentId: string): RevisionSummary[] {
  const rows = db
    .prepare(
      `SELECT r.id, r.revision, r.comment, r.created_at, r.actor_type, r.actor_id, r.actor_label,
              (SELECT COUNT(*) FROM secrets s WHERE s.revision_id = r.id) AS key_count
       FROM revisions r
       WHERE r.environment_id = ?
       ORDER BY r.revision DESC`,
    )
    .all(environmentId) as unknown as RevisionRow[];
  return rows.map((row) => ({
    revision: Number(row.revision),
    comment: row.comment,
    createdAt: row.created_at,
    actorType: row.actor_type,
    actorId: row.actor_id,
    actorLabel: row.actor_label,
    keyCount: Number(row.key_count),
  }));
}

export function rollbackSecrets(
  db: DatabaseSync,
  masterKey: Buffer,
  args: {
    project: Project;
    environment: Environment;
    targetRevision: number;
    comment: string;
    actor: Actor;
    meta: RequestMeta;
  },
): { revision: number; restoredFrom: number; count: number } {
  if (args.targetRevision === args.environment.currentRevision) {
    throw new ApiError(400, 'bad_request', 'That revision is already current');
  }
  const existing = readSecrets(
    db,
    masterKey,
    args.project.id,
    args.environment.name,
    args.environment.id,
    args.targetRevision,
  );
  const secrets = existing.map((item) => ({ key: item.key, value: item.value }));
  const comment = args.comment || `Rollback to revision ${args.targetRevision}`;
  const pushed = pushSecrets(db, masterKey, {
    project: args.project,
    environment: args.environment,
    secrets,
    comment,
    actor: args.actor,
    meta: args.meta,
    audit: (result) => ({
      action: 'rollback',
      detail: `restored revision ${args.targetRevision} as ${result.revision}`,
    }),
  });
  return { revision: pushed.revision, restoredFrom: args.targetRevision, count: pushed.count };
}
