import type { DatabaseSync } from 'node:sqlite';
import { newId, nowIso } from './util.ts';

export interface AuditWrite {
  action: string;
  projectId?: string | null;
  projectName?: string | null;
  environment?: string | null;
  tokenId?: string | null;
  tokenPrefix?: string | null;
  ip: string;
  userAgent: string;
  revision?: number | null;
  success: boolean;
  detail?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  projectId: string | null;
  projectName: string | null;
  environment: string | null;
  tokenId: string | null;
  tokenPrefix: string | null;
  ip: string;
  userAgent: string;
  revision: number | null;
  success: boolean;
  detail: string;
}

interface AuditRow {
  id: string;
  timestamp: string;
  action: string;
  project_id: string | null;
  project_name: string | null;
  environment: string | null;
  token_id: string | null;
  token_prefix: string | null;
  ip: string;
  user_agent: string;
  revision: number | null;
  success: number;
  detail: string;
}

function clip(value: string, max: number): string {
  return value.length <= max ? value : value.slice(0, max);
}

export function writeAudit(db: DatabaseSync, entry: AuditWrite): void {
  db.prepare(
    `INSERT INTO audit_logs (
      id, timestamp, action, project_id, project_name, environment,
      token_id, token_prefix, ip, user_agent, revision, success, detail
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    newId('aud'),
    nowIso(),
    clip(entry.action, 64),
    entry.projectId ?? null,
    entry.projectName ?? null,
    entry.environment ?? null,
    entry.tokenId ?? null,
    entry.tokenPrefix ?? null,
    clip(entry.ip, 128),
    clip(entry.userAgent, 300),
    entry.revision ?? null,
    entry.success ? 1 : 0,
    clip(entry.detail ?? '', 500),
  );
}

function mapAudit(row: AuditRow): AuditLog {
  return {
    id: row.id,
    timestamp: row.timestamp,
    action: row.action,
    projectId: row.project_id,
    projectName: row.project_name,
    environment: row.environment,
    tokenId: row.token_id,
    tokenPrefix: row.token_prefix,
    ip: row.ip,
    userAgent: row.user_agent,
    revision: row.revision === null ? null : Number(row.revision),
    success: Number(row.success) === 1,
    detail: row.detail,
  };
}

export function listAudit(
  db: DatabaseSync,
  filter: { projectId?: string; action?: string; limit: number; offset: number },
): { logs: AuditLog[]; total: number } {
  const where: string[] = [];
  const params: Array<string | number> = [];
  if (filter.projectId) {
    where.push('project_id = ?');
    params.push(filter.projectId);
  }
  if (filter.action) {
    where.push('action = ?');
    params.push(filter.action);
  }
  const clause = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
  const totalRow = db.prepare(`SELECT COUNT(*) AS total FROM audit_logs ${clause}`).get(...params) as
    | { total: number }
    | undefined;
  const rows = db
    .prepare(
      `SELECT id, timestamp, action, project_id, project_name, environment, token_id, token_prefix,
              ip, user_agent, revision, success, detail
       FROM audit_logs ${clause}
       ORDER BY timestamp DESC, id DESC
       LIMIT ? OFFSET ?`,
    )
    .all(...params, filter.limit, filter.offset) as unknown as AuditRow[];
  return {
    logs: rows.map(mapAudit),
    total: Number(totalRow?.total ?? 0),
  };
}
