#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
import { VERSION } from './version.ts';

interface Flags {
  positional: string[];
  flags: Record<string, string | boolean>;
}

function parseArgs(argv: string[]): Flags {
  const positional: string[] = [];
  const flags: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i] ?? '';
    if (arg === '--') {
      positional.push(...argv.slice(i + 1));
      break;
    }
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) {
        flags[key] = true;
      } else {
        flags[key] = next;
        i += 1;
      }
    } else {
      positional.push(arg);
    }
  }
  return { positional, flags };
}

function flag(flags: Flags, name: string): string | undefined {
  const value = flags.flags[name];
  return typeof value === 'string' ? value : undefined;
}

function usage(): void {
  process.stderr.write(`NexusEnv CLI ${VERSION}

Usage:
  nexusenv pull --project <id> --env <name> [--server URL] [--token TOKEN] [--revision N] [--out file]
  nexusenv push --project <id> --env <name> --file <path> [--server URL] [--token TOKEN] [--comment text]

The token may also be supplied as NEXUSENV_TOKEN.
Default server: http://127.0.0.1:8787
`);
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  const command = args.positional[0];
  if (!command || flag(args, 'help') === undefined && args.flags.help === true) {
    usage();
    process.exit(command ? 0 : 1);
  }
  if (command !== 'pull' && command !== 'push') {
    usage();
    process.exit(1);
  }
  const server = (flag(args, 'server') || process.env.NEXUSENV_SERVER || 'http://127.0.0.1:8787').replace(/\/$/, '');
  const project = flag(args, 'project');
  const environment = flag(args, 'env');
  const token = flag(args, 'token') || process.env.NEXUSENV_TOKEN;
  if (!project || !environment || !token) {
    throw new Error('project, env, and token are required');
  }

  if (command === 'pull') {
    const params = new URLSearchParams({ environment });
    const revision = flag(args, 'revision');
    if (revision) params.set('revision', revision);
    const response = await fetch(`${server}/api/v1/projects/${encodeURIComponent(project)}/env?${params.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const text = await response.text();
    if (!response.ok) throw new Error(errorMessage(text, response.status));
    const out = flag(args, 'out');
    if (out) writeFileSync(out, text, { mode: 0o600 });
    else process.stdout.write(text);
    return;
  }

  const file = flag(args, 'file');
  if (!file) throw new Error('--file is required');
  const params = new URLSearchParams({ environment });
  const comment = flag(args, 'comment');
  if (comment) params.set('comment', comment);
  const response = await fetch(
    `${server}/api/v1/projects/${encodeURIComponent(project)}/secrets?${params.toString()}`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'text/plain; charset=utf-8',
      },
      body: readFileSync(file),
    },
  );
  const text = await response.text();
  if (!response.ok) throw new Error(errorMessage(text, response.status));
  process.stderr.write(`${text}\n`);
}

function errorMessage(text: string, status: number): string {
  try {
    const parsed = JSON.parse(text) as { error?: { message?: string } };
    if (parsed.error?.message) return parsed.error.message;
  } catch {
    // The body was not JSON.
  }
  return `Request failed (${status})`;
}

if (process.argv[1] && (process.argv[1].endsWith('cli.ts') || process.argv[1].endsWith('cli.js'))) {
  main().catch((error: unknown) => {
    process.stderr.write(`${error instanceof Error ? error.message : 'Command failed'}\n`);
    process.exit(1);
  });
}
