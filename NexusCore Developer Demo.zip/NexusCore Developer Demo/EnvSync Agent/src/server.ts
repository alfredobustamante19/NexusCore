import { readFileSync } from 'node:fs';
import type { IncomingMessage, ServerResponse } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { hashPassword } from './crypto.ts';
import { bootstrapAdmin } from './auth.ts';
import type { Config } from './config.ts';
import type { AppContext } from './context.ts';
import { checkpoint, migrate, openDatabase } from './db.ts';
import { ApiError } from './errors.ts';
import {
  clientIp,
  parseCookies,
  readBearer,
  Router,
  SECURITY_HEADERS,
  sendApiError,
  sendBytes,
  sendJson,
  userAgent,
  type RequestContext,
} from './http.ts';
import { SlidingWindowRateLimiter } from './rateLimit.ts';
import { registerRoutes } from './routes.ts';

const STATIC_FILES: Record<string, { file: string; type: string }> = {
  '/': { file: 'index.html', type: 'text/html; charset=utf-8' },
  '/index.html': { file: 'index.html', type: 'text/html; charset=utf-8' },
  '/app.css': { file: 'app.css', type: 'text/css; charset=utf-8' },
  '/app.js': { file: 'app.js', type: 'text/javascript; charset=utf-8' },
  '/robots.txt': { file: 'robots.txt', type: 'text/plain; charset=utf-8' },
};

export interface App {
  handler: (req: IncomingMessage, res: ServerResponse) => void;
  db: AppContext['db'];
  config: Config;
  close: () => void;
  bootstrappedAdmin: boolean;
}

function webRoot(): string {
  return path.join(path.dirname(fileURLToPath(import.meta.url)), 'web');
}

function normalizePath(pathname: string): string {
  if (pathname.length > 1 && pathname.endsWith('/')) return pathname.slice(0, -1);
  return pathname;
}

function assertBrowserGuards(ctx: RequestContext): void {
  if (ctx.method === 'GET' || ctx.method === 'HEAD' || !ctx.path.startsWith('/api/')) return;
  if (ctx.query.has('access_token') || ctx.query.has('token')) {
    throw new ApiError(400, 'bad_request', 'Pass credentials in the Authorization header or session cookie');
  }
  const origin = ctx.req.headers.origin;
  if (typeof origin === 'string' && origin.length > 0 && origin !== 'null') {
    let originUrl: URL;
    try {
      originUrl = new URL(origin);
    } catch {
      throw new ApiError(403, 'csrf', 'Invalid Origin header');
    }
    const host = ctx.req.headers.host;
    if (!host || originUrl.host !== host) {
      throw new ApiError(403, 'csrf', 'Cross-origin request rejected');
    }
  }
  if (ctx.path === '/api/v1/admin/login') return;
  if (!ctx.bearer && ctx.cookies.nexusenv_session) {
    if (ctx.req.headers['x-nexusenv-request'] !== '1') {
      throw new ApiError(403, 'csrf', 'Missing X-NexusEnv-Request header');
    }
  }
}

function serveStatic(ctx: RequestContext): boolean {
  const asset = STATIC_FILES[ctx.path];
  if (!asset || ctx.method !== 'GET') return false;
  const filePath = path.join(webRoot(), asset.file);
  try {
    const body = readFileSync(filePath);
    for (const [key, value] of Object.entries(SECURITY_HEADERS)) {
      ctx.res.setHeader(key, value);
    }
    sendBytes(ctx, 200, body, asset.type);
    return true;
  } catch {
    return false;
  }
}

export function createApp(config: Config): App {
  const db = openDatabase(config.dbPath);
  migrate(db);
  const boot = bootstrapAdmin(db, config);
  const appContext: AppContext = {
    config,
    db,
    limiter: new SlidingWindowRateLimiter({
      limit: config.rateLimitMax,
      windowMs: config.rateLimitWindowMs,
    }),
    loginLimiter: new SlidingWindowRateLimiter({
      limit: config.loginRateLimitMax,
      windowMs: config.loginRateLimitWindowMs,
    }),
    dummyPasswordHash: hashPassword(`nexusenv-timing-${process.pid}`),
  };
  const router = new Router();
  registerRoutes(router, appContext);

  const handler = (req: IncomingMessage, res: ServerResponse): void => {
    void dispatch(appContext, router, req, res);
  };

  return {
    handler,
    db,
    config,
    bootstrappedAdmin: boot.created,
    close() {
      checkpoint(db);
      db.close();
    },
  };
}

async function dispatch(app: AppContext, router: Router, req: IncomingMessage, res: ServerResponse): Promise<void> {
  const host = req.headers.host || 'localhost';
  let url: URL;
  try {
    url = new URL(req.url || '/', `http://${host}`);
  } catch {
    res.statusCode = 400;
    res.end('Bad request');
    return;
  }
  const ctx: RequestContext = {
    req,
    res,
    method: (req.method || 'GET').toUpperCase(),
    path: normalizePath(url.pathname),
    params: {},
    query: url.searchParams,
    ip: clientIp(req, app.config.trustProxy),
    userAgent: userAgent(req),
    bearer: readBearer(req),
    cookies: parseCookies(typeof req.headers.cookie === 'string' ? req.headers.cookie : undefined),
    rateHeaders: {},
  };

  try {
    if (serveStatic(ctx)) return;
    assertBrowserGuards(ctx);
    const matched = router.match(ctx.method, ctx.path);
    if (!matched) {
      if (ctx.path.startsWith('/api/')) {
        sendJson(ctx, 404, { error: { code: 'not_found', message: 'Not found' } });
      } else {
        sendTextPlain(ctx, 404, 'Not found\n');
      }
      return;
    }
    if ('allow' in matched) {
      sendJson(
        ctx,
        405,
        { error: { code: 'method_not_allowed', message: 'Method not allowed' } },
        { Allow: matched.allow.join(', ') },
      );
      return;
    }
    ctx.params = matched.params;
    await matched.handler(ctx);
  } catch (error) {
    if (res.headersSent || res.writableEnded) return;
    if (error instanceof ApiError) {
      sendApiError(ctx, error);
      return;
    }
    console.error(
      JSON.stringify({
        level: 'error',
        msg: 'unhandled error',
        error: error instanceof Error ? error.message : 'unknown',
      }),
    );
    sendJson(ctx, 500, { error: { code: 'internal', message: 'Internal server error' } });
  }
}

function sendTextPlain(ctx: RequestContext, status: number, body: string): void {
  for (const [key, value] of Object.entries(SECURITY_HEADERS)) {
    ctx.res.setHeader(key, value);
  }
  ctx.res.statusCode = status;
  ctx.res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  ctx.res.end(body);
}
