import type { DatabaseSync } from 'node:sqlite';
import { ApiError } from './errors.ts';
import type { Environment, Project } from './types.ts';
import { isConstraintError, newId, nowIso, slugify } from './util.ts';
import { withTransaction } from './db.ts';

interface ProjectRow {
  id: string;
  name: string;
  slug: string;
  description: string;
  created_at: string;
  updated_at: string;
}

interface EnvironmentRow {
  id: string;
  project_id: string;
  name: string;
  current_revision: number;
  created_at: string;
}

const ENV_RANK: Record<string, number> = { dev: 0, staging: 1, production: 2 };

export function sortEnvironments(environments: Environment[]): Environment[] {
  return [...environments].sort((a, b) => {
    const left = ENV_RANK[a.name] ?? 10;
    const right = ENV_RANK[b.name] ?? 10;
    if (left !== right) return left - right;
    return a.name.localeCompare(b.name);
  });
}

function mapProject(row: ProjectRow): Project {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function mapEnvironment(row: EnvironmentRow): Environment {
  return {
    id: row.id,
    projectId: row.project_id,
    name: row.name,
    currentRevision: Number(row.current_revision),
    createdAt: row.created_at,
  };
}

export function listEnvironments(db: DatabaseSync, projectId: string): Environment[] {
  const rows = db
    .prepare(
      `SELECT id, project_id, name, current_revision, created_at
       FROM environments WHERE project_id = ?`,
    )
    .all(projectId) as unknown as EnvironmentRow[];
  return sortEnvironments(rows.map(mapEnvironment));
}

export function getProjectByRef(db: DatabaseSync, ref: string): Project | null {
  const row = db
    .prepare(
      `SELECT id, name, slug, description, created_at, updated_at
       FROM projects WHERE id = ? OR slug = ?`,
    )
    .get(ref, ref.toLowerCase()) as ProjectRow | undefined;
  return row ? mapProject(row) : null;
}

export function requireProject(db: DatabaseSync, ref: string): Project {
  const project = getProjectByRef(db, ref);
  if (!project) throw new ApiError(404, 'not_found', 'Project not found');
  return project;
}

export function getEnvironment(db: DatabaseSync, projectId: string, name: string): Environment | null {
  const row = db
    .prepare(
      `SELECT id, project_id, name, current_revision, created_at
       FROM environments WHERE project_id = ? AND name = ?`,
    )
    .get(projectId, name) as EnvironmentRow | undefined;
  return row ? mapEnvironment(row) : null;
}

export function requireEnvironment(db: DatabaseSync, projectId: string, name: string): Environment {
  const environment = getEnvironment(db, projectId, name);
  if (!environment) throw new ApiError(404, 'not_found', 'Environment not found');
  return environment;
}

export interface ProjectDetails extends Project {
  environments: Environment[];
}

export function projectDetails(db: DatabaseSync, project: Project): ProjectDetails {
  return { ...project, environments: listEnvironments(db, project.id) };
}

export function listProjects(db: DatabaseSync): ProjectDetails[] {
  const rows = db
    .prepare(
      `SELECT id, name, slug, description, created_at, updated_at
       FROM projects ORDER BY name COLLATE NOCASE`,
    )
    .all() as unknown as ProjectRow[];
  return rows.map((row) => projectDetails(db, mapProject(row)));
}

function uniqueSlug(db: DatabaseSync, base: string): string {
  let slug = base;
  let n = 2;
  while (db.prepare('SELECT id FROM projects WHERE slug = ?').get(slug)) {
    slug = `${base}-${n}`;
    n += 1;
    if (n > 50) throw new ApiError(409, 'conflict', 'Could not allocate a unique project slug');
  }
  return slug;
}

export function createProject(db: DatabaseSync, name: string, description: string): ProjectDetails {
  const base = slugify(name);
  if (!base) {
    throw new ApiError(400, 'bad_request', 'Project name must contain a letter or number');
  }
  try {
    return withTransaction(db, () => {
      const stamp = nowIso();
      const id = newId('prj');
      const slug = uniqueSlug(db, base);
      db.prepare(
        `INSERT INTO projects (id, name, slug, description, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
      ).run(id, name, slug, description, stamp, stamp);
      for (const envName of ['dev', 'staging', 'production']) {
        db.prepare(
          `INSERT INTO environments (id, project_id, name, current_revision, created_at)
           VALUES (?, ?, ?, 0, ?)`,
        ).run(newId('env'), id, envName, stamp);
      }
      const project = getProjectByRef(db, id);
      if (!project) throw new Error('Project insert failed');
      return projectDetails(db, project);
    });
  } catch (error) {
    if (isConstraintError(error)) {
      throw new ApiError(409, 'conflict', 'A project with that name already exists');
    }
    throw error;
  }
}

export function updateProject(
  db: DatabaseSync,
  project: Project,
  patch: { name?: string; description?: string },
): ProjectDetails {
  const name = patch.name ?? project.name;
  const description = patch.description ?? project.description;
  let slug = project.slug;
  if (patch.name && patch.name !== project.name) {
    const base = slugify(patch.name);
    if (!base) throw new ApiError(400, 'bad_request', 'Project name must contain a letter or number');
    slug = base;
    const clash = db.prepare('SELECT id FROM projects WHERE slug = ? AND id <> ?').get(slug, project.id) as
      | { id: string }
      | undefined;
    if (clash) throw new ApiError(409, 'conflict', 'A project with that name already exists');
  }
  try {
    db.prepare(
      `UPDATE projects SET name = ?, slug = ?, description = ?, updated_at = ? WHERE id = ?`,
    ).run(name, slug, description, nowIso(), project.id);
  } catch (error) {
    if (isConstraintError(error)) {
      throw new ApiError(409, 'conflict', 'A project with that name already exists');
    }
    throw error;
  }
  return projectDetails(db, requireProject(db, project.id));
}

export function deleteProject(db: DatabaseSync, projectId: string): void {
  const result = db.prepare('DELETE FROM projects WHERE id = ?').run(projectId);
  if (Number(result.changes) === 0) {
    throw new ApiError(404, 'not_found', 'Project not found');
  }
}

export function createEnvironment(db: DatabaseSync, projectId: string, name: string): Environment {
  try {
    const stamp = nowIso();
    const id = newId('env');
    db.prepare(
      `INSERT INTO environments (id, project_id, name, current_revision, created_at)
       VALUES (?, ?, ?, 0, ?)`,
    ).run(id, projectId, name, stamp);
    db.prepare('UPDATE projects SET updated_at = ? WHERE id = ?').run(stamp, projectId);
    const environment = getEnvironment(db, projectId, name);
    if (!environment) throw new Error('Environment insert failed');
    return environment;
  } catch (error) {
    if (isConstraintError(error)) {
      throw new ApiError(409, 'conflict', 'That environment already exists');
    }
    throw error;
  }
}

export function deleteEnvironment(db: DatabaseSync, projectId: string, name: string): void {
  const result = db.prepare('DELETE FROM environments WHERE project_id = ? AND name = ?').run(projectId, name);
  if (Number(result.changes) === 0) {
    throw new ApiError(404, 'not_found', 'Environment not found');
  }
  db.prepare('UPDATE projects SET updated_at = ? WHERE id = ?').run(nowIso(), projectId);
}

export function touchProject(db: DatabaseSync, projectId: string): void {
  db.prepare('UPDATE projects SET updated_at = ? WHERE id = ?').run(nowIso(), projectId);
}
