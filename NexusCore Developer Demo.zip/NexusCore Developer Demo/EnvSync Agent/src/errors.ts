export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly headers: Record<string, string>;

  constructor(status: number, code: string, message: string, headers: Record<string, string> = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.headers = headers;
  }
}

export class EnvSyntaxError extends Error {
  readonly line: number;

  constructor(line: number, message: string) {
    super(message);
    this.name = 'EnvSyntaxError';
    this.line = line;
  }
}
