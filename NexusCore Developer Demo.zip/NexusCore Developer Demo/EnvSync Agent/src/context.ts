import type { DatabaseSync } from 'node:sqlite';
import type { Config } from './config.ts';
import type { SlidingWindowRateLimiter } from './rateLimit.ts';

export interface AppContext {
  config: Config;
  db: DatabaseSync;
  limiter: SlidingWindowRateLimiter;
  loginLimiter: SlidingWindowRateLimiter;
  dummyPasswordHash: string;
}
