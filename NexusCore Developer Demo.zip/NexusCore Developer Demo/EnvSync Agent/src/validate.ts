import { ApiError } from './errors.ts';
import { ENV_NAME, LIMITS, SECRET_KEY } from './limits.ts';

export function secretKeyError(key: string): string | null {
  if (key.length === 0 || key.length > LIMITS.maxKeyLength) {
    return 'Invalid secret key';
  }
  if (!SECRET_KEY.test(key)) {
    return 'Invalid secret key';
  }
  return null;
}

export function requireLabel(value: unknown, field: string, max: number): string {
  if (typeof value !== 'string') {
    throw new ApiError(400, 'bad_request', `${field} is required`);
  }
  const trimmed = value.trim();
  if (trimmed.length < 1 || trimmed.length > max) {
    throw new ApiError(400, 'bad_request', `${field} must be between 1 and ${max} characters`);
  }
  if (/[\u0000-\u001f\u007f]/.test(trimmed)) {
    throw new ApiError(400, 'bad_request', `${field} contains unsupported characters`);
  }
  return trimmed;
}

export function optionalDescription(value: unknown): string {
  if (value === undefined || value === null || value === '') return '';
  if (typeof value !== 'string') {
    throw new ApiError(400, 'bad_request', 'description must be a string');
  }
  if (value.length > LIMITS.maxDescription) {
    throw new ApiError(400, 'bad_request', 'description is too long');
  }
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value)) {
    throw new ApiError(400, 'bad_request', 'description contains unsupported characters');
  }
  return value;
}

export function optionalComment(value: unknown): string {
  if (value === undefined || value === null || value === '') return '';
  if (typeof value !== 'string') {
    throw new ApiError(400, 'bad_request', 'comment must be a string');
  }
  if (value.length > LIMITS.maxCommentLength) {
    throw new ApiError(400, 'bad_request', 'comment is too long');
  }
  if (/[\u0000-\u001f\u007f]/.test(value)) {
    throw new ApiError(400, 'bad_request', 'comment contains unsupported characters');
  }
  return value;
}

export function requireEnvName(value: unknown): string {
  if (typeof value !== 'string' || !ENV_NAME.test(value)) {
    throw new ApiError(
      400,
      'bad_request',
      'environment must match [a-z][a-z0-9_-]{0,31} (for example dev, staging, production)',
    );
  }
  return value;
}

export function requireRevision(value: unknown): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 1 || value > 1_000_000_000) {
    throw new ApiError(400, 'bad_request', 'revision must be a positive integer');
  }
  return value;
}

export interface SecretInput {
  key: string;
  value: string;
}

export function normalizeSecrets(input: unknown): SecretInput[] {
  if (Array.isArray(input)) {
    if (input.length === 0) {
      throw new ApiError(400, 'bad_request', 'At least one secret is required');
    }
    if (input.length > LIMITS.maxSecrets) {
      throw new ApiError(400, 'bad_request', 'Too many secrets');
    }
    const seen = new Set<string>();
    const out: SecretInput[] = [];
    for (const item of input) {
      if (!item || typeof item !== 'object' || Array.isArray(item)) {
        throw new ApiError(400, 'bad_request', 'Each secret must be an object with key and value');
      }
      const rec = item as Record<string, unknown>;
      if (typeof rec.key !== 'string' || secretKeyError(rec.key)) {
        throw new ApiError(400, 'bad_request', 'Invalid secret key');
      }
      if (seen.has(rec.key)) {
        throw new ApiError(400, 'bad_request', 'Duplicate secret key');
      }
      seen.add(rec.key);
      if (typeof rec.value !== 'string') {
        throw new ApiError(400, 'bad_request', 'Secret values must be strings');
      }
      if (rec.value.length > LIMITS.maxValueLength) {
        throw new ApiError(400, 'bad_request', 'Secret value is too long');
      }
      out.push({ key: rec.key, value: rec.value });
    }
    return out;
  }

  if (input && typeof input === 'object') {
    return normalizeSecrets(
      Object.entries(input as Record<string, unknown>).map(([key, value]) => ({ key, value })),
    );
  }

  throw new ApiError(400, 'bad_request', 'secrets must be an object or an array');
}
