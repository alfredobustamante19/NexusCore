import { createServer } from 'node:http';
import { createServer as createHttpsServer } from 'node:https';
import type { Server } from 'node:http';
import { readFileSync } from 'node:fs';
import { loadConfig } from './config.ts';
import { createApp } from './server.ts';
import { VERSION } from './version.ts';

function main(): void {
  const config = loadConfig(process.env);
  const app = createApp(config);
  if (app.bootstrappedAdmin) {
    console.log(JSON.stringify({ level: 'info', msg: 'bootstrapped admin user', username: config.adminUsername }));
  }

  let server: Server;
  if (config.tlsCertFile && config.tlsKeyFile) {
    server = createHttpsServer(
      {
        cert: readFileSync(config.tlsCertFile),
        key: readFileSync(config.tlsKeyFile),
      },
      app.handler,
    );
  } else {
    server = createServer(app.handler);
  }
  server.requestTimeout = 30_000;
  server.headersTimeout = 10_000;
  server.listen(config.port, config.host, () => {
    const address = server.address();
    const port = address && typeof address === 'object' ? address.port : config.port;
    console.log(
      JSON.stringify({
        level: 'info',
        msg: 'listening',
        service: 'nexusenv',
        version: VERSION,
        host: config.host,
        port,
        tls: Boolean(config.tlsCertFile),
      }),
    );
  });

  let closing = false;
  const shutdown = (): void => {
    if (closing) return;
    closing = true;
    server.close(() => {
      app.close();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 5_000).unref();
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

try {
  main();
} catch (error) {
  console.error(
    JSON.stringify({
      level: 'error',
      msg: error instanceof Error ? error.message : 'startup failed',
    }),
  );
  process.exit(1);
}
