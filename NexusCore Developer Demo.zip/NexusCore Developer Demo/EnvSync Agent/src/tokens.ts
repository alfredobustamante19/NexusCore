import type { DatabaseSync } from 'node:sqlite';
import { generateApiToken, presentedTokenPrefix, sha256Hex } from './crypto.ts';
import { ApiError } from './errors.ts';
import { LIMITS } from './limits.ts';
import type { Actor } from './types.ts';
import { newId, nowIso } from './util.ts';

export interface ApiToken {
  id: string;
  projectId: string;
  name: string;
  prefix: string;
  environments: string[];
  permissions: string[];
  createdAt: string;
  lastUsedAt: string | null;
  revokedAt: string | null;
}

interface TokenRow {
  id: string;
  project_id: string;
  name: string;
  token_hash: string;
  token_prefix: string;
  environments_json: string;
  permissions_json: string;
  created_at: string;
  last_used_at: string | null;
  revoked_at: string | null;
}

function parseJsonArray(raw: string): string[] {
  const parsed = JSON.parse(raw) as unknown;
  if (!Array.isArray(parsed) || !parsed.every((item) => typeof item === 'string')) {
    throw new Error('Corrupt token scope');
  }
  return parsed;
}

function mapToken(row: TokenRow): ApiToken {
  return {
    id: row.id,
    projectId: row.project_id,
    name: row.name,
    prefix: row.token_prefix,
    environments: parseJsonArray(row.environments_json),
    permissions: parseJsonArray(row.permissions_json),
    createdAt: row.created_at,
    lastUsedAt: row.last_used_at,
    revokedAt: row.revoked_at,
  };
}

export function normalizeTokenScopes(
  environments: unknown,
  permissions: unknown,
  knownEnvironments: string[],
): { environments: string[]; permissions: string[] } {
  if (!Array.isArray(environments) || environments.length === 0) {
    throw new ApiError(400, 'bad_request', 'environments must be a non-empty array');
  }
  const envNames: string[] = [];
  for (const item of environments) {
    if (typeof item !== 'string') {
      throw new ApiError(400, 'bad_request', 'environments must contain strings');
    }
    envNames.push(item);
  }
  const uniqueEnvs = [...new Set(envNames)];
  const wildcard = uniqueEnvs.includes('*');
  if (wildcard) {
    return finish(permissions, ['*']);
  }
  for (const name of uniqueEnvs) {
    if (!knownEnvironments.includes(name)) {
      throw new ApiError(400, 'bad_request', 'Token environment is not part of this project');
    }
  }
  return finish(permissions, uniqueEnvs);
}

function finish(permissions: unknown, environments: string[]): { environments: string[]; permissions: string[] } {
  if (!Array.isArray(permissions) || permissions.length === 0) {
    throw new ApiError(400, 'bad_request', 'permissions must include read, write, or both');
  }
  const allowed = new Set<string>();
  for (const item of permissions) {
    if (item !== 'read' && item !== 'write') {
      throw new ApiError(400, 'bad_request', 'permissions may only contain read and write');
    }
    allowed.add(item);
  }
  const stored = ['read', 'write'].filter((item) => allowed.has(item));
  return { environments, permissions: stored };
}

export function createToken(
  db: DatabaseSync,
  projectId: string,
  name: string,
  environments: string[],
  permissions: string[],
): { token: ApiToken; secret: string } {
  const issued = generateApiToken();
  const stamp = nowIso();
  const id = newId('tok');
  db.prepare(
    `INSERT INTO api_tokens (
      id, project_id, name, token_hash, token_prefix, environments_json, permissions_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    id,
    projectId,
    name,
    issued.hash,
    issued.prefix,
    JSON.stringify(environments),
    JSON.stringify(permissions),
    stamp,
  );
  const token = getToken(db, projectId, id);
  if (!token) throw new Error('Token insert failed');
  return { token, secret: issued.secret };
}

export function listTokens(db: DatabaseSync, projectId: string): ApiToken[] {
  const rows = db
    .prepare(
      `SELECT id, project_id, name, token_hash, token_prefix, environments_json, permissions_json,
              created_at, last_used_at, revoked_at
       FROM api_tokens WHERE project_id = ? ORDER BY created_at DESC`,
    )
    .all(projectId) as unknown as TokenRow[];
  return rows.map(mapToken);
}

export function getToken(db: DatabaseSync, projectId: string, tokenId: string): ApiToken | null {
  const row = db
    .prepare(
      `SELECT id, project_id, name, token_hash, token_prefix, environments_json, permissions_json,
              created_at, last_used_at, revoked_at
       FROM api_tokens WHERE project_id = ? AND id = ?`,
    )
    .get(projectId, tokenId) as TokenRow | undefined;
  return row ? mapToken(row) : null;
}

export function revokeToken(db: DatabaseSync, projectId: string, tokenId: string): ApiToken {
  const existing = getToken(db, projectId, tokenId);
  if (!existing) throw new ApiError(404, 'not_found', 'Token not found');
  if (!existing.revokedAt) {
    db.prepare('UPDATE api_tokens SET revoked_at = ? WHERE id = ?').run(nowIso(), tokenId);
  }
  const updated = getToken(db, projectId, tokenId);
  if (!updated) throw new ApiError(404, 'not_found', 'Token not found');
  return updated;
}

export function lookupApiToken(db: DatabaseSync, presented: string): ApiToken | null {
  if (presented.length === 0 || presented.length > LIMITS.maxBearerLength) return null;
  if (!presented.startsWith('nxe_')) return null;
  if (!presentedTokenPrefix(presented)) return null;
  const row = db
    .prepare(
      `SELECT id, project_id, name, token_hash, token_prefix, environments_json, permissions_json,
              created_at, last_used_at, revoked_at
       FROM api_tokens WHERE token_hash = ?`,
    )
    .get(sha256Hex(presented)) as TokenRow | undefined;
  if (!row) return null;
  if (!row.revoked_at) {
    db.prepare('UPDATE api_tokens SET last_used_at = ? WHERE id = ?').run(nowIso(), row.id);
  }
  return mapToken(row);
}

export function authenticateApiToken(db: DatabaseSync, presented: string): ApiToken | null {
  const token = lookupApiToken(db, presented);
  if (!token || token.revokedAt) return null;
  return token;
}

export function tokenAllows(token: ApiToken, environment: string | null, permission: 'read' | 'write'): boolean {
  if (environment && !token.environments.includes('*') && !token.environments.includes(environment)) {
    return false;
  }
  if (token.permissions.includes(permission)) return true;
  if (permission === 'read' && token.permissions.includes('write')) return true;
  return false;
}

export function actorFromToken(token: ApiToken): Actor {
  return {
    type: 'token',
    id: token.id,
    label: token.name,
    tokenPrefix: token.prefix,
  };
}
