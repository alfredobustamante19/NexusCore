export interface Actor {
  type: 'admin' | 'token';
  id: string;
  label: string;
  tokenPrefix: string | null;
}

export interface Project {
  id: string;
  name: string;
  slug: string;
  description: string;
  createdAt: string;
  updatedAt: string;
}

export interface Environment {
  id: string;
  projectId: string;
  name: string;
  currentRevision: number;
  createdAt: string;
}

export interface RequestMeta {
  ip: string;
  userAgent: string;
}
