import { existsSync } from 'node:fs';
import path from 'node:path';
import { parseMasterKey } from './crypto.ts';

export interface Config {
  masterKey: Buffer;
  host: string;
  port: number;
  dbPath: string;
  adminUsername: string;
  adminPassword: string | undefined;
  sessionTtlMs: number;
  cookieSecure: boolean;
  trustProxy: boolean;
  rateLimitMax: number;
  rateLimitWindowMs: number;
  loginRateLimitMax: number;
  loginRateLimitWindowMs: number;
  tlsCertFile: string | undefined;
  tlsKeyFile: string | undefined;
}

function requiredPositiveInt(raw: string | undefined, fallback: number, name: string): number {
  if (raw === undefined || raw === '') return fallback;
  if (!/^\d+$/.test(raw)) {
    throw new Error(`${name} must be a non-negative integer`);
  }
  const value = Number(raw);
  if (!Number.isSafeInteger(value)) {
    throw new Error(`${name} is out of range`);
  }
  return value;
}

export function loadConfig(env: NodeJS.ProcessEnv): Config {
  const masterRaw = env.NEXUSENV_MASTER_KEY;
  if (!masterRaw || !masterRaw.trim()) {
    throw new Error(
      'NEXUSENV_MASTER_KEY is required. Generate one with: node -e "process.stdout.write(require(\'crypto\').randomBytes(32).toString(\'hex\'))"',
    );
  }
  const masterKey = parseMasterKey(masterRaw);

  const dataDir = path.resolve(env.NEXUSENV_DATA_DIR?.trim() || 'data');
  const dbPath = path.resolve(env.NEXUSENV_DB_PATH?.trim() || path.join(dataDir, 'nexusenv.db'));

  const host = env.NEXUSENV_HOST?.trim() || '127.0.0.1';
  if (host.length === 0 || host.length > 255) {
    throw new Error('NEXUSENV_HOST is invalid');
  }

  const port = requiredPositiveInt(env.NEXUSENV_PORT, 8787, 'NEXUSENV_PORT');
  if (port > 65_535) {
    throw new Error('NEXUSENV_PORT must be between 0 and 65535');
  }

  const adminUsername = env.NEXUSENV_ADMIN_USERNAME?.trim() || 'admin';
  if (!/^[a-zA-Z0-9._-]{1,64}$/.test(adminUsername)) {
    throw new Error('NEXUSENV_ADMIN_USERNAME may contain only letters, numbers, dots, underscores, and hyphens');
  }

  const adminPassword = env.NEXUSENV_ADMIN_PASSWORD;
  if (adminPassword !== undefined && adminPassword.length > 0) {
    if (adminPassword.length < 10 || adminPassword.length > 256) {
      throw new Error('NEXUSENV_ADMIN_PASSWORD must be between 10 and 256 characters');
    }
  }

  const sessionHours = requiredPositiveInt(env.NEXUSENV_SESSION_TTL_HOURS, 12, 'NEXUSENV_SESSION_TTL_HOURS');
  if (sessionHours < 1 || sessionHours > 24 * 30) {
    throw new Error('NEXUSENV_SESSION_TTL_HOURS must be between 1 and 720');
  }

  const rateLimitMax = requiredPositiveInt(env.NEXUSENV_RATE_LIMIT_MAX, 60, 'NEXUSENV_RATE_LIMIT_MAX');
  const rateLimitWindowMs = requiredPositiveInt(
    env.NEXUSENV_RATE_LIMIT_WINDOW_MS,
    60_000,
    'NEXUSENV_RATE_LIMIT_WINDOW_MS',
  );
  if (rateLimitMax < 1 || rateLimitMax > 100_000) {
    throw new Error('NEXUSENV_RATE_LIMIT_MAX must be between 1 and 100000');
  }
  if (rateLimitWindowMs < 1000 || rateLimitWindowMs > 24 * 60 * 60 * 1000) {
    throw new Error('NEXUSENV_RATE_LIMIT_WINDOW_MS must be between 1000 and 86400000');
  }

  const tlsCertFile = env.NEXUSENV_TLS_CERT_FILE?.trim() || undefined;
  const tlsKeyFile = env.NEXUSENV_TLS_KEY_FILE?.trim() || undefined;
  if (Boolean(tlsCertFile) !== Boolean(tlsKeyFile)) {
    throw new Error('Set both NEXUSENV_TLS_CERT_FILE and NEXUSENV_TLS_KEY_FILE, or neither');
  }
  if (tlsCertFile && !existsSync(tlsCertFile)) {
    throw new Error(`TLS certificate file not found: ${tlsCertFile}`);
  }
  if (tlsKeyFile && !existsSync(tlsKeyFile)) {
    throw new Error(`TLS key file not found: ${tlsKeyFile}`);
  }

  let cookieSecure = Boolean(tlsCertFile);
  if (env.NEXUSENV_COOKIE_SECURE === 'true') cookieSecure = true;
  if (env.NEXUSENV_COOKIE_SECURE === 'false') cookieSecure = false;

  return {
    masterKey,
    host,
    port,
    dbPath,
    adminUsername,
    adminPassword: adminPassword && adminPassword.length > 0 ? adminPassword : undefined,
    sessionTtlMs: sessionHours * 60 * 60 * 1000,
    cookieSecure,
    trustProxy: env.NEXUSENV_TRUST_PROXY === 'true',
    rateLimitMax,
    rateLimitWindowMs,
    loginRateLimitMax: 10,
    loginRateLimitWindowMs: 15 * 60 * 1000,
    tlsCertFile,
    tlsKeyFile,
  };
}
