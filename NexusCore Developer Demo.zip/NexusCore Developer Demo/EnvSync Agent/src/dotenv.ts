import { EnvSyntaxError } from './errors.ts';
import { secretKeyError, type SecretInput } from './validate.ts';

function readQuoted(raw: string, line: number): string {
  const quote = raw[0];
  if (quote !== '"' && quote !== "'") {
    throw new EnvSyntaxError(line, `Invalid .env syntax at line ${line}`);
  }
  let out = '';
  for (let i = 1; i < raw.length; i += 1) {
    const ch = raw[i];
    if (ch === undefined) break;
    if (quote === '"' && ch === '\\') {
      const next = raw[i + 1];
      if (next === undefined) {
        throw new EnvSyntaxError(line, `Invalid .env syntax at line ${line}`);
      }
      if (next === 'n') out += '\n';
      else if (next === 'r') out += '\r';
      else out += next;
      i += 1;
      continue;
    }
    if (ch === quote) return out;
    out += ch;
  }
  throw new EnvSyntaxError(line, `Invalid .env syntax at line ${line}`);
}

export function parseEnv(text: string): SecretInput[] {
  const source = text.replace(/^\uFEFF/, '');
  const lines = source.split(/\r?\n/);
  const out: SecretInput[] = [];
  const seen = new Set<string>();
  for (let index = 0; index < lines.length; index += 1) {
    const lineNo = index + 1;
    const rawLine = lines[index] ?? '';
    const trimmed = rawLine.trim();
    if (trimmed.length === 0 || trimmed.startsWith('#')) continue;
    let body = trimmed;
    if (body.startsWith('export ')) {
      body = body.slice('export '.length).trim();
    }
    const eq = body.indexOf('=');
    if (eq <= 0) {
      throw new EnvSyntaxError(lineNo, `Invalid .env syntax at line ${lineNo}`);
    }
    const key = body.slice(0, eq).trim();
    if (secretKeyError(key)) {
      throw new EnvSyntaxError(lineNo, `Invalid secret key at line ${lineNo}`);
    }
    let rawValue = body.slice(eq + 1);
    let value: string;
    if (rawValue.startsWith('"') || rawValue.startsWith("'")) {
      value = readQuoted(rawValue.trim(), lineNo);
    } else {
      const comment = rawValue.indexOf(' #');
      if (comment >= 0) rawValue = rawValue.slice(0, comment);
      value = rawValue.trim();
    }
    if (seen.has(key)) {
      throw new EnvSyntaxError(lineNo, `Duplicate secret key at line ${lineNo}`);
    }
    seen.add(key);
    out.push({ key, value });
  }
  return out;
}

export function formatEnvValue(value: string): string {
  if (value === '') return '""';
  if (/^[A-Za-z0-9_@%^*+\-./:?]*$/.test(value)) return value;
  const escaped = value
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\r/g, '\\r')
    .replace(/\n/g, '\\n');
  return `"${escaped}"`;
}

export function formatEnv(entries: SecretInput[]): string {
  if (entries.length === 0) return '';
  return `${entries.map((entry) => `${entry.key}=${formatEnvValue(entry.value)}`).join('\n')}\n`;
}
