import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from 'node:crypto';
import { base64url } from './util.ts';

const SCRYPT_N = 16_384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const SCRYPT_KEYLEN = 64;

export class DecryptionError extends Error {
  constructor() {
    super('Decryption failed');
    this.name = 'DecryptionError';
  }
}

/**
 * Each secret value is stored as AES-256-GCM ciphertext.
 * The nonce is 12 random bytes and is never reused with the same master key.
 * Associated data binds the ciphertext to this service, project, environment,
 * secret name, and revision so a blob cannot be swapped into another record.
 */
export function secretAad(projectId: string, environment: string, key: string, revision: number): string {
  return ['nexusenv/v1', projectId, environment, key, String(revision)].join('\0');
}

export interface EncryptedSecret {
  ciphertext: string;
  nonce: string;
  tag: string;
}

function assertMasterKey(key: Buffer): void {
  if (key.length !== 32) {
    throw new Error('Master key must be 32 bytes');
  }
}

export function assertStrongKey(key: Buffer): Buffer {
  assertMasterKey(key);
  if (new Set(key).size < 8) {
    throw new Error('NEXUSENV_MASTER_KEY is not random enough. Generate 32 bytes from a CSPRNG.');
  }
  return key;
}

export function parseMasterKey(raw: string): Buffer {
  const value = raw.trim();
  if (!value) {
    throw new Error('NEXUSENV_MASTER_KEY is required');
  }
  if (/^[0-9a-fA-F]{64}$/.test(value)) {
    return assertStrongKey(Buffer.from(value, 'hex'));
  }
  const compact = value.replace(/\s+/g, '');
  if (!/^[A-Za-z0-9+/=_-]+$/.test(compact)) {
    throw new Error('NEXUSENV_MASTER_KEY must be 64 hex characters or base64-encoded 32 bytes.');
  }
  const b64 = compact.replace(/-/g, '+').replace(/_/g, '/');
  const buf = Buffer.from(b64, 'base64');
  if (buf.length !== 32) {
    throw new Error('NEXUSENV_MASTER_KEY must decode to exactly 32 bytes.');
  }
  return assertStrongKey(buf);
}

export function encryptSecret(masterKey: Buffer, plaintext: string, aad: string): EncryptedSecret {
  assertMasterKey(masterKey);
  const nonce = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', masterKey, nonce);
  cipher.setAAD(Buffer.from(aad, 'utf8'));
  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    ciphertext: ciphertext.toString('base64'),
    nonce: nonce.toString('base64'),
    tag: tag.toString('base64'),
  };
}

export function decryptSecret(
  masterKey: Buffer,
  ciphertext: string,
  nonce: string,
  tag: string,
  aad: string,
): string {
  try {
    assertMasterKey(masterKey);
    const nonceBuf = Buffer.from(nonce, 'base64');
    const tagBuf = Buffer.from(tag, 'base64');
    const data = Buffer.from(ciphertext, 'base64');
    if (nonceBuf.length !== 12 || tagBuf.length !== 16) {
      throw new DecryptionError();
    }
    const decipher = createDecipheriv('aes-256-gcm', masterKey, nonceBuf);
    decipher.setAAD(Buffer.from(aad, 'utf8'));
    decipher.setAuthTag(tagBuf);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  } catch (error) {
    if (error instanceof DecryptionError) throw error;
    throw new DecryptionError();
  }
}

export function sha256Hex(value: string): string {
  return createHash('sha256').update(value, 'utf8').digest('hex');
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, SCRYPT_KEYLEN, {
    N: SCRYPT_N,
    r: SCRYPT_R,
    p: SCRYPT_P,
    maxmem: 64 * 1024 * 1024,
  });
  return [
    'scrypt',
    String(SCRYPT_N),
    String(SCRYPT_R),
    String(SCRYPT_P),
    salt.toString('base64'),
    hash.toString('base64'),
  ].join('$');
}

export function verifyPassword(password: string, encoded: string): boolean {
  try {
    const parts = encoded.split('$');
    if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
    const n = Number(parts[1]);
    const r = Number(parts[2]);
    const p = Number(parts[3]);
    if (!Number.isInteger(n) || !Number.isInteger(r) || !Number.isInteger(p)) return false;
    const salt = Buffer.from(parts[4] ?? '', 'base64');
    const expected = Buffer.from(parts[5] ?? '', 'base64');
    if (salt.length < 8 || expected.length < 16) return false;
    const actual = scryptSync(password, salt, expected.length, {
      N: n,
      r,
      p,
      maxmem: 64 * 1024 * 1024,
    });
    if (actual.length !== expected.length) return false;
    return timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

export interface IssuedToken {
  secret: string;
  hash: string;
  prefix: string;
}

export function generateApiToken(): IssuedToken {
  const secret = `nxe_${base64url(randomBytes(32))}`;
  return {
    secret,
    hash: sha256Hex(secret),
    prefix: secret.slice(0, 12),
  };
}

export function generateSessionToken(): { secret: string; hash: string } {
  const secret = base64url(randomBytes(32));
  return { secret, hash: sha256Hex(secret) };
}

export function presentedTokenPrefix(token: string): string | null {
  if (!/^nxe_[A-Za-z0-9_-]{8}/.test(token)) return null;
  const prefix = token.slice(0, 12);
  if (!/^nxe_[A-Za-z0-9_-]{8}$/.test(prefix)) return null;
  return prefix;
}
