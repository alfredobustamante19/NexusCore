export const LIMITS = {
  maxSecrets: 200,
  maxKeyLength: 128,
  maxValueLength: 16_384,
  maxCommentLength: 500,
  maxProjectName: 80,
  maxDescription: 500,
  maxTokenName: 80,
  maxBodyBytes: 2 * 1024 * 1024,
  maxBearerLength: 200,
  maxPasswordLength: 256,
  minPasswordLength: 10,
} as const;

export const ENV_NAME = /^[a-z][a-z0-9_-]{0,31}$/;
export const SECRET_KEY = /^[A-Za-z_][A-Za-z0-9_]*$/;
