import { listAudit, writeAudit } from './audit.ts';
import {
  actorFromAdmin,
  assertPasswordShape,
  assertUsernameShape,
  changeAdminPassword,
  destroySession,
  loginAdmin,
  readSession,
} from './auth.ts';
import type { AppContext } from './context.ts';
import { presentedTokenPrefix } from './crypto.ts';
import { formatEnv, parseEnv } from './dotenv.ts';
import { ApiError, EnvSyntaxError } from './errors.ts';
import {
  clearSessionCookie,
  isContentType,
  readBody,
  readJson,
  sendJson,
  sendText,
  sessionCookie,
  type RequestContext,
  type Router,
} from './http.ts';
import { LIMITS } from './limits.ts';
import {
  createEnvironment,
  createProject,
  deleteEnvironment,
  deleteProject,
  getProjectByRef,
  listProjects,
  projectDetails,
  requireEnvironment,
  requireProject,
  updateProject,
} from './projects.ts';
import { listRevisions, pushSecrets, readSecrets, rollbackSecrets } from './secrets.ts';
import {
  actorFromToken,
  lookupApiToken,
  createToken,
  listTokens,
  normalizeTokenScopes,
  revokeToken,
  tokenAllows,
} from './tokens.ts';
import type { Actor, Project } from './types.ts';
import { VERSION } from './version.ts';
import {
  normalizeSecrets,
  optionalComment,
  optionalDescription,
  requireEnvName,
  requireLabel,
  requireRevision,
} from './validate.ts';

interface AuditBag {
  project: Project | null;
  environment: string | null;
  revision: number | null;
  actor: Actor | null;
}

function meta(ctx: RequestContext): { ip: string; userAgent: string } {
  return { ip: ctx.ip, userAgent: ctx.userAgent };
}

function failurePrefix(ctx: RequestContext): string | null {
  if (ctx.bearer) return presentedTokenPrefix(ctx.bearer);
  if (ctx.cookies.nexusenv_session) return 'invalid-session';
  return null;
}

function applyLimit(app: AppContext, ctx: RequestContext, bucket: 'pull' | 'push'): void {
  const decision = app.limiter.check(`${bucket}:${ctx.ip}`);
  ctx.rateHeaders['X-RateLimit-Limit'] = String(decision.limit);
  ctx.rateHeaders['X-RateLimit-Remaining'] = String(decision.remaining);
  if (!decision.allowed) {
    const retryAfter = String(Math.max(1, Math.ceil(decision.retryAfterMs / 1000)));
    ctx.rateHeaders['Retry-After'] = retryAfter;
    throw new ApiError(429, 'rate_limited', 'Too many requests', {
      'Retry-After': retryAfter,
      'X-RateLimit-Limit': String(decision.limit),
      'X-RateLimit-Remaining': '0',
    });
  }
}

function applyLoginLimit(app: AppContext, ctx: RequestContext): void {
  const decision = app.loginLimiter.check(`login:${ctx.ip}`);
  if (!decision.allowed) {
    const retryAfter = String(Math.max(1, Math.ceil(decision.retryAfterMs / 1000)));
    throw new ApiError(429, 'rate_limited', 'Too many login attempts', {
      'Retry-After': retryAfter,
    });
  }
}

async function withAccessAudit(
  app: AppContext,
  ctx: RequestContext,
  action: string,
  fn: (bag: AuditBag) => Promise<void>,
): Promise<void> {
  const bag: AuditBag = { project: null, environment: null, revision: null, actor: null };
  try {
    await fn(bag);
  } catch (error) {
    if (error instanceof ApiError) {
      writeAudit(app.db, {
        action,
        projectId: bag.project?.id ?? null,
        projectName: bag.project?.name ?? null,
        environment: bag.environment,
        tokenId: bag.actor?.id ?? null,
        tokenPrefix: bag.actor?.tokenPrefix ?? failurePrefix(ctx),
        ip: ctx.ip,
        userAgent: ctx.userAgent,
        revision: bag.revision,
        success: false,
        detail: error.code === 'rate_limited' ? 'rate limited' : error.message,
      });
    }
    throw error;
  }
}

function requireAdmin(app: AppContext, ctx: RequestContext): Actor {
  if (ctx.bearer) {
    throw new ApiError(403, 'forbidden', 'This endpoint requires an admin session');
  }
  const session = readSession(app.db, ctx.cookies.nexusenv_session);
  if (!session) throw new ApiError(401, 'unauthorized', 'Authentication required');
  return actorFromAdmin(session.userId, session.username);
}

function authorizeProject(
  app: AppContext,
  ctx: RequestContext,
  ref: string,
  environment: string | null,
  permission: 'read' | 'write',
  bag?: AuditBag,
): { project: Project; actor: Actor } {
  if (ctx.bearer) {
    const token = lookupApiToken(app.db, ctx.bearer);
    if (!token) throw new ApiError(401, 'unauthorized', 'Invalid API token');
    const project = getProjectByRef(app.db, ref);
    if (!project || project.id !== token.projectId) {
      throw new ApiError(404, 'not_found', 'Project not found');
    }
    const actor = actorFromToken(token);
    if (bag) {
      bag.project = project;
      bag.actor = actor;
    }
    if (token.revokedAt) throw new ApiError(401, 'unauthorized', 'Invalid API token');
    if (!tokenAllows(token, environment, permission)) {
      if (environment && !token.environments.includes('*') && !token.environments.includes(environment)) {
        throw new ApiError(403, 'forbidden', 'API token does not grant access to this environment');
      }
      throw new ApiError(403, 'forbidden', 'API token does not grant this permission');
    }
    return { project, actor };
  }
  const actor = requireAdmin(app, ctx);
  const project = requireProject(app.db, ref);
  if (bag) {
    bag.project = project;
    bag.actor = actor;
  }
  return { project, actor };
}

function parseOptionalRevision(raw: string | null): number | null {
  if (raw === null || raw === '') return null;
  if (!/^[1-9][0-9]{0,8}$/.test(raw)) {
    throw new ApiError(400, 'bad_request', 'revision must be a positive integer');
  }
  return Number(raw);
}

function envHeaders(environment: string, revision: number): Record<string, string> {
  return {
    'X-NexusEnv-Environment': environment,
    'X-NexusEnv-Revision': String(revision),
  };
}

function asRecord(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new ApiError(400, 'bad_request', 'Request body must be a JSON object');
  }
  return value as Record<string, unknown>;
}

export function registerRoutes(router: Router, app: AppContext): void {
  router.add('GET', '/api/v1/health', async (ctx) => {
    app.db.prepare('SELECT 1 AS ok').get();
    sendJson(ctx, 200, { status: 'ok', service: 'nexusenv', version: VERSION });
  });

  router.add('POST', '/api/v1/admin/login', async (ctx) => {
    applyLoginLimit(app, ctx);
    const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
    const username = assertUsernameShape(body.username);
    const password = assertPasswordShape(body.password);
    const session = loginAdmin(
      app.db,
      username,
      password,
      ctx.ip,
      app.dummyPasswordHash,
      app.config.sessionTtlMs,
    );
    if (!session) {
      writeAudit(app.db, {
        action: 'login_failure',
        ip: ctx.ip,
        userAgent: ctx.userAgent,
        success: false,
        detail: 'invalid credentials',
      });
      throw new ApiError(401, 'unauthorized', 'Invalid username or password');
    }
    writeAudit(app.db, {
      action: 'login_success',
      tokenId: session.userId,
      tokenPrefix: 'admin-session',
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      success: true,
      detail: 'admin login',
    });
    sendJson(
      ctx,
      200,
      { username: session.username },
      {
        'Set-Cookie': sessionCookie(
          session.token,
          Math.floor(app.config.sessionTtlMs / 1000),
          app.config.cookieSecure,
        ),
      },
    );
  });

  router.add('POST', '/api/v1/admin/logout', async (ctx) => {
    const actor = requireAdmin(app, ctx);
    destroySession(app.db, ctx.cookies.nexusenv_session);
    writeAudit(app.db, {
      action: 'logout',
      tokenId: actor.id,
      tokenPrefix: actor.tokenPrefix,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      success: true,
      detail: 'admin logout',
    });
    sendJson(ctx, 200, { ok: true }, { 'Set-Cookie': clearSessionCookie(app.config.cookieSecure) });
  });

  router.add('GET', '/api/v1/admin/session', async (ctx) => {
    const actor = requireAdmin(app, ctx);
    sendJson(ctx, 200, { username: actor.label });
  });

  router.add('POST', '/api/v1/admin/password', async (ctx) => {
    applyLoginLimit(app, ctx);
    const actor = requireAdmin(app, ctx);
    const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
    const currentPassword = assertPasswordShape(body.currentPassword);
    const newPassword = assertPasswordShape(body.newPassword);
    try {
      changeAdminPassword(app.db, actor.id, currentPassword, newPassword);
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) {
        writeAudit(app.db, {
          action: 'password_change',
          tokenId: actor.id,
          tokenPrefix: actor.tokenPrefix,
          ip: ctx.ip,
          userAgent: ctx.userAgent,
          success: false,
          detail: 'invalid credentials',
        });
      }
      throw error;
    }
    writeAudit(app.db, {
      action: 'password_change',
      tokenId: actor.id,
      tokenPrefix: actor.tokenPrefix,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      success: true,
      detail: 'password changed',
    });
    sendJson(ctx, 200, { ok: true }, { 'Set-Cookie': clearSessionCookie(app.config.cookieSecure) });
  });

  router.add('GET', '/api/v1/projects', async (ctx) => {
    requireAdmin(app, ctx);
    sendJson(ctx, 200, { projects: listProjects(app.db) });
  });

  router.add('POST', '/api/v1/projects', async (ctx) => {
    requireAdmin(app, ctx);
    const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
    const name = requireLabel(body.name, 'name', LIMITS.maxProjectName);
    const description = optionalDescription(body.description);
    const project = createProject(app.db, name, description);
    sendJson(ctx, 201, { project });
  });

  router.add('GET', '/api/v1/projects/:id', async (ctx) => {
    requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    sendJson(ctx, 200, { project: projectDetails(app.db, project) });
  });

  router.add('PATCH', '/api/v1/projects/:id', async (ctx) => {
    requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
    const patch: { name?: string; description?: string } = {};
    if (body.name !== undefined) patch.name = requireLabel(body.name, 'name', LIMITS.maxProjectName);
    if (body.description !== undefined) patch.description = optionalDescription(body.description);
    sendJson(ctx, 200, { project: updateProject(app.db, project, patch) });
  });

  router.add('DELETE', '/api/v1/projects/:id', async (ctx) => {
    requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    deleteProject(app.db, project.id);
    sendJson(ctx, 200, { ok: true });
  });

  router.add('POST', '/api/v1/projects/:id/environments', async (ctx) => {
    requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
    const name = requireEnvName(body.name);
    const environment = createEnvironment(app.db, project.id, name);
    sendJson(ctx, 201, { environment });
  });

  router.add('DELETE', '/api/v1/projects/:id/environments/:env', async (ctx) => {
    requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    const name = requireEnvName(ctx.params.env ?? '');
    deleteEnvironment(app.db, project.id, name);
    sendJson(ctx, 200, { ok: true });
  });

  router.add('POST', '/api/v1/projects/:id/secrets', async (ctx) => {
    await withAccessAudit(app, ctx, 'push', async (bag) => {
      applyLimit(app, ctx, 'push');
      const loaded = await loadPush(ctx);
      bag.environment = loaded.environment;
      const { project, actor } = authorizeProject(app, ctx, ctx.params.id ?? '', loaded.environment, 'write', bag);
      const environment = requireEnvironment(app.db, project.id, loaded.environment);
      const result = pushSecrets(app.db, app.config.masterKey, {
        project,
        environment,
        secrets: loaded.secrets,
        comment: loaded.comment,
        actor,
        meta: meta(ctx),
      });
      bag.revision = result.revision;
      sendJson(ctx, 201, {
        revision: result.revision,
        environment: environment.name,
        count: result.count,
        mode: 'replace',
      });
    });
  });

  router.add('GET', '/api/v1/projects/:id/env', async (ctx) => {
    await withAccessAudit(app, ctx, 'pull', async (bag) => {
      applyLimit(app, ctx, 'pull');
      const environmentName = ctx.query.get('environment');
      if (!environmentName) {
        throw new ApiError(400, 'bad_request', 'Query parameter environment is required');
      }
      const environmentLabel = requireEnvName(environmentName);
      bag.environment = environmentLabel;
      const format = ctx.query.get('format') ?? 'dotenv';
      if (format !== 'dotenv' && format !== 'json') {
        throw new ApiError(400, 'bad_request', 'format must be dotenv or json');
      }
      const { project, actor } = authorizeProject(app, ctx, ctx.params.id ?? '', environmentLabel, 'read', bag);
      const environment = requireEnvironment(app.db, project.id, environmentLabel);
      const requested = parseOptionalRevision(ctx.query.get('revision'));
      const revision = requested ?? environment.currentRevision;
      bag.revision = revision;
      const secrets =
        revision === 0
          ? []
          : readSecrets(app.db, app.config.masterKey, project.id, environment.name, environment.id, revision);
      writeAudit(app.db, {
        action: 'pull',
        projectId: project.id,
        projectName: project.name,
        environment: environment.name,
        tokenId: actor.id,
        tokenPrefix: actor.tokenPrefix,
        ip: ctx.ip,
        userAgent: ctx.userAgent,
        revision,
        success: true,
        detail: `format ${format}`,
      });
      const headers = envHeaders(environment.name, revision);
      if (format === 'json') {
        const record: Record<string, string> = {};
        for (const secret of secrets) record[secret.key] = secret.value;
        sendJson(
          ctx,
          200,
          {
            projectId: project.id,
            environment: environment.name,
            revision,
            secrets: record,
          },
          headers,
        );
        return;
      }
      sendText(ctx, 200, formatEnv(secrets), 'text/plain; charset=utf-8', headers);
    });
  });

  router.add('GET', '/api/v1/projects/:id/environments/:env/revisions', async (ctx) => {
    const environmentName = requireEnvName(ctx.params.env ?? '');
    const { project } = authorizeProject(app, ctx, ctx.params.id ?? '', environmentName, 'read');
    const environment = requireEnvironment(app.db, project.id, environmentName);
    sendJson(ctx, 200, {
      environment: environment.name,
      currentRevision: environment.currentRevision,
      revisions: listRevisions(app.db, environment.id),
    });
  });

  router.add('GET', '/api/v1/projects/:id/environments/:env/revisions/:rev', async (ctx) => {
    await withAccessAudit(app, ctx, 'pull', async (bag) => {
      applyLimit(app, ctx, 'pull');
      const environmentName = requireEnvName(ctx.params.env ?? '');
      bag.environment = environmentName;
      const { project, actor } = authorizeProject(app, ctx, ctx.params.id ?? '', environmentName, 'read', bag);
      const environment = requireEnvironment(app.db, project.id, environmentName);
      const revision = parseOptionalRevision(ctx.params.rev ?? null);
      if (!revision) throw new ApiError(400, 'bad_request', 'revision must be a positive integer');
      bag.revision = revision;
      const secrets = readSecrets(
        app.db,
        app.config.masterKey,
        project.id,
        environment.name,
        environment.id,
        revision,
      );
      const summary = listRevisions(app.db, environment.id).find((item) => item.revision === revision);
      writeAudit(app.db, {
        action: 'pull',
        projectId: project.id,
        projectName: project.name,
        environment: environment.name,
        tokenId: actor.id,
        tokenPrefix: actor.tokenPrefix,
        ip: ctx.ip,
        userAgent: ctx.userAgent,
        revision,
        success: true,
        detail: 'revision view',
      });
      sendJson(ctx, 200, {
        revision,
        comment: summary?.comment ?? '',
        createdAt: summary?.createdAt ?? null,
        actorType: summary?.actorType ?? null,
        actorLabel: summary?.actorLabel ?? null,
        secrets: secrets.map((secret) => ({ key: secret.key, value: secret.value })),
      });
    });
  });

  router.add('POST', '/api/v1/projects/:id/environments/:env/rollback', async (ctx) => {
    await withAccessAudit(app, ctx, 'rollback', async (bag) => {
      applyLimit(app, ctx, 'push');
      const environmentName = requireEnvName(ctx.params.env ?? '');
      bag.environment = environmentName;
      const { project, actor } = authorizeProject(app, ctx, ctx.params.id ?? '', environmentName, 'write', bag);
      const environment = requireEnvironment(app.db, project.id, environmentName);
      const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
      const target = requireRevision(body.revision);
      const comment = optionalComment(body.comment);
      const result = rollbackSecrets(app.db, app.config.masterKey, {
        project,
        environment,
        targetRevision: target,
        comment,
        actor,
        meta: meta(ctx),
      });
      bag.revision = result.revision;
      sendJson(ctx, 200, {
        environment: environment.name,
        revision: result.revision,
        restoredFrom: result.restoredFrom,
        count: result.count,
      });
    });
  });

  router.add('GET', '/api/v1/projects/:id/tokens', async (ctx) => {
    requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    sendJson(ctx, 200, { tokens: listTokens(app.db, project.id) });
  });

  router.add('POST', '/api/v1/projects/:id/tokens', async (ctx) => {
    const actor = requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
    const name = requireLabel(body.name, 'name', LIMITS.maxTokenName);
    const scopes = normalizeTokenScopes(
      body.environments,
      body.permissions,
      projectDetails(app.db, project).environments.map((item) => item.name),
    );
    const created = createToken(app.db, project.id, name, scopes.environments, scopes.permissions);
    writeAudit(app.db, {
      action: 'token_create',
      projectId: project.id,
      projectName: project.name,
      tokenId: created.token.id,
      tokenPrefix: created.token.prefix,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      success: true,
      detail: `name ${name}`,
    });
    sendJson(ctx, 201, {
      token: { ...created.token, secret: created.secret },
      issuedBy: actor.label,
    });
  });

  router.add('DELETE', '/api/v1/projects/:id/tokens/:tokenId', async (ctx) => {
    const actor = requireAdmin(app, ctx);
    const project = requireProject(app.db, ctx.params.id ?? '');
    const token = revokeToken(app.db, project.id, ctx.params.tokenId ?? '');
    writeAudit(app.db, {
      action: 'token_revoke',
      projectId: project.id,
      projectName: project.name,
      tokenId: token.id,
      tokenPrefix: token.prefix,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      success: true,
      detail: `revoked by ${actor.label}`,
    });
    sendJson(ctx, 200, { token });
  });

  router.add('GET', '/api/v1/audit', async (ctx) => {
    requireAdmin(app, ctx);
    const projectId = ctx.query.get('projectId') || undefined;
    const action = ctx.query.get('action') || undefined;
    if (action && !/^[a-z_]{1,64}$/.test(action)) {
      throw new ApiError(400, 'bad_request', 'Invalid action filter');
    }
    const limitRaw = ctx.query.get('limit');
    const offsetRaw = ctx.query.get('offset');
    const limit = limitRaw === null || limitRaw === '' ? 50 : Number(limitRaw);
    const offset = offsetRaw === null || offsetRaw === '' ? 0 : Number(offsetRaw);
    if (!Number.isInteger(limit) || limit < 1 || limit > 200) {
      throw new ApiError(400, 'bad_request', 'limit must be an integer from 1 to 200');
    }
    if (!Number.isInteger(offset) || offset < 0 || offset > 100_000) {
      throw new ApiError(400, 'bad_request', 'offset must be a non-negative integer');
    }
    const result = listAudit(app.db, { projectId, action, limit, offset });
    sendJson(ctx, 200, result);
  });
}

async function loadPush(
  ctx: RequestContext,
): Promise<{ environment: string; comment: string; secrets: ReturnType<typeof normalizeSecrets> }> {
  if (isContentType(ctx, 'application/json')) {
    const body = asRecord(await readJson(ctx, LIMITS.maxBodyBytes));
    return {
      environment: requireEnvName(body.environment),
      comment: optionalComment(body.comment),
      secrets: normalizeSecrets(body.secrets),
    };
  }
  if (isContentType(ctx, 'text/plain')) {
    const text = (await readBody(ctx.req, LIMITS.maxBodyBytes)).toString('utf8');
    try {
      return {
        environment: requireEnvName(ctx.query.get('environment')),
        comment: optionalComment(ctx.query.get('comment')),
        secrets: normalizeSecrets(parseEnv(text)),
      };
    } catch (error) {
      if (error instanceof EnvSyntaxError) {
        throw new ApiError(400, 'bad_request', error.message);
      }
      throw error;
    }
  }
  throw new ApiError(415, 'unsupported_media_type', 'Content-Type must be application/json or text/plain');
}
