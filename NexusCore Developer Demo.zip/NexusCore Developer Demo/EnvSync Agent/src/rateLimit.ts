export interface RateLimitDecision {
  allowed: boolean;
  limit: number;
  remaining: number;
  retryAfterMs: number;
}

export class SlidingWindowRateLimiter {
  private readonly hits = new Map<string, number[]>();
  private readonly limit: number;
  private readonly windowMs: number;
  private readonly now: () => number;

  constructor(options: { limit: number; windowMs: number; now?: () => number }) {
    if (!Number.isInteger(options.limit) || options.limit < 1) {
      throw new Error('Rate limit must be a positive integer');
    }
    if (!Number.isInteger(options.windowMs) || options.windowMs < 1) {
      throw new Error('Rate limit window must be a positive integer');
    }
    this.limit = options.limit;
    this.windowMs = options.windowMs;
    this.now = options.now ?? (() => Date.now());
  }

  check(key: string): RateLimitDecision {
    const now = this.now();
    this.sweep(now);
    const fresh = (this.hits.get(key) ?? []).filter((stamp) => now - stamp < this.windowMs);
    if (fresh.length >= this.limit) {
      const oldest = fresh[0] ?? now;
      this.hits.set(key, fresh);
      return {
        allowed: false,
        limit: this.limit,
        remaining: 0,
        retryAfterMs: Math.max(0, oldest + this.windowMs - now),
      };
    }
    fresh.push(now);
    this.hits.set(key, fresh);
    return {
      allowed: true,
      limit: this.limit,
      remaining: this.limit - fresh.length,
      retryAfterMs: 0,
    };
  }

  private sweep(now: number): void {
    if (this.hits.size < 5_000) return;
    for (const [key, stamps] of this.hits) {
      const fresh = stamps.filter((stamp) => now - stamp < this.windowMs);
      if (fresh.length === 0) this.hits.delete(key);
      else this.hits.set(key, fresh);
    }
  }
}
