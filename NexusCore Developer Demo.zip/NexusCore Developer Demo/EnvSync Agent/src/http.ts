import type { IncomingMessage, ServerResponse } from 'node:http';
import { ApiError } from './errors.ts';

export const SECURITY_HEADERS: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'X-DNS-Prefetch-Control': 'off',
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Cache-Control': 'no-store',
};

export interface RequestContext {
  req: IncomingMessage;
  res: ServerResponse;
  method: string;
  path: string;
  params: Record<string, string>;
  query: URLSearchParams;
  ip: string;
  userAgent: string;
  bearer: string | null;
  cookies: Record<string, string>;
  rateHeaders: Record<string, string>;
}

export function clientIp(req: IncomingMessage, trustProxy: boolean): string {
  if (trustProxy) {
    const forwarded = req.headers['x-forwarded-for'];
    const raw = Array.isArray(forwarded) ? forwarded[0] : forwarded;
    if (typeof raw === 'string' && raw.trim()) {
      return normalizeIp(raw.split(',')[0]?.trim() || 'unknown');
    }
  }
  return normalizeIp(req.socket.remoteAddress || 'unknown');
}

function normalizeIp(ip: string): string {
  const value = ip.startsWith('::ffff:') ? ip.slice('::ffff:'.length) : ip;
  return value.slice(0, 128);
}

export function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx <= 0) continue;
    const key = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (!key) continue;
    try {
      out[key] = decodeURIComponent(value);
    } catch {
      out[key] = value;
    }
  }
  return out;
}

export function readBearer(req: IncomingMessage): string | null {
  const header = req.headers.authorization;
  if (typeof header !== 'string') return null;
  const match = /^Bearer\s+(\S+)$/i.exec(header.trim());
  return match?.[1] ?? null;
}

export function sessionCookie(token: string, maxAgeSec: number, secure: boolean): string {
  const parts = [
    `nexusenv_session=${token}`,
    'HttpOnly',
    'SameSite=Strict',
    'Path=/',
    `Max-Age=${maxAgeSec}`,
  ];
  if (secure) parts.push('Secure');
  return parts.join('; ');
}

export function clearSessionCookie(secure: boolean): string {
  const parts = ['nexusenv_session=', 'HttpOnly', 'SameSite=Strict', 'Path=/', 'Max-Age=0'];
  if (secure) parts.push('Secure');
  return parts.join('; ');
}

export async function readBody(req: IncomingMessage, limit: number): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    size += buf.length;
    if (size > limit) {
      throw new ApiError(413, 'payload_too_large', 'Request body exceeds the configured limit');
    }
    chunks.push(buf);
  }
  return Buffer.concat(chunks);
}

export async function readJson(ctx: RequestContext, limit: number): Promise<unknown> {
  if (!isContentType(ctx, 'application/json')) {
    throw new ApiError(415, 'unsupported_media_type', 'Content-Type must be application/json');
  }
  const buf = await readBody(ctx.req, limit);
  if (buf.length === 0) {
    throw new ApiError(400, 'bad_request', 'Request body is required');
  }
  try {
    return JSON.parse(buf.toString('utf8')) as unknown;
  } catch {
    throw new ApiError(400, 'bad_request', 'Request body must be valid JSON');
  }
}

export function isContentType(ctx: RequestContext, type: string): boolean {
  const header = ctx.req.headers['content-type'];
  if (typeof header !== 'string') return false;
  return header.split(';')[0]?.trim().toLowerCase() === type;
}

export function userAgent(req: IncomingMessage): string {
  const value = req.headers['user-agent'];
  return typeof value === 'string' ? value.slice(0, 300) : '';
}

function applyHeaders(ctx: RequestContext, status: number, headers: Record<string, string | number>): void {
  for (const [key, value] of Object.entries(SECURITY_HEADERS)) {
    ctx.res.setHeader(key, value);
  }
  for (const [key, value] of Object.entries(ctx.rateHeaders)) {
    ctx.res.setHeader(key, value);
  }
  for (const [key, value] of Object.entries(headers)) {
    ctx.res.setHeader(key, value);
  }
  ctx.res.statusCode = status;
}

export function sendJson(ctx: RequestContext, status: number, body: unknown, extra: Record<string, string> = {}): void {
  const payload = JSON.stringify(body);
  applyHeaders(ctx, status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    ...extra,
  });
  ctx.res.end(payload);
}

export function sendText(
  ctx: RequestContext,
  status: number,
  body: string,
  contentType: string,
  extra: Record<string, string> = {},
): void {
  applyHeaders(ctx, status, {
    'Content-Type': contentType,
    'Content-Length': Buffer.byteLength(body),
    ...extra,
  });
  ctx.res.end(body);
}

export function sendBytes(
  ctx: RequestContext,
  status: number,
  body: Buffer,
  contentType: string,
): void {
  applyHeaders(ctx, status, {
    'Content-Type': contentType,
    'Content-Length': body.length,
  });
  ctx.res.end(body);
}

export function sendApiError(ctx: RequestContext, error: ApiError): void {
  for (const [key, value] of Object.entries(error.headers)) {
    ctx.rateHeaders[key] = value;
  }
  sendJson(ctx, error.status, { error: { code: error.code, message: error.message } });
}

export type Handler = (ctx: RequestContext) => Promise<void>;

interface CompiledRoute {
  method: string;
  regex: RegExp;
  keys: string[];
  handler: Handler;
}

export class Router {
  private readonly routes: CompiledRoute[] = [];

  add(method: string, path: string, handler: Handler): void {
    const keys: string[] = [];
    const pattern = path
      .split('/')
      .map((part) => {
        if (part.startsWith(':')) {
          keys.push(part.slice(1));
          return '([^/]+)';
        }
        return part.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      })
      .join('/');
    this.routes.push({
      method: method.toUpperCase(),
      regex: new RegExp(`^${pattern}$`),
      keys,
      handler,
    });
  }

  match(method: string, path: string): { handler: Handler; params: Record<string, string> } | { allow: string[] } | null {
    const matches: CompiledRoute[] = [];
    for (const route of this.routes) {
      if (route.regex.test(path)) matches.push(route);
    }
    if (matches.length === 0) return null;
    const found = matches.find((route) => route.method === method.toUpperCase());
    if (!found) {
      return { allow: [...new Set(matches.map((route) => route.method))] };
    }
    const result = found.regex.exec(path);
    const params: Record<string, string> = {};
    found.keys.forEach((key, index) => {
      const raw = result?.[index + 1] ?? '';
      try {
        params[key] = decodeURIComponent(raw);
      } catch {
        throw new ApiError(400, 'bad_request', 'Invalid URL encoding');
      }
    });
    return { handler: found.handler, params };
  }
}
