"""Self-hosted webhook ingestion, transformation, and multi-channel dispatch."""

__version__ = "1.0.0"
