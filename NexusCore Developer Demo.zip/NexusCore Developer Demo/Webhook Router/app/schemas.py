"""Pydantic models for the admin API, route configuration, and transform rules."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.config import get_settings
from app.services.security import assert_discord_webhook, assert_safe_outbound_url
from app.services.transformer import CASTS

AuthType = Literal["none", "bearer", "stripe", "hmac"]
DestinationType = Literal["database", "discord", "telegram", "webhook", "sheets"]
def format_validation_error(exc: Exception) -> str:
    """Flatten a Pydantic validation error into one readable sentence."""
    errors = getattr(exc, "errors", None)
    if not callable(errors):
        return str(exc)
    parts: list[str] = []
    for error in errors():
        location = ".".join(str(item) for item in error.get("loc", ()))
        message = str(error.get("msg", "invalid value"))
        parts.append(f"{location}: {message}" if location else message)
    return "; ".join(parts) or str(exc)


class TransformRules(BaseModel):
    """Declarative mapping applied to every payload received by an endpoint."""

    model_config = ConfigDict(extra="forbid")

    pick: list[str] = Field(default_factory=list, max_length=100)
    rename: dict[str, str] = Field(default_factory=dict)
    drop: list[str] = Field(default_factory=list, max_length=100)
    include: list[str] | None = None
    casts: dict[str, str] = Field(default_factory=dict)
    defaults: dict[str, Any] = Field(default_factory=dict)
    static: dict[str, Any] = Field(default_factory=dict)
    template_fields: dict[str, str] = Field(default_factory=dict)

    @field_validator("pick", "drop")
    @classmethod
    def paths_are_usable(cls, value: list[str]) -> list[str]:
        """Reject blank paths before they fail at runtime."""
        for item in value:
            if not item.strip():
                raise ValueError("paths must not be blank")
        return value

    @field_validator("include")
    @classmethod
    def include_is_usable(cls, value: list[str] | None) -> list[str] | None:
        """Reject a whitelist that contains a blank key."""
        if value is None:
            return None
        if not value:
            raise ValueError("include must list at least one key, or be omitted")
        if any(not item.strip() for item in value):
            raise ValueError("include keys must not be blank")
        return value

    @field_validator("rename")
    @classmethod
    def rename_pairs_are_usable(cls, value: dict[str, str]) -> dict[str, str]:
        """Reject empty rename sources or targets."""
        for old, new in value.items():
            if not old.strip() or not new.strip():
                raise ValueError("rename keys and values must not be blank")
        return value

    @field_validator("casts")
    @classmethod
    def casts_are_known(cls, value: dict[str, str]) -> dict[str, str]:
        """Allow only the casts the transformer implements."""
        unknown = sorted(set(value.values()) - CASTS)
        if unknown:
            raise ValueError(
                f"unsupported casts: {', '.join(unknown)}. "
                f"Choose from: {', '.join(sorted(CASTS))}"
            )
        return value

    @field_validator("defaults", "static")
    @classmethod
    def values_are_json(cls, value: dict[str, Any]) -> dict[str, Any]:
        """Keep injected values inside what JSON can store."""
        try:
            json.dumps(value)
        except TypeError as exc:
            raise ValueError("defaults and static values must be JSON values") from exc
        return value

    @model_validator(mode="after")
    def rules_stay_small(self) -> TransformRules:
        """Cap the serialized rule document so one endpoint cannot store a blob."""
        encoded = json.dumps(self.model_dump(mode="json"))
        if len(encoded) > 100_000:
            raise ValueError("transform_rules must be smaller than 100KB")
        return self


class EndpointCreate(BaseModel):
    """Body for creating an inbound webhook endpoint."""

    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "name": "Stripe payments",
                "slug": "stripe-payments",
                "description": "Successful charges forwarded to Discord",
                "auth_type": "stripe",
                "auth_secret": "whsec_replace_with_the_stripe_signing_secret",
                "idempotency_path": "id",
                "transform_rules": {
                    "pick": ["id", "type", "data.object.amount", "data.object.currency"],
                    "rename": {"data.object.amount": "amount_cents"},
                    "casts": {"amount_cents": "cents_to_decimal"},
                    "template_fields": {"summary": "{type} for {amount_cents} {currency}"},
                },
            }
        },
    )

    name: str = Field(min_length=1, max_length=120)
    slug: str = Field(min_length=1, max_length=80)
    description: str = Field(default="", max_length=2000)
    auth_type: AuthType = "bearer"
    auth_secret: str | None = Field(default=None, max_length=500)
    transform_rules: TransformRules = Field(default_factory=TransformRules)
    idempotency_path: str | None = Field(default=None, max_length=200)
    is_active: bool = True

    @field_validator("name", "description")
    @classmethod
    def strip_text(cls, value: str) -> str:
        """Trim surrounding whitespace from labels."""
        return value.strip()

    @field_validator("slug")
    @classmethod
    def normalize_slug(cls, value: str) -> str:
        """Store slugs in lower case and keep them URL-safe."""
        slug = value.strip().lower()
        if not _is_slug(slug):
            raise ValueError("slug must use lowercase letters, numbers, and single hyphens")
        return slug

    @field_validator("idempotency_path")
    @classmethod
    def normalize_idempotency_path(cls, value: str | None) -> str | None:
        """Treat a blank path as 'not set'."""
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None

    @model_validator(mode="after")
    def secret_matches_auth(self) -> EndpointCreate:
        """Require a usable secret for every auth mode except open endpoints."""
        if self.auth_type == "none":
            return self
        if not self.auth_secret or len(self.auth_secret.strip()) < 8:
            raise ValueError("auth_secret must be at least 8 characters unless auth_type is none")
        self.auth_secret = self.auth_secret.strip()
        return self


class EndpointUpdate(BaseModel):
    """Partial update. Omitted fields stay as they are."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, min_length=1, max_length=120)
    description: str | None = Field(default=None, max_length=2000)
    auth_type: AuthType | None = None
    auth_secret: str | None = Field(default=None, max_length=500)
    transform_rules: TransformRules | None = None
    idempotency_path: str | None = Field(default=None, max_length=200)
    is_active: bool | None = None

    @field_validator("name", "description")
    @classmethod
    def strip_optional_text(cls, value: str | None) -> str | None:
        """Trim labels when they are present."""
        if value is None:
            return None
        return value.strip()

    @field_validator("auth_secret")
    @classmethod
    def secret_length(cls, value: str | None) -> str | None:
        """Reject a secret rotation that would store a weak value."""
        if value is None:
            return None
        cleaned = value.strip()
        if len(cleaned) < 8:
            raise ValueError("auth_secret must be at least 8 characters")
        return cleaned

    @field_validator("idempotency_path")
    @classmethod
    def blank_path_clears_it(cls, value: str | None) -> str | None:
        """An empty string clears the idempotency path."""
        if value is None:
            return None
        return value.strip()


class EndpointOut(BaseModel):
    """Endpoint details safe to show in the admin API."""

    id: int
    name: str
    slug: str
    description: str
    auth_type: str
    has_secret: bool
    secret_hint: str | None
    transform_rules: dict[str, Any]
    idempotency_path: str | None
    is_active: bool
    ingest_path: str
    route_count: int
    created_at: datetime
    updated_at: datetime


class DiscordRouteConfig(BaseModel):
    """Discord incoming webhook."""

    model_config = ConfigDict(extra="forbid")

    webhook_url: str = Field(min_length=20, max_length=500)
    username: str | None = Field(default=None, max_length=80)
    message_template: str | None = Field(default=None, max_length=4000)
    use_embed: bool = True
    embed_title: str = Field(default="Webhook Bridge", max_length=256)
    embed_color: int = Field(default=0x5865F2, ge=0, le=0xFFFFFF)

    @field_validator("webhook_url")
    @classmethod
    def discord_url(cls, value: str) -> str:
        """Check the URL shape before anything is saved."""
        cleaned = value.strip()
        assert_discord_webhook(cleaned)
        return cleaned


class TelegramRouteConfig(BaseModel):
    """Telegram Bot API sendMessage target."""

    model_config = ConfigDict(extra="forbid")

    bot_token: str = Field(pattern=r"^\d{6,}:[A-Za-z0-9_-]{20,}$")
    chat_id: str = Field(min_length=1, max_length=64)
    message_template: str | None = Field(default=None, max_length=4000)
    parse_mode: Literal["HTML", "Markdown", "MarkdownV2"] | None = None

    @field_validator("chat_id", mode="before")
    @classmethod
    def chat_id_as_text(cls, value: object) -> object:
        """Allow a numeric chat id in JSON without quotes."""
        if isinstance(value, int) and not isinstance(value, bool):
            return str(value)
        return value


class WebhookRouteConfig(BaseModel):
    """Generic outbound HTTP request."""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(min_length=8, max_length=2000)
    method: Literal["POST", "PUT", "PATCH"] = "POST"
    headers: dict[str, str] = Field(default_factory=dict)
    timeout_seconds: float | None = Field(default=None, ge=3, le=120)
    include_metadata: bool = False

    @field_validator("url")
    @classmethod
    def outbound_url(cls, value: str) -> str:
        """Block metadata hosts and accidental plaintext URLs."""
        cleaned = value.strip()
        assert_safe_outbound_url(cleaned, allow_insecure_http=get_settings().allow_insecure_http)
        return cleaned

    @field_validator("headers")
    @classmethod
    def headers_are_safe(cls, value: dict[str, str]) -> dict[str, str]:
        """Reject header injection and oversized header blocks."""
        if len(value) > 30:
            raise ValueError("headers cannot contain more than 30 entries")
        for key, header_value in value.items():
            if not key.strip() or any(char in key or char in header_value for char in "\r\n"):
                raise ValueError("header names and values must not contain new lines")
            if len(key) > 80 or len(header_value) > 2000:
                raise ValueError("header names must be <= 80 characters and values <= 2000")
        return value


class SheetsRouteConfig(BaseModel):
    """Append one row to a Google Sheet with a service account."""

    model_config = ConfigDict(extra="forbid")

    spreadsheet_id: str = Field(pattern=r"^[a-zA-Z0-9_-]{10,128}$")
    range: str = Field(default="Sheet1!A1", max_length=128)
    columns: list[str] | None = None
    credentials_file: str | None = Field(default=None, max_length=500)
    credentials_json: dict[str, Any] | None = None
    value_input_option: Literal["RAW", "USER_ENTERED"] = "USER_ENTERED"

    @field_validator("range")
    @classmethod
    def range_is_a_sheet_range(cls, value: str) -> str:
        """Keep the A1 range free of control characters."""
        cleaned = value.strip()
        if not cleaned or any(char in cleaned for char in "\r\n"):
            raise ValueError("range must be a Google Sheets A1 range such as Sheet1!A1")
        return cleaned

    @field_validator("columns")
    @classmethod
    def columns_are_named(cls, value: list[str] | None) -> list[str] | None:
        """Require real field names when the caller specifies column order."""
        if value is None:
            return None
        cleaned = [item.strip() for item in value]
        if not cleaned or any(not item for item in cleaned):
            raise ValueError("columns must be a non-empty list of field names")
        if len(cleaned) > 100:
            raise ValueError("columns cannot contain more than 100 names")
        return cleaned

    @field_validator("credentials_file")
    @classmethod
    def credentials_path(cls, value: str | None) -> str | None:
        """Trim the service-account path."""
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None


class DatabaseRouteConfig(BaseModel):
    """Marker route. The payload is already stored before routes run."""

    model_config = ConfigDict(extra="forbid")

    note: str | None = Field(default=None, max_length=300)


_CONFIG_MODELS: dict[str, type[BaseModel]] = {
    "database": DatabaseRouteConfig,
    "discord": DiscordRouteConfig,
    "telegram": TelegramRouteConfig,
    "webhook": WebhookRouteConfig,
    "sheets": SheetsRouteConfig,
}


def validate_destination_config(destination_type: str, config: dict[str, Any]) -> dict[str, Any]:
    """Validate and normalize a route config for its destination type."""
    model = _CONFIG_MODELS.get(destination_type)
    if model is None:
        raise ValueError(
            "destination_type must be one of: database, discord, telegram, webhook, sheets"
        )
    try:
        parsed = model.model_validate(config or {})
    except Exception as exc:
        from pydantic import ValidationError

        if isinstance(exc, ValidationError):
            raise ValueError(format_validation_error(exc)) from exc
        raise
    return parsed.model_dump(mode="json")


class RouteCreate(BaseModel):
    """Body for attaching a destination to an endpoint."""

    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "name": "Ops Discord",
                "destination_type": "discord",
                "config": {
                    "webhook_url": "https://discord.com/api/webhooks/123/replace-me",
                    "message_template": "{summary}",
                },
            }
        },
    )

    name: str | None = Field(default=None, max_length=120)
    destination_type: DestinationType
    config: dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True

    @field_validator("name")
    @classmethod
    def strip_name(cls, value: str | None) -> str | None:
        """Trim the route label."""
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None


class RouteUpdate(BaseModel):
    """Partial route update. Destination type cannot change."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, min_length=1, max_length=120)
    config: dict[str, Any] | None = None
    is_active: bool | None = None

    @field_validator("name")
    @classmethod
    def strip_name(cls, value: str | None) -> str | None:
        """Trim the route label."""
        if value is None:
            return None
        return value.strip()


class RouteOut(BaseModel):
    """Route details with secrets masked."""

    id: int
    endpoint_id: int
    name: str
    destination_type: str
    config: dict[str, Any]
    is_active: bool
    created_at: datetime
    updated_at: datetime


class IngestResponse(BaseModel):
    """Acknowledgement returned to the external sender."""

    id: int
    status: Literal["accepted", "duplicate", "failed"]
    detail: str | None = None


class ErrorResponse(BaseModel):
    """Consistent error body for handled failures."""

    detail: str


class TrialRequest(BaseModel):
    """Sample payload used from the admin API."""

    model_config = ConfigDict(extra="forbid")

    payload: Any
    dispatch: bool = False

    @field_validator("payload")
    @classmethod
    def payload_is_json_container(cls, value: Any) -> Any:
        """Match what a real webhook body is allowed to be."""
        if not isinstance(value, (dict, list)):
            raise ValueError("payload must be a JSON object or array")
        return value


class TrialResponse(BaseModel):
    """Result of a dry run or a real admin test dispatch."""

    transformed: dict[str, Any] | None = None
    dispatched: bool
    payload_id: int | None = None
    status: str | None = None
    deliveries: list[dict[str, Any]] = Field(default_factory=list)


class DeliveryOut(BaseModel):
    """One outbound attempt."""

    id: int
    payload_id: int
    route_id: int | None
    destination_type: str
    destination_label: str
    status: str
    trigger: str
    attempt_count: int
    response_status: int | None
    response_excerpt: str
    error_message: str
    created_at: datetime
    completed_at: datetime | None


class PayloadOut(BaseModel):
    """Stored payload shown to the operator."""

    id: int
    endpoint_id: int
    endpoint_slug: str | None = None
    source: str
    status: str
    raw_payload: dict[str, Any] | list[Any] | None
    transformed_payload: dict[str, Any] | None
    request_headers: dict[str, Any]
    source_ip: str
    idempotency_key: str | None
    error_message: str
    received_at: datetime
    delivery_count: int = 0


class PayloadDetail(PayloadOut):
    """Payload plus the deliveries that were attempted."""

    deliveries: list[DeliveryOut] = Field(default_factory=list)


class PayloadPage(BaseModel):
    """One page of stored payloads."""

    items: list[PayloadOut]
    total: int
    limit: int
    offset: int


class DeliveryPage(BaseModel):
    """One page of delivery attempts."""

    items: list[DeliveryOut]
    total: int
    limit: int
    offset: int


class HealthResponse(BaseModel):
    """Liveness payload."""

    status: str
    version: str
    environment: str


def _is_slug(value: str) -> bool:
    if not value or value.startswith("-") or value.endswith("-") or "--" in value:
        return False
    return all(character.isalnum() or character == "-" for character in value)
