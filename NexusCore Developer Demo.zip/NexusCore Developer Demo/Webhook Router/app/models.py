"""Database tables for endpoints, routes, stored payloads, and deliveries."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import JSON


def utcnow() -> datetime:
    """Return the current time in UTC."""
    return datetime.now(timezone.utc)


def empty_dict() -> dict[str, object]:
    """Return a fresh dictionary for JSON column defaults."""
    return {}


class PayloadStatus:
    """Lifecycle of a stored inbound payload."""

    ACCEPTED = "accepted"
    PROCESSED = "processed"
    PARTIAL = "partial"
    FAILED = "failed"


class DeliveryStatus:
    """Lifecycle of one outbound delivery attempt."""

    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class Base(DeclarativeBase):
    """Shared declarative base."""


class WebhookEndpoint(Base):
    """An inbound URL (`/hooks/{slug}`) plus its auth and transform rules."""

    __tablename__ = "webhook_endpoints"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    slug: Mapped[str] = mapped_column(String(80), unique=True, index=True, nullable=False)
    description: Mapped[str] = mapped_column(Text, default="", nullable=False)
    auth_type: Mapped[str] = mapped_column(String(20), default="bearer", nullable=False)
    auth_secret: Mapped[str | None] = mapped_column(Text, nullable=True)
    transform_rules: Mapped[dict] = mapped_column(JSON, default=empty_dict, nullable=False)
    idempotency_path: Mapped[str | None] = mapped_column(String(200), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    routes: Mapped[list[Route]] = relationship(
        back_populates="endpoint",
        cascade="all, delete-orphan",
        order_by="Route.id",
    )
    payloads: Mapped[list[StoredPayload]] = relationship(back_populates="endpoint")

    def __repr__(self) -> str:
        return f"WebhookEndpoint(id={self.id}, slug={self.slug!r})"


class Route(Base):
    """One outbound destination attached to an endpoint."""

    __tablename__ = "routes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    endpoint_id: Mapped[int] = mapped_column(
        ForeignKey("webhook_endpoints.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    destination_type: Mapped[str] = mapped_column(String(32), nullable=False)
    config: Mapped[dict] = mapped_column(JSON, default=empty_dict, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    endpoint: Mapped[WebhookEndpoint] = relationship(back_populates="routes")

    def __repr__(self) -> str:
        return f"Route(id={self.id}, type={self.destination_type!r}, name={self.name!r})"


class StoredPayload(Base):
    """Raw and transformed body for one accepted webhook call."""

    __tablename__ = "stored_payloads"
    __table_args__ = (
        UniqueConstraint("endpoint_id", "idempotency_key", name="uq_payload_idempotency"),
        Index("ix_payloads_endpoint_received", "endpoint_id", "received_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    endpoint_id: Mapped[int] = mapped_column(
        ForeignKey("webhook_endpoints.id", ondelete="CASCADE"),
        nullable=False,
    )
    source: Mapped[str] = mapped_column(String(32), default="webhook", nullable=False)
    status: Mapped[str] = mapped_column(String(20), default=PayloadStatus.ACCEPTED, nullable=False, index=True)
    raw_body: Mapped[str] = mapped_column(Text, default="", nullable=False)
    raw_payload: Mapped[dict | list | None] = mapped_column(JSON, nullable=True)
    transformed_payload: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    request_headers: Mapped[dict] = mapped_column(JSON, default=empty_dict, nullable=False)
    source_ip: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(200), nullable=True)
    error_message: Mapped[str] = mapped_column(Text, default="", nullable=False)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)

    endpoint: Mapped[WebhookEndpoint] = relationship(back_populates="payloads")
    deliveries: Mapped[list[DeliveryAttempt]] = relationship(
        back_populates="payload",
        cascade="all, delete-orphan",
        order_by="DeliveryAttempt.id",
    )

    def __repr__(self) -> str:
        return f"StoredPayload(id={self.id}, status={self.status!r})"


class DeliveryAttempt(Base):
    """The outcome of sending one payload to one route, including retries."""

    __tablename__ = "delivery_attempts"
    __table_args__ = (Index("ix_deliveries_payload", "payload_id", "id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    payload_id: Mapped[int] = mapped_column(
        ForeignKey("stored_payloads.id", ondelete="CASCADE"),
        nullable=False,
    )
    route_id: Mapped[int | None] = mapped_column(
        ForeignKey("routes.id", ondelete="SET NULL"),
        nullable=True,
    )
    destination_type: Mapped[str] = mapped_column(String(32), nullable=False)
    destination_label: Mapped[str] = mapped_column(String(200), default="", nullable=False)
    status: Mapped[str] = mapped_column(String(20), default=DeliveryStatus.PENDING, nullable=False, index=True)
    trigger: Mapped[str] = mapped_column(String(20), default="ingest", nullable=False)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    response_status: Mapped[int | None] = mapped_column(Integer, nullable=True)
    response_excerpt: Mapped[str] = mapped_column(Text, default="", nullable=False)
    error_message: Mapped[str] = mapped_column(Text, default="", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    payload: Mapped[StoredPayload] = relationship(back_populates="deliveries")

    def __repr__(self) -> str:
        return f"DeliveryAttempt(id={self.id}, status={self.status!r}, type={self.destination_type!r})"
