"""Map an inbound JSON document into the shape destinations should receive.

Rule order:

1. `pick` builds a new object from dot paths, or the whole object is copied.
2. `rename` renames top-level keys, and dotted sources are copied onto new keys.
3. `casts` convert values in place.
4. `defaults` fill missing keys.
5. `static` overwrites keys with constants.
6. `template_fields` render `{placeholders}` from the object so far.
7. `include` keeps only the named keys.
8. `drop` removes keys.
"""

from __future__ import annotations

import json
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any


class _MissingType:
    """Sentinel for a dotted path that is not present. It is never a JSON value."""

    def __repr__(self) -> str:
        return "MISSING"


MISSING = _MissingType()

CASTS = frozenset(
    {
        "string",
        "integer",
        "float",
        "boolean",
        "cents_to_decimal",
        "unix_to_iso",
        "lower",
        "upper",
    }
)


class TransformError(Exception):
    """The payload could not be mapped with the endpoint's rules."""


def transform_payload(payload: Any, rules: dict | None) -> dict[str, Any]:
    """Return the mapped payload. The input is never mutated."""
    working_rules = dict(rules or {})
    source = payload if isinstance(payload, dict) else {"value": payload}
    result = _project(source, working_rules)
    _apply_casts(result, working_rules.get("casts") or {})
    for key, value in (working_rules.get("defaults") or {}).items():
        result.setdefault(str(key), value)
    for key, value in (working_rules.get("static") or {}).items():
        result[str(key)] = value
    for key, template in (working_rules.get("template_fields") or {}).items():
        result[str(key)] = render_template(str(template), result)
    include = working_rules.get("include")
    if include:
        result = {key: result[key] for key in include if key in result}
    for key in working_rules.get("drop") or []:
        result.pop(str(key), None)
    return result


def render_template(template: str, data: dict[str, Any]) -> str:
    """Substitute `{key}` placeholders. Missing keys stay visible in the text."""
    try:
        return template.format_map(_SafeMap({key: stringify(value) for key, value in data.items()}))
    except (ValueError, IndexError) as exc:
        raise TransformError(f"Could not render template {template!r}: {exc}") from exc


def stringify(value: Any) -> str:
    """Render a value for a message template or a sheet cell."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":"))
    return str(value)


def get_path(payload: Any, path: str) -> Any:
    """Read a dotted path such as `data.object.amount` or `items.0.sku`."""
    current = payload
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
            continue
        if isinstance(current, list) and part.isdigit():
            index = int(part)
            if index >= len(current):
                return MISSING
            current = current[index]
            continue
        return MISSING
    return current


def _project(source: dict[str, Any], rules: dict) -> dict[str, Any]:
    rename = {str(key): str(value) for key, value in (rules.get("rename") or {}).items()}
    pick = rules.get("pick") or []
    if pick:
        result: dict[str, Any] = {}
        for path in pick:
            value = get_path(source, str(path))
            if value is MISSING:
                continue
            output_key = rename.get(str(path), str(path).split(".")[-1])
            result[output_key] = deepcopy(value)
        return result

    result = deepcopy(source)
    for old, new in rename.items():
        if "." in old:
            value = get_path(source, old)
            if value is not MISSING:
                result[new] = deepcopy(value)
            continue
        if old in result:
            result[new] = result.pop(old)
    return result


def _apply_casts(result: dict[str, Any], casts: dict) -> None:
    for key, cast_name in casts.items():
        if key not in result:
            continue
        result[str(key)] = apply_cast(result[key], str(cast_name), str(key))


def apply_cast(value: Any, cast_name: str, key: str) -> Any:
    """Convert one value. Raises TransformError with the field name included."""
    try:
        if cast_name == "string":
            return stringify(value)
        if cast_name == "integer":
            if isinstance(value, bool):
                raise ValueError("booleans are not integers")
            return int(value)
        if cast_name == "float":
            if isinstance(value, bool):
                raise ValueError("booleans are not floats")
            return float(value)
        if cast_name == "boolean":
            return _as_bool(value)
        if cast_name == "cents_to_decimal":
            amount = (Decimal(str(value)) / Decimal("100")).quantize(Decimal("0.01"))
            return format(amount, "f")
        if cast_name == "unix_to_iso":
            return _unix_to_iso(value)
        if cast_name == "lower":
            return stringify(value).lower()
        if cast_name == "upper":
            return stringify(value).upper()
    except (ValueError, TypeError, InvalidOperation, OSError) as exc:
        raise TransformError(f"Could not cast '{key}' with '{cast_name}': {exc}") from exc
    raise TransformError(f"Unknown cast '{cast_name}' on '{key}'")


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "y"}:
            return True
        if lowered in {"0", "false", "no", "n", ""}:
            return False
    raise ValueError(f"cannot interpret {value!r} as a boolean")


def _unix_to_iso(value: Any) -> str:
    if isinstance(value, bool):
        raise ValueError("booleans are not timestamps")
    numeric = Decimal(str(value))
    if abs(numeric) > Decimal("10000000000"):
        numeric = numeric / Decimal("1000")
    moment = datetime.fromtimestamp(float(numeric), tz=timezone.utc)
    return moment.isoformat()


class _SafeMap(dict[str, str]):
    """Leave unknown `{placeholders}` intact instead of raising KeyError."""

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"
