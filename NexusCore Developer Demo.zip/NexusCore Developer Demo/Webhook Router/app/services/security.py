"""Inbound signature checks, outbound URL guards, and secret masking."""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import re
import secrets
import time
from urllib.parse import urlparse

from fastapi import Request

from app.config import Settings

BLOCKED_HOSTS = frozenset({"metadata.google.internal", "metadata.google.com"})
_DISCORD_HOSTS = frozenset(
    {"discord.com", "discordapp.com", "canary.discord.com", "ptb.discord.com"}
)
_MASK_MARK = "…"
_SENSITIVE_KEY = re.compile(r"token|secret|password|authorization|credential|api_key|apikey", re.I)


class AuthError(Exception):
    """The inbound request failed its endpoint's authentication check."""

    def __init__(self, detail: str) -> None:
        self.detail = detail
        super().__init__(detail)


def safe_compare(left: str, right: str) -> bool:
    """Compare two strings without leaking their contents through timing."""
    return secrets.compare_digest(left.encode("utf-8"), right.encode("utf-8"))


def mask_secret(value: object) -> str:
    """Hide a secret while leaving a short hint for the operator."""
    text = "" if value is None else str(value)
    if not text:
        return ""
    if len(text) <= 8:
        return "••••••••"
    return f"{text[:4]}{_MASK_MARK}{text[-4:]}"


def mask_config(config: dict) -> dict:
    """Return a copy of a route config with secrets replaced by hints."""
    masked: dict = {}
    for key, value in config.items():
        masked[key] = _mask_config_value(str(key), value)
    return masked


def _mask_config_value(key: str, value: object) -> object:
    lowered = key.lower()
    if lowered == "credentials_json" and isinstance(value, dict):
        return {
            "client_email": str(value.get("client_email", "")),
            "private_key": "***",
        }
    if lowered == "headers" and isinstance(value, dict):
        hidden: dict[str, object] = {}
        for header, header_value in value.items():
            if _SENSITIVE_KEY.search(str(header)):
                hidden[str(header)] = mask_secret(header_value)
            else:
                hidden[str(header)] = header_value
        return hidden
    if lowered == "webhook_url" and isinstance(value, str):
        return mask_secret(value)
    if _SENSITIVE_KEY.search(lowered):
        if isinstance(value, dict):
            return "***"
        return mask_secret(value)
    return value


def merge_route_config(existing: dict, updates: dict) -> dict:
    """Merge a route update, keeping secrets when the client echoes a mask."""
    current_mask = mask_config(existing)
    merged = dict(existing)
    for key, value in updates.items():
        if value is None:
            merged.pop(key, None)
            continue
        if key == "headers" and isinstance(value, dict):
            merged["headers"] = _merge_headers(existing.get("headers") or {}, current_mask.get("headers") or {}, value)
            continue
        if key == "credentials_json" and isinstance(value, dict):
            merged["credentials_json"] = _merge_credentials(existing.get("credentials_json") or {}, value)
            continue
        if key in current_mask and value == current_mask[key]:
            continue
        merged[key] = value
    return merged


def _merge_headers(existing: dict, masked: dict, updates: dict) -> dict:
    merged = dict(existing)
    for key, value in updates.items():
        if value is None:
            merged.pop(str(key), None)
            continue
        if key in masked and value == masked[key]:
            continue
        merged[str(key)] = value
    return merged


def _merge_credentials(existing: dict, updates: dict) -> dict:
    merged = dict(existing) if isinstance(existing, dict) else {}
    for key, value in updates.items():
        if key == "private_key" and value == "***":
            continue
        merged[key] = value
    return merged


def client_ip(request: Request, settings: Settings) -> str:
    """Return the caller address, honoring X-Forwarded-For only when configured."""
    if settings.trust_proxy:
        forwarded = request.headers.get("x-forwarded-for", "")
        if forwarded:
            return forwarded.split(",")[0].strip()[:64]
    if request.client is None or not request.client.host:
        return ""
    return request.client.host[:64]


def safe_request_headers(headers: object) -> dict[str, str]:
    """Keep a small, non-secret subset of request headers for the payload log."""
    kept = ("content-type", "user-agent", "x-request-id", "idempotency-key")
    snapshot: dict[str, str] = {}
    for name in kept:
        value = headers.get(name)  # type: ignore[attr-defined]
        if value:
            snapshot[name] = str(value)[:300]
    if headers.get("stripe-signature"):  # type: ignore[attr-defined]
        snapshot["stripe-signature"] = "present"
    if headers.get("x-signature") or headers.get("x-hub-signature-256"):  # type: ignore[attr-defined]
        snapshot["signature"] = "present"
    return snapshot


def verify_endpoint_auth(
    *,
    auth_type: str,
    secret: str | None,
    body: bytes,
    headers: object,
    tolerance_seconds: int,
) -> None:
    """Validate the inbound request for the endpoint's auth mode.

    Raises:
        AuthError: The request is missing credentials or the check failed.
    """
    if auth_type == "none":
        return
    if not secret:
        raise AuthError("This endpoint has no secret configured")
    if auth_type == "bearer":
        _verify_bearer(secret, headers)
        return
    if auth_type == "stripe":
        signature = headers.get("stripe-signature", "")  # type: ignore[attr-defined]
        _verify_stripe(secret, body, signature, tolerance_seconds)
        return
    if auth_type == "hmac":
        signature = headers.get("x-hub-signature-256") or headers.get("x-signature") or ""  # type: ignore[attr-defined]
        _verify_hmac(secret, body, str(signature))
        return
    raise AuthError("This endpoint uses an unsupported auth type")


def _verify_bearer(secret: str, headers: object) -> None:
    presented = ""
    authorization = headers.get("authorization", "")  # type: ignore[attr-defined]
    if isinstance(authorization, str) and authorization.lower().startswith("bearer "):
        presented = authorization.split(" ", 1)[1].strip()
    if not presented:
        alternate = headers.get("x-webhook-token", "")  # type: ignore[attr-defined]
        presented = str(alternate).strip()
    if not presented:
        raise AuthError("Missing bearer token")
    if not safe_compare(presented, secret):
        raise AuthError("Invalid bearer token")


def _verify_hmac(secret: str, body: bytes, signature: str) -> None:
    presented = signature.strip()
    if presented.lower().startswith("sha256="):
        presented = presented.split("=", 1)[1].strip()
    if not presented:
        raise AuthError("Missing signature")
    expected = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    if not safe_compare(expected, presented.lower()):
        raise AuthError("Invalid signature")


def _verify_stripe(secret: str, body: bytes, signature_header: str, tolerance_seconds: int) -> None:
    if not signature_header:
        raise AuthError("Missing Stripe-Signature header")
    parts: dict[str, list[str]] = {}
    for item in signature_header.split(","):
        key, separator, value = item.strip().partition("=")
        if separator:
            parts.setdefault(key, []).append(value)
    timestamps = parts.get("t") or []
    signatures = parts.get("v1") or []
    if not timestamps or not signatures:
        raise AuthError("Invalid signature")
    try:
        timestamp = int(timestamps[0])
    except ValueError as exc:
        raise AuthError("Invalid signature") from exc
    if abs(int(time.time()) - timestamp) > tolerance_seconds:
        raise AuthError("Signature timestamp is outside the allowed window")
    signed = f"{timestamp}.".encode("utf-8") + body
    expected = hmac.new(secret.encode("utf-8"), signed, hashlib.sha256).hexdigest()
    if not any(safe_compare(expected, candidate.lower()) for candidate in signatures):
        raise AuthError("Invalid signature")


def assert_discord_webhook(url: str) -> None:
    """Accept only official Discord webhook URLs."""
    parsed = urlparse(url.strip())
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme != "https" or host not in _DISCORD_HOSTS:
        raise ValueError("Discord webhook_url must be an https://discord.com/api/webhooks/... URL")
    if not parsed.path.startswith("/api/webhooks/"):
        raise ValueError("Discord webhook_url path must start with /api/webhooks/")


def assert_safe_outbound_url(url: str, *, allow_insecure_http: bool) -> None:
    """Reject malformed, credentialed, or cloud-metadata outbound URLs.

    Plain HTTP is limited to localhost unless `allow_insecure_http` is on,
    which is the switch for a private LAN target you control.
    """
    parsed = urlparse(url.strip())
    if parsed.username or parsed.password:
        raise ValueError("Outbound URL must not include embedded credentials")
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme not in {"http", "https"} or not host:
        raise ValueError("Outbound URL must be an absolute http(s) URL")
    if host in BLOCKED_HOSTS:
        raise ValueError("Outbound URL host is blocked")
    literal = _literal_ip(host)
    if literal is not None and _is_blocked_ip(literal):
        raise ValueError("Outbound URL host is blocked")
    if parsed.scheme == "http" and host not in {"localhost", "127.0.0.1", "::1"}:
        if not allow_insecure_http:
            raise ValueError(
                "Outbound http URLs are disabled except for localhost. "
                "Use https, or set ALLOW_INSECURE_HTTP=true for a private network target."
            )


def redact_text(text: str, secrets_to_hide: list[str]) -> str:
    """Remove known secrets from an error string before it is stored or logged."""
    cleaned = text
    for secret in secrets_to_hide:
        if secret and len(secret) >= 6:
            cleaned = cleaned.replace(secret, "***")
    return cleaned[:1000]


def _literal_ip(host: str) -> ipaddress.IPv4Address | ipaddress.IPv6Address | None:
    candidate = host
    if candidate.startswith("[") and candidate.endswith("]"):
        candidate = candidate[1:-1]
    try:
        return ipaddress.ip_address(candidate)
    except ValueError:
        return None


def _is_blocked_ip(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    return bool(ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified)
