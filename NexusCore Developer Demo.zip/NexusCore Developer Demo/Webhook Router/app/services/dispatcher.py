"""Send a transformed payload to every active route, with retries."""

from __future__ import annotations

import json
import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app import __version__
from app.config import get_settings
from app.database import get_session_factory
from app.models import (
    DeliveryAttempt,
    DeliveryStatus,
    PayloadStatus,
    Route,
    StoredPayload,
    WebhookEndpoint,
    utcnow,
)
from app.schemas import (
    DiscordRouteConfig,
    SheetsRouteConfig,
    TelegramRouteConfig,
    WebhookRouteConfig,
)
from app.services.security import redact_text
from app.services.transformer import TransformError, render_template, stringify, transform_payload

logger = logging.getLogger("bridge.dispatcher")

_LOCKS_GUARD = threading.Lock()
_PAYLOAD_LOCKS: dict[int, threading.Lock] = {}
_SHEETS_GUARD = threading.Lock()
_SHEETS_CLIENTS: dict[str, Any] = {}
_SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets"
_RESUME_AGE = timedelta(seconds=60)


@dataclass
class DispatchContext:
    """Values a destination formatter is allowed to see."""

    payload: dict[str, Any]
    endpoint_slug: str
    endpoint_name: str
    payload_id: int
    received_at: str


@dataclass
class AttemptOutcome:
    """Result of a single try, before the retry loop decides to continue."""

    success: bool
    retryable: bool
    status_code: int | None
    body: str
    error: str
    retry_after: float | None = None


@dataclass
class DeliveryResult:
    """Final result stored on a delivery row."""

    success: bool
    attempt_count: int
    response_status: int | None
    response_excerpt: str
    error_message: str


class DispatchConfigError(Exception):
    """The route is configured in a way a retry cannot fix."""


def dispatch_stored_payload(
    payload_id: int,
    *,
    trigger: str = "ingest",
    force: bool = False,
    retransform: bool = False,
) -> dict[str, Any]:
    """Deliver one stored payload. Concurrent calls for the same id wait in line."""
    with _lock_for(payload_id):
        try:
            return _dispatch(payload_id, trigger=trigger, force=force, retransform=retransform)
        except Exception:
            logger.exception("dispatch crashed payload_id=%s", payload_id)
            return {
                "payload_id": payload_id,
                "status": PayloadStatus.FAILED,
                "detail": "Dispatch failed unexpectedly. See app.log.",
                "deliveries": [],
            }


def resume_pending_deliveries() -> None:
    """Finish deliveries that were still pending after a restart."""
    factory = get_session_factory()
    session = factory()
    try:
        cutoff = utcnow() - _RESUME_AGE
        pending_ids = session.scalars(
            select(DeliveryAttempt.payload_id).where(
                DeliveryAttempt.status == DeliveryStatus.PENDING,
                DeliveryAttempt.created_at <= cutoff,
            )
        ).all()
        accepted_ids = session.scalars(
            select(StoredPayload.id).where(StoredPayload.status == PayloadStatus.ACCEPTED)
        ).all()
        payload_ids = sorted(set(pending_ids).union(accepted_ids))
    finally:
        session.close()

    for payload_id in payload_ids:
        logger.info("resuming payload_id=%s", payload_id)
        dispatch_stored_payload(payload_id, trigger="resume", force=False)


def deliver_route(route: Route, context: DispatchContext) -> DeliveryResult:
    """Send to one route. Network failures are retried. Bad config is not."""
    try:
        if route.destination_type == "database":
            return DeliveryResult(True, 1, None, "Stored in the local database", "")
        if route.destination_type == "discord":
            config = DiscordRouteConfig.model_validate(route.config)
            return _send_discord(config, context)
        if route.destination_type == "telegram":
            config = TelegramRouteConfig.model_validate(route.config)
            return _send_telegram(config, context)
        if route.destination_type == "webhook":
            config = WebhookRouteConfig.model_validate(route.config)
            return _send_webhook(config, context)
        if route.destination_type == "sheets":
            config = SheetsRouteConfig.model_validate(route.config)
            return _send_sheets(config, context)
        return DeliveryResult(False, 1, None, "", f"Unknown destination '{route.destination_type}'")
    except ValidationError as exc:
        return DeliveryResult(False, 1, None, "", f"Route configuration is invalid: {exc.errors()[0]['msg']}")
    except DispatchConfigError as exc:
        return DeliveryResult(False, 1, None, "", str(exc)[:1000])
    except TransformError as exc:
        return DeliveryResult(False, 1, None, "", str(exc)[:1000])
    except Exception:
        logger.exception("unexpected dispatch error route_id=%s", route.id)
        return DeliveryResult(False, 1, None, "", "Unexpected dispatch error")


def build_sheet_row(payload: dict[str, Any], columns: list[str] | None) -> list[Any]:
    """Build one spreadsheet row in a stable column order."""
    keys = columns if columns else sorted(payload.keys())
    return [_sheet_cell(payload.get(key)) for key in keys]


def destination_label(route: Route) -> str:
    """Human-readable destination name that does not include secrets."""
    config = route.config or {}
    if route.destination_type == "discord":
        return "Discord webhook"
    if route.destination_type == "telegram":
        return f"Telegram {config.get('chat_id', '')}".strip()
    if route.destination_type == "webhook":
        host = urlparse(str(config.get("url", ""))).hostname or "webhook"
        return f"Webhook {host}"
    if route.destination_type == "sheets":
        return f"Sheet {config.get('spreadsheet_id', '')}".strip()
    if route.destination_type == "database":
        return "Local database"
    return route.destination_type


def _dispatch(
    payload_id: int,
    *,
    trigger: str,
    force: bool,
    retransform: bool,
) -> dict[str, Any]:
    factory = get_session_factory()
    session = factory()
    try:
        payload = session.scalars(
            select(StoredPayload)
            .where(StoredPayload.id == payload_id)
            .options(
                selectinload(StoredPayload.endpoint).selectinload(WebhookEndpoint.routes),
                selectinload(StoredPayload.deliveries),
            )
        ).first()
        if payload is None:
            logger.warning("payload_id=%s disappeared before dispatch", payload_id)
            return {"payload_id": payload_id, "status": "missing", "deliveries": []}

        endpoint = payload.endpoint
        transform_error = _maybe_retransform(session, payload, endpoint, retransform)
        if transform_error:
            return {
                "payload_id": payload.id,
                "status": payload.status,
                "detail": transform_error,
                "deliveries": [],
            }
        if payload.transformed_payload is None:
            return {
                "payload_id": payload.id,
                "status": payload.status,
                "detail": payload.error_message or "Payload has no transformed body",
                "deliveries": [],
            }

        active_routes = sorted(
            (route for route in endpoint.routes if route.is_active),
            key=lambda route: route.id,
        )
        context = DispatchContext(
            payload=dict(payload.transformed_payload),
            endpoint_slug=endpoint.slug,
            endpoint_name=endpoint.name,
            payload_id=payload.id,
            received_at=payload.received_at.isoformat(),
        )
        for route in active_routes:
            _deliver_one(session, payload, route, context, trigger=trigger, force=force)

        _refresh_payload_status(session, payload, active_routes)
        session.commit()
        deliveries = [_delivery_dict(item) for item in payload.deliveries]
        logger.info(
            "dispatch finished payload_id=%s status=%s routes=%s",
            payload.id,
            payload.status,
            len(active_routes),
        )
        return {"payload_id": payload.id, "status": payload.status, "deliveries": deliveries}
    finally:
        session.close()


def _maybe_retransform(
    session: Session,
    payload: StoredPayload,
    endpoint: WebhookEndpoint,
    retransform: bool,
) -> str | None:
    if payload.transformed_payload is not None and not retransform:
        return None
    source = payload.raw_payload if payload.raw_payload is not None else {}
    try:
        payload.transformed_payload = transform_payload(source, endpoint.transform_rules or {})
    except TransformError as exc:
        payload.status = PayloadStatus.FAILED
        payload.error_message = str(exc)[:2000]
        session.commit()
        return payload.error_message
    payload.error_message = ""
    payload.status = PayloadStatus.ACCEPTED
    session.commit()
    return None


def _deliver_one(
    session: Session,
    payload: StoredPayload,
    route: Route,
    context: DispatchContext,
    *,
    trigger: str,
    force: bool,
) -> None:
    existing = [item for item in payload.deliveries if item.route_id == route.id]
    latest = existing[-1] if existing else None
    if not force and latest is not None and latest.status in {DeliveryStatus.SUCCESS, DeliveryStatus.FAILED}:
        return
    if not force and latest is not None and latest.status == DeliveryStatus.PENDING:
        attempt = latest
    else:
        attempt = DeliveryAttempt(
            payload_id=payload.id,
            route_id=route.id,
            destination_type=route.destination_type,
            destination_label=destination_label(route)[:200],
            status=DeliveryStatus.PENDING,
            trigger=trigger,
            created_at=utcnow(),
        )
        session.add(attempt)
        payload.deliveries.append(attempt)
        session.commit()

    result = deliver_route(route, context)
    attempt.attempt_count = result.attempt_count
    attempt.response_status = result.response_status
    attempt.response_excerpt = result.response_excerpt[:2000]
    attempt.error_message = result.error_message[:2000]
    attempt.status = DeliveryStatus.SUCCESS if result.success else DeliveryStatus.FAILED
    attempt.completed_at = utcnow()
    session.commit()
    if result.success:
        logger.info(
            "delivered payload_id=%s route_id=%s type=%s attempts=%s status_code=%s",
            payload.id,
            route.id,
            route.destination_type,
            result.attempt_count,
            result.response_status,
        )
    else:
        logger.error(
            "delivery failed payload_id=%s route_id=%s type=%s attempts=%s error=%s",
            payload.id,
            route.id,
            route.destination_type,
            result.attempt_count,
            result.error_message,
        )


def _refresh_payload_status(session: Session, payload: StoredPayload, routes: list[Route]) -> None:
    del session
    if not routes:
        payload.status = PayloadStatus.PROCESSED
        return
    latest: dict[int, DeliveryAttempt] = {}
    for attempt in payload.deliveries:
        if attempt.route_id is not None:
            latest[attempt.route_id] = attempt
    outcomes = [latest.get(route.id) for route in routes]
    if any(item is None or item.status == DeliveryStatus.PENDING for item in outcomes):
        payload.status = PayloadStatus.ACCEPTED
        return
    successes = [item for item in outcomes if item is not None and item.status == DeliveryStatus.SUCCESS]
    if len(successes) == len(routes):
        payload.status = PayloadStatus.PROCESSED
    elif successes:
        payload.status = PayloadStatus.PARTIAL
    else:
        payload.status = PayloadStatus.FAILED


def _delivery_dict(attempt: DeliveryAttempt) -> dict[str, Any]:
    return {
        "id": attempt.id,
        "route_id": attempt.route_id,
        "destination_type": attempt.destination_type,
        "destination_label": attempt.destination_label,
        "status": attempt.status,
        "trigger": attempt.trigger,
        "attempt_count": attempt.attempt_count,
        "response_status": attempt.response_status,
        "error_message": attempt.error_message,
    }


def _send_discord(config: DiscordRouteConfig, context: DispatchContext) -> DeliveryResult:
    content = _message_text(config.message_template, context.payload, limit=1900)
    if config.use_embed:
        body: dict[str, Any] = {
            "embeds": [
                {
                    "title": render_template(config.embed_title, context.payload)[:256],
                    "description": content[:4096],
                    "color": config.embed_color,
                    "fields": _embed_fields(context.payload),
                }
            ]
        }
    else:
        body = {"content": content[:2000]}
    if config.username:
        body["username"] = config.username[:80]
    return _request_with_retries(
        "POST",
        config.webhook_url,
        json_body=body,
        headers={},
        timeout=None,
        secrets=[config.webhook_url],
    )


def _send_telegram(config: TelegramRouteConfig, context: DispatchContext) -> DeliveryResult:
    text = _message_text(config.message_template, context.payload, limit=3900)
    if config.parse_mode == "HTML" and not config.message_template:
        text = _html_escape(text)
    body: dict[str, Any] = {"chat_id": config.chat_id, "text": text}
    if config.parse_mode:
        body["parse_mode"] = config.parse_mode
    url = f"https://api.telegram.org/bot{config.bot_token}/sendMessage"
    return _request_with_retries(
        "POST",
        url,
        json_body=body,
        headers={},
        timeout=None,
        secrets=[config.bot_token, url],
    )


def _send_webhook(config: WebhookRouteConfig, context: DispatchContext) -> DeliveryResult:
    if config.include_metadata:
        json_body: dict[str, Any] = {
            "data": context.payload,
            "meta": {
                "endpoint": context.endpoint_slug,
                "endpoint_name": context.endpoint_name,
                "payload_id": context.payload_id,
                "received_at": context.received_at,
            },
        }
    else:
        json_body = context.payload
    header_secrets = [value for key, value in config.headers.items() if value and len(value) >= 6]
    return _request_with_retries(
        config.method,
        config.url,
        json_body=json_body,
        headers=config.headers,
        timeout=config.timeout_seconds,
        secrets=[config.url, *header_secrets],
    )


def _send_sheets(config: SheetsRouteConfig, context: DispatchContext) -> DeliveryResult:
    info = _load_service_account(config)
    row = build_sheet_row(context.payload, config.columns)
    secrets = [str(info.get("private_key", "")), str(info.get("private_key_id", ""))]

    def operation() -> AttemptOutcome:
        try:
            service = _sheets_service(info)
            response = (
                service.spreadsheets()
                .values()
                .append(
                    spreadsheetId=config.spreadsheet_id,
                    range=config.range,
                    valueInputOption=config.value_input_option,
                    insertDataOption="INSERT_ROWS",
                    body={"values": [row]},
                )
                .execute()
            )
        except DispatchConfigError:
            raise
        except Exception as exc:
            status = _status_code_from_exception(exc)
            name = type(exc).__name__
            if status is None:
                retryable = any(token in name for token in ("Timeout", "Connection", "Transport"))
            else:
                retryable = status in {408, 429} or status >= 500
            message = redact_text(f"{name}: {exc}", secrets)
            return AttemptOutcome(False, retryable, status, "", message)
        excerpt = json.dumps(response, default=str)[:2000] if response is not None else ""
        return AttemptOutcome(True, False, 200, excerpt, "")

    return _run_attempts(operation)


def _load_service_account(config: SheetsRouteConfig) -> dict[str, Any]:
    settings = get_settings()
    if config.credentials_json:
        return config.credentials_json
    file_path = config.credentials_file or settings.google_service_account_file
    if file_path:
        path = Path(file_path)
        if not path.is_file():
            raise DispatchConfigError(f"Google service account file was not found: {file_path}")
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise DispatchConfigError("Google service account file is not valid JSON") from exc
        if not isinstance(loaded, dict):
            raise DispatchConfigError("Google service account file must contain a JSON object")
        return loaded
    if settings.google_service_account_json.strip():
        try:
            loaded = json.loads(settings.google_service_account_json)
        except json.JSONDecodeError as exc:
            raise DispatchConfigError("GOOGLE_SERVICE_ACCOUNT_JSON is not valid JSON") from exc
        if not isinstance(loaded, dict):
            raise DispatchConfigError("GOOGLE_SERVICE_ACCOUNT_JSON must contain a JSON object")
        return loaded
    raise DispatchConfigError(
        "Google Sheets credentials are not configured. Set credentials_file on the route "
        "or GOOGLE_SERVICE_ACCOUNT_FILE in the environment."
    )


def _sheets_service(info: dict[str, Any]) -> Any:
    try:
        from google.oauth2.service_account import Credentials
        from googleapiclient.discovery import build
    except ImportError as exc:
        raise DispatchConfigError(
            "Google Sheets libraries are not installed. Install the requirements.txt packages."
        ) from exc
    cache_key = str(info.get("client_email", "")) + ":" + str(info.get("private_key_id", ""))
    with _SHEETS_GUARD:
        cached = _SHEETS_CLIENTS.get(cache_key)
        if cached is not None:
            return cached
        credentials = Credentials.from_service_account_info(info, scopes=[_SHEETS_SCOPE])
        service = build("sheets", "v4", credentials=credentials, cache_discovery=False)
        _SHEETS_CLIENTS[cache_key] = service
        return service


def _request_with_retries(
    method: str,
    url: str,
    *,
    json_body: dict[str, Any],
    headers: dict[str, str],
    timeout: float | None,
    secrets: list[str],
) -> DeliveryResult:
    settings = get_settings()
    request_timeout = timeout if timeout is not None else settings.outbound_timeout_seconds
    request_headers = {
        "User-Agent": f"WebhookBridge/{__version__}",
        "Accept": "application/json",
    }
    request_headers.update(headers)

    def operation() -> AttemptOutcome:
        try:
            response = client.request(method, url, json=json_body, headers=request_headers)
        except httpx.TimeoutException as exc:
            return AttemptOutcome(False, True, None, "", redact_text(f"Timeout: {exc}", secrets))
        except httpx.HTTPError as exc:
            return AttemptOutcome(False, True, None, "", redact_text(f"{type(exc).__name__}: {exc}", secrets))
        body = response.text[:2000]
        if 200 <= response.status_code < 300:
            return AttemptOutcome(True, False, response.status_code, body, "")
        retryable = response.status_code in {408, 429} or response.status_code >= 500
        retry_after: float | None = None
        header = response.headers.get("retry-after", "")
        if response.status_code == 429 and str(header).isdigit():
            retry_after = min(float(header), 30.0)
        error = f"HTTP {response.status_code}"
        return AttemptOutcome(
            False,
            retryable,
            response.status_code,
            body,
            redact_text(error, secrets),
            retry_after,
        )

    with httpx.Client(timeout=request_timeout, follow_redirects=False) as client:
        return _run_attempts(operation)


def _run_attempts(operation: Callable[[], AttemptOutcome]) -> DeliveryResult:
    settings = get_settings()
    attempts = settings.max_retry_attempts
    last = AttemptOutcome(False, True, None, "", "No attempt was made")
    for attempt in range(1, attempts + 1):
        last = operation()
        if last.success or not last.retryable or attempt == attempts:
            return DeliveryResult(
                success=last.success,
                attempt_count=attempt,
                response_status=last.status_code,
                response_excerpt=last.body[:2000],
                error_message="" if last.success else last.error[:1000],
            )
        delay = last.retry_after
        if delay is None:
            delay = settings.retry_backoff_seconds * (2 ** (attempt - 1))
        if delay > 0:
            time.sleep(delay)
    return DeliveryResult(False, attempts, last.status_code, last.body[:2000], last.error[:1000])


def _message_text(template: str | None, payload: dict[str, Any], *, limit: int) -> str:
    if template:
        text = render_template(template, payload)
    else:
        text = json.dumps(payload, indent=2, ensure_ascii=False, default=str)
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def _embed_fields(payload: dict[str, Any]) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []
    for key, value in list(payload.items())[:20]:
        rendered = stringify(value)
        if len(rendered) > 1024:
            rendered = rendered[:1023] + "…"
        fields.append({"name": str(key)[:256] or "field", "value": rendered or "—", "inline": len(rendered) <= 80})
    return fields


def _sheet_cell(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float, str)):
        return value
    return stringify(value)


def _status_code_from_exception(exc: Exception) -> int | None:
    raw = getattr(getattr(exc, "resp", None), "status", None)
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str) and raw.isdigit():
        return int(raw)
    return None


def _html_escape(value: str) -> str:
    return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _lock_for(payload_id: int) -> threading.Lock:
    with _LOCKS_GUARD:
        lock = _PAYLOAD_LOCKS.get(payload_id)
        if lock is None:
            lock = threading.Lock()
            _PAYLOAD_LOCKS[payload_id] = lock
        return lock
