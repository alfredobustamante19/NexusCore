"""Persist an inbound payload and resolve its idempotency key."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import PayloadStatus, StoredPayload, WebhookEndpoint, utcnow
from app.services.transformer import MISSING, TransformError, get_path, transform_payload

logger = logging.getLogger("bridge.ingest")


@dataclass(frozen=True)
class IngestResult:
    """Plain result of storing one payload. Safe to use after the session commits."""

    payload_id: int
    status: str
    duplicate: bool
    detail: str | None = None


def resolve_idempotency_key(
    *,
    header_value: str | None,
    idempotency_path: str | None,
    payload: Any,
) -> str | None:
    """Prefer the Idempotency-Key header, then a dotted path inside the body."""
    if header_value and header_value.strip():
        key = header_value.strip()
        if len(key) > 200:
            raise TransformError("Idempotency-Key must be 200 characters or fewer")
        return key
    if not idempotency_path or not isinstance(payload, dict):
        return None
    found = get_path(payload, idempotency_path)
    if found is MISSING or found is None:
        return None
    key = found if isinstance(found, str) else str(found)
    key = key.strip()
    if not key:
        return None
    if len(key) > 200:
        raise TransformError("Idempotency value must be 200 characters or fewer")
    return key


def accept_payload(
    db: Session,
    endpoint: WebhookEndpoint,
    *,
    raw_body: str,
    parsed: Any,
    headers: dict[str, str],
    source_ip: str,
    idempotency_key: str | None,
    source: str,
) -> IngestResult:
    """Transform and store a payload. Duplicate keys return the original row."""
    if idempotency_key:
        existing = _find_duplicate(db, endpoint.id, idempotency_key)
        if existing is not None:
            logger.info(
                "duplicate payload endpoint=%s key=%s existing_id=%s",
                endpoint.slug,
                idempotency_key,
                existing.id,
            )
            return IngestResult(payload_id=existing.id, status="duplicate", duplicate=True)

    transformed: dict[str, Any] | None = None
    error = ""
    status = PayloadStatus.ACCEPTED
    try:
        transformed = transform_payload(parsed, endpoint.transform_rules or {})
    except TransformError as exc:
        error = str(exc)[:2000]
        status = PayloadStatus.FAILED

    record = StoredPayload(
        endpoint_id=endpoint.id,
        source=source,
        status=status,
        raw_body=raw_body,
        raw_payload=parsed if isinstance(parsed, (dict, list)) else {"value": parsed},
        transformed_payload=transformed,
        request_headers=headers,
        source_ip=source_ip,
        idempotency_key=idempotency_key,
        error_message=error,
        received_at=utcnow(),
    )
    db.add(record)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        if idempotency_key:
            existing = _find_duplicate(db, endpoint.id, idempotency_key)
            if existing is not None:
                return IngestResult(payload_id=existing.id, status="duplicate", duplicate=True)
        logger.exception("failed to store payload endpoint=%s", endpoint.slug)
        raise
    db.refresh(record)
    if error:
        logger.warning("transform failed endpoint=%s payload_id=%s error=%s", endpoint.slug, record.id, error)
        return IngestResult(
            payload_id=record.id,
            status="failed",
            duplicate=False,
            detail="Payload was stored but the transform rules rejected it. See the payload log.",
        )
    logger.info("stored payload endpoint=%s payload_id=%s", endpoint.slug, record.id)
    return IngestResult(payload_id=record.id, status="accepted", duplicate=False)


def _find_duplicate(db: Session, endpoint_id: int, key: str) -> StoredPayload | None:
    return db.scalars(
        select(StoredPayload).where(
            StoredPayload.endpoint_id == endpoint_id,
            StoredPayload.idempotency_key == key,
        )
    ).first()
