"""Docker entrypoint.

The container starts as root so it can make the data volume writable, then
drops to the unprivileged `bridge` user before Uvicorn binds the port.
Running `python -m app.main` on your own machine does not use this module.
"""

from __future__ import annotations

import os
import sys


def main() -> None:
    """Prepare the data directory, drop root, and replace this process."""
    if len(sys.argv) < 2:
        print("Usage: python -m app.entrypoint <command> [args...]", file=sys.stderr)
        raise SystemExit(1)
    if os.name == "posix" and hasattr(os, "geteuid") and os.geteuid() == 0:
        _prepare_runtime_user()
    os.execvp(sys.argv[1], sys.argv[1:])


def _prepare_runtime_user() -> None:
    import pwd

    account = pwd.getpwnam("bridge")
    data_dir = "/app/data"
    os.makedirs(data_dir, exist_ok=True)
    for root, directories, files in os.walk(data_dir):
        os.chown(root, account.pw_uid, account.pw_gid)
        for name in directories + files:
            os.chown(os.path.join(root, name), account.pw_uid, account.pw_gid)
    os.setgid(account.pw_gid)
    os.setuid(account.pw_uid)


if __name__ == "__main__":
    main()
