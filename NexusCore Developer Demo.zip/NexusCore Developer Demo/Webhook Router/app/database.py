"""SQLAlchemy engine and session management.

SQLite is the default so the app runs with no extra services. Point
`DATABASE_URL` at PostgreSQL (`postgresql+psycopg://...`) to use the same
models without code changes.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from app.config import get_settings

logger = logging.getLogger("bridge.database")

_engine: Engine | None = None
SessionLocal: sessionmaker[Session] | None = None


def _sqlite_file_path(database_url: str) -> Path | None:
    """Return the on-disk path for a SQLite URL, or None for memory databases."""
    if not database_url.startswith("sqlite:"):
        return None
    if ":memory:" in database_url:
        return None
    raw = database_url.removeprefix("sqlite:///")
    if raw.startswith(":memory:"):
        return None
    return Path(raw)


def ensure_sqlite_directory(database_url: str) -> None:
    """Create the parent directory for a file-backed SQLite database."""
    path = _sqlite_file_path(database_url)
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)


def get_engine() -> Engine:
    """Create the engine on first use and reuse it afterwards."""
    global _engine, SessionLocal
    if _engine is not None and SessionLocal is not None:
        return _engine

    settings = get_settings()
    url = settings.database_url
    ensure_sqlite_directory(url)

    kwargs: dict[str, object] = {"future": True, "pool_pre_ping": True}
    if url.startswith("sqlite"):
        kwargs["pool_pre_ping"] = False
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}
        if ":memory:" in url:
            kwargs["poolclass"] = StaticPool

    engine = create_engine(url, **kwargs)
    if url.startswith("sqlite"):

        @event.listens_for(engine, "connect")
        def _sqlite_pragmas(dbapi_connection: object, connection_record: object) -> None:
            """Enable foreign keys and WAL mode for file-backed SQLite."""
            del connection_record
            cursor = dbapi_connection.cursor()  # type: ignore[attr-defined]
            cursor.execute("PRAGMA foreign_keys=ON")
            if ":memory:" not in url:
                cursor.execute("PRAGMA journal_mode=WAL")
            cursor.close()

    _engine = engine
    SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)
    logger.debug("Database engine ready")
    return engine


def get_session_factory() -> sessionmaker[Session]:
    """Return the session factory, creating the engine if needed."""
    get_engine()
    if SessionLocal is None:
        raise RuntimeError("Database session factory was not initialized")
    return SessionLocal


def init_db() -> None:
    """Create any missing tables. Existing tables are left as they are."""
    from app.models import Base

    Base.metadata.create_all(bind=get_engine())
    logger.info("Database schema is ready")


def get_db() -> Iterator[Session]:
    """Yield a request-scoped session and always close it."""
    factory = get_session_factory()
    session = factory()
    try:
        yield session
    finally:
        session.close()


def reset_database_state() -> None:
    """Dispose the engine so tests can point at a different database URL."""
    global _engine, SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    SessionLocal = None
