"""Inbound webhook ingestion."""

from __future__ import annotations

import json
import logging

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from app.config import get_settings
from app.database import get_db
from app.models import WebhookEndpoint
from app.schemas import IngestResponse
from app.services.dispatcher import dispatch_stored_payload
from app.services.ingest import accept_payload, resolve_idempotency_key
from app.services.security import (
    AuthError,
    client_ip,
    safe_request_headers,
    verify_endpoint_auth,
)
from app.services.transformer import TransformError

logger = logging.getLogger("bridge.webhooks")

router = APIRouter(prefix="/hooks", tags=["Inbound webhooks"])


@router.post(
    "/{slug}",
    response_model=IngestResponse,
    summary="Receive a webhook",
    responses={
        400: {"description": "The body is not JSON, or the idempotency key is unusable"},
        401: {"description": "The bearer token or signature was missing or invalid"},
        403: {"description": "The endpoint exists but is disabled"},
        404: {"description": "No endpoint uses this slug"},
        413: {"description": "The body is larger than WEBHOOK_MAX_BODY_BYTES"},
        415: {"description": "The Content-Type is not JSON"},
    },
)
async def receive_webhook(
    slug: str,
    request: Request,
    background: BackgroundTasks,
    db: Session = Depends(get_db),
) -> IngestResponse:
    """Verify, transform, store, and queue delivery for one inbound payload.

    The caller receives `accepted` as soon as the payload is stored. Destinations
    are called after the response, then retried when they fail with a network
    error or a 408, 429, or 5xx status. A repeated idempotency key returns
    `duplicate` and does not send the payload again.
    """
    settings = get_settings()
    normalized = slug.strip().lower()
    body = await request.body()
    if len(body) > settings.webhook_max_body_bytes:
        raise HTTPException(status_code=413, detail="Payload exceeds the configured size limit")

    endpoint = db.scalars(select(WebhookEndpoint).where(WebhookEndpoint.slug == normalized)).first()
    if endpoint is None:
        raise HTTPException(status_code=404, detail="Endpoint not found")
    if not endpoint.is_active:
        raise HTTPException(status_code=403, detail="Endpoint is disabled")
    if not _is_json_content_type(request.headers.get("content-type", "")):
        raise HTTPException(status_code=415, detail="Content-Type must be application/json")

    try:
        verify_endpoint_auth(
            auth_type=endpoint.auth_type,
            secret=endpoint.auth_secret,
            body=body,
            headers=request.headers,
            tolerance_seconds=settings.stripe_tolerance_seconds,
        )
    except AuthError as exc:
        logger.info("rejected webhook slug=%s reason=%s", normalized, exc.detail)
        raise HTTPException(status_code=401, detail=exc.detail) from exc

    if not body:
        raise HTTPException(status_code=400, detail="Body must be valid UTF-8 JSON")
    try:
        parsed = json.loads(body)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=400, detail="Body must be valid UTF-8 JSON") from exc
    if not isinstance(parsed, (dict, list)):
        raise HTTPException(status_code=400, detail="JSON body must be an object or array")

    try:
        idempotency_key = resolve_idempotency_key(
            header_value=request.headers.get("idempotency-key"),
            idempotency_path=endpoint.idempotency_path,
            payload=parsed,
        )
    except TransformError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    result = accept_payload(
        db,
        endpoint,
        raw_body=body.decode("utf-8"),
        parsed=parsed,
        headers=safe_request_headers(request.headers),
        source_ip=client_ip(request, settings),
        idempotency_key=idempotency_key,
        source="webhook",
    )
    if result.status == "accepted":
        background.add_task(_dispatch_later, result.payload_id)
    logger.info("ingest slug=%s payload_id=%s status=%s", normalized, result.payload_id, result.status)
    return IngestResponse(id=result.payload_id, status=result.status, detail=result.detail)


async def _dispatch_later(payload_id: int) -> None:
    """Run outbound delivery off the event loop."""
    await run_in_threadpool(dispatch_stored_payload, payload_id)


def _is_json_content_type(value: str) -> bool:
    if not value.strip():
        return True
    media = value.split(";", 1)[0].strip().lower()
    return media == "application/json" or media.endswith("+json")
