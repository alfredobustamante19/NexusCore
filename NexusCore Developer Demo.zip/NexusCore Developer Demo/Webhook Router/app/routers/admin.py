"""Authenticated API for endpoints, routes, payload history, and replays."""

from __future__ import annotations

import json
import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.config import admin_token_is_usable, get_settings
from app.database import get_db
from app.models import (
    DeliveryAttempt,
    DeliveryStatus,
    PayloadStatus,
    Route,
    StoredPayload,
    WebhookEndpoint,
    utcnow,
)
from app.schemas import (
    DeliveryOut,
    DeliveryPage,
    EndpointCreate,
    EndpointOut,
    EndpointUpdate,
    PayloadDetail,
    PayloadOut,
    PayloadPage,
    RouteCreate,
    RouteOut,
    RouteUpdate,
    TrialRequest,
    TrialResponse,
    validate_destination_config,
)
from app.services.dispatcher import dispatch_stored_payload
from app.services.ingest import accept_payload
from app.services.security import mask_config, mask_secret, merge_route_config, safe_compare
from app.services.transformer import TransformError, transform_payload

logger = logging.getLogger("bridge.admin")

router = APIRouter(prefix="/api", tags=["Admin"])
_bearer = HTTPBearer(auto_error=False, description="Admin token from ADMIN_API_TOKEN")
_MAX_ROUTES = 20
_PAYLOAD_STATUSES = {
    PayloadStatus.ACCEPTED,
    PayloadStatus.PROCESSED,
    PayloadStatus.PARTIAL,
    PayloadStatus.FAILED,
}
_DELIVERY_STATUSES = {DeliveryStatus.PENDING, DeliveryStatus.SUCCESS, DeliveryStatus.FAILED}


def require_admin(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)],
) -> None:
    """Reject requests that do not present the configured admin token."""
    settings = get_settings()
    minimum = 24 if settings.is_production else 16
    if not admin_token_is_usable(settings, minimum_length=minimum):
        raise HTTPException(
            status_code=503,
            detail="Set ADMIN_API_TOKEN to a long random string before using the admin API.",
        )
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=401,
            detail="Missing bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not safe_compare(credentials.credentials, settings.admin_api_token.strip()):
        raise HTTPException(
            status_code=401,
            detail="Invalid admin token",
            headers={"WWW-Authenticate": "Bearer"},
        )


router.dependencies.append(Depends(require_admin))


@router.post("/endpoints", response_model=EndpointOut, status_code=201)
def create_endpoint(body: EndpointCreate, db: Session = Depends(get_db)) -> EndpointOut:
    """Create an inbound URL at `/hooks/{slug}`."""
    endpoint = WebhookEndpoint(
        name=body.name,
        slug=body.slug,
        description=body.description,
        auth_type=body.auth_type,
        auth_secret=body.auth_secret,
        transform_rules=body.transform_rules.model_dump(mode="json"),
        idempotency_path=body.idempotency_path,
        is_active=body.is_active,
        created_at=utcnow(),
        updated_at=utcnow(),
    )
    db.add(endpoint)
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="An endpoint with this slug already exists") from exc
    db.refresh(endpoint)
    if endpoint.auth_type == "none":
        logger.warning("endpoint slug=%s is open. Anyone who can reach it can send data.", endpoint.slug)
    logger.info("created endpoint slug=%s auth=%s", endpoint.slug, endpoint.auth_type)
    return _endpoint_out(endpoint, route_count=0)


@router.get("/endpoints", response_model=list[EndpointOut])
def list_endpoints(db: Session = Depends(get_db)) -> list[EndpointOut]:
    """List every inbound endpoint."""
    rows = db.scalars(
        select(WebhookEndpoint).options(selectinload(WebhookEndpoint.routes)).order_by(WebhookEndpoint.id)
    ).all()
    return [_endpoint_out(row, route_count=len(row.routes)) for row in rows]


@router.get("/endpoints/{endpoint_id}", response_model=EndpointOut)
def get_endpoint(endpoint_id: int, db: Session = Depends(get_db)) -> EndpointOut:
    """Return one endpoint. The signing secret is masked."""
    endpoint = _endpoint_or_404(db, endpoint_id)
    return _endpoint_out(endpoint)


@router.patch("/endpoints/{endpoint_id}", response_model=EndpointOut)
def update_endpoint(endpoint_id: int, body: EndpointUpdate, db: Session = Depends(get_db)) -> EndpointOut:
    """Change name, auth, rules, or the enabled flag. The slug stays the same."""
    endpoint = _endpoint_or_404(db, endpoint_id)
    changes = body.model_dump(exclude_unset=True)
    if "name" in changes:
        endpoint.name = changes["name"]
    if "description" in changes:
        endpoint.description = changes["description"]
    if "auth_type" in changes:
        endpoint.auth_type = changes["auth_type"]
    if "auth_secret" in changes:
        endpoint.auth_secret = changes["auth_secret"]
    if "transform_rules" in changes and body.transform_rules is not None:
        endpoint.transform_rules = body.transform_rules.model_dump(mode="json")
    if "idempotency_path" in changes:
        endpoint.idempotency_path = changes["idempotency_path"] or None
    if "is_active" in changes:
        endpoint.is_active = bool(changes["is_active"])
    if endpoint.auth_type != "none" and not endpoint.auth_secret:
        raise HTTPException(status_code=422, detail="auth_secret is required unless auth_type is none")
    endpoint.updated_at = utcnow()
    db.commit()
    db.refresh(endpoint)
    logger.info("updated endpoint slug=%s", endpoint.slug)
    return _endpoint_out(endpoint)


@router.delete("/endpoints/{endpoint_id}", status_code=204)
def delete_endpoint(endpoint_id: int, db: Session = Depends(get_db)) -> Response:
    """Delete an endpoint, its routes, and its stored payloads."""
    endpoint = _endpoint_or_404(db, endpoint_id)
    payload_ids = select(StoredPayload.id).where(StoredPayload.endpoint_id == endpoint.id)
    db.execute(delete(DeliveryAttempt).where(DeliveryAttempt.payload_id.in_(payload_ids)))
    db.execute(delete(StoredPayload).where(StoredPayload.endpoint_id == endpoint.id))
    db.execute(delete(Route).where(Route.endpoint_id == endpoint.id))
    db.execute(delete(WebhookEndpoint).where(WebhookEndpoint.id == endpoint.id))
    db.commit()
    logger.info("deleted endpoint slug=%s", endpoint.slug)
    return Response(status_code=204)


@router.post("/endpoints/{endpoint_id}/routes", response_model=RouteOut, status_code=201)
def create_route(endpoint_id: int, body: RouteCreate, db: Session = Depends(get_db)) -> RouteOut:
    """Attach a Discord, Telegram, Sheets, webhook, or database destination."""
    endpoint = _endpoint_or_404(db, endpoint_id)
    current = db.scalar(select(func.count()).select_from(Route).where(Route.endpoint_id == endpoint.id)) or 0
    if current >= _MAX_ROUTES:
        raise HTTPException(status_code=422, detail=f"An endpoint can have at most {_MAX_ROUTES} routes")
    config = _validated_config(body.destination_type, body.config)
    route = Route(
        endpoint_id=endpoint.id,
        name=body.name or _default_route_name(body.destination_type),
        destination_type=body.destination_type,
        config=config,
        is_active=body.is_active,
        created_at=utcnow(),
        updated_at=utcnow(),
    )
    db.add(route)
    db.commit()
    db.refresh(route)
    logger.info("created route endpoint=%s type=%s id=%s", endpoint.slug, route.destination_type, route.id)
    return _route_out(route)


@router.get("/endpoints/{endpoint_id}/routes", response_model=list[RouteOut])
def list_routes(endpoint_id: int, db: Session = Depends(get_db)) -> list[RouteOut]:
    """List destinations for one endpoint. Secrets in the config are masked."""
    endpoint = _endpoint_or_404(db, endpoint_id)
    rows = db.scalars(select(Route).where(Route.endpoint_id == endpoint.id).order_by(Route.id)).all()
    return [_route_out(row) for row in rows]


@router.patch("/routes/{route_id}", response_model=RouteOut)
def update_route(route_id: int, body: RouteUpdate, db: Session = Depends(get_db)) -> RouteOut:
    """Update a route. Masked secrets sent back unchanged are preserved."""
    route = _route_or_404(db, route_id)
    changes = body.model_dump(exclude_unset=True)
    if "name" in changes and changes["name"]:
        route.name = changes["name"]
    if "is_active" in changes:
        route.is_active = bool(changes["is_active"])
    if "config" in changes and body.config is not None:
        merged = merge_route_config(dict(route.config or {}), body.config)
        route.config = _validated_config(route.destination_type, merged)
    route.updated_at = utcnow()
    db.commit()
    db.refresh(route)
    logger.info("updated route id=%s", route.id)
    return _route_out(route)


@router.delete("/routes/{route_id}", status_code=204)
def delete_route(route_id: int, db: Session = Depends(get_db)) -> Response:
    """Remove a destination. Older delivery rows keep their history."""
    route = _route_or_404(db, route_id)
    db.execute(delete(Route).where(Route.id == route.id))
    db.commit()
    logger.info("deleted route id=%s", route_id)
    return Response(status_code=204)


@router.post("/endpoints/{endpoint_id}/test", response_model=TrialResponse)
def test_endpoint(endpoint_id: int, body: TrialRequest, db: Session = Depends(get_db)) -> TrialResponse:
    """Transform a sample payload. Set dispatch=true to store it and send it."""
    endpoint = _endpoint_or_404(db, endpoint_id)
    try:
        transformed = transform_payload(body.payload, endpoint.transform_rules or {})
    except TransformError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not body.dispatch:
        return TrialResponse(transformed=transformed, dispatched=False)

    result = accept_payload(
        db,
        endpoint,
        raw_body=json.dumps(body.payload, default=str),
        parsed=body.payload,
        headers={"content-type": "application/json"},
        source_ip="",
        idempotency_key=None,
        source="admin-test",
    )
    if result.status != "accepted":
        return TrialResponse(
            transformed=None,
            dispatched=False,
            payload_id=result.payload_id,
            status=result.status,
        )
    summary = dispatch_stored_payload(result.payload_id, trigger="admin-test", force=True)
    return TrialResponse(
        transformed=transformed,
        dispatched=True,
        payload_id=result.payload_id,
        status=str(summary.get("status") or ""),
        deliveries=list(summary.get("deliveries") or []),
    )


@router.get("/payloads", response_model=PayloadPage)
def list_payloads(
    db: Session = Depends(get_db),
    endpoint_id: int | None = None,
    status: str | None = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> PayloadPage:
    """Return the newest stored payloads."""
    if status is not None and status not in _PAYLOAD_STATUSES:
        raise HTTPException(status_code=422, detail="Unknown payload status")
    filters = _payload_filters(endpoint_id, status)
    count_stmt = select(func.count()).select_from(StoredPayload)
    list_stmt = select(StoredPayload).options(selectinload(StoredPayload.endpoint))
    if filters:
        count_stmt = count_stmt.where(*filters)
        list_stmt = list_stmt.where(*filters)
    total = db.scalar(count_stmt) or 0
    rows = db.scalars(
        list_stmt.order_by(StoredPayload.received_at.desc(), StoredPayload.id.desc()).limit(limit).offset(offset)
    ).all()
    counts = _delivery_counts(db, [row.id for row in rows])
    items = [_payload_out(row, delivery_count=counts.get(row.id, 0)) for row in rows]
    return PayloadPage(items=items, total=total, limit=limit, offset=offset)


@router.get("/payloads/{payload_id}", response_model=PayloadDetail)
def get_payload(payload_id: int, db: Session = Depends(get_db)) -> PayloadDetail:
    """Return one payload and every delivery attempted for it."""
    payload = _payload_or_404(db, payload_id)
    base = _payload_out(payload, delivery_count=len(payload.deliveries))
    return PayloadDetail(
        **base.model_dump(),
        deliveries=[_delivery_out(item) for item in payload.deliveries],
    )


@router.delete("/payloads/{payload_id}", status_code=204)
def delete_payload(payload_id: int, db: Session = Depends(get_db)) -> Response:
    """Delete one stored payload and its delivery history."""
    payload = _payload_or_404(db, payload_id)
    db.execute(delete(DeliveryAttempt).where(DeliveryAttempt.payload_id == payload.id))
    db.execute(delete(StoredPayload).where(StoredPayload.id == payload.id))
    db.commit()
    return Response(status_code=204)


@router.post("/payloads/{payload_id}/replay")
def replay_payload(
    payload_id: int,
    db: Session = Depends(get_db),
    retransform: Annotated[bool, Query()] = True,
) -> dict[str, Any]:
    """Send a stored payload to its active routes again.

    Retransform is on by default, so fixing the endpoint rules and replaying
    uses the new mapping. Delivery is at-least-once: a replay always sends again.
    """
    payload = _payload_or_404(db, payload_id)
    summary = dispatch_stored_payload(
        payload.id,
        trigger="replay",
        force=True,
        retransform=retransform,
    )
    if not summary.get("deliveries") and summary.get("status") == PayloadStatus.FAILED:
        raise HTTPException(status_code=422, detail=str(summary.get("detail") or "Replay failed"))
    return summary


@router.get("/deliveries", response_model=DeliveryPage)
def list_deliveries(
    db: Session = Depends(get_db),
    payload_id: int | None = None,
    status: str | None = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> DeliveryPage:
    """Return delivery attempts, newest first."""
    if status is not None and status not in _DELIVERY_STATUSES:
        raise HTTPException(status_code=422, detail="Unknown delivery status")
    filters = []
    if payload_id is not None:
        filters.append(DeliveryAttempt.payload_id == payload_id)
    if status is not None:
        filters.append(DeliveryAttempt.status == status)
    count_stmt = select(func.count()).select_from(DeliveryAttempt)
    list_stmt = select(DeliveryAttempt)
    if filters:
        count_stmt = count_stmt.where(*filters)
        list_stmt = list_stmt.where(*filters)
    total = db.scalar(count_stmt) or 0
    rows = db.scalars(list_stmt.order_by(DeliveryAttempt.id.desc()).limit(limit).offset(offset)).all()
    return DeliveryPage(
        items=[_delivery_out(row) for row in rows],
        total=total,
        limit=limit,
        offset=offset,
    )


def _validated_config(destination_type: str, config: dict[str, Any]) -> dict[str, Any]:
    try:
        return validate_destination_config(destination_type, config)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


def _endpoint_or_404(db: Session, endpoint_id: int) -> WebhookEndpoint:
    endpoint = db.scalars(
        select(WebhookEndpoint)
        .where(WebhookEndpoint.id == endpoint_id)
        .options(selectinload(WebhookEndpoint.routes))
    ).first()
    if endpoint is None:
        raise HTTPException(status_code=404, detail="Endpoint not found")
    return endpoint


def _route_or_404(db: Session, route_id: int) -> Route:
    route = db.get(Route, route_id)
    if route is None:
        raise HTTPException(status_code=404, detail="Route not found")
    return route


def _payload_or_404(db: Session, payload_id: int) -> StoredPayload:
    payload = db.scalars(
        select(StoredPayload)
        .where(StoredPayload.id == payload_id)
        .options(
            selectinload(StoredPayload.endpoint),
            selectinload(StoredPayload.deliveries),
        )
    ).first()
    if payload is None:
        raise HTTPException(status_code=404, detail="Payload not found")
    return payload


def _payload_filters(endpoint_id: int | None, status: str | None) -> list[Any]:
    filters: list[Any] = []
    if endpoint_id is not None:
        filters.append(StoredPayload.endpoint_id == endpoint_id)
    if status is not None:
        filters.append(StoredPayload.status == status)
    return filters


def _delivery_counts(db: Session, payload_ids: list[int]) -> dict[int, int]:
    if not payload_ids:
        return {}
    rows = db.execute(
        select(DeliveryAttempt.payload_id, func.count())
        .where(DeliveryAttempt.payload_id.in_(payload_ids))
        .group_by(DeliveryAttempt.payload_id)
    ).all()
    return {int(payload_id): int(count) for payload_id, count in rows}


def _endpoint_out(endpoint: WebhookEndpoint, route_count: int | None = None) -> EndpointOut:
    secret = endpoint.auth_secret or ""
    return EndpointOut(
        id=endpoint.id,
        name=endpoint.name,
        slug=endpoint.slug,
        description=endpoint.description,
        auth_type=endpoint.auth_type,
        has_secret=bool(secret),
        secret_hint=mask_secret(secret) if secret else None,
        transform_rules=dict(endpoint.transform_rules or {}),
        idempotency_path=endpoint.idempotency_path,
        is_active=endpoint.is_active,
        ingest_path=f"/hooks/{endpoint.slug}",
        route_count=len(endpoint.routes) if route_count is None else route_count,
        created_at=endpoint.created_at,
        updated_at=endpoint.updated_at,
    )


def _route_out(route: Route) -> RouteOut:
    return RouteOut(
        id=route.id,
        endpoint_id=route.endpoint_id,
        name=route.name,
        destination_type=route.destination_type,
        config=mask_config(dict(route.config or {})),
        is_active=route.is_active,
        created_at=route.created_at,
        updated_at=route.updated_at,
    )


def _payload_out(payload: StoredPayload, *, delivery_count: int) -> PayloadOut:
    slug = payload.endpoint.slug if payload.endpoint is not None else None
    return PayloadOut(
        id=payload.id,
        endpoint_id=payload.endpoint_id,
        endpoint_slug=slug,
        source=payload.source,
        status=payload.status,
        raw_payload=payload.raw_payload,
        transformed_payload=payload.transformed_payload,
        request_headers=dict(payload.request_headers or {}),
        source_ip=payload.source_ip,
        idempotency_key=payload.idempotency_key,
        error_message=payload.error_message,
        received_at=payload.received_at,
        delivery_count=delivery_count,
    )


def _delivery_out(attempt: DeliveryAttempt) -> DeliveryOut:
    return DeliveryOut(
        id=attempt.id,
        payload_id=attempt.payload_id,
        route_id=attempt.route_id,
        destination_type=attempt.destination_type,
        destination_label=attempt.destination_label,
        status=attempt.status,
        trigger=attempt.trigger,
        attempt_count=attempt.attempt_count,
        response_status=attempt.response_status,
        response_excerpt=attempt.response_excerpt,
        error_message=attempt.error_message,
        created_at=attempt.created_at,
        completed_at=attempt.completed_at,
    )


def _default_route_name(destination_type: str) -> str:
    labels = {
        "database": "Local database",
        "discord": "Discord",
        "telegram": "Telegram",
        "webhook": "Webhook",
        "sheets": "Google Sheets",
    }
    return labels.get(destination_type, destination_type)
