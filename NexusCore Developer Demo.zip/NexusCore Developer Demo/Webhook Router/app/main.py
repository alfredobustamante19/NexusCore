"""FastAPI application entrypoint."""

from __future__ import annotations

import logging
import sys
import threading
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.orm import Session
from starlette.middleware.base import BaseHTTPMiddleware

from app import __version__
from app.config import admin_token_is_usable, assert_runtime_safety, get_settings
from app.database import get_db, init_db
from app.routers.admin import router as admin_router
from app.routers.webhooks import router as webhook_router
from app.schemas import HealthResponse
from app.services.dispatcher import resume_pending_deliveries

logger = logging.getLogger("bridge.api")


def configure_logging() -> None:
    """Send bridge logs to stderr and a rotating `app.log` file."""
    settings = get_settings()
    bridge_logger = logging.getLogger("bridge")
    bridge_logger.setLevel(settings.log_level)
    bridge_logger.propagate = False
    for handler in list(bridge_logger.handlers):
        handler.close()
        bridge_logger.removeHandler(handler)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )
    path = Path(settings.log_file)
    if path.parent != Path("."):
        path.parent.mkdir(parents=True, exist_ok=True)
    file_handler = RotatingFileHandler(path, maxBytes=5_242_880, backupCount=5, encoding="utf-8")
    file_handler.setFormatter(formatter)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    bridge_logger.addHandler(file_handler)
    bridge_logger.addHandler(stream_handler)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Prepare logging, the database, and any deliveries interrupted by a restart."""
    del app
    settings = get_settings()
    configure_logging()
    assert_runtime_safety(settings)
    init_db()
    logger.info("started name=%s env=%s version=%s", settings.app_name, settings.app_env, __version__)
    if admin_token_is_usable(settings, minimum_length=24 if settings.is_production else 16):
        logger.info("admin API enabled")
    else:
        logger.warning(
            "ADMIN_API_TOKEN is missing or still a placeholder. The admin API will refuse requests."
        )
    if settings.resume_pending_on_startup:
        threading.Thread(target=resume_pending_deliveries, name="bridge-resume", daemon=True).start()
    yield
    logger.info("stopped")


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Attach a request id to the request state and the response headers."""

    async def dispatch(self, request: Request, call_next):  # type: ignore[no-untyped-def]
        incoming = request.headers.get("x-request-id", "")
        request_id = incoming.strip()[:64] or uuid.uuid4().hex
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


def create_app() -> FastAPI:
    """Build the ASGI application."""
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 or newer is required")

    settings = get_settings()
    configure_logging()
    application = FastAPI(
        title=settings.app_name,
        version=__version__,
        summary="Self-hosted webhook ingestion, transformation, and multi-channel dispatch.",
        description=(
            "Receive JSON from Stripe, forms, and other services, reshape it, "
            "store it locally, and forward it to Discord, Telegram, Google Sheets, "
            "or any HTTPS endpoint you control."
        ),
        lifespan=lifespan,
    )
    application.add_middleware(RequestIdMiddleware)
    if settings.cors_origin_list:
        application.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origin_list,
            allow_credentials=False,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    application.include_router(webhook_router)
    application.include_router(admin_router)
    _register_exception_handlers(application)

    @application.get("/", include_in_schema=False)
    def root() -> dict[str, str]:
        """Point a browser at the interactive docs and the health check."""
        current = get_settings()
        return {
            "name": current.app_name,
            "version": __version__,
            "health": "/health",
            "docs": "/docs",
            "ingest": "/hooks/{slug}",
        }

    @application.get("/health", response_model=HealthResponse, tags=["Meta"])
    def health(db: Session = Depends(get_db)) -> HealthResponse:
        """Report process and database availability."""
        try:
            db.execute(text("SELECT 1"))
        except Exception as exc:
            logger.exception("health check failed")
            raise HTTPException(status_code=503, detail="Database is unavailable") from exc
        return HealthResponse(status="ok", version=__version__, environment=get_settings().app_env)

    return application


def _register_exception_handlers(application: FastAPI) -> None:
    @application.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
        detail = exc.detail if isinstance(exc.detail, str) else "Request failed"
        headers = dict(exc.headers or {})
        headers["X-Request-ID"] = _request_id(request)
        return JSONResponse(status_code=exc.status_code, content={"detail": detail}, headers=headers)

    @application.exception_handler(RequestValidationError)
    async def validation_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
        errors = []
        for error in exc.errors():
            location = ".".join(str(part) for part in error.get("loc", ()) if part != "body")
            errors.append({"field": location or "body", "message": str(error.get("msg", "invalid value"))})
        return JSONResponse(
            status_code=422,
            content={"detail": "The request body is invalid.", "errors": errors},
            headers={"X-Request-ID": _request_id(request)},
        )

    @application.exception_handler(Exception)
    async def unhandled_handler(request: Request, exc: Exception) -> JSONResponse:
        del exc
        logger.exception("unhandled error path=%s", request.url.path)
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error", "request_id": _request_id(request)},
            headers={"X-Request-ID": _request_id(request)},
        )


def _request_id(request: Request) -> str:
    return str(getattr(request.state, "request_id", "") or "")


app = create_app()


def run() -> None:
    """Start Uvicorn using the host and port from settings."""
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "app.main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=settings.app_env == "development",
    )


if __name__ == "__main__":
    run()
