"""Runtime settings loaded from the process environment and an optional `.env` file."""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

INSECURE_ADMIN_TOKENS = frozenset(
    {
        "",
        "change-me",
        "changeme",
        "replace-me",
        "replace-with-a-long-random-string",
    }
)


class Settings(BaseSettings):
    """Application configuration.

    Environment variables use the same names as the fields, in upper case.
    A local `.env` file is read when present. Real environment variables win
    over that file.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_name: str = "Webhook & Data Bridge"
    app_env: Literal["development", "production", "test"] = "development"
    app_host: str = "0.0.0.0"
    app_port: int = Field(default=8000, ge=1, le=65535)
    admin_api_token: str = ""
    database_url: str = "sqlite:///./data/bridge.db"
    log_level: str = "INFO"
    log_file: str = "app.log"
    max_retry_attempts: int = Field(default=3, ge=1, le=8)
    retry_backoff_seconds: float = Field(default=1.5, ge=0, le=30)
    webhook_max_body_bytes: int = Field(default=1_048_576, ge=1_024, le=10_485_760)
    stripe_tolerance_seconds: int = Field(default=300, ge=30, le=86_400)
    outbound_timeout_seconds: float = Field(default=20.0, ge=3, le=120)
    cors_origins: str = ""
    google_service_account_file: str = ""
    google_service_account_json: str = ""
    trust_proxy: bool = False
    allow_insecure_http: bool = False
    resume_pending_on_startup: bool = True

    @field_validator("app_env", mode="before")
    @classmethod
    def normalize_environment(cls, value: object) -> object:
        """Accept the short names `dev` and `prod`."""
        if not isinstance(value, str):
            return value
        aliases = {"dev": "development", "prod": "production"}
        return aliases.get(value.strip().lower(), value.strip().lower())

    @field_validator("log_level", mode="before")
    @classmethod
    def normalize_log_level(cls, value: object) -> object:
        """Store log levels in upper case and reject unknown names."""
        if not isinstance(value, str):
            return value
        normalized = value.strip().upper()
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if normalized not in allowed:
            raise ValueError(f"log_level must be one of: {', '.join(sorted(allowed))}")
        return normalized

    @field_validator("database_url")
    @classmethod
    def database_url_not_blank(cls, value: str) -> str:
        """Reject an empty database URL before SQLAlchemy does."""
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("database_url must not be empty")
        return cleaned

    @property
    def cors_origin_list(self) -> list[str]:
        """Split the comma-separated CORS origin list."""
        return [item.strip() for item in self.cors_origins.split(",") if item.strip()]

    @property
    def is_production(self) -> bool:
        """Return whether the process is running in production mode."""
        return self.app_env == "production"


def admin_token_is_usable(settings: Settings, *, minimum_length: int) -> bool:
    """Return whether the admin token is set and not a known placeholder."""
    token = settings.admin_api_token.strip()
    return token not in INSECURE_ADMIN_TOKENS and len(token) >= minimum_length


def assert_runtime_safety(settings: Settings) -> None:
    """Refuse to boot production with a missing or placeholder admin token."""
    if not settings.is_production:
        return
    if not admin_token_is_usable(settings, minimum_length=24):
        raise RuntimeError(
            "Refusing to start in production. Set ADMIN_API_TOKEN to a random "
            "string of at least 24 characters. Generate one with: "
            "python -c \"import secrets; print(secrets.token_urlsafe(32))\""
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-wide settings object."""
    return Settings()
