# Webhook & Data Bridge

A private webhook service you run yourself. Point Stripe, a form, or any other JSON sender at it. The bridge checks the signature, reshapes the payload, saves both copies, and forwards the result to Discord, Telegram, Google Sheets, and any HTTPS endpoint you choose.

It is one small FastAPI app with a SQLite database. There is no account to create and no monthly automation bill.

```mermaid
flowchart LR
  source[Stripe, form, or app] --> hook["POST /hooks/your-slug"]
  hook --> check[Check token or signature]
  check --> map[Rename, cast, and template]
  map --> db[(SQLite)]
  map --> discord[Discord]
  map --> telegram[Telegram]
  map --> sheets[Google Sheets]
  map --> other[Your own HTTPS endpoint]
```

## What you need

- Python 3.10 or newer for a local install, or Docker Desktop if you prefer containers
- A long random admin token
- The webhook URL and secret from the service you want to receive, plus the destination you want to notify

The admin token protects the management API. Inbound senders do not use it. Each inbound endpoint has its own secret.

## Run it on your computer

Open a terminal in this folder.

**Windows (PowerShell)**

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

**macOS or Linux**

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

Open `.env` and paste that token into `ADMIN_API_TOKEN`. Leave the other values as they are for a first run.

Start the app:

```bash
python -m app.main
```

Open [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs). That page is the control panel: every management call is listed, and you can try them from the browser. Click **Authorize** and paste the admin token as `Bearer <your token>`.

Check that the process and the database are up:

```bash
curl http://127.0.0.1:8000/health
```

A healthy response looks like `{"status":"ok",...}`. Logs are written to `app.log` in this folder and also to the terminal. Payloads are stored in `data/bridge.db`.

## Run it with Docker

Docker Compose reads `ADMIN_API_TOKEN` from the `.env` file next to `docker-compose.yml`. It does **not** use `DATABASE_URL` or `LOG_FILE` from that file. The container always stores the database and the log in a Docker volume at `/app/data`, so a laptop path cannot leak into the container.

```bash
# Windows: copy .env.example .env
# macOS or Linux: cp .env.example .env
```

Set `ADMIN_API_TOKEN` to a random string of at least 24 characters. `APP_ENV` inside Compose is `production`, and the app will refuse to boot if the token is still the example placeholder.

```bash
docker compose up -d --build
docker compose logs -f bridge
```

The API is on [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).

Stop it with `docker compose down`. Add `--volumes` only when you mean to delete the database.

Put a Google service-account JSON file at `secrets/sheets.json` when you want Sheets. The file must be readable by the container (`chmod 644 secrets/sheets.json` on macOS or Linux).

## Create a bridge

A bridge is an **endpoint** plus one or more **routes**.

- The endpoint is the URL senders call: `/hooks/contact-form`
- A route is one destination: Discord, Telegram, Sheets, another webhook, or an explicit “saved in the database” record

The database save happens for every accepted call, even when you add no routes. A `database` route only adds a visible delivery row for that save.

### 1. Create the endpoint

PowerShell:

```powershell
$token = "paste-the-admin-token"
$headers = @{ Authorization = "Bearer $token" }
$body = @{
  name = "Contact form"
  slug = "contact-form"
  description = "Form submissions from the marketing site"
  auth_type = "bearer"
  auth_secret = "choose-a-long-form-secret"
  transform_rules = @{
    rename = @{ full_name = "name" }
    template_fields = @{ summary = "New contact from {name}" }
  }
} | ConvertTo-Json -Depth 8
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/api/endpoints -Headers $headers -ContentType "application/json" -Body $body
```

bash:

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Contact form",
    "slug": "contact-form",
    "auth_type": "bearer",
    "auth_secret": "choose-a-long-form-secret",
    "transform_rules": {
      "rename": {"full_name": "name"},
      "template_fields": {"summary": "New contact from {name}"}
    }
  }'
```

The response includes `ingest_path`. The secret you just set is not echoed back; you get a short hint instead. The slug is permanent. To change the public URL, create a new endpoint.

`auth_type` is one of:

| Value | What the sender must present |
| --- | --- |
| `bearer` | `Authorization: Bearer <secret>` or the header `X-Webhook-Token: <secret>` |
| `stripe` | A `Stripe-Signature` header. Use the signing secret from the Stripe dashboard, not your API key. |
| `hmac` | `X-Hub-Signature-256: sha256=<hex>` or `X-Signature: <hex>`, HMAC-SHA256 of the raw body |
| `none` | Nothing. Leave this off unless the sender truly cannot sign requests. |

### 2. Attach Discord

In Discord, create a webhook on the channel (Channel settings, Integrations, Webhooks) and copy its URL.

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints/1/routes \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Ops Discord",
    "destination_type": "discord",
    "config": {
      "webhook_url": "https://discord.com/api/webhooks/123/replace-me",
      "message_template": "{summary}",
      "use_embed": true,
      "embed_title": "New contact"
    }
  }'
```

Only `https://discord.com/api/webhooks/...` (and Discord’s canary, PTB, and discordapp.com hosts) is accepted. The saved URL is masked when you read the route back.

### 3. Send a test from the admin API

This does not require the form to be live yet.

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints/1/test \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{"payload": {"full_name": "Ada Lovelace"}, "dispatch": false}'
```

`"dispatch": false` only shows the transformed JSON. Set it to `true` to save the event and send it to every active route.

Send it the way a real form would:

```bash
curl -s -X POST http://127.0.0.1:8000/hooks/contact-form \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Token: choose-a-long-form-secret" \
  -d '{"full_name": "Ada Lovelace", "email": "ada@example.com"}'
```

You should see `{"id": 1, "status": "accepted"}`. Delivery happens after that response. `accepted` means the event is stored and queued, not that Discord has already answered. Open the payload a moment later to see the delivery result.

## Telegram

Create a bot with BotFather, copy the token, and get the chat id (your user id, or the group id).

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints/1/routes \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Founder Telegram",
    "destination_type": "telegram",
    "config": {
      "bot_token": "123456789:replace-with-the-bot-token",
      "chat_id": "123456789",
      "message_template": "{summary}"
    }
  }'
```

`parse_mode` may be `HTML`, `Markdown`, or `MarkdownV2`. When you set `HTML` and do not set a template, the bridge escapes the generated JSON so Telegram does not reject it. A template is sent as you wrote it.

## Google Sheets

1. In Google Cloud, create a service account and a JSON key.
2. Create a spreadsheet and share it with the service account email as **Editor**.
3. Put the key file at `secrets/sheets.json`, or set `credentials_file` on the route to a path the app can read.
4. Add a header row yourself (`name`, `email`, `summary`). The bridge appends data rows; it does not invent the header.

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints/1/routes \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Leads sheet",
    "destination_type": "sheets",
    "config": {
      "spreadsheet_id": "the-id-between-d-and-edit-in-the-sheet-url",
      "range": "Sheet1!A1",
      "columns": ["name", "email", "summary"],
      "credentials_file": "secrets/sheets.json"
    }
  }'
```

Inside Docker, use `"credentials_file": "/app/secrets/sheets.json"`. Omit `columns` and the row is written in alphabetical field order, which is rarely what you want. Name the columns.

You can also set `GOOGLE_SERVICE_ACCOUNT_FILE` or `GOOGLE_SERVICE_ACCOUNT_JSON` in the environment and leave `credentials_file` off the route. A JSON blob in `.env` is awkward to quote. Prefer the file.

## Forward to your own service

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints/1/routes \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Billing API",
    "destination_type": "webhook",
    "config": {
      "url": "https://billing.example.com/events",
      "method": "POST",
      "headers": {"Authorization": "Bearer destination-token"},
      "include_metadata": true
    }
  }'
```

`include_metadata: true` wraps the body:

```json
{
  "data": {"name": "Ada Lovelace"},
  "meta": {"endpoint": "contact-form", "payload_id": 1, "received_at": "2026-01-01T00:00:00+00:00"}
}
```

Plain `http://` is allowed for `localhost` only. For a private LAN address such as `http://192.168.1.20:8080/hook`, set `ALLOW_INSECURE_HTTP=true`. Cloud metadata addresses are always rejected. Redirects are not followed.

## Stripe

In the Stripe dashboard, add an endpoint whose URL is:

```text
https://your-domain.example/hooks/stripe-payments
```

Reveal the signing secret. It starts with `whsec_`. Put that in `auth_secret`. Do not put your Stripe API key here.

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Stripe payments",
    "slug": "stripe-payments",
    "auth_type": "stripe",
    "auth_secret": "whsec_replace_me",
    "idempotency_path": "id",
    "transform_rules": {
      "pick": ["id", "type", "data.object.amount", "data.object.currency", "data.object.receipt_email"],
      "rename": {
        "data.object.amount": "amount",
        "data.object.receipt_email": "email"
      },
      "casts": {"amount": "cents_to_decimal", "email": "lower"},
      "template_fields": {"summary": "{type}: {amount} {currency} from {email}"}
    }
  }'
```

`idempotency_path` reads Stripe’s event id. The same event delivered twice is stored once and answered with `"status": "duplicate"`. A sender may also pass an `Idempotency-Key` header. The header wins over the path. Delivery is at-least-once: a crash after Stripe was accepted, or a manual replay, can send the destination again.

The signature is checked against the raw body, with a default clock window of 300 seconds (`STRIPE_TOLERANCE_SECONDS`).

Amounts in Stripe are cents. `cents_to_decimal` turns `1999` into the string `"19.99"`, which Sheets will accept as a number when the route uses `USER_ENTERED`.

## HMAC

For a sender you control, sign the raw body with the shared secret:

```bash
python -c "import hmac,hashlib,sys; body=sys.stdin.buffer.read(); print('sha256='+hmac.new(b'your-shared-secret', body, hashlib.sha256).hexdigest())" < event.json
```

Send that value in `X-Hub-Signature-256` or `X-Signature`. Create the endpoint with `"auth_type": "hmac"`.

## Transform rules

Rules run in this order:

1. `pick` builds a new object from dotted paths. Without `pick`, the whole JSON object is copied.
2. `rename` renames top-level keys. With `pick`, the rename key is the source path. Without `pick`, a dotted rename copies that value onto a new top-level key.
3. `casts` convert values that are present.
4. `defaults` fill keys that are still missing.
5. `static` overwrites keys with constants.
6. `template_fields` render `{placeholders}` from the object so far. A missing placeholder is left as `{name}`. A literal brace in a template is written `{{`.
7. `include` keeps only those keys.
8. `drop` removes keys.

| Cast | Result |
| --- | --- |
| `string` | Text |
| `integer` | Whole number |
| `float` | Decimal number |
| `boolean` | `true`, `false`, `yes`, `no`, `1`, `0` |
| `cents_to_decimal` | `"19.99"` from `1999` cents |
| `unix_to_iso` | UTC timestamp. Values with 13 digits are treated as milliseconds. |
| `lower` / `upper` | Letter case |

Paths can walk lists: `items.0.sku`. A missing path is skipped. A cast that cannot convert the value stores the raw payload, marks it `failed`, and returns HTTP 200 with `"status": "failed"` so the sender does not retry a rules bug forever. The reason is on the payload row, not in the public response.

Arrays sent as the JSON root are wrapped as `{"value": [...]}` before the rules run.

Try rules without saving anything:

```bash
curl -s -X POST http://127.0.0.1:8000/api/endpoints/1/test \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{"payload": {"data": {"object": {"amount": 1999}}}, "dispatch": false}'
```

A bad rule returns 422 and names the field.

## See what arrived

```bash
curl -s "http://127.0.0.1:8000/api/payloads?limit=20" \
  -H "Authorization: Bearer paste-the-admin-token"
```

Filter with `endpoint_id` and `status` (`accepted`, `processed`, `partial`, `failed`).

```bash
curl -s http://127.0.0.1:8000/api/payloads/1 \
  -H "Authorization: Bearer paste-the-admin-token"
```

The detail includes each delivery: destination, HTTP status, attempt count, and a short error. Destination secrets are not written into those errors.

| Payload status | Meaning |
| --- | --- |
| `accepted` | Stored, and delivery has not finished |
| `processed` | Every active route succeeded, or there were no active routes |
| `partial` | At least one route succeeded and one failed |
| `failed` | The rules rejected the body, or every route failed |

Retries cover timeouts, connection errors, and HTTP 408, 429, and 5xx. A normal 4xx is not retried, because sending the same body again will not fix it. The default is 3 attempts. The first retry waits `RETRY_BACKOFF_SECONDS` (1.5 seconds), and each later wait doubles. A `Retry-After` header on HTTP 429 is honored up to 30 seconds.

After you fix a route or a transform, send the stored event again:

```bash
curl -s -X POST "http://127.0.0.1:8000/api/payloads/1/replay?retransform=true" \
  -H "Authorization: Bearer paste-the-admin-token"
```

`retransform=true` runs the current rules against the saved raw JSON. Use that after editing `transform_rules`. Replay always sends again.

Pause a destination without deleting history:

```bash
curl -s -X PATCH http://127.0.0.1:8000/api/routes/1 \
  -H "Authorization: Bearer paste-the-admin-token" \
  -H "Content-Type: application/json" \
  -d '{"is_active": false}'
```

When you update a route, send only the fields you want to change. If you round-trip a masked secret, the stored secret is kept. Send the full new secret to rotate it. Set a config key to `null` to remove it.

An endpoint can have 20 routes. Delete a test payload with `DELETE /api/payloads/1`. Deleting an endpoint deletes its routes and payloads.

## Security checklist

- Keep `.env`, `data/bridge.db`, and `app.log` private. The database holds inbound secrets and destination tokens.
- Use `auth_type: bearer`, `stripe`, or `hmac` on every public endpoint.
- The admin token is not the webhook secret. Callers of `/hooks/...` never need the admin token. Callers of `/api/...` always do.
- Production (`APP_ENV=production`, which is what Docker uses) will not start until `ADMIN_API_TOKEN` is at least 24 characters and is not the placeholder from `.env.example`.
- Put a reverse proxy with HTTPS in front of the app before the internet can reach it. The app speaks HTTP. Caddy on the same machine:

```text
hooks.example.com {
    reverse_proxy 127.0.0.1:8000
}
```

Then set `TRUST_PROXY=true` so the stored source address comes from `X-Forwarded-For`. Leave it false when you connect directly, or clients can spoof that header.

- Interactive docs at `/docs` are available without the admin token. They describe the API. They do not reveal secrets. Do not publish port 8000 on a public network interface without the proxy and a firewall.
- Outbound webhook URLs are called from your server. Point them only at services you trust.

## Switch to PostgreSQL

The same tables work on PostgreSQL. The driver is already installed (`postgresql+psycopg`).

Start the optional database:

```bash
docker compose --profile postgres up -d
```

For a local Python process, set:

```text
DATABASE_URL=postgresql+psycopg://bridge:bridge@127.0.0.1:5432/bridge
```

For the app container, edit `docker-compose.yml` and replace the SQLite `DATABASE_URL` with:

```text
postgresql+psycopg://bridge:bridge@postgres:5432/bridge
```

Add `postgres` to the bridge service `depends_on`, then `docker compose --profile postgres up -d --build`. Tables are created on startup. This project does not migrate old SQLite files into Postgres for you. Export anything you need before you switch, or start on Postgres on day one.

Change the `bridge` database password before anyone else can reach port 5432. The published password in the Compose file is only a local default.

## Backups and updates

Copy the SQLite file while you have a copy of `.env` stored somewhere safe:

```bash
copy data\bridge.db bridge-backup.db
```

Docker:

```bash
docker compose cp bridge:/app/data/bridge.db .\bridge-backup.db
```

To update, replace this folder’s `app` code, keep `.env` and the data volume, and start again (`python -m app.main`, or `docker compose up -d --build`). Tables that already exist are left in place. A future version that changes columns will say so. To wipe a local experiment, stop the app and delete `data/bridge.db`.

If the process stops after a payload was stored and before every destination answered, the next startup sends the unfinished ones. Set `RESUME_PENDING_ON_STARTUP=false` to disable that.

## Configuration

| Variable | Default | What it does |
| --- | --- | --- |
| `ADMIN_API_TOKEN` | empty | Unlocks `/api`. Required in production. |
| `APP_ENV` | `development` | `production` refuses a weak admin token. |
| `DATABASE_URL` | `sqlite:///./data/bridge.db` | SQLite file, or a `postgresql+psycopg://` URL. |
| `LOG_FILE` / `LOG_LEVEL` | `app.log` / `INFO` | Rotating log, 5 MB × 5 files. |
| `MAX_RETRY_ATTEMPTS` | `3` | Tries per delivery, from 1 to 8. |
| `RETRY_BACKOFF_SECONDS` | `1.5` | First wait. Later waits double, up to the cap in settings. |
| `WEBHOOK_MAX_BODY_BYTES` | `1048576` | Largest accepted body. 1 KB minimum, 10 MB maximum. |
| `STRIPE_TOLERANCE_SECONDS` | `300` | How far a Stripe timestamp may drift. |
| `OUTBOUND_TIMEOUT_SECONDS` | `20` | Per-request timeout for Discord, Telegram, and webhooks. |
| `ALLOW_INSECURE_HTTP` | `false` | Allow `http://` destinations beyond localhost. |
| `TRUST_PROXY` | `false` | Trust `X-Forwarded-For` for the stored IP. |
| `CORS_ORIGINS` | empty | Comma-separated browser origins, if you build a UI later. |
| `GOOGLE_SERVICE_ACCOUNT_FILE` | empty | Fallback Sheets credential file. |
| `RESUME_PENDING_ON_STARTUP` | `true` | Finish deliveries that were in progress at shutdown. |

## Troubleshooting

**The admin API says the token is missing.** `ADMIN_API_TOKEN` is empty or still `replace-with-a-long-random-string`. Put a real token in `.env` and start the app again. Docker reads that file at `docker compose up` time.

**Docker exits immediately in production.** The token is shorter than 24 characters. Generate a new one and recreate the container.

**Stripe says the signature is invalid.** The secret must be the endpoint signing secret. The app must see the raw body, so do not let another proxy reformat JSON. A timestamp error means the server clock is off, or the event is older than `STRIPE_TOLERANCE_SECONDS`.

**Discord or Telegram never fires, and the payload is `failed`.** Open `GET /api/payloads/{id}`. The delivery error is the reason: a bad webhook URL, a bot that has not been started with `/start`, or a sheet that is not shared with the service account.

**The sender keeps retrying.** Inbound auth failures return 401 on purpose. Transform failures return 200 with `"status": "failed"` so a rules mistake does not create a retry storm. Fix the rules, then replay.

**`database is locked`.** Use one app process against a SQLite file. Do not open the file in a second writer. PostgreSQL is the step up when you outgrow that.

**Port 8000 is taken.** Change `APP_PORT` for a local run. For Docker, change the left side of `8000:8000` in `docker-compose.yml`.

## API map

| Method | Path | Auth |
| --- | --- | --- |
| `GET` | `/health` | Public |
| `POST` | `/hooks/{slug}` | Endpoint secret |
| `POST` | `/api/endpoints` | Admin |
| `GET` | `/api/endpoints` | Admin |
| `GET` | `/api/endpoints/{id}` | Admin |
| `PATCH` | `/api/endpoints/{id}` | Admin |
| `DELETE` | `/api/endpoints/{id}` | Admin |
| `POST` | `/api/endpoints/{id}/routes` | Admin |
| `GET` | `/api/endpoints/{id}/routes` | Admin |
| `PATCH` | `/api/routes/{id}` | Admin |
| `DELETE` | `/api/routes/{id}` | Admin |
| `POST` | `/api/endpoints/{id}/test` | Admin |
| `GET` | `/api/payloads` | Admin |
| `GET` | `/api/payloads/{id}` | Admin |
| `DELETE` | `/api/payloads/{id}` | Admin |
| `POST` | `/api/payloads/{id}/replay` | Admin |
| `GET` | `/api/deliveries` | Admin |

The live reference, including request bodies, is `/docs`.

## Project layout

```text
app/main.py                 process startup, logging, error handlers
app/config.py               environment settings
app/database.py             SQLite or PostgreSQL sessions
app/models.py               endpoints, routes, payloads, deliveries
app/schemas.py              request validation and route config
app/routers/webhooks.py     inbound POST /hooks/{slug}
app/routers/admin.py        management API
app/services/transformer.py mapping rules
app/services/dispatcher.py  Discord, Telegram, Sheets, webhooks, retries
app/services/security.py    signatures, URL checks, secret masking
app/services/ingest.py      store a payload and its idempotency key
```

## Tests

```bash
pip install -r requirements-dev.txt
pytest
```

The tests use a temporary SQLite file and do not call Discord, Telegram, or Google.
