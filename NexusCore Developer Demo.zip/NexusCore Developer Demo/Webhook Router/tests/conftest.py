"""Test client pointed at a throwaway SQLite file."""

from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

_TMP = Path(__file__).resolve().parent / "_tmp"
_TMP.mkdir(exist_ok=True)

TOKEN = "test-admin-token-value-123456"
os.environ["APP_ENV"] = "test"
os.environ["ADMIN_API_TOKEN"] = TOKEN
os.environ["DATABASE_URL"] = "sqlite:///" + (_TMP / "import.sqlite3").as_posix()
os.environ["LOG_FILE"] = (_TMP / "import.log").as_posix()
os.environ["LOG_LEVEL"] = "WARNING"
os.environ["RESUME_PENDING_ON_STARTUP"] = "false"
os.environ["ALLOW_INSECURE_HTTP"] = "false"


@pytest.fixture
def auth() -> dict[str, str]:
    """Bearer header for the admin API."""
    return {"Authorization": f"Bearer {TOKEN}"}


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Start a fresh app against a temporary database."""
    monkeypatch.setenv("APP_ENV", "test")
    monkeypatch.setenv("ADMIN_API_TOKEN", TOKEN)
    monkeypatch.setenv("DATABASE_URL", "sqlite:///" + (tmp_path / "bridge.sqlite3").as_posix())
    monkeypatch.setenv("LOG_FILE", (tmp_path / "app.log").as_posix())
    monkeypatch.setenv("LOG_LEVEL", "WARNING")
    monkeypatch.setenv("RESUME_PENDING_ON_STARTUP", "false")
    monkeypatch.setenv("ALLOW_INSECURE_HTTP", "false")
    monkeypatch.setenv("GOOGLE_SERVICE_ACCOUNT_FILE", "")
    monkeypatch.setenv("GOOGLE_SERVICE_ACCOUNT_JSON", "")

    from app.config import get_settings
    from app.database import reset_database_state

    get_settings.cache_clear()
    reset_database_state()
    monkeypatch.setattr("app.services.dispatcher.time.sleep", lambda *_args, **_kwargs: None)

    from app.main import create_app

    application = create_app()
    with TestClient(application) as test_client:
        yield test_client
    reset_database_state()
    get_settings.cache_clear()


@pytest.fixture
def http_script(monkeypatch: pytest.MonkeyPatch) -> dict[str, list]:
    """Replace outbound HTTP with a script of responses."""
    calls: list[dict] = []
    script: list = []

    class FakeResponse:
        def __init__(self, status_code: int = 204, text: str = "", headers: dict | None = None) -> None:
            self.status_code = status_code
            self.text = text
            self.headers = headers or {}

    class FakeClient:
        def __init__(self, *args: object, **kwargs: object) -> None:
            del args, kwargs

        def __enter__(self) -> FakeClient:
            return self

        def __exit__(self, exc_type: object, exc: object, traceback: object) -> bool:
            del exc_type, exc, traceback
            return False

        def request(self, method: str, url: str, **kwargs: object) -> FakeResponse:
            calls.append({"method": method, "url": url, "json": kwargs.get("json")})
            if not script:
                return FakeResponse()
            item = script.pop(0)
            if isinstance(item, Exception):
                raise item
            return item

    monkeypatch.setattr("app.services.dispatcher.httpx.Client", FakeClient)
    return {"calls": calls, "script": script, "response": FakeResponse}
