"""Behavior tests for transform rules, authentication, ingest, and dispatch."""

from __future__ import annotations

import hashlib
import hmac
import json
import time

import httpx
import pytest

from app.config import assert_runtime_safety, get_settings
from app.services.dispatcher import build_sheet_row
from app.services.security import AuthError, assert_safe_outbound_url, verify_endpoint_auth
from app.services.transformer import TransformError, transform_payload

DISCORD_URL = "https://discord.com/api/webhooks/123456789/abcdefghijklmnopqrstuvwxyz"


def test_transform_pick_cast_and_template() -> None:
    result = transform_payload(
        {"id": "evt_1", "data": {"object": {"amount": 1999, "currency": "usd", "email": "A@Example.com"}}},
        {
            "pick": ["id", "data.object.amount", "data.object.currency", "data.object.email"],
            "rename": {"data.object.amount": "amount", "data.object.email": "email"},
            "casts": {"amount": "cents_to_decimal", "email": "lower"},
            "defaults": {"source": "stripe"},
            "static": {"bridge": "local"},
            "template_fields": {"summary": "{email} paid {amount} {currency}"},
            "drop": ["id"],
        },
    )
    assert result == {
        "amount": "19.99",
        "currency": "usd",
        "email": "a@example.com",
        "source": "stripe",
        "bridge": "local",
        "summary": "a@example.com paid 19.99 usd",
    }


def test_transform_rejects_bad_cast() -> None:
    with pytest.raises(TransformError):
        transform_payload({"amount": "nope"}, {"casts": {"amount": "integer"}})


def test_unix_and_bool_casts() -> None:
    result = transform_payload(
        {"created": 0, "ok": "yes"},
        {"casts": {"created": "unix_to_iso", "ok": "boolean"}},
    )
    assert result["created"].startswith("1970-01-01T00:00:00")
    assert result["ok"] is True


def test_sheet_row_uses_requested_columns() -> None:
    assert build_sheet_row({"b": 2, "a": {"nested": True}, "c": None}, ["c", "a", "missing"]) == [
        "",
        '{"nested":true}',
        "",
    ]


def test_blocks_metadata_and_plaintext_lan() -> None:
    with pytest.raises(ValueError):
        assert_safe_outbound_url("http://169.254.169.254/latest/meta-data", allow_insecure_http=True)
    with pytest.raises(ValueError):
        assert_safe_outbound_url("http://10.0.0.8/hook", allow_insecure_http=False)
    assert_safe_outbound_url("http://127.0.0.1:9/hook", allow_insecure_http=False)


def test_production_refuses_placeholder(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("ADMIN_API_TOKEN", "replace-with-a-long-random-string")
    get_settings.cache_clear()
    with pytest.raises(RuntimeError):
        assert_runtime_safety(get_settings())
    get_settings.cache_clear()


def test_stripe_signature_accepts_raw_body_and_rejects_stale_timestamp() -> None:
    body = b'{"id":"evt_1"}'
    secret = "whsec_test_secret_value"
    stamp = int(time.time())
    signature = hmac.new(secret.encode(), f"{stamp}.".encode() + body, hashlib.sha256).hexdigest()
    verify_endpoint_auth(
        auth_type="stripe",
        secret=secret,
        body=body,
        headers={"stripe-signature": f"t={stamp},v1={signature}"},
        tolerance_seconds=300,
    )
    with pytest.raises(AuthError):
        verify_endpoint_auth(
            auth_type="stripe",
            secret=secret,
            body=body,
            headers={"stripe-signature": f"t={stamp - 10_000},v1={signature}"},
            tolerance_seconds=300,
        )


def test_health_docs_and_admin_auth(client, auth: dict[str, str]) -> None:
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"
    assert client.get("/docs").status_code == 200
    assert client.get("/api/endpoints").status_code == 401
    assert client.get("/api/endpoints", headers={"Authorization": "Bearer wrong-token-value"}).status_code == 401
    assert client.get("/api/endpoints", headers=auth).status_code == 200


def test_ingest_transforms_and_delivers(client, auth: dict[str, str], http_script: dict) -> None:
    created = _create_endpoint(client, auth)
    route = client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={
            "name": "Ops Discord",
            "destination_type": "discord",
            "config": {"webhook_url": DISCORD_URL, "message_template": "{summary}", "use_embed": False},
        },
    )
    assert route.status_code == 201, route.text
    assert route.json()["config"]["webhook_url"] != DISCORD_URL

    received = client.post(
        "/hooks/contact-form",
        headers={"X-Webhook-Token": "form-secret-value"},
        json={"full_name": "Ada Lovelace", "ignored": True},
    )
    assert received.status_code == 200
    assert received.json()["status"] == "accepted"
    assert http_script["calls"][0]["url"] == DISCORD_URL
    assert http_script["calls"][0]["json"]["content"] == "New contact from Ada Lovelace"

    stored = client.get("/api/payloads", headers=auth).json()
    assert stored["total"] == 1
    assert stored["items"][0]["status"] == "processed"
    assert stored["items"][0]["transformed_payload"]["name"] == "Ada Lovelace"
    detail = client.get(f"/api/payloads/{received.json()['id']}", headers=auth).json()
    assert detail["deliveries"][0]["status"] == "success"
    assert "form-secret-value" not in json.dumps(created)


def test_bad_token_is_not_stored(client, auth: dict[str, str]) -> None:
    _create_endpoint(client, auth)
    rejected = client.post("/hooks/contact-form", json={"full_name": "Ada"})
    assert rejected.status_code == 401
    assert client.get("/api/payloads", headers=auth).json()["total"] == 0


def test_stripe_ingest_and_idempotency(client, auth: dict[str, str], http_script: dict) -> None:
    secret = "whsec_test_secret_value"
    created = _create_endpoint(
        client,
        auth,
        slug="stripe-payments",
        auth_type="stripe",
        auth_secret=secret,
        idempotency_path="id",
        transform_rules={
            "pick": ["type", "data.object.amount"],
            "rename": {"data.object.amount": "amount"},
            "casts": {"amount": "cents_to_decimal"},
        },
    )
    client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={"destination_type": "database", "config": {}},
    )
    payload = {"id": "evt_123", "type": "charge.succeeded", "data": {"object": {"amount": 2500}}}
    body = json.dumps(payload, separators=(",", ":")).encode()
    stamp = int(time.time())
    signature = hmac.new(secret.encode(), f"{stamp}.".encode() + body, hashlib.sha256).hexdigest()
    headers = {"Content-Type": "application/json", "Stripe-Signature": f"t={stamp},v1={signature}"}
    first = client.post("/hooks/stripe-payments", content=body, headers=headers)
    second = client.post("/hooks/stripe-payments", content=body, headers=headers)
    assert first.status_code == 200
    assert first.json()["status"] == "accepted"
    assert second.json()["status"] == "duplicate"
    assert second.json()["id"] == first.json()["id"]
    assert client.get("/api/payloads", headers=auth).json()["total"] == 1
    stored = client.get(f"/api/payloads/{first.json()['id']}", headers=auth).json()
    assert stored["transformed_payload"]["amount"] == "25.00"
    assert http_script["calls"] == []


def test_retries_then_succeeds_and_partial_failure(client, auth: dict[str, str], http_script: dict) -> None:
    created = _create_endpoint(client, auth, slug="alerts")
    client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={"destination_type": "discord", "config": {"webhook_url": DISCORD_URL, "use_embed": False}},
    )
    client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={"destination_type": "webhook", "config": {"url": "http://127.0.0.1:9/internal"}},
    )
    response_type = http_script["response"]
    http_script["script"].extend([response_type(500, "busy"), response_type(204), response_type(400, "no")])
    received = client.post(
        "/hooks/alerts",
        headers={"Authorization": "Bearer form-secret-value"},
        json={"full_name": "Grace"},
    )
    assert received.status_code == 200
    detail = client.get(f"/api/payloads/{received.json()['id']}", headers=auth).json()
    assert detail["status"] == "partial"
    by_type = {item["destination_type"]: item for item in detail["deliveries"]}
    assert by_type["discord"]["attempt_count"] == 2
    assert by_type["discord"]["status"] == "success"
    assert by_type["webhook"]["attempt_count"] == 1
    assert by_type["webhook"]["status"] == "failed"


def test_transform_failure_is_stored_for_the_operator(client, auth: dict[str, str], http_script: dict) -> None:
    created = _create_endpoint(
        client,
        auth,
        slug="typed",
        transform_rules={"casts": {"amount": "integer"}},
    )
    client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={"destination_type": "discord", "config": {"webhook_url": DISCORD_URL}},
    )
    received = client.post(
        "/hooks/typed",
        headers={"Authorization": "Bearer form-secret-value"},
        json={"amount": "nope"},
    )
    assert received.status_code == 200
    assert received.json()["status"] == "failed"
    assert http_script["calls"] == []
    stored = client.get(f"/api/payloads/{received.json()['id']}", headers=auth).json()
    assert stored["status"] == "failed"
    assert "amount" in stored["error_message"]


def test_dry_run_replay_and_masked_update(client, auth: dict[str, str], http_script: dict) -> None:
    created = _create_endpoint(client, auth, slug="preview")
    route = client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={
            "destination_type": "discord",
            "config": {"webhook_url": DISCORD_URL, "use_embed": False, "message_template": "{summary}"},
        },
    ).json()
    dry = client.post(
        f"/api/endpoints/{created['id']}/test",
        headers=auth,
        json={"payload": {"full_name": "Lin"}, "dispatch": False},
    )
    assert dry.status_code == 200
    assert dry.json()["transformed"]["summary"] == "New contact from Lin"
    assert client.get("/api/payloads", headers=auth).json()["total"] == 0

    masked = route["config"]
    masked["message_template"] = "Hello {name}"
    updated = client.patch(f"/api/routes/{route['id']}", headers=auth, json={"config": masked})
    assert updated.status_code == 200, updated.text

    sent = client.post(
        "/hooks/preview",
        headers={"Authorization": "Bearer form-secret-value"},
        json={"full_name": "Lin"},
    )
    assert http_script["calls"][-1]["url"] == DISCORD_URL
    assert http_script["calls"][-1]["json"]["content"] == "Hello Lin"
    replay = client.post(f"/api/payloads/{sent.json()['id']}/replay", headers=auth)
    assert replay.status_code == 200, replay.text
    assert replay.json()["deliveries"][-1]["trigger"] == "replay"
    assert len(http_script["calls"]) == 2


def test_sheets_route_reports_missing_credentials(client, auth: dict[str, str]) -> None:
    created = _create_endpoint(client, auth, slug="sheet-demo", transform_rules={})
    route = client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={
            "destination_type": "sheets",
            "config": {"spreadsheet_id": "abcdefghij1234", "columns": ["name"]},
        },
    )
    assert route.status_code == 201, route.text
    received = client.post(
        "/hooks/sheet-demo",
        headers={"Authorization": "Bearer form-secret-value"},
        json={"full_name": "Kai"},
    )
    detail = client.get(f"/api/payloads/{received.json()['id']}", headers=auth).json()
    assert detail["status"] == "failed"
    assert "Google Sheets credentials" in detail["deliveries"][0]["error_message"]


def test_disabled_unknown_and_unsafe_targets(client, auth: dict[str, str]) -> None:
    created = _create_endpoint(client, auth, slug="paused")
    assert client.post("/hooks/missing", json={}).status_code == 404
    client.patch(f"/api/endpoints/{created['id']}", headers=auth, json={"is_active": False})
    paused = client.post("/hooks/paused", headers={"Authorization": "Bearer form-secret-value"}, json={"full_name": "A"})
    assert paused.status_code == 403
    blocked = client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={"destination_type": "webhook", "config": {"url": "http://169.254.169.254/latest"}},
    )
    assert blocked.status_code == 422
    again = client.post(
        "/api/endpoints",
        headers=auth,
        json={
            "name": "Other",
            "slug": "paused",
            "auth_type": "bearer",
            "auth_secret": "form-secret-value",
        },
    )
    assert again.status_code == 409


def test_hmac_header(client, auth: dict[str, str], http_script: dict) -> None:
    del http_script
    secret = "hmac-shared-secret"
    _create_endpoint(client, auth, slug="signed", auth_type="hmac", auth_secret=secret, transform_rules={})
    body = b'{"hello":"world"}'
    digest = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    received = client.post(
        "/hooks/signed",
        content=body,
        headers={"Content-Type": "application/json", "X-Hub-Signature-256": f"sha256={digest}"},
    )
    assert received.status_code == 200
    assert received.json()["status"] == "accepted"
    rejected = client.post(
        "/hooks/signed",
        content=body,
        headers={"Content-Type": "application/json", "X-Hub-Signature-256": "sha256=deadbeef"},
    )
    assert rejected.status_code == 401


def test_body_limit_and_content_type(client, auth: dict[str, str], monkeypatch: pytest.MonkeyPatch) -> None:
    _create_endpoint(client, auth, slug="limited", transform_rules={})
    monkeypatch.setenv("WEBHOOK_MAX_BODY_BYTES", "1024")
    get_settings.cache_clear()
    too_big = client.post(
        "/hooks/limited",
        headers={"Authorization": "Bearer form-secret-value", "Content-Type": "application/json"},
        content=b'{"blob":"' + (b"x" * 1100) + b'"}',
    )
    assert too_big.status_code == 413
    wrong_type = client.post(
        "/hooks/limited",
        headers={"Authorization": "Bearer form-secret-value", "Content-Type": "text/plain"},
        content=b'{"full_name":"Ada"}',
    )
    assert wrong_type.status_code == 415
    get_settings.cache_clear()


def test_network_errors_are_retried(client, auth: dict[str, str], http_script: dict) -> None:
    created = _create_endpoint(client, auth, slug="flaky", transform_rules={})
    client.post(
        f"/api/endpoints/{created['id']}/routes",
        headers=auth,
        json={"destination_type": "webhook", "config": {"url": "https://example.com/hook"}},
    )
    http_script["script"].extend([httpx.ConnectError("connection reset"), http_script["response"](202, "ok")])
    received = client.post(
        "/hooks/flaky",
        headers={"Authorization": "Bearer form-secret-value"},
        json={"full_name": "Nia"},
    )
    detail = client.get(f"/api/payloads/{received.json()['id']}", headers=auth).json()
    assert detail["deliveries"][0]["status"] == "success"
    assert detail["deliveries"][0]["attempt_count"] == 2
    assert "connection reset" not in detail["deliveries"][0]["error_message"]


def test_open_endpoint_delete_and_retransform(client, auth: dict[str, str], http_script: dict) -> None:
    created = client.post(
        "/api/endpoints",
        headers=auth,
        json={"name": "Open form", "slug": "open-form", "auth_type": "none"},
    )
    assert created.status_code == 201, created.text
    received = client.post("/hooks/open-form", json={"hello": "world"})
    assert received.status_code == 200
    assert received.json()["status"] == "accepted"

    typed = _create_endpoint(
        client,
        auth,
        slug="fix-rules",
        transform_rules={"casts": {"amount": "integer"}},
    )
    route = client.post(
        f"/api/endpoints/{typed['id']}/routes",
        headers=auth,
        json={"destination_type": "discord", "config": {"webhook_url": DISCORD_URL, "use_embed": False}},
    )
    assert route.status_code == 201, route.text
    failed = client.post(
        "/hooks/fix-rules",
        headers={"Authorization": "Bearer form-secret-value"},
        json={"amount": "nope"},
    )
    assert failed.json()["status"] == "failed"
    patched = client.patch(
        f"/api/endpoints/{typed['id']}",
        headers=auth,
        json={"transform_rules": {}},
    )
    assert patched.status_code == 200, patched.text
    replay = client.post(f"/api/payloads/{failed.json()['id']}/replay", headers=auth)
    assert replay.status_code == 200, replay.text
    assert replay.json()["status"] == "processed"
    assert http_script["calls"][-1]["url"] == DISCORD_URL

    assert client.delete(f"/api/routes/{route.json()['id']}", headers=auth).status_code == 204
    assert client.delete(f"/api/endpoints/{typed['id']}", headers=auth).status_code == 204
    assert client.delete(f"/api/endpoints/{created.json()['id']}", headers=auth).status_code == 204
    assert client.get(f"/api/endpoints/{typed['id']}", headers=auth).status_code == 404
    assert client.get("/api/payloads", headers=auth).json()["total"] == 0


def _create_endpoint(client, auth: dict[str, str], **overrides: object) -> dict:
    body: dict[str, object] = {
        "name": "Contact form",
        "slug": "contact-form",
        "auth_type": "bearer",
        "auth_secret": "form-secret-value",
        "transform_rules": {
            "rename": {"full_name": "name"},
            "template_fields": {"summary": "New contact from {name}"},
        },
    }
    body.update(overrides)
    response = client.post("/api/endpoints", headers=auth, json=body)
    if response.status_code != 201:
        return response.json()
    assert "form-secret-value" not in response.text
    assert "whsec_test_secret_value" not in response.text
    return response.json()
