# NexusCore Developer Trial

A local trial of seven NexusCore products:

- API Proxy Agent
- EnvSync Agent
- LogStream Microservice
- NexusAdmin Downloads & Docs
- NexusCron
- NexusPipeline Package & Setup
- Webhook Router

The launcher installs dependencies, starts each product on its own port, and walks a checkout scenario through all seven. A console at [http://127.0.0.1:7400](http://127.0.0.1:7400) links to every screen and shows the local sign-in values.

## What you need

- Python 3.12 or newer
- Node.js 24 or newer, with npm

The first launch creates `.demo\venv` and installs Node packages inside the three Node products. Later launches reuse those installs.

## Start

From this folder:

```bash
python demo/run_demo.py
```

Windows can also run `Start Demo.ps1`. macOS and Linux can run `./start-demo.sh`.

Leave the terminal open. Stop everything with Ctrl+C.

Sign-in values are on the console and in `.demo/trial.json`. Deleting the `.demo` folder starts the trial from an empty database.

Looking for the licensed editions of API Proxy Agent, EnvSync Agent, LogStream Microservice, NexusAdmin Downloads & Docs, NexusCron, NexusPipeline Package & Setup, and Webhook Router? Visit https://nexuscore-store.whop.site
