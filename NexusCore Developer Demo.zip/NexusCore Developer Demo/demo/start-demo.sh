#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
if [[ -f "$here/demo/run_demo.py" ]]; then
  cd "$here"
  script="$here/demo/run_demo.py"
else
  cd "$(dirname "$here")"
  script="$here/run_demo.py"
fi
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$script"
fi
if command -v python >/dev/null 2>&1; then
  exec python "$script"
fi
printf '%s\n' "Install Python 3.12 or newer, then run this script again." >&2
exit 1
