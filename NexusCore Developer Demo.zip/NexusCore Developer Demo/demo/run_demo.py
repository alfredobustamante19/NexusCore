#!/usr/bin/env python3
"""Local trial for the seven NexusCore products.

Starts each product on its own port, walks a checkout scenario through all
seven, and serves a console at http://127.0.0.1:7400. Nothing is sent off
this machine. The store link on that page is where the licensed editions live.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

STORE_URL = "https://nexuscore-store.whop.site"
REPO_URL = "https://github.com/alfredobustamante19/NexusCore"
HUB_HOST = "127.0.0.1"
HUB_PORT = 7400
NOTICE = (
    "Looking for the licensed editions of API Proxy Agent, EnvSync Agent, "
    "LogStream Microservice, NexusAdmin Downloads & Docs, NexusCron, "
    "NexusPipeline Package & Setup, and Webhook Router? "
    f"Visit {STORE_URL}"
)

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / ".demo"
DATA = RUNTIME / "data"
LOGS = RUNTIME / "logs"
VENV = RUNTIME / "venv"
HUB_FILE = Path(__file__).resolve().parent / "hub.html"


def log(message: str) -> None:
    print(f"[NexusCore Demo] {message}", flush=True)


def python_version_ok() -> bool:
    return sys.version_info >= (3, 12)


def node_major() -> int | None:
    npm_node = shutil.which("node")
    if not npm_node:
        return None
    try:
        out = subprocess.check_output([npm_node, "-p", "process.versions.node"], text=True)
    except (OSError, subprocess.CalledProcessError):
        return None
    major = out.strip().split(".", 1)[0]
    return int(major) if major.isdigit() else None


def venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def sqlite_url(path: Path) -> str:
    return "sqlite:///" + path.resolve().as_posix()


def port_is_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((HUB_HOST, port))
        except OSError:
            return False
    return True


class TrialState:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.phase = "starting"
        self.detail = "Starting the local trial."
        self.products: list[dict[str, str]] = []
        self.credentials: list[dict[str, str]] = []

    def update(self, **fields: Any) -> None:
        with self._lock:
            for key, value in fields.items():
                setattr(self, key, value)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "phase": self.phase,
                "detail": self.detail,
                "store": STORE_URL,
                "products": [dict(item) for item in self.products],
                "credentials": [dict(item) for item in self.credentials],
            }


STATE = TrialState()


class CatalogHandler(BaseHTTPRequestHandler):
    """Tiny upstream so API Proxy Agent has a healthy service to route."""

    def do_GET(self) -> None:  # noqa: N802
        if self.path.split("?", 1)[0] != "/items":
            self.send_error(404)
            return
        body = json.dumps(
            {"items": [{"sku": "NX-100", "name": "NexusCore seat", "price": 49}]}
        ).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:
        return


class HubHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        path = self.path.split("?", 1)[0]
        if path == "/api/status":
            body = json.dumps(STATE.snapshot()).encode()
            content_type = "application/json"
        elif path in {"/", "/index.html"}:
            body = HUB_FILE.read_bytes()
            content_type = "text/html; charset=utf-8"
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:
        return


def start_background_server(server: ThreadingHTTPServer) -> threading.Thread:
    thread = threading.Thread(target=server.serve_forever, name="nexuscore-demo-http", daemon=True)
    thread.start()
    return thread


class Client:
    def __init__(self) -> None:
        self.cookies: dict[str, str] = {}

    def call(
        self,
        method: str,
        url: str,
        body: Any = None,
        headers: dict[str, str] | None = None,
        timeout: float = 20,
    ) -> tuple[int, dict[str, str], Any]:
        data = None if body is None else json.dumps(body).encode()
        request = urllib.request.Request(url, data=data, method=method)
        merged = {"Accept": "application/json"}
        if body is not None:
            merged["Content-Type"] = "application/json"
        if self.cookies:
            merged["Cookie"] = "; ".join(f"{key}={value}" for key, value in self.cookies.items())
        if headers:
            merged.update(headers)
        for key, value in merged.items():
            request.add_header(key, value)
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read()
                self._store_cookies(response.headers.get_all("Set-Cookie") or [])
                return response.status, {k.lower(): v for k, v in response.headers.items()}, self._parse(raw)
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            self._store_cookies(exc.headers.get_all("Set-Cookie") or [])
            return exc.code, {k.lower(): v for k, v in exc.headers.items()}, self._parse(raw)

    def _store_cookies(self, values: list[str]) -> None:
        for value in values:
            pair = value.split(";", 1)[0]
            if "=" not in pair:
                continue
            key, cookie = pair.split("=", 1)
            self.cookies[key.strip()] = cookie.strip()

    @staticmethod
    def _parse(raw: bytes) -> Any:
        text = raw.decode("utf-8", "replace")
        if not text:
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"raw": text[:500]}


class Service:
    def __init__(self, name: str, folder: str, port: int, summary: str, open_path: str, health_path: str) -> None:
        self.name = name
        self.folder = ROOT / folder
        self.port = port
        self.summary = summary
        self.open_path = open_path
        self.health_path = health_path
        self.process: subprocess.Popen[bytes] | None = None
        self.log_handle: Any = None
        self.state = "wait"
        self.tour = "Waiting for the trial walkthrough."

    @property
    def base(self) -> str:
        return f"http://{HUB_HOST}:{self.port}"

    def card(self) -> dict[str, str]:
        return {
            "name": self.name,
            "summary": self.summary,
            "url": self.base + self.open_path,
            "health": self.base + self.health_path,
            "state": self.state,
            "tour": self.tour,
        }


def products() -> list[Service]:
    return [
        Service(
            "API Proxy Agent",
            "API Proxy Service",
            8080,
            "File-driven gateway with circuit breakers, retries, and a live metrics board.",
            "/nexus-metrics",
            "/nexus-health",
        ),
        Service(
            "EnvSync Agent",
            "EnvSync Agent",
            8787,
            "Encrypted .env sync for projects, revisions, tokens, and an audit log.",
            "/",
            "/api/v1/health",
        ),
        Service(
            "LogStream Microservice",
            "LogStream Microservice",
            8790,
            "JSON log ingestion, search, and a dark operator dashboard.",
            "/",
            "/healthz",
        ),
        Service(
            "NexusAdmin Downloads & Docs",
            "NexusAdmin Downloads & Docs",
            8010,
            "Internal admin console for people, records, audit, and settings.",
            "/",
            "/api/health",
        ),
        Service(
            "NexusCron",
            "NexusCron",
            8020,
            "SQLite-backed cron scheduler with a dashboard and run history.",
            "/",
            "/api/health",
        ),
        Service(
            "NexusPipeline Package & Setup",
            "NexusPipeline Package & Setup",
            8030,
            "Sequential HTTP pipelines with extraction, retries, and a run trace.",
            "/",
            "/api/health",
        ),
        Service(
            "Webhook Router",
            "Webhook Router",
            8040,
            "Authenticated inbound webhooks, stored payloads, and delivery routes.",
            "/docs",
            "/health",
        ),
    ]


def publish(services: list[Service], phase: str, detail: str) -> None:
    STATE.update(phase=phase, detail=detail, products=[item.card() for item in services])
    log(detail)


def tail(path: Path, limit: int = 1800) -> str:
    if not path.is_file():
        return ""
    text = path.read_text(encoding="utf-8", errors="replace")
    return text[-limit:]


def run_checked(args: list[str], cwd: Path, log_path: Path) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as handle:
        completed = subprocess.run(args, cwd=cwd, stdout=handle, stderr=subprocess.STDOUT)
    if completed.returncode != 0:
        raise RuntimeError(f"{' '.join(args)} failed.\n{tail(log_path)}")


def ensure_python(services: list[Service]) -> Path:
    interpreter = venv_python()
    stamp = RUNTIME / "python-deps.stamp"
    sources = [
        ROOT / "NexusAdmin Downloads & Docs" / "requirements.txt",
        ROOT / "NexusCron" / "requirements.txt",
        ROOT / "NexusPipeline Package & Setup" / "requirements.txt",
        ROOT / "Webhook Router" / "requirements.txt",
    ]
    signature = "\n".join(path.read_text(encoding="utf-8") for path in sources)
    if interpreter.is_file() and stamp.is_file() and stamp.read_text(encoding="utf-8") == signature:
        log("Python packages already installed")
        return interpreter
    publish(services, "installing", "Installing Python packages for the four Python products.")
    if not interpreter.is_file():
        run_checked([sys.executable, "-m", "venv", str(VENV)], ROOT, LOGS / "venv.log")
    pip_args = [str(interpreter), "-m", "pip", "install", "--disable-pip-version-check"]
    for path in sources:
        pip_args.extend(["-r", str(path)])
    run_checked(pip_args, ROOT, LOGS / "pip.log")
    stamp.write_text(signature, encoding="utf-8")
    return interpreter


def ensure_node(folder: Path, services: list[Service]) -> None:
    package = json.loads((folder / "package.json").read_text(encoding="utf-8"))
    has_runtime_deps = bool(package.get("dependencies"))
    dist_ready = (folder / "dist" / "index.js").is_file()
    modules_ready = (folder / "node_modules").is_dir()
    npm = shutil.which("npm")
    if npm is None:
        raise RuntimeError("npm was not found on PATH.")
    if has_runtime_deps and not modules_ready:
        publish(services, "installing", f"Installing Node packages in {folder.name}.")
        args = [npm, "ci", "--omit=dev"] if dist_ready else [npm, "ci"]
        run_checked(args, folder, LOGS / f"npm-{folder.name}.log")
        modules_ready = True
    if not dist_ready:
        if not modules_ready:
            publish(services, "installing", f"Installing Node packages in {folder.name}.")
            run_checked([npm, "ci"], folder, LOGS / f"npm-{folder.name}.log")
        publish(services, "installing", f"Building {folder.name}.")
        run_checked([npm, "run", "build"], folder, LOGS / f"build-{folder.name}.log")


def spawn(service: Service, args: list[str], env: dict[str, str]) -> None:
    log_path = LOGS / f"{service.port}.log"
    service.log_handle = log_path.open("w", encoding="utf-8")
    kwargs: dict[str, Any] = {
        "cwd": service.folder,
        "env": env,
        "stdout": service.log_handle,
        "stderr": subprocess.STDOUT,
    }
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs["start_new_session"] = True
    service.process = subprocess.Popen(args, **kwargs)


def wait_healthy(service: Service, timeout: float = 45) -> None:
    deadline = time.time() + timeout
    url = service.base + service.health_path
    last = "no response"
    while time.time() < deadline:
        if service.process and service.process.poll() is not None:
            last = f"process exited {service.process.returncode}"
            break
        try:
            with urllib.request.urlopen(url, timeout=2) as response:
                if 200 <= response.status < 300:
                    service.state = "up"
                    return
                last = f"HTTP {response.status}"
        except (OSError, urllib.error.URLError) as exc:
            last = str(exc)
        time.sleep(0.4)
    service.state = "down"
    service.tour = f"Did not become healthy. {last}. See .demo/logs/{service.port}.log"
    raise TimeoutError(service.tour + "\n" + tail(LOGS / f"{service.port}.log"))


def stop_service(service: Service) -> None:
    process = service.process
    if process is None or process.poll() is not None:
        if service.log_handle:
            service.log_handle.close()
        return
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(process.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        process.terminate()
    try:
        process.wait(timeout=8)
    except subprocess.TimeoutExpired:
        process.kill()
    if service.log_handle:
        service.log_handle.close()


def base_env() -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["NODE_ENV"] = "production"
    return env


def write_proxy_routes() -> Path:
    payload = {
        "routes": [
            {
                "id": "catalog",
                "prefix": "/catalog",
                "target": "http://127.0.0.1:4010",
                "methods": ["GET", "HEAD"],
                "stripPrefix": True,
                "timeoutMs": 800,
                "cacheTtlMs": 5000,
                "fallback": {
                    "statusCode": 503,
                    "body": {
                        "error": "upstream_unavailable",
                        "service": "catalog",
                        "message": "Catalog is temporarily unavailable",
                    },
                },
            },
            {
                "id": "billing",
                "prefix": "/billing",
                "target": "http://127.0.0.1:4019",
                "methods": ["GET", "POST"],
                "stripPrefix": True,
                "timeoutMs": 800,
                "cacheTtlMs": 0,
                "retries": {
                    "maxRetries": 1,
                    "baseDelayMs": 10,
                    "maxDelayMs": 40,
                    "retryOn": [500, 502, 503, 504],
                    "retryUnsafeMethods": False,
                },
                "circuit": {
                    "failureThreshold": 5,
                    "successThreshold": 2,
                    "openDurationMs": 15000,
                    "halfOpenMaxProbes": 1,
                },
                "fallback": {
                    "statusCode": 503,
                    "body": {
                        "error": "upstream_unavailable",
                        "service": "billing",
                        "message": "Billing is temporarily unavailable",
                    },
                },
            },
        ]
    }
    path = RUNTIME / "proxy-routes.json"
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def load_secrets() -> dict[str, str]:
    path = RUNTIME / "trial.json"
    if path.is_file():
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict) and loaded.get("admin_password"):
            return {str(key): str(value) for key, value in loaded.items()}
    import secrets

    generated = {
        "admin_email": "ada@nexuscore.dev",
        "admin_password": "Demo-" + secrets.token_urlsafe(12),
        "envsync_username": "admin",
        "envsync_password": "Demo-" + secrets.token_urlsafe(12),
        "envsync_master_key": secrets.token_hex(32),
        "log_token": secrets.token_urlsafe(32),
        "webhook_admin_token": secrets.token_urlsafe(32),
        "webhook_ingest_secret": secrets.token_urlsafe(24),
        "secret_key": secrets.token_urlsafe(48),
    }
    path.write_text(json.dumps(generated, indent=2), encoding="utf-8")
    return generated


def credential_rows(secrets: dict[str, str]) -> list[dict[str, str]]:
    return [
        {"product": "NexusAdmin Downloads & Docs", "label": "Email", "value": secrets["admin_email"]},
        {"product": "NexusAdmin Downloads & Docs", "label": "Password", "value": secrets["admin_password"]},
        {"product": "EnvSync Agent", "label": "Username", "value": secrets["envsync_username"]},
        {"product": "EnvSync Agent", "label": "Password", "value": secrets["envsync_password"]},
        {"product": "LogStream Microservice", "label": "Bearer token", "value": secrets["log_token"]},
        {"product": "Webhook Router", "label": "Admin bearer token", "value": secrets["webhook_admin_token"]},
        {"product": "Webhook Router", "label": "Inbound hook secret", "value": secrets["webhook_ingest_secret"]},
    ]


def expect(status: int, payload: Any, allowed: set[int], what: str) -> None:
    if status not in allowed:
        raise RuntimeError(f"{what} returned HTTP {status}: {payload}")


def tour(services: dict[str, Service], secrets: dict[str, str]) -> None:
    client = Client()
    proxy = services["API Proxy Agent"]
    status, headers, payload = client.call("GET", proxy.base + "/catalog/items", timeout=10)
    expect(status, payload, {200}, "catalog route")
    if headers.get("x-nexus-route") != "catalog":
        raise RuntimeError(f"catalog route missing x-nexus-route: {headers}")
    status, _, payload = client.call("GET", proxy.base + "/billing/invoices", timeout=15)
    expect(status, payload, {503}, "billing fallback")
    if not isinstance(payload, dict) or payload.get("error") != "upstream_unavailable":
        raise RuntimeError(f"billing fallback body was unexpected: {payload}")
    proxy.tour = "Routed /catalog/items to the local upstream and served the billing fallback when that upstream was down."

    env = services["EnvSync Agent"]
    status, _, payload = client.call(
        "POST",
        env.base + "/api/v1/admin/login",
        {"username": secrets["envsync_username"], "password": secrets["envsync_password"]},
    )
    expect(status, payload, {200}, "EnvSync login")
    status, _, payload = client.call(
        "POST",
        env.base + "/api/v1/projects",
        {"name": "Demo Checkout", "description": "Local trial project"},
        {"X-NexusEnv-Request": "1"},
    )
    if status == 409:
        status, _, payload = client.call("GET", env.base + "/api/v1/projects", headers={"X-NexusEnv-Request": "1"})
        expect(status, payload, {200}, "EnvSync project list")
        projects = payload.get("projects", [])
        match = next((item for item in projects if item.get("name") == "Demo Checkout"), None)
        if match is None:
            raise RuntimeError("EnvSync project conflict did not return Demo Checkout")
        project_id = match["id"]
    else:
        expect(status, payload, {201}, "EnvSync project create")
        project_id = payload["project"]["id"]
    status, _, payload = client.call(
        "POST",
        f"{env.base}/api/v1/projects/{project_id}/secrets",
        {
            "environment": "dev",
            "comment": "trial",
            "secrets": {"WEBHOOK_SECRET": secrets["webhook_ingest_secret"]},
        },
        {"X-NexusEnv-Request": "1"},
    )
    expect(status, payload, {201}, "EnvSync push")
    status, _, payload = client.call(
        "GET",
        f"{env.base}/api/v1/projects/{project_id}/env?environment=dev&format=json",
        headers={"X-NexusEnv-Request": "1"},
    )
    expect(status, payload, {200}, "EnvSync pull")
    pulled = payload.get("secrets", {}).get("WEBHOOK_SECRET")
    if pulled != secrets["webhook_ingest_secret"]:
        raise RuntimeError("EnvSync pull did not return the stored secret")
    env.tour = "Stored WEBHOOK_SECRET with AES-256-GCM and read the same value back."

    logs = services["LogStream Microservice"]
    auth = {"Authorization": f"Bearer {secrets['log_token']}"}
    status, _, payload = client.call(
        "POST",
        logs.base + "/api/v1/log",
        {
            "level": "ERROR",
            "service": "checkout",
            "message": "demo checkout needs review",
            "payload": {"order": "NX-100"},
        },
        auth,
    )
    expect(status, payload, {201}, "LogStream ingest")
    status, _, payload = client.call(
        "GET",
        logs.base + "/api/v1/logs?service=checkout&q=demo%20checkout",
        headers=auth,
    )
    expect(status, payload, {200}, "LogStream query")
    if not payload.get("logs"):
        raise RuntimeError("LogStream query returned no rows")
    logs.tour = "Accepted an error event and returned it from search."

    admin = services["NexusAdmin Downloads & Docs"]
    status, _, payload = client.call("GET", admin.base + "/api/auth/bootstrap")
    expect(status, payload, {200}, "NexusAdmin bootstrap")
    if payload.get("bootstrap_open"):
        status, _, payload = client.call(
            "POST",
            admin.base + "/api/auth/register",
            {"email": secrets["admin_email"], "password": secrets["admin_password"]},
        )
        expect(status, payload, {201}, "NexusAdmin register")
    else:
        status, _, payload = client.call(
            "POST",
            admin.base + "/api/auth/login",
            {"email": secrets["admin_email"], "password": secrets["admin_password"]},
        )
        expect(status, payload, {200}, "NexusAdmin login")
    token = payload.get("access_token")
    if not token:
        raise RuntimeError(f"NexusAdmin did not return an access token: {payload}")
    bearer = {"Authorization": f"Bearer {token}"}
    status, _, payload = client.call("GET", admin.base + "/api/customers?limit=100", headers=bearer)
    expect(status, payload, {200}, "NexusAdmin customers")
    existing = payload.get("items", [])
    if not any(item.get("name") == "Northwind Freight" for item in existing):
        status, _, payload = client.call(
            "POST",
            admin.base + "/api/customers",
            {"name": "Northwind Freight", "status": "active", "value": 12800},
            bearer,
        )
        expect(status, payload, {201}, "NexusAdmin customer")
    admin.tour = "Signed in the first administrator and stored the Northwind Freight record."

    cron = services["NexusCron"]
    status, _, payload = client.call("GET", cron.base + "/api/tasks")
    expect(status, payload, {200}, "NexusCron list")
    tasks = payload if isinstance(payload, list) else payload.get("items", payload.get("tasks", []))
    task = next((item for item in tasks if item.get("name") == "Trial health"), None)
    if task is None:
        status, _, payload = client.call(
            "POST",
            cron.base + "/api/tasks",
            {
                "name": "Trial health",
                "cron_expression": "* * * * *",
                "target_url": logs.base + "/healthz",
                "http_method": "GET",
            },
        )
        expect(status, payload, {201}, "NexusCron create")
        task = payload
    status, _, payload = client.call("POST", f"{cron.base}/api/tasks/{task['id']}/trigger")
    expect(status, payload, {200}, "NexusCron trigger")
    if payload.get("status_code") != 200:
        raise RuntimeError(f"NexusCron trigger did not get HTTP 200: {payload}")
    cron.tour = "Scheduled a health check and ran it on demand against LogStream."

    pipeline = services["NexusPipeline Package & Setup"]
    status, _, payload = client.call("GET", pipeline.base + "/api/pipelines")
    expect(status, payload, {200}, "Pipeline list")
    definition = next((item for item in payload if item.get("name") == "Trial echo chain"), None)
    if definition is None:
        status, _, payload = client.call(
            "POST",
            pipeline.base + "/api/pipelines",
            {
                "name": "Trial echo chain",
                "description": "Create a record, then confirm the extracted id.",
                "is_active": True,
                "steps": [
                    {
                        "id": "create_record",
                        "name": "Create record",
                        "method": "POST",
                        "url": pipeline.base + "/api/echo",
                        "headers": {"Content-Type": "application/json"},
                        "body": {"name": "{{input.name}}", "role": "engineer"},
                        "body_mode": "json",
                        "timeout_seconds": 10,
                        "retries": 1,
                        "retry_backoff_seconds": 0.1,
                        "extract": {"record_id": "id", "name": "received.name"},
                    },
                    {
                        "id": "confirm_record",
                        "name": "Confirm record",
                        "method": "POST",
                        "url": pipeline.base + "/api/echo",
                        "headers": {
                            "Content-Type": "application/json",
                            "X-Record-Id": "{{steps.create_record.extract.record_id}}",
                        },
                        "body": {
                            "parent_id": "{{steps.create_record.extract.record_id}}",
                            "name": "{{steps.create_record.extract.name}}",
                        },
                        "body_mode": "json",
                        "timeout_seconds": 10,
                        "retries": 0,
                        "retry_backoff_seconds": 0.1,
                        "extract": {"confirmation_id": "$.id"},
                    },
                ],
            },
        )
        expect(status, payload, {201}, "Pipeline create")
        definition = payload
    status, _, payload = client.call(
        "POST",
        f"{pipeline.base}/api/pipelines/{definition['id']}/run",
        {"input": {"name": "Ada"}},
    )
    expect(status, payload, {200}, "Pipeline run")
    if payload.get("status") != "success":
        raise RuntimeError(f"Pipeline run status was {payload.get('status')}")
    pipeline.tour = "Ran a two-step echo chain and carried the extracted id into step 2."

    hooks = services["Webhook Router"]
    hook_auth = {"Authorization": f"Bearer {secrets['webhook_admin_token']}"}
    status, _, payload = client.call("GET", hooks.base + "/api/endpoints", headers=hook_auth)
    expect(status, payload, {200}, "Webhook list")
    endpoint = next((item for item in payload if item.get("slug") == "demo-checkout"), None)
    if endpoint is None:
        status, _, payload = client.call(
            "POST",
            hooks.base + "/api/endpoints",
            {
                "name": "Demo checkout",
                "slug": "demo-checkout",
                "description": "Local trial orders",
                "auth_type": "bearer",
                "auth_secret": secrets["webhook_ingest_secret"],
            },
            hook_auth,
        )
        expect(status, payload, {201}, "Webhook create")
    status, _, payload = client.call(
        "POST",
        hooks.base + "/hooks/demo-checkout",
        {"event": "order.created", "sku": "NX-100"},
        {"Authorization": f"Bearer {secrets['webhook_ingest_secret']}"},
    )
    expect(status, payload, {200}, "Webhook ingest")
    hooks.tour = "Accepted an authenticated checkout webhook and stored the payload."


def launch_services(interpreter: Path, services: list[Service], secrets: dict[str, str]) -> None:
    routes = write_proxy_routes()
    by_name = {item.name: item for item in services}
    common = base_env()

    proxy_env = common.copy()
    proxy_env.update(
        {
            "NEXUS_HOST": HUB_HOST,
            "NEXUS_PORT": "8080",
            "NEXUS_CONFIG": str(by_name["API Proxy Agent"].folder / "config.json"),
            "NEXUS_ROUTES": str(routes),
        }
    )
    spawn(by_name["API Proxy Agent"], ["node", "dist/index.js"], proxy_env)

    env_env = common.copy()
    env_env.update(
        {
            "NEXUSENV_MASTER_KEY": secrets["envsync_master_key"],
            "NEXUSENV_ADMIN_PASSWORD": secrets["envsync_password"],
            "NEXUSENV_ADMIN_USERNAME": secrets["envsync_username"],
            "NEXUSENV_HOST": HUB_HOST,
            "NEXUSENV_PORT": "8787",
            "NEXUSENV_DB_PATH": str(DATA / "nexusenv.db"),
            "NEXUSENV_COOKIE_SECURE": "false",
        }
    )
    spawn(by_name["EnvSync Agent"], ["node", "dist/index.js"], env_env)

    log_env = common.copy()
    log_env.update(
        {
            "HOST": HUB_HOST,
            "PORT": "8790",
            "NEXUS_TOKEN": secrets["log_token"],
            "DB_PATH": str(DATA / "nexuslog.sqlite"),
            "COOKIE_SECURE": "false",
            "LOG_LEVEL": "info",
        }
    )
    spawn(
        by_name["LogStream Microservice"],
        ["node", "--max-old-space-size=48", "dist/index.js"],
        log_env,
    )

    py_services = {
        "NexusAdmin Downloads & Docs": (
            ["-m", "uvicorn", "app.main:app", "--host", HUB_HOST, "--port", "8010", "--log-level", "warning"],
            {
                "SECRET_KEY": secrets["secret_key"],
                "DATABASE_URL": sqlite_url(DATA / "atrium.db"),
                "COOKIE_SECURE": "false",
                "AUTO_MIGRATE": "true",
                "DEMO_MODE": "false",
            },
        ),
        "NexusCron": (
            ["-m", "uvicorn", "app.main:app", "--host", HUB_HOST, "--port", "8020", "--log-level", "warning"],
            {"DATABASE_PATH": str(DATA / "scheduler.db")},
        ),
        "NexusPipeline Package & Setup": (
            ["-m", "uvicorn", "app.main:app", "--host", HUB_HOST, "--port", "8030", "--log-level", "warning"],
            {
                "PIPELINE_DATABASE_URL": sqlite_url(DATA / "pipelines.db"),
                "PIPELINE_ENABLE_ECHO": "true",
                "PIPELINE_API_TOKEN": "",
            },
        ),
        "Webhook Router": (
            ["-m", "app.main"],
            {
                "APP_ENV": "production",
                "APP_HOST": HUB_HOST,
                "APP_PORT": "8040",
                "ADMIN_API_TOKEN": secrets["webhook_admin_token"],
                "DATABASE_URL": sqlite_url(DATA / "bridge.db"),
                "LOG_FILE": str(LOGS / "webhook-bridge.log"),
                "ALLOW_INSECURE_HTTP": "true",
            },
        ),
    }
    for name, (args, extra) in py_services.items():
        env = common.copy()
        env.update(extra)
        spawn(by_name[name], [str(interpreter), *args], env)

    for service in services:
        publish(services, "starting", f"Waiting for {service.name}.")
        try:
            wait_healthy(service)
            service.tour = "Process is up. The walkthrough has not reached it yet."
        except (TimeoutError, OSError) as exc:
            service.state = "down"
            service.tour = str(exc).splitlines()[0]
            log(f"{service.name} failed to start. {service.tour}")


def print_banner() -> None:
    """Show the hub, the repo, and the license link while attention is highest."""
    rule = "-" * 56
    lines = [
        rule,
        f"🚀 NexusCore Hub Running at http://localhost:{HUB_PORT}",
        f"⭐ Star the repo: {REPO_URL}",
        "🛒 Get your lifetime license (Code: DEVLAUNCH for 20% off):",
        f"   {STORE_URL}",
        rule,
    ]
    text = "\n".join(lines) + "\n"
    stream = sys.stdout
    if hasattr(stream, "reconfigure"):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            pass
    try:
        stream.write(text)
        stream.flush()
    except UnicodeEncodeError:
        plain = text.replace("🚀 ", "").replace("⭐ ", "").replace("🛒 ", "")
        stream.buffer.write(plain.encode("ascii", "replace"))
        stream.flush()


def main() -> int:
    print_banner()
    if not python_version_ok():
        log("Python 3.12 or newer is required.")
        return 1
    major = node_major()
    if major is None or major < 24:
        log("Node.js 24 or newer is required. EnvSync Agent refuses to run on older Node versions.")
        return 1
    missing = [name for name in (
        "API Proxy Service",
        "EnvSync Agent",
        "LogStream Microservice",
        "NexusAdmin Downloads & Docs",
        "NexusCron",
        "NexusPipeline Package & Setup",
        "Webhook Router",
    ) if not (ROOT / name).is_dir()]
    if missing:
        log("Missing product folders: " + ", ".join(missing))
        return 1
    if not port_is_free(HUB_PORT):
        log(f"Port {HUB_PORT} is already in use.")
        return 1

    DATA.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    services = products()
    busy = [item for item in services if not port_is_free(item.port)]
    if busy or not port_is_free(4010):
        names = ", ".join(f"{item.name} ({item.port})" for item in busy)
        log(f"A trial port is already in use. Close the other process and start again. {names}")
        return 1

    hub = ThreadingHTTPServer((HUB_HOST, HUB_PORT), HubHandler)
    catalog = ThreadingHTTPServer((HUB_HOST, 4010), CatalogHandler)
    start_background_server(hub)
    start_background_server(catalog)
    publish(services, "starting", f"Console ready at http://{HUB_HOST}:{HUB_PORT}")
    webbrowser.open(f"http://{HUB_HOST}:{HUB_PORT}")

    try:
        interpreter = ensure_python(services)
        for folder in ("API Proxy Service", "EnvSync Agent", "LogStream Microservice"):
            ensure_node(ROOT / folder, services)
        secrets = load_secrets()
        STATE.update(credentials=credential_rows(secrets))
        launch_services(interpreter, services, secrets)
        healthy = [item for item in services if item.state == "up"]
        if len(healthy) != len(services):
            publish(services, "degraded", "One or more products did not start. The console lists the working ones.")
        else:
            publish(services, "walking", "All seven processes are up. Running the trial walkthrough.")
            try:
                tour({item.name: item for item in services}, secrets)
                for item in services:
                    item.state = "up"
                publish(
                    services,
                    "ready",
                    "Trial complete. Open any product from the cards. Leave this terminal running.",
                )
            except Exception as exc:
                publish(services, "degraded", f"Walkthrough stopped: {exc}")
                log(str(exc))
        print_banner()
        log("Press Ctrl+C to stop every trial process.")
        while True:
            time.sleep(0.5)
            if any(item.process and item.process.poll() not in {None} and item.state == "up" for item in services):
                for item in services:
                    if item.process and item.process.poll() is not None and item.state == "up":
                        item.state = "down"
                        item.tour = f"Process exited ({item.process.returncode}). See .demo/logs/{item.port}.log"
                publish(services, "degraded", "A product process exited. The others are still running.")
    except KeyboardInterrupt:
        log("Stopping.")
    finally:
        for item in services:
            stop_service(item)
        hub.shutdown()
        catalog.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
